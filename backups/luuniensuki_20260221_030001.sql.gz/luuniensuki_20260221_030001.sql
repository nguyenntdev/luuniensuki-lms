--
-- PostgreSQL database dump
--

\restrict Dva2pG47iBmJohczRRKnaooagqQNuz1vn6d7oe9QiEbjUzScxzu88B4co0diJsG

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: badge_category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.badge_category AS ENUM (
    'quest',
    'achievement',
    'collection',
    'special'
);


ALTER TYPE public.badge_category OWNER TO postgres;

--
-- Name: content_rating; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.content_rating AS ENUM (
    'everyone',
    'teen',
    'mature'
);


ALTER TYPE public.content_rating OWNER TO postgres;

--
-- Name: content_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.content_status AS ENUM (
    'draft',
    'review',
    'published',
    'archived'
);


ALTER TYPE public.content_status OWNER TO postgres;

--
-- Name: email_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.email_status AS ENUM (
    'pending',
    'sent',
    'failed',
    'cancelled'
);


ALTER TYPE public.email_status OWNER TO postgres;

--
-- Name: flag_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.flag_type AS ENUM (
    'boolean',
    'percentage',
    'user_list'
);


ALTER TYPE public.flag_type OWNER TO postgres;

--
-- Name: friend_request_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.friend_request_status AS ENUM (
    'pending',
    'accepted',
    'rejected'
);


ALTER TYPE public.friend_request_status OWNER TO postgres;

--
-- Name: heart_transaction_reason; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.heart_transaction_reason AS ENUM (
    'quiz_wrong',
    'heart_purchase',
    'daily_refill',
    'streak_freeze_used',
    'reward',
    'admin_grant',
    'ad_watch',
    'practice_complete',
    'quiz_hint'
);


ALTER TYPE public.heart_transaction_reason OWNER TO postgres;

--
-- Name: hint_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.hint_type AS ENUM (
    'explain',
    'clue',
    'elimination'
);


ALTER TYPE public.hint_type OWNER TO postgres;

--
-- Name: interaction_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.interaction_type AS ENUM (
    'view',
    'complete',
    'like',
    'save'
);


ALTER TYPE public.interaction_type OWNER TO postgres;

--
-- Name: milestone_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.milestone_type AS ENUM (
    'first_motif_discovered',
    'first_quiz_passed',
    'first_lesson_completed',
    'first_badge_earned',
    'first_streak_7',
    'onboarding_completed'
);


ALTER TYPE public.milestone_type OWNER TO postgres;

--
-- Name: mission_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.mission_type AS ENUM (
    'lesson',
    'quiz',
    'discovery',
    'streak'
);


ALTER TYPE public.mission_type OWNER TO postgres;

--
-- Name: motif_category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.motif_category AS ENUM (
    'linh_thu',
    'dong_vat',
    'thao_moc',
    'dia_ly',
    'nong_nghiep',
    'vo_bi',
    'giao_thuong',
    'thien_van',
    'kien_truc'
);


ALTER TYPE public.motif_category OWNER TO postgres;

--
-- Name: motif_rarity; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.motif_rarity AS ENUM (
    'common',
    'uncommon',
    'rare',
    'epic',
    'legendary'
);


ALTER TYPE public.motif_rarity OWNER TO postgres;

--
-- Name: quest_category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.quest_category AS ENUM (
    'exploration',
    'mastery',
    'quiz_champion',
    'streak_master'
);


ALTER TYPE public.quest_category OWNER TO postgres;

--
-- Name: question_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.question_type AS ENUM (
    'multiple_choice',
    'true_false',
    'image_select',
    'mesh_location'
);


ALTER TYPE public.question_type OWNER TO postgres;

--
-- Name: share_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.share_type AS ENUM (
    'achievement',
    'badge',
    'streak',
    'level_up',
    'certificate'
);


ALTER TYPE public.share_type OWNER TO postgres;

--
-- Name: share_visibility; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.share_visibility AS ENUM (
    'public',
    'followers',
    'private'
);


ALTER TYPE public.share_visibility OWNER TO postgres;

--
-- Name: unlock_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.unlock_status AS ENUM (
    'hidden',
    'discovered',
    'learned',
    'mastered'
);


ALTER TYPE public.unlock_status OWNER TO postgres;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_role AS ENUM (
    'guest',
    'learner',
    'teacher',
    'admin',
    'super_admin'
);


ALTER TYPE public.user_role OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: abuse_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.abuse_reports (
    id uuid NOT NULL,
    reporter_id uuid NOT NULL,
    reported_user_id uuid,
    content_type character varying(50) NOT NULL,
    content_id uuid,
    reason character varying(50) NOT NULL,
    description text NOT NULL,
    evidence_urls jsonb,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'low'::character varying NOT NULL,
    assigned_to_id uuid,
    resolution_notes text,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.abuse_reports OWNER TO postgres;

--
-- Name: ai_conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_conversations (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255),
    context_type character varying(50),
    context_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    message_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_conversations OWNER TO postgres;

--
-- Name: ai_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_jobs (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    job_type character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    provider character varying(50),
    prompt text,
    response text,
    error text,
    retry_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_jobs OWNER TO postgres;

--
-- Name: ai_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_messages (
    id uuid NOT NULL,
    conversation_id uuid NOT NULL,
    role character varying(20) NOT NULL,
    content text NOT NULL,
    tokens_used integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_messages OWNER TO postgres;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(64) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: analytics_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_events (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    event_name character varying(100) NOT NULL,
    path character varying(255),
    payload jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    session_id uuid,
    cohort character varying(50),
    event_category character varying(50),
    device_info jsonb
);


ALTER TABLE public.analytics_events OWNER TO postgres;

--
-- Name: app_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_versions (
    id uuid NOT NULL,
    platform character varying(20) NOT NULL,
    version character varying(20) NOT NULL,
    version_code integer NOT NULL,
    min_required_version character varying(20) NOT NULL,
    is_current boolean DEFAULT false NOT NULL,
    force_update boolean DEFAULT false NOT NULL,
    release_notes text,
    download_url character varying(500),
    released_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.app_versions OWNER TO postgres;

--
-- Name: assignment_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assignment_progress (
    id uuid NOT NULL,
    assignment_id uuid NOT NULL,
    user_id uuid NOT NULL,
    status character varying(20) DEFAULT 'assigned'::character varying NOT NULL,
    completed_at timestamp with time zone
);


ALTER TABLE public.assignment_progress OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    user_id uuid,
    action character varying(50) NOT NULL,
    resource_type character varying(50) NOT NULL,
    resource_id uuid,
    old_value jsonb,
    new_value jsonb,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: badges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.badges (
    id uuid NOT NULL,
    slug character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    name_en character varying(255),
    description text,
    icon_url text NOT NULL,
    category public.badge_category NOT NULL,
    xp_bonus integer DEFAULT 0 NOT NULL,
    unlock_criteria jsonb NOT NULL,
    is_secret boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    tier character varying(20) DEFAULT 'bronze'::character varying,
    tier_xp_bonus integer DEFAULT 0
);


ALTER TABLE public.badges OWNER TO postgres;

--
-- Name: certificates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.certificates (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    code character varying(64) NOT NULL,
    issuer_name character varying(255) NOT NULL,
    reason_type character varying(50) NOT NULL,
    reason_id uuid NOT NULL,
    status character varying(20) DEFAULT 'issued'::character varying NOT NULL,
    issued_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.certificates OWNER TO postgres;

--
-- Name: class_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.class_members (
    id uuid NOT NULL,
    class_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role character varying(20) DEFAULT 'learner'::character varying NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.class_members OWNER TO postgres;

--
-- Name: classes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.classes (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    teacher_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    class_code character varying(8) NOT NULL,
    max_students integer,
    is_archived boolean DEFAULT false NOT NULL,
    settings jsonb,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.classes OWNER TO postgres;

--
-- Name: content_flags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.content_flags (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    content_type character varying(50) NOT NULL,
    content_id uuid NOT NULL,
    reason character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.content_flags OWNER TO postgres;

--
-- Name: content_provenance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.content_provenance (
    id uuid NOT NULL,
    content_type character varying(50) NOT NULL,
    content_id uuid NOT NULL,
    provider character varying(50),
    model character varying(100),
    generated_at timestamp with time zone,
    metadata jsonb
);


ALTER TABLE public.content_provenance OWNER TO postgres;

--
-- Name: content_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.content_tags (
    id uuid NOT NULL,
    tag_id uuid NOT NULL,
    content_type character varying(50) NOT NULL,
    content_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.content_tags OWNER TO postgres;

--
-- Name: content_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.content_versions (
    id uuid NOT NULL,
    content_type character varying(50) NOT NULL,
    content_id uuid NOT NULL,
    version integer NOT NULL,
    data jsonb NOT NULL,
    editor_id uuid,
    change_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.content_versions OWNER TO postgres;

--
-- Name: crash_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crash_reports (
    id uuid NOT NULL,
    user_id uuid,
    session_id uuid,
    error_type character varying(20) NOT NULL,
    error_message text NOT NULL,
    stack_trace text,
    platform character varying(20) NOT NULL,
    app_version character varying(20) NOT NULL,
    device_model character varying(100),
    os_version character varying(50),
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    is_resolved boolean DEFAULT false NOT NULL,
    resolved_by_id uuid,
    resolved_at timestamp with time zone
);


ALTER TABLE public.crash_reports OWNER TO postgres;

--
-- Name: daily_missions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.daily_missions (
    id uuid NOT NULL,
    slug character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    mission_type public.mission_type NOT NULL,
    target_count integer DEFAULT 1 NOT NULL,
    xp_reward integer DEFAULT 50 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.daily_missions OWNER TO postgres;

--
-- Name: email_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_templates (
    id uuid NOT NULL,
    key character varying(100) NOT NULL,
    name character varying(200) NOT NULL,
    subject_template character varying(500) NOT NULL,
    body_html text NOT NULL,
    body_text text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.email_templates OWNER TO postgres;

--
-- Name: embedding_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.embedding_jobs (
    id uuid NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    total_documents integer DEFAULT 0 NOT NULL,
    processed_documents integer DEFAULT 0 NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    created_by_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.embedding_jobs OWNER TO postgres;

--
-- Name: experiment_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.experiment_events (
    id uuid NOT NULL,
    experiment_id uuid NOT NULL,
    user_id uuid NOT NULL,
    assignment_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    event_name character varying(100) NOT NULL,
    event_value double precision,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.experiment_events OWNER TO postgres;

--
-- Name: experiment_metric_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.experiment_metric_events (
    id uuid NOT NULL,
    experiment_id uuid NOT NULL,
    user_id uuid NOT NULL,
    variant character varying(100) NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_value double precision NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.experiment_metric_events OWNER TO postgres;

--
-- Name: experiments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.experiments (
    id uuid NOT NULL,
    key character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    variants jsonb NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by_id uuid,
    target_audience jsonb
);


ALTER TABLE public.experiments OWNER TO postgres;

--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_flags (
    id uuid NOT NULL,
    key character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_enabled boolean DEFAULT false NOT NULL,
    rollout_percentage integer DEFAULT 0 NOT NULL,
    user_whitelist jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_blacklist jsonb,
    rules jsonb,
    created_by_id uuid,
    CONSTRAINT check_rollout_percentage_range CHECK (((rollout_percentage >= 0) AND (rollout_percentage <= 100)))
);


ALTER TABLE public.feature_flags OWNER TO postgres;

--
-- Name: friend_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.friend_requests (
    id uuid NOT NULL,
    from_user_id uuid NOT NULL,
    to_user_id uuid NOT NULL,
    status public.friend_request_status DEFAULT 'pending'::public.friend_request_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    responded_at timestamp with time zone
);


ALTER TABLE public.friend_requests OWNER TO postgres;

--
-- Name: guest_previews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.guest_previews (
    id uuid NOT NULL,
    session_id character varying(255) NOT NULL,
    preview_lesson_id uuid,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    converted_to_user_id uuid,
    device_info jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.guest_previews OWNER TO postgres;

--
-- Name: heart_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.heart_transactions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    user_hearts_id uuid NOT NULL,
    amount integer NOT NULL,
    reason public.heart_transaction_reason NOT NULL,
    balance_after integer NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.heart_transactions OWNER TO postgres;

--
-- Name: lesson_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lesson_cache (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    lesson_id uuid NOT NULL,
    cached_at timestamp with time zone DEFAULT now() NOT NULL,
    cache_version integer DEFAULT 1 NOT NULL,
    file_size_bytes integer DEFAULT 0 NOT NULL,
    is_valid boolean DEFAULT true NOT NULL,
    expires_at timestamp with time zone
);


ALTER TABLE public.lesson_cache OWNER TO postgres;

--
-- Name: lesson_content; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lesson_content (
    id uuid NOT NULL,
    motif_id uuid NOT NULL,
    intro_text text,
    description text NOT NULL,
    historical_context text,
    symbolism text,
    fun_fact text,
    audio_narration_url text,
    additional_images jsonb,
    video_url text,
    is_published boolean DEFAULT true NOT NULL,
    is_ai_generated boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    status public.content_status DEFAULT 'draft'::public.content_status NOT NULL,
    submitted_for_review_at timestamp with time zone,
    reviewed_by_id uuid,
    reviewed_at timestamp with time zone,
    review_notes text,
    content_rating public.content_rating DEFAULT 'everyone'::public.content_rating NOT NULL,
    preview_eligible boolean DEFAULT false NOT NULL,
    difficulty_level integer,
    estimated_time_minutes integer,
    version integer DEFAULT 1 NOT NULL,
    last_editor_id uuid,
    published_at timestamp with time zone,
    publish_note text
);


ALTER TABLE public.lesson_content OWNER TO postgres;

--
-- Name: lesson_prerequisites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lesson_prerequisites (
    id uuid NOT NULL,
    lesson_id uuid NOT NULL,
    prerequisite_lesson_id uuid NOT NULL,
    is_strict boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lesson_prerequisites OWNER TO postgres;

--
-- Name: motifs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.motifs (
    id uuid NOT NULL,
    urn_id uuid NOT NULL,
    mesh_name character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    name_en character varying(255),
    category public.motif_category NOT NULL,
    rarity public.motif_rarity DEFAULT 'common'::public.motif_rarity NOT NULL,
    pos_x double precision NOT NULL,
    pos_y double precision NOT NULL,
    pos_z double precision NOT NULL,
    bounding_radius double precision NOT NULL,
    cam_pos_x double precision,
    cam_pos_y double precision,
    cam_pos_z double precision,
    cam_look_at_x double precision,
    cam_look_at_y double precision,
    cam_look_at_z double precision,
    thumbnail_url text,
    silhouette_url text,
    is_demo boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    content_rating public.content_rating DEFAULT 'everyone'::public.content_rating NOT NULL
);


ALTER TABLE public.motifs OWNER TO postgres;

--
-- Name: push_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.push_notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    body text NOT NULL,
    notification_type character varying(50) NOT NULL,
    data_payload jsonb,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    scheduled_for timestamp with time zone,
    sent_at timestamp with time zone,
    delivered_at timestamp with time zone,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.push_notifications OWNER TO postgres;

--
-- Name: quest_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quest_assignments (
    id uuid NOT NULL,
    class_id uuid NOT NULL,
    quest_id uuid NOT NULL,
    assigned_by_id uuid,
    due_at timestamp with time zone,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL,
    points_override integer,
    notes text
);


ALTER TABLE public.quest_assignments OWNER TO postgres;

--
-- Name: quest_objectives; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quest_objectives (
    id uuid NOT NULL,
    quest_step_id uuid NOT NULL,
    objective_type character varying(50) NOT NULL,
    target_value integer DEFAULT 1 NOT NULL,
    params jsonb,
    display_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.quest_objectives OWNER TO postgres;

--
-- Name: quest_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quest_progress (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    quest_id uuid NOT NULL,
    status character varying(20) DEFAULT 'in_progress'::character varying NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


ALTER TABLE public.quest_progress OWNER TO postgres;

--
-- Name: quest_rewards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quest_rewards (
    id uuid NOT NULL,
    quest_id uuid NOT NULL,
    reward_type character varying(50) NOT NULL,
    amount integer,
    badge_slug character varying(100),
    metadata jsonb
);


ALTER TABLE public.quest_rewards OWNER TO postgres;

--
-- Name: quest_steps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quest_steps (
    id uuid NOT NULL,
    quest_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quest_steps OWNER TO postgres;

--
-- Name: quests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quests (
    id uuid NOT NULL,
    slug character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    category character varying(50),
    display_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    prerequisite_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    content_rating public.content_rating DEFAULT 'everyone'::public.content_rating NOT NULL
);


ALTER TABLE public.quests OWNER TO postgres;

--
-- Name: quiz_attempts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_attempts (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    motif_id uuid NOT NULL,
    score integer NOT NULL,
    max_score integer NOT NULL,
    percentage integer NOT NULL,
    answers jsonb NOT NULL,
    time_taken_seconds integer,
    completed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quiz_attempts OWNER TO postgres;

--
-- Name: quiz_hint_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_hint_requests (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    question_id uuid NOT NULL,
    hint_type character varying(20) NOT NULL,
    hint_text text NOT NULL,
    heart_cost integer DEFAULT 0 NOT NULL,
    rag_sources jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quiz_hint_requests OWNER TO postgres;

--
-- Name: quiz_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_questions (
    id uuid NOT NULL,
    motif_id uuid NOT NULL,
    urn_id uuid,
    question_type public.question_type NOT NULL,
    question_text text NOT NULL,
    options jsonb,
    correct_answer character varying(255) NOT NULL,
    target_mesh_name character varying(100),
    difficulty integer DEFAULT 1 NOT NULL,
    explanation text,
    is_published boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    status public.content_status DEFAULT 'draft'::public.content_status NOT NULL,
    submitted_for_review_at timestamp with time zone,
    reviewed_by_id uuid,
    reviewed_at timestamp with time zone,
    review_notes text,
    created_by_id uuid,
    skill_type character varying(50)
);


ALTER TABLE public.quiz_questions OWNER TO postgres;

--
-- Name: rag_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rag_documents (
    id uuid NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    source_type character varying(30) DEFAULT 'manual'::character varying NOT NULL,
    source_path character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    embedding jsonb,
    embedding_model character varying(100),
    embedding_updated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rag_documents OWNER TO postgres;

--
-- Name: rag_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rag_settings (
    id uuid NOT NULL,
    system_instruction text,
    prompt_prefix text,
    model_override character varying(100),
    temperature double precision,
    max_documents integer DEFAULT 6 NOT NULL,
    embedding_enabled boolean DEFAULT true NOT NULL,
    hybrid_alpha double precision DEFAULT 0.6 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rag_settings OWNER TO postgres;

--
-- Name: recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recommendations (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    source character varying(20) NOT NULL,
    items jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.recommendations OWNER TO postgres;

--
-- Name: scheduled_emails; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scheduled_emails (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    template_id uuid NOT NULL,
    scheduled_for timestamp with time zone NOT NULL,
    status public.email_status DEFAULT 'pending'::public.email_status NOT NULL,
    context_data jsonb,
    sent_at timestamp with time zone,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scheduled_emails OWNER TO postgres;

--
-- Name: spaced_repetition_cards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.spaced_repetition_cards (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    motif_id uuid NOT NULL,
    ease_factor double precision DEFAULT 2.5 NOT NULL,
    interval_days integer DEFAULT 0 NOT NULL,
    repetitions integer DEFAULT 0 NOT NULL,
    next_review_at timestamp with time zone DEFAULT now() NOT NULL,
    last_reviewed_at timestamp with time zone,
    review_history jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.spaced_repetition_cards OWNER TO postgres;

--
-- Name: streak_rewards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.streak_rewards (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    streak_day integer NOT NULL,
    reward_type character varying(50) NOT NULL,
    reward_amount integer DEFAULT 0 NOT NULL,
    awarded_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.streak_rewards OWNER TO postgres;

--
-- Name: student_progress_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_progress_snapshots (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    classroom_id uuid NOT NULL,
    snapshot_date date NOT NULL,
    lessons_completed integer DEFAULT 0 NOT NULL,
    quizzes_passed integer DEFAULT 0 NOT NULL,
    average_quiz_score double precision DEFAULT '0'::double precision NOT NULL,
    motifs_discovered integer DEFAULT 0 NOT NULL,
    current_streak integer DEFAULT 0 NOT NULL,
    xp_earned integer DEFAULT 0 NOT NULL,
    time_spent_minutes integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.student_progress_snapshots OWNER TO postgres;

--
-- Name: tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tags (
    id uuid NOT NULL,
    slug character varying(100) NOT NULL,
    name character varying(200) NOT NULL,
    tag_type character varying(50) NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tags OWNER TO postgres;

--
-- Name: urn_exam_attempts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.urn_exam_attempts (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    urn_exam_id uuid NOT NULL,
    score integer NOT NULL,
    passed boolean NOT NULL,
    time_taken integer,
    answers jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.urn_exam_attempts OWNER TO postgres;

--
-- Name: urn_exams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.urn_exams (
    id uuid NOT NULL,
    urn_id uuid NOT NULL,
    questions jsonb NOT NULL,
    passing_score integer DEFAULT 80 NOT NULL,
    xp_reward integer DEFAULT 100 NOT NULL
);


ALTER TABLE public.urn_exams OWNER TO postgres;

--
-- Name: urns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.urns (
    id uuid NOT NULL,
    slug character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    name_han character varying(50),
    represents character varying(255),
    description text,
    model_url text NOT NULL,
    thumbnail_url text,
    display_order integer NOT NULL,
    is_demo boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.urns OWNER TO postgres;

--
-- Name: user_badges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_badges (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    badge_id uuid NOT NULL,
    earned_at timestamp with time zone DEFAULT now() NOT NULL,
    current_tier character varying(20) DEFAULT 'bronze'::character varying
);


ALTER TABLE public.user_badges OWNER TO postgres;

--
-- Name: user_content_interactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_content_interactions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    content_type character varying(50) NOT NULL,
    content_id uuid NOT NULL,
    interaction_type public.interaction_type NOT NULL,
    duration_seconds integer,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_content_interactions OWNER TO postgres;

--
-- Name: user_daily_missions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_daily_missions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    mission_id uuid NOT NULL,
    mission_date timestamp without time zone NOT NULL,
    current_count integer DEFAULT 0 NOT NULL,
    is_completed boolean DEFAULT false NOT NULL,
    completed_at timestamp with time zone,
    xp_awarded integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_daily_missions OWNER TO postgres;

--
-- Name: user_experiment_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_experiment_assignments (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    experiment_id uuid NOT NULL,
    variant_key character varying(100) NOT NULL,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_experiment_assignments OWNER TO postgres;

--
-- Name: user_follows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_follows (
    id uuid NOT NULL,
    follower_id uuid NOT NULL,
    following_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_user_follows_no_self_follow CHECK ((follower_id <> following_id))
);


ALTER TABLE public.user_follows OWNER TO postgres;

--
-- Name: user_hearts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_hearts (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    current_hearts integer DEFAULT 5 NOT NULL,
    max_hearts integer DEFAULT 5 NOT NULL,
    last_heart_lost_at timestamp with time zone,
    hearts_refill_at timestamp with time zone,
    unlimited_until timestamp with time zone,
    streak_freezes integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_hearts OWNER TO postgres;

--
-- Name: user_leaderboard_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_leaderboard_settings (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    show_on_global boolean DEFAULT true NOT NULL,
    show_real_name boolean DEFAULT false NOT NULL,
    preferred_leaderboard character varying(20) DEFAULT 'global'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_leaderboard_settings OWNER TO postgres;

--
-- Name: user_learning_paths; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_learning_paths (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    path_date timestamp with time zone NOT NULL,
    recommended_lessons jsonb DEFAULT '[]'::jsonb NOT NULL,
    recommended_reviews jsonb DEFAULT '[]'::jsonb NOT NULL,
    recommended_quizzes jsonb DEFAULT '[]'::jsonb NOT NULL,
    estimated_time_minutes integer DEFAULT 0 NOT NULL,
    completed_items jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_completed boolean DEFAULT false NOT NULL,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


ALTER TABLE public.user_learning_paths OWNER TO postgres;

--
-- Name: user_milestones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_milestones (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    milestone_type public.milestone_type NOT NULL,
    achieved_at timestamp with time zone DEFAULT now() NOT NULL,
    context_data jsonb,
    celebrated boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_milestones OWNER TO postgres;

--
-- Name: user_notification_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_notification_settings (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    push_enabled boolean DEFAULT false NOT NULL,
    push_token text,
    push_platform character varying(20),
    email_enabled boolean DEFAULT true NOT NULL,
    streak_reminders boolean DEFAULT true NOT NULL,
    daily_mission_reminders boolean DEFAULT true NOT NULL,
    weekly_digest boolean DEFAULT true NOT NULL,
    marketing_enabled boolean DEFAULT false NOT NULL,
    quiet_hours_start integer,
    quiet_hours_end integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_notification_settings OWNER TO postgres;

--
-- Name: user_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_progress (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    motif_id uuid NOT NULL,
    status public.unlock_status DEFAULT 'hidden'::public.unlock_status NOT NULL,
    discovered_at timestamp with time zone,
    lesson_viewed_at timestamp with time zone,
    learned_at timestamp with time zone,
    mastered_at timestamp with time zone,
    quiz_attempts integer DEFAULT 0 NOT NULL,
    quiz_best_score integer DEFAULT 0 NOT NULL,
    xp_earned integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    ease_factor double precision DEFAULT 2.5,
    interval_days integer DEFAULT 0,
    repetitions integer DEFAULT 0,
    next_review_at timestamp with time zone,
    last_reviewed_at timestamp with time zone,
    review_history jsonb DEFAULT '[]'::jsonb
);


ALTER TABLE public.user_progress OWNER TO postgres;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sessions (
    id uuid NOT NULL,
    user_id uuid,
    session_id uuid NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    last_active_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    device_type character varying(20) NOT NULL,
    platform character varying(20) NOT NULL,
    app_version character varying(20),
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.user_sessions OWNER TO postgres;

--
-- Name: user_shares; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_shares (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    share_type character varying(50) NOT NULL,
    content_id uuid,
    caption text,
    visibility character varying(20) DEFAULT 'public'::character varying NOT NULL,
    share_url character varying(255),
    view_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_shares OWNER TO postgres;

--
-- Name: user_skill_levels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_skill_levels (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    skill_type character varying(50) NOT NULL,
    skill_level double precision DEFAULT 0.5 NOT NULL,
    total_questions integer DEFAULT 0 NOT NULL,
    correct_answers integer DEFAULT 0 NOT NULL,
    last_updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_skill_levels OWNER TO postgres;

--
-- Name: user_weekly_quests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_weekly_quests (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    quest_id uuid NOT NULL,
    week_start_date timestamp without time zone NOT NULL,
    current_count integer DEFAULT 0 NOT NULL,
    is_completed boolean DEFAULT false NOT NULL,
    completed_at timestamp with time zone,
    xp_awarded integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_weekly_quests OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(100) NOT NULL,
    avatar_url text,
    bio text,
    username character varying(50),
    starting_urn_id uuid,
    is_profile_public boolean DEFAULT true NOT NULL,
    ai_personalization_enabled boolean DEFAULT true NOT NULL,
    role public.user_role DEFAULT 'learner'::public.user_role NOT NULL,
    total_xp integer DEFAULT 0 NOT NULL,
    current_streak integer DEFAULT 0 NOT NULL,
    longest_streak integer DEFAULT 0 NOT NULL,
    streak_freezes integer DEFAULT 0 NOT NULL,
    last_active_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    birth_year integer,
    age_verified boolean DEFAULT false NOT NULL,
    age_verified_at timestamp with time zone,
    push_permission_prompted boolean DEFAULT false NOT NULL,
    onboarding_goal character varying(50),
    onboarding_completed boolean DEFAULT false NOT NULL,
    onboarding_completed_at timestamp with time zone,
    xp_boost_active boolean DEFAULT false,
    xp_boost_expires_at timestamp without time zone,
    xp_boost_multiplier double precision DEFAULT 1.0
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: weekly_quests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.weekly_quests (
    id uuid NOT NULL,
    slug character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    category public.quest_category NOT NULL,
    week_number integer,
    year integer,
    target_count integer DEFAULT 1 NOT NULL,
    xp_reward integer DEFAULT 100 NOT NULL,
    badge_slug character varying(100),
    is_recurring boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.weekly_quests OWNER TO postgres;

--
-- Data for Name: abuse_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.abuse_reports (id, reporter_id, reported_user_id, content_type, content_id, reason, description, evidence_urls, status, priority, assigned_to_id, resolution_notes, resolved_at, created_at) FROM stdin;
\.


--
-- Data for Name: ai_conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_conversations (id, user_id, title, context_type, context_id, is_active, message_count, created_at, updated_at) FROM stdin;
bf1a2eb2-58ae-4142-9ef8-cdba795e5764	1df31222-3934-471c-8624-a87034fd017d	Cuộc hội thoại mới	\N	\N	t	0	2026-02-12 03:19:42.937434+00	2026-02-12 03:19:42.937434+00
\.


--
-- Data for Name: ai_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_jobs (id, user_id, job_type, status, provider, prompt, response, error, retry_count, created_at, updated_at) FROM stdin;
84144c84-1bad-4d07-8811-bb1b84be2e67	1df31222-3934-471c-8624-a87034fd017d	diagnostic	failed	deepseek	diagnostic quiz	\N	The read operation timed out	0	2026-01-15 13:57:07.432832+00	2026-01-15 13:57:07.454106+00
de690b97-e51f-4a6d-aca5-09f36470bfa6	1df31222-3934-471c-8624-a87034fd017d	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: cửu đỉnh là gì?\nTrả lời:	Cửu Đỉnh là 9 chiếc đỉnh bằng đồng lớn, được vua Minh Mạng cho đúc từ năm 1835-1837 và đặt ở Hoàng thành Huế [S1].  \n\nMỗi đỉnh tượng trưng cho một vị vua triều Nguyễn, đồng thời khắc họa hình ảnh về núi sông, động thực vật và văn hóa Việt Nam. Chúng vừa thể hiện quyền lực nhà Nguyễn, vừa như một "bách khoa toàn thư" bằng hình ảnh về đất nước thế kỷ 19 [S1].  \n\nVí dụ: Trên đỉnh Cao Đỉnh (tượng trưng vua Gia Long) có khắc hình sông Hương, núi Ngự Bình - biểu tượng của Huế.	\N	0	2026-01-15 14:24:09.006452+00	2026-01-15 14:24:09.021291+00
e0ccdd2e-d5dc-4592-aef6-eaa9257e00b8	1df31222-3934-471c-8624-a87034fd017d	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: chín đỉnh đồng đạưt ở đâu\nTrả lời:	Chín đỉnh đồng (Cửu Đỉnh) hiện được đặt tại **sân Thế Miếu** trong **Hoàng thành Huế**, tỉnh Thừa Thiên Huế, Việt Nam.  \n\n- **Vị trí cụ thể**: Trước mặt Thế Miếu (nơi thờ các vua Nguyễn), xếp thành một hàng ngang.  \n- **Đặc điểm**: Mỗi đỉnh tượng trưng cho một vị vua triều Nguyễn, khắc họa hình ảnh thiên nhiên, văn hóa Việt Nam [S1].  \n\n*Ví dụ*: Du khách tham quan Huế có thể dễ dàng chiêm ngưỡng Cửu Đỉnh khi đến khu vực Đại Nội.  \n\nNguồn: [S1]	\N	0	2026-01-15 14:31:41.171253+00	2026-01-15 14:31:41.185976+00
c30f056f-c508-441a-9ec6-bfaa3b1e6931	1df31222-3934-471c-8624-a87034fd017d	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: alo\nTrả lời:	Xin lỗi, tôi không hiểu câu hỏi của bạn. Bạn có thể hỏi rõ hơn về Cửu Đỉnh hoặc lịch sử Việt Nam không?  \n\nVí dụ:  \n- "Cửu Đỉnh là gì?" → Là 9 đỉnh đồng lớn ở Huế, do vua Minh Mạng cho đúc, khắc hình ảnh về thiên nhiên, văn hóa Việt Nam [S1].  \n- "Cửu Đỉnh có ý nghĩa gì?" → Biểu tượng quyền lực triều Nguyễn và như một cuốn sách bằng đồng về đất nước.  \n\nBạn muốn biết điều gì cụ thể? 😊	\N	0	2026-01-15 14:46:23.86515+00	2026-01-15 14:46:23.871652+00
8964acd7-beb4-4937-bf15-d9bff3ea71f7	1df31222-3934-471c-8624-a87034fd017d	coach	succeeded	deepseek	{"goal": null, "availability_minutes_per_day": 15, "days_per_week": 5, "stats": {"total_xp": 1000, "current_streak": 1, "progress": {"discovered": 5, "learned": 1, "mastered": 1}}, "format": {"message": "string", "weekly_plan": ["string"]}}	Dưới đây là JSON response theo yêu cầu của bạn:\n\n```json\n{\n  "goal": null,\n  "availability_minutes_per_day": 15,\n  "days_per_week": 5,\n  "stats": {\n    "total_xp": 1000,\n    "current_streak": 1,\n    "progress": {\n      "discovered": 5,\n      "learned": 1,\n      "mastered": 1\n    }\n  },\n  "format": {\n    "message": "string",\n    "weekly_plan": ["string"]\n  }\n}\n```\n\nGiải thích các trường:\n- `goal`: Mục tiêu học tập (hiện chưa thiết lập)\n- `availability_minutes_per_day`: 15 phút mỗi ngày\n- `days_per_week`: 5 ngày/tuần\n- `stats`: Thống kê tiến độ\n  - `total_xp`: 1000 điểm kinh nghiệm\n  - `current_streak`: Chuỗi ngày học liên tiếp hiện tại là 1\n  - `progress`: Tiến độ học tập\n    - `discovered`: 5 nội dung đã khám phá\n    - `learned`: 1 nội dung đã học\n    - `mastered`: 1 nội dung đã thành thạo\n- `format`: Định dạng thông báo\n  - `message`: Chuỗi thông báo\n  - `weekly_plan`: Kế hoạch tuần (dạng mảng chuỗi)	\N	0	2026-01-15 14:49:16.362525+00	2026-01-15 14:49:16.37232+00
9a9d409e-0ba9-462e-b897-a090d5fdf6e2	1df31222-3934-471c-8624-a87034fd017d	explain	failed	deepseek	{"text": "motifs chữ hán cao đỉnh", "level": "expert", "format": {"explanation": "string"}}	\N	The read operation timed out	0	2026-01-15 14:49:58.600098+00	2026-01-15 14:49:58.607715+00
9262d80f-3e94-4dfe-bf58-29b7bf3cec6c	1df31222-3934-471c-8624-a87034fd017d	coach	succeeded	deepseek	{"goal": null, "availability_minutes_per_day": 15, "days_per_week": 5, "stats": {"total_xp": 1000, "current_streak": 1, "progress": {"discovered": 5, "learned": 1, "mastered": 1}}, "format": {"message": "string", "weekly_plan": ["string"]}}	```json\n{\n  "goal": "Master the content of Cửu Đỉnh",\n  "availability_minutes_per_day": 15,\n  "days_per_week": 5,\n  "stats": {\n    "total_xp": 1000,\n    "current_streak": 1,\n    "progress": {\n      "discovered": 5,\n      "learned": 1,\n      "mastered": 1\n    }\n  },\n  "format": {\n    "message": "Let's make steady progress on mastering Cửu Đỉnh! With just 15 minutes a day, you can build a strong foundation.",\n    "weekly_plan": [\n      "Day 1: Review the 5 discovered items, focusing on understanding their significance.",\n      "Day 2: Deepen your knowledge of the 1 learned item with additional research or practice.",\n      "Day 3: Test your mastery of the 1 mastered item by teaching it to someone else.",\n      "Day 4: Discover 1 new item related to Cửu Đỉnh and take notes.",\n      "Day 5: Review all progress and plan for the next week's learning goals."\n    ]\n  }\n}\n```	\N	0	2026-01-15 14:50:54.53327+00	2026-01-15 14:50:54.547706+00
730fef3b-4e2e-47e5-bf2f-5d9d04a34b76	1df31222-3934-471c-8624-a87034fd017d	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: Cửu Đỉnh nằm ở đâu\nTrả lời:	Cửu Đỉnh nằm trong **Hoàng thành Huế** (cố đô Huế, tỉnh Thừa Thiên Huế ngày nay). Chúng được đặt trước **Thế Miếu** - nơi thờ các vua Nguyễn. [S1]  \n\n*Ví dụ:* Khi tham quan Đại Nội Huế, bạn sẽ thấy 9 đỉnh đồng lớn xếp thành hàng trước điện Thế Miếu, mỗi đỉnh cao khoảng 2m và nặng hơn 2 tấn.	\N	0	2026-01-15 14:55:35.323805+00	2026-01-15 14:55:35.335628+00
ba6edda3-9e02-4aa4-9b8e-de58195bc0cb	1df31222-3934-471c-8624-a87034fd017d	flashcards	succeeded	deepseek	Tạo 6 thẻ ghi nhớ ngắn về chủ đề: Cửu Đỉnh.\nTrả về JSON với khóa cards: [{front, back}].\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.	Dưới đây là 6 thẻ ghi nhớ ngắn về chủ đề Cửu Đỉnh dưới dạng JSON:\n\n```json\n{\n  "cards": [\n    {\n      "front": "Cửu Đỉnh là gì?",\n      "back": "Chín đỉnh đồng lớn đặt tại Hoàng thành Huế, đúc dưới thời vua Minh Mạng (1835-1837)."\n    },\n    {\n      "front": "Cửu Đỉnh đại diện cho điều gì?",\n      "back": "Biểu tượng quyền lực triều Nguyễn và bộ \\"bách khoa\\" về địa lý - văn hóa Việt Nam thế kỷ XIX."\n    },\n    {\n      "front": "Tên các đỉnh được đặt theo gì?",\n      "back": "Theo thụy hiệu của các vị vua triều Nguyễn: Cao, Nhân, Chương, Anh, Nghị, Thuần, Tuyên, Dụ, Huyền."\n    },\n    {\n      "front": "Cửu Đỉnh khắc họa những gì?",\n      "back": "Hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của Việt Nam."\n    },\n    {\n      "front": "Vị trí đặt Cửu Đỉnh?",\n      "back": "Sân Thế Miếu trong Hoàng thành Huế, trước điện Thái Hòa."\n    },\n    {\n      "front": "Giá trị nghệ thuật của Cửu Đỉnh?",\n      "back": "Kiệt tác đúc đồng thời Nguyễn, kết hợp hài hòa nghệ thuật trang trí và biểu tượng vương quyền."\n    }\n  ]\n}\n```	\N	0	2026-01-15 16:11:29.335167+00	2026-01-15 16:11:29.343369+00
f68c8a63-af09-4bf9-88f8-2ada62fd53b2	1df31222-3934-471c-8624-a87034fd017d	coach	succeeded	deepseek	{"goal": null, "availability_minutes_per_day": 15, "days_per_week": 5, "stats": {"total_xp": 1000, "current_streak": 1, "progress": {"discovered": 5, "learned": 1, "mastered": 1}}, "format": {"message": "string", "weekly_plan": ["string"]}}	```json\n{\n  "goal": "Master the content of Cửu Đỉnh",\n  "availability_minutes_per_day": 15,\n  "days_per_week": 5,\n  "stats": {\n    "total_xp": 1000,\n    "current_streak": 1,\n    "progress": {\n      "discovered": 5,\n      "learned": 1,\n      "mastered": 1\n    }\n  },\n  "format": {\n    "message": "Let's make steady progress on mastering Cửu Đỉnh! With 15 minutes a day, 5 days a week, we'll focus on deepening your understanding and retention.",\n    "weekly_plan": [\n      "Day 1: Review the 5 discovered items, focusing on understanding their significance.",\n      "Day 2: Deep dive into the 1 learned item, exploring its context and details.",\n      "Day 3: Practice recalling the 1 mastered item and test your knowledge.",\n      "Day 4: Discover 1 new item related to Cửu Đỉnh and take notes.",\n      "Day 5: Review all items, focusing on moving 1 discovered item to learned."\n    ]\n  }\n}\n```	\N	0	2026-01-15 16:12:09.080938+00	2026-01-15 16:12:09.091576+00
039ddb71-b51e-4c82-8dbf-ebbe3da4659f	3f8790e9-13ed-4a41-8e40-4885f86c2d99	qa	fallback	deepseek	Chỉ trả lời dựa trên nguồn đã cung cấp. Nếu thiếu dữ kiện, hãy nói rõ cần thêm thông tin.\nTrích dẫn nguồn bằng [S#].\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: Họa tiết rồng có ý nghĩa gì?\nTrả lời:	Theo [S1], Cửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt N…\n\nBạn có thể hỏi chi tiết hơn hoặc thử lại để nhận câu trả lời đầy đủ.	The read operation timed out	0	2026-01-17 12:46:11.04053+00	2026-01-17 12:46:12.515922+00
1f7710e3-a54c-4b01-8398-8e3db5a23f43	1df31222-3934-471c-8624-a87034fd017d	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: làm thế nào để vào cửu đỉnh\nTrả lời:	Để vào tham quan **Cửu Đỉnh** ở Huế, bạn có thể làm theo các bước sau:  \n\n1. **Đến Hoàng thành Huế** – Cửu Đỉnh nằm trong khuôn viên Đại Nội (phía trước Thế Miếu).  \n2. **Mua vé tham quan** – Vé thường bao gồm cả khu vực Đại Nội, nơi đặt Cửu Đỉnh.  \n3. **Di chuyển vào khu vực Thế Miếu** – Từ Ngọ Môn, đi thẳng qua Điện Thái Hòa, tiếp tục vào sâu đến khu Thế Miếu. Cửu Đỉnh đặt ở sân trước điện này.  \n\n**Lưu ý:**  \n- Giờ mở cửa: Thường từ **7h00 - 17h30** hàng ngày.  \n- Nên đi sớm hoặc chiều muộn để tránh nắng.  \n\nCửu Đỉnh là di sản quý, khi tham quan cần giữ gìn, không chạm vào hiện vật [S1].  \n\n*Ví dụ:* Nếu đi từ Đà Nẵng, bạn có thể bắt xe bus hoặc thuê xe máy đến Huế (khoảng 2-3 tiếng), sau đó vào thẳng Đại Nội.	\N	0	2026-01-15 16:18:22.923979+00	2026-01-15 16:18:22.935624+00
bbb644de-68dc-4bc8-8def-72df7b6aedc3	1df31222-3934-471c-8624-a87034fd017d	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: Làm thế nào để đi vào Cửu Đin\nTrả lời:	Để tham quan Cửu Đỉnh, bạn cần đến **Hoàng thành Huế** (Thừa Thiên Huế). Cửu Đỉnh nằm trước **Thế Miếu** (nơi thờ các vua Nguyễn), trong khuôn viên Đại Nội.  \n\n**Cách đi:**  \n1. **Vào Đại Nội Huế**: Mua vé tham quan tại cổng chính (cổng Ngọ Môn).  \n2. **Đi bộ hoặc dùng xe điện**: Từ Ngọ Môn, đi thẳng qua điện Thái Hòa, tiếp tục vào sân sau, rẽ trái hướng về Thế Miếu.  \n3. **Đến Cửu Đỉnh**: 9 đỉnh đồng đặt trên bệ đá trước sân Thế Miếu, dễ nhận biết nhờ kích thước lớn và hoa văn tinh xảo.  \n\n**Lưu ý:**  \n- Giờ mở cửa: 7h30 - 17h30 hàng ngày [S1].  \n- Nên thuê hướng dẫn viên hoặc đọc thông tin trước để hiểu ý nghĩa các hình khắc.  \n\nVí dụ: Từ Hà Nội, bạn bay/bắt tàu đến Huế, sau đó đi taxi hoặc xe máy vào Đại Nội (khoảng 15 phút từ trung tâm thành phố).	\N	0	2026-01-16 00:39:08.8745+00	2026-01-16 00:39:10.400801+00
7072a396-ca65-46f3-bbbf-85308122164c	1df31222-3934-471c-8624-a87034fd017d	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: hi\nTrả lời:	Xin chào! Mình là trợ giảng về Cửu Đỉnh. Bạn muốn tìm hiểu điều gì về 9 chiếc đỉnh đồng đặc biệt này ở Huế?  \n\nVí dụ:  \n- Cửu Đỉnh gồm Cao Đỉnh, Nhân Đỉnh, Chương Đỉnh... [S1]  \n- Mỗi đỉnh khắc hình sông Hương, núi Ngự Bình, cây lúa... như một bản đồ Việt Nam thu nhỏ.  \n\nBạn muốn biết chi tiết về đỉnh nào hay ý nghĩa của chúng? 😊	\N	0	2026-01-16 00:53:08.257776+00	2026-01-16 00:53:09.660595+00
903ea659-c683-4f37-8667-bf8422ec4602	3f8790e9-13ed-4a41-8e40-4885f86c2d99	qa	pending	deepseek	Chỉ trả lời dựa trên nguồn đã cung cấp. Nếu thiếu dữ kiện, hãy nói rõ cần thêm thông tin.\nTrích dẫn nguồn bằng [S#].\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: Họa tiết rồng có ý nghĩa gì?\nTrả lời:	\N	\N	0	2026-01-17 12:41:32.743272+00	2026-01-17 12:41:32.743272+00
3afca2c5-75a8-4584-bf76-125e025b8d26	1df31222-3934-471c-8624-a87034fd017d	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: lô\nTrả lời:	"Lô" là một cách chào thân mật, giống như "xin chào" hoặc "hi".  \n\nVí dụ:  \n- A: "Lô!"  \n- B: "Chào bạn! Bạn khỏe không?"  \n\nBạn muốn tìm hiểu thêm về chủ đề nào? 😊	\N	0	2026-01-24 00:25:14.337905+00	2026-01-24 00:25:15.108771+00
4c52973c-d223-4a00-a2c8-b7dd959bd74a	1df31222-3934-471c-8624-a87034fd017d	tutor	fallback	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: h\nTrả lời:	Theo [S1], Cửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt N…\n\nBạn có thể hỏi chi tiết hơn hoặc thử lại để nhận câu trả lời đầy đủ.	The read operation timed out	0	2026-01-17 12:53:51.051163+00	2026-01-17 12:53:55.340272+00
480e62aa-894c-4fbb-a5ad-7cf815435de1	1df31222-3934-471c-8624-a87034fd017d	tutor	fallback	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: Làm sao để vào Cửu Đỉnh?\nTrả lời:	Theo [S1], Cửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt N…\n\nBạn có thể hỏi chi tiết hơn hoặc thử lại để nhận câu trả lời đầy đủ.	The read operation timed out	0	2026-01-18 08:20:26.885075+00	2026-01-18 08:20:37.770959+00
a2804039-f2fb-48f4-87e2-17e5c28c63a1	1df31222-3934-471c-8624-a87034fd017d	tutor	fallback	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: Cho tôi biết về Cao Đỉnh\nTrả lời:	Theo [S1], Cửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt N…\n\nBạn có thể hỏi chi tiết hơn hoặc thử lại để nhận câu trả lời đầy đủ.	The read operation timed out	0	2026-01-18 08:33:55.305851+00	2026-01-18 08:34:02.269188+00
6ef36202-55e0-41bb-a15e-576fba04c792	1df31222-3934-471c-8624-a87034fd017d	tutor	fallback	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: Cho tôi biết về Cao Đỉnh\nTrả lời:	Theo [S1], Cửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt N…\n\nBạn có thể hỏi chi tiết hơn hoặc thử lại để nhận câu trả lời đầy đủ.	The read operation timed out	0	2026-01-18 08:34:37.193806+00	2026-01-18 08:34:49.137945+00
b4919a61-5c7b-4202-bf94-c0805a938c4e	1df31222-3934-471c-8624-a87034fd017d	tutor	fallback	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: Xin chào\nTrả lời:	Theo [S1], Cửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt N…\n\nBạn có thể hỏi chi tiết hơn hoặc thử lại để nhận câu trả lời đầy đủ.	The read operation timed out	0	2026-01-18 08:35:47.006864+00	2026-01-18 08:35:53.54289+00
e867581e-ba4b-4d77-8d62-86bcb22ff8f9	9212f3ba-8e00-4199-83df-25271cd78d3c	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: Bạn là mô hình nào\nTrả lời:	Mình là AI Tutor, một trợ lý ảo chuyên hỗ trợ học tập về lịch sử Việt Nam, đặc biệt là các chủ đề liên quan đến Cửu Đỉnh triều Nguyễn.  \n\nVí dụ: Nếu bạn hỏi *"Cao Đỉnh tượng trưng cho vị vua nào?"*, mình sẽ trả lời ngắn gọn: *"Cao Đỉnh tượng trưng cho vua Gia Long – vị vua sáng lập triều Nguyễn [S1]."*  \n\nBạn muốn tìm hiểu gì về Cửu Đỉnh? 😊	\N	0	2026-01-21 00:17:42.429698+00	2026-01-21 00:17:44.49404+00
fb908c18-cff8-4bf2-8c52-060cc4b381e8	1df31222-3934-471c-8624-a87034fd017d	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: hi\nTrả lời:	Chào bạn! Mình là trợ giảng về Cửu Đỉnh - bảo vật quốc gia triều Nguyễn. Bạn cần tìm hiểu gì về 9 đỉnh đồng này?  \n\nVí dụ:  \n- Cửu Đỉnh đặt trước Thế Miếu (Huế), mỗi đỉnh tượng trưng cho một vị vua Nguyễn [S1].  \n- Đỉnh Cao Đỉnh lớn nhất, nặng 4.300kg, khắc hình sông Hồng, núi Tản Viên...  \n\nBạn muốn biết chi tiết về đỉnh nào? 😊	\N	0	2026-01-22 08:32:51.185421+00	2026-01-22 08:33:04.478101+00
3edf5418-4cd1-48d9-ac9e-a650e10db8a4	1df31222-3934-471c-8624-a87034fd017d	tutor	fallback	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: cửu đỉnh ở đâu zay\nTrả lời:	Theo [S1], Cửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt N…\n\nBạn có thể hỏi chi tiết hơn hoặc thử lại để nhận câu trả lời đầy đủ.	The read operation timed out	0	2026-01-22 10:05:28.890068+00	2026-01-22 10:05:40.91775+00
8f3bdf78-1a3e-4bd6-8632-0cdaa7fe89b0	1df31222-3934-471c-8624-a87034fd017d	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: vgv\nTrả lời:	Xin lỗi, nhưng tôi không hiểu câu hỏi "vgv" của bạn. Bạn có thể diễn đạt rõ hơn hoặc đặt câu hỏi cụ thể về Cửu Đỉnh Huế không?  \n\nVí dụ:  \n- Cửu Đỉnh gồm những đỉnh nào?  \n- Tại sao Cửu Đỉnh được coi là bản đồ văn hóa Việt Nam?  \n\nNguồn tham khảo: [S1]	\N	0	2026-01-22 17:03:54.154862+00	2026-01-22 17:03:55.699557+00
57b50f46-72dd-4282-9216-952fb93b8515	1df31222-3934-471c-8624-a87034fd017d	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: Cao Đỉnh mang ý nghĩa gì\nTrả lời:	Cao Đỉnh là một trong chín đỉnh đồng (Cửu Đỉnh) ở Huế, được đặt theo thụy hiệu của vua Gia Long (Cao Hoàng đế) [S1]. \n\nÝ nghĩa chính:\n1. Tượng trưng cho vương quyền triều Nguyễn\n2. Là biểu tượng của sự vĩ đại (do gắn với vua đầu triều)\n3. Trên đỉnh khắc các hình ảnh quan trọng về sông núi, sản vật Việt Nam như sông Hồng, núi Tản Viên [S1].\n\nVí dụ: Giống như quốc huy ngày nay, Cao Đỉnh giúp khẳng định chủ quyền đất nước thời Nguyễn.\n\n[S1] Nguồn thông tin về Cửu Đỉnh	\N	0	2026-01-22 17:07:41.704814+00	2026-01-22 17:07:43.137626+00
e53cef20-38ac-4248-8e6f-cb75809de9d1	1df31222-3934-471c-8624-a87034fd017d	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cao Đỉnh\nChữ 'Cao' là thụy hiệu (tên tôn vinh) của vua Gia Long (1762-1820), vị hoàng đế sáng lập triều Nguyễn và thống nhất đất nước sau nhiều thế kỷ chia cắt. Cao Đỉnh được đúc vào năm 1835 dưới triều vua Minh Mạng để tưởng nhớ công lao to lớn của vua cha. Trên bề mặt đỉnh, chữ 'Cao' được chạm khắc nổi bật với nét chữ Hán uy nghiêm, thể hiện sự tôn kính của con cháu đối với tổ tiên. Xung quanh chữ 'Cao' là các họa tiết rồng phượng, mây vân và cảnh vật thiên nhiên, tượng trưng cho sự thịnh vượng và bền vững của triều đại. Cao Đỉnh không chỉ là một tác phẩm nghệ thuật đúc đồng tinh xảo mà còn là biểu tượng của lòng hiếu thảo và sự kế thừa truyền thống trong văn hóa Việt Nam.\n\n[S2] Bài học: Cao Đỉnh\nChữ 'Cao' là thụy hiệu (tên tôn vinh) của vua Gia Long (1762-1820), vị hoàng đế sáng lập triều Nguyễn và thống nhất đất nước sau nhiều thế kỷ chia cắt. Cao Đỉnh được đúc vào năm 1835 dưới triều vua Minh Mạng để tưởng nhớ công lao to lớn của vua cha. Trên bề mặt đỉnh, chữ 'Cao' được chạm khắc nổi bật với nét chữ Hán uy nghiêm, thể hiện sự tôn kính của con cháu đối với tổ tiên. Xung quanh chữ 'Cao' là các họa tiết rồng phượng, mây vân và cảnh vật thiên nhiên, tượng trưng cho sự thịnh vượng và bền vững của triều đại. Cao Đỉnh không chỉ là một tác phẩm nghệ thuật đúc đồng tinh xảo mà còn là biểu tượng của lòng hiếu thảo và sự kế thừa truyền thống trong văn hóa Việt Nam. Cửu Đỉnh được vua Minh Mạng cho đúc từ năm 1835 đến 1837, lấy cảm hứng từ Cửu Đỉnh của nhà Hạ ở Trung Quốc. Cao Đỉnh là đỉnh đầu tiên trong chín chiếc, dành riêng để tôn vinh vua Gia Long - người đã dẹp yên loạn Tây Sơn, thống nhất đất nước và mở ra triều đại Nguyễn kéo dài 143 năm (1802-1945). Việc đúc Cửu Đỉnh thể hiện khát vọng của vua Minh Mạng về một triều đại vững mạnh, trường tồn như chín chiếc đỉnh đồng bất diệt. Chữ 'Cao' không chỉ là tên thụy hiệu mà còn mang ý nghĩa 'cao quý', 'cao cả', thể hiện đức độ và công lao vĩ đại của vua Gia Long. Trong văn hóa Việt Nam, việc đặt tên thụy hiệu cho vua sau khi băng hà là truyền thống quan trọng, thể hiện lòng tôn kính và ghi nhớ công đức của bậc tiền nhân. Cao Đỉnh đặt ở vị trí trung tâm trong Cửu Đỉnh, khẳng định vai trò nền tảng của vua Gia Long đối với triều Nguyễn. Cao Đỉnh nặng khoảng 2.600 kg và cao 2,3 mét, là một trong những chiếc đỉnh lớn nhất. Để đúc Cửu Đỉnh, vua Minh Mạng đã thu thập đồng từ khắp cả nước, bao gồm cả vũ khí, đồ dùng cũ và đồng tiền. Điều này tượng trưng cho sự đoàn kết của toàn dân trong việc xây dựng quốc gia.\n\n[S3] Cao Đỉnh\n\n\nCâu hỏi: vvb\nTrả lời:	Xin lỗi, tôi không hiểu câu hỏi "vvb" của bạn. Bạn có thể vui lòng diễn đạt rõ hơn hoặc đặt câu hỏi cụ thể về chủ đề liên quan đến Cửu Đỉnh, lịch sử Việt Nam hoặc vua Gia Long không? Tôi rất sẵn lòng giải đáp. \n\nVí dụ: \n- "Cao Đỉnh là gì?" \n- "Vua Gia Long có công lao gì?" \n- "Cửu Đỉnh được đúc khi nào?" \n\nNguồn tham khảo: [S1], [S2]	\N	0	2026-01-23 05:15:25.971644+00	2026-01-23 05:15:27.510462+00
8abe8941-6743-49b3-a0c7-49723f2dfd7b	1df31222-3934-471c-8624-a87034fd017d	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: ali\nTrả lời:	Xin lỗi, nhưng câu hỏi "ali" không rõ ý nghĩa hoặc không liên quan đến chủ đề Cửu Đỉnh. Bạn có thể vui lòng đặt câu hỏi cụ thể hơn về Cửu Đỉnh hoặc lịch sử Việt Nam để mình hỗ trợ tốt hơn không? \n\nVí dụ:  \n- "Cửu Đỉnh là gì?"  \n- "Cửu Đỉnh được đúc vào thời gian nào?"  \n\nNguồn tham khảo: [S1]	\N	0	2026-01-23 09:14:57.966109+00	2026-01-23 09:14:59.541932+00
724acc72-7cf0-498d-8d81-03eec3905892	1df31222-3934-471c-8624-a87034fd017d	tutor	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: hi\nTrả lời:	Xin chào! Bạn có thể cho mình biết cụ thể bạn muốn hỏi về điều gì liên quan đến Cửu Đỉnh không?  \n\nVí dụ:  \n- Bạn muốn biết Cửu Đỉnh là gì?  \n- Hay bạn muốn tìm hiểu về ý nghĩa của Cửu Đỉnh?  \n\nMình sẽ giải đáp ngắn gọn và dễ hiểu nhất có thể!  \n\nNguồn tham khảo: [S1]	\N	0	2026-01-24 01:29:18.69249+00	2026-01-24 01:29:19.507434+00
840fb0dd-c86a-4cb1-a332-55f079f699f6	1df31222-3934-471c-8624-a87034fd017d	tutor_stream	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: hi\nTrả lời:	Xin chào! Tôi là trợ giảng về Cửu Đỉnh - bảo vật quốc gia thời Nguyễn.  \n\nBạn muốn tìm hiểu điều gì về Cửu Đỉnh? Ví dụ:  \n- **Cửu Đỉnh là gì?** → 9 đỉnh đồng lớn ở Huế, khắc hình ảnh Việt Nam thế kỷ 19 [S1].  \n- **Ai tạo ra?** → Vua Minh Mạng cho đúc từ 1835-1837 [S1].  \n\nHãy cho tôi biết bạn quan tâm đến khía cạnh nào nhé!	\N	0	2026-02-05 16:33:32.642299+00	2026-02-05 16:33:34.191764+00
a86675f0-3efa-496e-bdca-6d44e3ed9ad0	1df31222-3934-471c-8624-a87034fd017d	tutor_stream	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: hhh\nTrả lời:	Xin lỗi, nhưng câu hỏi "hhh" của bạn không rõ ý nghĩa. Bạn có thể vui lòng diễn đạt lại câu hỏi cụ thể hơn về Cửu Đỉnh hoặc lịch sử Việt Nam không? Mình rất sẵn lòng giải đáp!\n\nVí dụ:  \n- "Cửu Đỉnh nằm ở đâu?"  \n- "Cửu Đỉnh có ý nghĩa gì?"  \n- "Ai là người tạo ra Cửu Đỉnh?"  \n\nNguồn tham khảo: [S1]	\N	0	2026-02-06 10:17:35.668433+00	2026-02-06 10:17:37.406581+00
58effc0e-07bc-4085-9aa0-88120f8e6033	1df31222-3934-471c-8624-a87034fd017d	tutor_stream	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: hhh\nTrả lời:	Câu hỏi của bạn chưa rõ ý. Mình có thể giúp gì cho bạn về Cửu Đỉnh?  \n\nVí dụ:  \n- Bạn muốn biết Cửu Đỉnh là gì?  \n- Hay tên của 9 đỉnh là gì?  \n- Hoặc ý nghĩa của Cửu Đỉnh?  \n\nHãy cho mình biết chi tiết hơn nhé! [S1]	\N	0	2026-02-06 11:50:25.3894+00	2026-02-06 11:50:30.314965+00
b308e061-bb62-4383-90e8-237f824bf140	1df31222-3934-471c-8624-a87034fd017d	tutor_stream	succeeded	deepseek	Người học ở mức: beginner.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: lô\nTrả lời:	"Lô" là một trong 9 đỉnh đồng thuộc bộ Cửu Đỉnh ở Huế, tượng trưng cho vua Tự Đức (triều Nguyễn). Đỉnh Lô đúc năm 1835-1837, khắc các hình ảnh về sông núi, động thực vật tiêu biểu của Việt Nam thế kỷ 19. [S1]\n\nVí dụ: Trên đỉnh Lô có khắc hình sông Lô (Phú Thọ) và cây lúa - hai biểu tượng quan trọng của nông nghiệp Việt Nam.	\N	0	2026-02-08 12:41:37.148915+00	2026-02-08 12:41:38.837562+00
d1d3901b-ceed-4f62-846d-7e6554b1797d	1df31222-3934-471c-8624-a87034fd017d	tutor_stream	fallback	deepseek	Người học ở mức: teen.\nHãy trả lời ngắn gọn, dễ hiểu, có ví dụ thực tế nếu phù hợp.\nTrích dẫn nguồn bằng [S#] nếu sử dụng thông tin từ nguồn bên dưới.\n\nNguồn:\n[S1] Cửu Đỉnh\nCửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt Nam thế kỷ XIX.\n\nCâu hỏi: mấy con gà bt j\nTrả lời:	Theo [S1], Cửu Đỉnh là chín đỉnh đồng lớn đặt tại Hoàng thành Huế, được vua Minh Mạng cho đúc giai đoạn 1835-1837. Mỗi đỉnh mang tên thụy hiệu của các vị vua triều Nguyễn và khắc họa hàng trăm hình tượng núi sông, cây cỏ, chim thú, thủy hệ và khí vật tiêu biểu của đất nước. Cửu Đỉnh vừa là biểu tượng quyền lực quốc gia, vừa là bộ "bách khoa" về địa lý - văn hóa Việt N…\n\nBạn có thể hỏi chi tiết hơn hoặc thử lại để nhận câu trả lời đầy đủ.	list index out of range	0	2026-02-12 03:19:43.495553+00	2026-02-12 03:19:44.441358+00
\.


--
-- Data for Name: ai_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_messages (id, conversation_id, role, content, tokens_used, created_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
0037
0033_feature_flags_experiments
0032_email_scheduling
0031_user_shares
0024_user_learning_paths
0024
0021_classroom_enhancements
0019_app_versions
0014
0014_crash_reports
0013_weekly_quests
0013_content_tagging
0012_onboarding_fields
0012_analytics_taxonomy
\.


--
-- Data for Name: analytics_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_events (id, user_id, event_name, path, payload, created_at, session_id, cohort, event_category, device_info) FROM stdin;
48a32c06-c6c4-4bd3-a1c9-246f7258c230	9212f3ba-8e00-4199-83df-25271cd78d3c	dashboard_view	/dashboard	{"source": "client", "starting_urn_id": null}	2026-01-08 15:02:13.432675+00	\N	\N	\N	\N
ebd5bdba-d84f-476f-a4ea-4bb7703aaf8a	9212f3ba-8e00-4199-83df-25271cd78d3c	starting_path_selected	/dashboard	{"source": "client", "urn_id": "5dee75b5-558b-44ce-81da-6a44673927db", "urn_slug": "cao-dinh"}	2026-01-08 15:02:25.090038+00	\N	\N	\N	\N
59752f04-0352-4df6-8e6d-a516fff847ab	9212f3ba-8e00-4199-83df-25271cd78d3c	dashboard_view	/dashboard	{"source": "client", "starting_urn_id": "5dee75b5-558b-44ce-81da-6a44673927db"}	2026-01-08 15:02:39.943102+00	\N	\N	\N	\N
f91649bf-c2d7-41c6-abec-2f2a46e9b647	9212f3ba-8e00-4199-83df-25271cd78d3c	resume_click	/dashboard	{"source": "client", "status": "hidden", "motif_id": null, "starting_urn_id": "5dee75b5-558b-44ce-81da-6a44673927db"}	2026-01-08 15:02:39.943102+00	\N	\N	\N	\N
3a27d817-42c7-40fa-9a48-400d5573325e	9212f3ba-8e00-4199-83df-25271cd78d3c	dashboard_view	/dashboard	{"source": "client", "starting_urn_id": "5dee75b5-558b-44ce-81da-6a44673927db"}	2026-01-08 15:02:48.685774+00	\N	\N	\N	\N
6ee42749-f2ec-42de-9df4-c7a0982bf352	9212f3ba-8e00-4199-83df-25271cd78d3c	dashboard_view	/dashboard	{"source": "client", "starting_urn_id": "5dee75b5-558b-44ce-81da-6a44673927db"}	2026-01-10 14:38:24.181806+00	\N	\N	\N	\N
e29c2ab8-ce7b-42e1-8208-3d71d08021fb	9212f3ba-8e00-4199-83df-25271cd78d3c	resume_click	/dashboard	{"source": "client", "status": "hidden", "motif_id": null, "starting_urn_id": "5dee75b5-558b-44ce-81da-6a44673927db"}	2026-01-10 14:38:24.181806+00	\N	\N	\N	\N
e938d8eb-08d3-421e-a86d-b8866c52fea9	1df31222-3934-471c-8624-a87034fd017d	lesson_completed	\N	{"source": "server", "status": "learned", "urn_id": "5dee75b5-558b-44ce-81da-6a44673927db", "motif_id": "bf4a67a3-162d-4d04-98b0-adff8a1860f1", "xp_awarded": 50}	2026-01-12 07:58:19.4701+00	\N	\N	\N	\N
87d7fd62-d96f-4126-883c-ab741be6e3b7	1df31222-3934-471c-8624-a87034fd017d	quiz_start	/motif/bf4a67a3-162d-4d04-98b0-adff8a1860f1/quiz	{"source": "client", "urn_id": "5dee75b5-558b-44ce-81da-6a44673927db", "motif_id": "bf4a67a3-162d-4d04-98b0-adff8a1860f1"}	2026-01-12 07:58:25.212054+00	\N	\N	\N	\N
72d65b94-14fc-4f23-87ad-8f20cfed2b22	1df31222-3934-471c-8624-a87034fd017d	quiz_completed	\N	{"score": 2, "passed": false, "source": "server", "urn_id": "5dee75b5-558b-44ce-81da-6a44673927db", "motif_id": "bf4a67a3-162d-4d04-98b0-adff8a1860f1", "max_score": 3, "percentage": 67, "time_taken_seconds": 11}	2026-01-12 07:58:35.041811+00	\N	\N	\N	\N
dc7929d6-a4f1-48b6-92e7-44e5756072cf	1df31222-3934-471c-8624-a87034fd017d	quiz_complete	/motif/bf4a67a3-162d-4d04-98b0-adff8a1860f1/quiz	{"passed": false, "source": "client", "urn_id": "5dee75b5-558b-44ce-81da-6a44673927db", "attempts": 1, "motif_id": "bf4a67a3-162d-4d04-98b0-adff8a1860f1", "percentage": 67}	2026-01-12 07:58:36.846146+00	\N	\N	\N	\N
30ace0e6-e2cf-4563-9c6d-37f14450018d	1df31222-3934-471c-8624-a87034fd017d	dashboard_view	/dashboard	{"source": "client", "starting_urn_id": "5dee75b5-558b-44ce-81da-6a44673927db"}	2026-01-12 07:58:40.122822+00	\N	\N	\N	\N
f6848365-db14-427a-9010-a08eed18be0b	1df31222-3934-471c-8624-a87034fd017d	lesson_completed	\N	{"source": "server", "status": "learned", "urn_id": "5dee75b5-558b-44ce-81da-6a44673927db", "motif_id": "798e6ca7-ca19-4851-b320-889549db1096", "xp_awarded": 50}	2026-01-12 08:02:05.498676+00	\N	\N	\N	\N
749fce7a-50d6-4510-8f17-c176925a51c5	1df31222-3934-471c-8624-a87034fd017d	quiz_start	/motif/798e6ca7-ca19-4851-b320-889549db1096/quiz	{"source": "client", "urn_id": "5dee75b5-558b-44ce-81da-6a44673927db", "motif_id": "798e6ca7-ca19-4851-b320-889549db1096"}	2026-01-12 08:02:09.992926+00	\N	\N	\N	\N
06a90497-d600-41c1-bc30-0a48d875a01f	1df31222-3934-471c-8624-a87034fd017d	quiz_completed	\N	{"score": 2, "passed": true, "source": "server", "urn_id": "5dee75b5-558b-44ce-81da-6a44673927db", "motif_id": "798e6ca7-ca19-4851-b320-889549db1096", "max_score": 2, "percentage": 100, "time_taken_seconds": 8}	2026-01-12 08:02:16.346109+00	\N	\N	\N	\N
a7d72744-8bd9-4dcf-8493-92ca96ec8931	1df31222-3934-471c-8624-a87034fd017d	motif_mastered	\N	{"source": "server", "urn_id": "5dee75b5-558b-44ce-81da-6a44673927db", "motif_id": "798e6ca7-ca19-4851-b320-889549db1096", "percentage": 100}	2026-01-12 08:02:16.356736+00	\N	\N	\N	\N
0e0d04db-dd06-4e68-8b41-1c13d33ef93d	1df31222-3934-471c-8624-a87034fd017d	quiz_complete	/motif/798e6ca7-ca19-4851-b320-889549db1096/quiz	{"passed": true, "source": "client", "urn_id": "5dee75b5-558b-44ce-81da-6a44673927db", "attempts": 1, "motif_id": "798e6ca7-ca19-4851-b320-889549db1096", "percentage": 100}	2026-01-12 08:02:18.164071+00	\N	\N	\N	\N
7643b2e9-e752-4cd7-a4a0-f7be71de3f49	1df31222-3934-471c-8624-a87034fd017d	mastery_complete	/motif/798e6ca7-ca19-4851-b320-889549db1096/quiz	{"source": "client", "urn_id": "5dee75b5-558b-44ce-81da-6a44673927db", "motif_id": "798e6ca7-ca19-4851-b320-889549db1096", "percentage": 100}	2026-01-12 08:02:18.164071+00	\N	\N	\N	\N
2cdc8e25-b89f-4315-94d1-8b1452a23575	1df31222-3934-471c-8624-a87034fd017d	lesson_completed	\N	{"source": "server", "urn_id": "5dee75b5-558b-44ce-81da-6a44673927db", "motif_id": "036b8060-4597-4028-bded-135081787c70"}	2026-01-29 05:23:51.472731+00	\N	\N	lesson	null
224d26ad-ddf0-4099-bc88-cc397d248417	1df31222-3934-471c-8624-a87034fd017d	lesson_completed	\N	{"source": "server", "urn_id": "5dee75b5-558b-44ce-81da-6a44673927db", "motif_id": "f3a49a22-ec62-492e-a662-29419f1c2fca"}	2026-02-05 16:39:12.50924+00	\N	\N	lesson	null
547edce5-a03f-47dc-bd38-5f8e7529bace	1df31222-3934-471c-8624-a87034fd017d	lesson_completed	\N	{"source": "server", "urn_id": "5dee75b5-558b-44ce-81da-6a44673927db", "motif_id": "d27e9e0b-a9eb-42a2-8466-83442f48939d"}	2026-02-06 11:50:43.942653+00	\N	\N	lesson	null
\.


--
-- Data for Name: app_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_versions (id, platform, version, version_code, min_required_version, is_current, force_update, release_notes, download_url, released_at, created_at) FROM stdin;
\.


--
-- Data for Name: assignment_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assignment_progress (id, assignment_id, user_id, status, completed_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, user_id, action, resource_type, resource_id, old_value, new_value, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: badges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.badges (id, slug, name, name_en, description, icon_url, category, xp_bonus, unlock_criteria, is_secret, is_active, created_at, tier, tier_xp_bonus) FROM stdin;
6d53a206-604b-4ca0-8025-950a4a8c3099	first-discovery	Khai Môn	First Discovery	Mở khóa họa tiết đầu tiên.	🎯	achievement	100	{"type": "first_discovery"}	f	t	2026-01-08 14:55:01.200388+00	bronze	0
2b881a08-fba9-40de-a004-1ec37945fc47	first-mastered	Bậc Thầy Đầu Tiên	First Mastery	Hoàn thành (mastered) họa tiết đầu tiên.	🏆	achievement	200	{"type": "first_mastered"}	f	t	2026-01-08 14:55:01.200388+00	bronze	0
e0aacea8-5bc3-4c80-9308-dd0e79dbc74f	streak-7	Thất Nhật Liên Tiếp	7-Day Streak	Duy trì streak 7 ngày liên tiếp.	🔥	achievement	150	{"days": 7, "type": "streak"}	f	t	2026-01-08 14:55:01.200388+00	bronze	0
3fa3337c-e77e-4a58-b2c3-8c3c86453012	collector-10	Nhà Sưu Tầm Tập Sự	Collector (10)	Thu thập 10 họa tiết.	📦	collection	150	{"type": "motif_discovered_count", "count": 10}	f	t	2026-01-08 14:55:01.200388+00	bronze	0
b958a040-ee83-49d9-bb08-cd3d4cb7b3f7	collector-50	Nhà Sưu Tầm Lão Luyện	Collector (50)	Thu thập 50 họa tiết.	💎	collection	500	{"type": "motif_discovered_count", "count": 50}	f	t	2026-01-08 14:55:01.200388+00	bronze	0
831aff26-76e4-4bf1-830a-68d5450730ee	explorer-all-urns	Chinh Phục Cửu Đỉnh	Explore All Urns	Khám phá tất cả 9 đỉnh.	🗺️	quest	300	{"type": "urns_explored_count", "count": 9}	f	t	2026-01-08 14:55:01.200388+00	bronze	0
7cbea92e-45ac-4435-91f7-a480361a7ddd	quiz-master	Bậc Thầy Quiz	Quiz Master	Hoàn thành 10 quiz với điểm tối đa.	🎓	achievement	400	{"type": "quiz_max_score_count", "count": 10}	f	t	2026-01-08 14:55:01.200388+00	bronze	0
aef1d95c-9b78-449f-a4a5-6e76add9a1ca	speed-demon	Thần Tốc	Speed Demon	Hoàn thành quiz trong 30 giây.	⚡	achievement	200	{"type": "quiz_complete_under_seconds", "seconds": 30}	f	t	2026-01-08 14:55:01.200388+00	bronze	0
aad694ca-3c38-4bce-a267-1c3f3fe1af4c	perfect-score	Điểm Tuyệt Đối	Perfect Score	Đạt 100% trong quiz.	💯	achievement	150	{"type": "quiz_percentage", "percentage": 100}	f	t	2026-01-08 14:55:01.200388+00	bronze	0
90f841e5-1418-4122-bc30-8b9d381b6ca9	early-bird	Chim Sớm	Early Bird	Đăng nhập trước 6 giờ sáng.	🌅	special	100	{"hour": 6, "type": "login_before_hour"}	f	t	2026-01-08 14:55:01.200388+00	bronze	0
245fbf4c-96c7-4b8a-9176-61fc306c3fd9	nong-dan	Nông Dân	Farmer	Hoàn thành quest Đất & Mùa Màng.	🌾	quest	100	{"type": "quest_complete", "quest_slug": "dat-mua-mang"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
2a817996-a436-488f-8c85-f8fbd66d8cd2	thu-hoang-gia	Thú Hoang Gia	Royal Beasts	Hoàn thành quest Thế Giới Động Vật.	🦁	quest	100	{"type": "quest_complete", "quest_slug": "the-gioi-dong-vat"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
d5067a30-78d1-42f8-82f8-1c589edfac6c	nha-dia-ly	Nhà Địa Lý	Geographer	Hoàn thành quest Sơn Hà Xã Tắc.	🏔️	quest	100	{"type": "quest_complete", "quest_slug": "son-ha-xa-tac"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
6b6b20a2-e76e-4e00-bef5-d069737dcdd2	nha-thao-hoc	Nhà Thảo Học	Botanist	Hoàn thành quest Thảo Mộc Thiên Nhiên.	🌿	quest	100	{"type": "quest_complete", "quest_slug": "thao-moc-thien-nhien"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
b72cdcda-3565-4935-b7d1-aef67f579249	chien-binh	Chiến Binh	Warrior	Hoàn thành quest Võ Bị & Quân Sự.	⚔️	quest	100	{"type": "quest_complete", "quest_slug": "vo-bi-quan-su"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
4cc40dfa-dedf-4fae-adbd-d5f4a61d1567	nha-thien-van	Nhà Thiên Văn	Astronomer	Hoàn thành quest Thiên Văn & Vũ Trụ.	🌟	quest	100	{"type": "quest_complete", "quest_slug": "thien-van-vu-tru"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
645a054d-ff53-4402-840a-859a64c58028	kien-truc-su	Kiến Trúc Sư	Architect	Hoàn thành quest Kiến Trúc Cổ.	🏛️	quest	100	{"type": "quest_complete", "quest_slug": "kien-truc-co"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
32c200b1-7999-4532-84d8-3a8ed68dbe2c	cao-dinh-master	Bậc Thầy Cao Đỉnh	Cao Dinh Master	Hoàn thành quest Khám Phá Cao Đỉnh.	👑	quest	150	{"type": "quest_complete", "quest_slug": "kham-pha-cao-dinh"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
c894f5a5-11e2-4607-a7e3-2be10c457714	nhan-dinh-master	Bậc Thầy Nhân Đỉnh	Nhan Dinh Master	Hoàn thành quest Khám Phá Nhân Đỉnh.	🏅	quest	150	{"type": "quest_complete", "quest_slug": "kham-pha-nhan-dinh"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
fe167ec5-5005-4111-9aa2-59b4dd20a4e4	chuong-dinh-master	Bậc Thầy Chương Đỉnh	Chuong Dinh Master	Hoàn thành quest Khám Phá Chương Đỉnh.	🏅	quest	150	{"type": "quest_complete", "quest_slug": "kham-pha-chuong-dinh"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
927ca3e9-79d6-47b0-a934-2edd0b8953bf	anh-dinh-master	Bậc Thầy Anh Đỉnh	Anh Dinh Master	Hoàn thành quest Khám Phá Anh Đỉnh.	🏅	quest	150	{"type": "quest_complete", "quest_slug": "kham-pha-anh-dinh"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
2537ff01-8593-4d5b-a7e6-634346067b1f	nghi-dinh-master	Bậc Thầy Nghị Đỉnh	Nghi Dinh Master	Hoàn thành quest Khám Phá Nghị Đỉnh.	🏅	quest	150	{"type": "quest_complete", "quest_slug": "kham-pha-nghi-dinh"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
20c78ffe-afbe-4f34-8b79-475fc9938a25	thuan-dinh-master	Bậc Thầy Thuần Đỉnh	Thuan Dinh Master	Hoàn thành quest Khám Phá Thuần Đỉnh.	🏅	quest	150	{"type": "quest_complete", "quest_slug": "kham-pha-thuan-dinh"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
0b4b9917-1a3b-413d-b140-2b325c667b35	tuyen-dinh-master	Bậc Thầy Tuyên Đỉnh	Tuyen Dinh Master	Hoàn thành quest Khám Phá Tuyên Đỉnh.	🏅	quest	150	{"type": "quest_complete", "quest_slug": "kham-pha-tuyen-dinh"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
5f534873-f194-4682-b2b0-ae51b8aea7e7	du-dinh-master	Bậc Thầy Dụ Đỉnh	Du Dinh Master	Hoàn thành quest Khám Phá Dụ Đỉnh.	🏅	quest	150	{"type": "quest_complete", "quest_slug": "kham-pha-du-dinh"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
1817acb0-ed68-44c9-8b4e-467db01b9423	huyen-dinh-master	Bậc Thầy Huyền Đỉnh	Huyen Dinh Master	Hoàn thành quest Khám Phá Huyền Đỉnh.	🏅	quest	150	{"type": "quest_complete", "quest_slug": "kham-pha-huyen-dinh"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
a558c365-e146-4aaa-b6dd-ba96f8ea24fd	cuu-dinh-expert	Chuyên Gia Cửu Đỉnh	Nine Urns Expert	Vượt qua thử thách Cửu Đỉnh.	🎖️	quest	300	{"type": "quest_complete", "quest_slug": "cuu-dinh-thu-thach"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
83394c19-0a5b-4c98-8119-daeb132eaae8	grand-collector	Đại Sưu Tầm Gia	Grand Collector	Thu thập và thành thạo tất cả họa tiết.	💎	quest	500	{"type": "quest_complete", "quest_slug": "nha-suu-tam-vi-dai"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
c37e571f-07ff-4cc9-b4d3-cf164f83f8ff	cuu-dinh-scholar	Học Giả Cửu Đỉnh	Nine Urns Scholar	Đạt thành tích cao nhất trong tất cả các lĩnh vực.	📜	quest	1000	{"type": "quest_complete", "quest_slug": "hoc-gia-cuu-dinh"}	f	t	2026-01-08 16:07:16.959774+00	bronze	0
\.


--
-- Data for Name: certificates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.certificates (id, user_id, code, issuer_name, reason_type, reason_id, status, issued_at) FROM stdin;
\.


--
-- Data for Name: class_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.class_members (id, class_id, user_id, role, joined_at) FROM stdin;
127d9120-ad58-424f-8800-2d4e43ba5acd	d5fd99f4-8008-44ed-8f0f-e49d7d1a0d73	5290740d-3e7b-4774-b7d2-567d09b0ad94	learner	2026-01-08 14:55:01.200388+00
\.


--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.classes (id, name, description, teacher_id, created_at, class_code, max_students, is_archived, settings, updated_at) FROM stdin;
d5fd99f4-8008-44ed-8f0f-e49d7d1a0d73	Lớp Demo	Lớp học mẫu cho giáo viên.	91335bab-f27b-4b29-b650-b9b29d5997e8	2026-01-08 14:55:01.200388+00	SP829JTY	\N	f	\N	2026-01-17 06:04:52.120477+00
\.


--
-- Data for Name: content_flags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.content_flags (id, user_id, content_type, content_id, reason, created_at) FROM stdin;
\.


--
-- Data for Name: content_provenance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.content_provenance (id, content_type, content_id, provider, model, generated_at, metadata) FROM stdin;
\.


--
-- Data for Name: content_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.content_tags (id, tag_id, content_type, content_id, created_at) FROM stdin;
\.


--
-- Data for Name: content_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.content_versions (id, content_type, content_id, version, data, editor_id, change_note, created_at) FROM stdin;
\.


--
-- Data for Name: crash_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crash_reports (id, user_id, session_id, error_type, error_message, stack_trace, platform, app_version, device_model, os_version, additional_data, created_at, is_resolved, resolved_by_id, resolved_at) FROM stdin;
\.


--
-- Data for Name: daily_missions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.daily_missions (id, slug, name, description, mission_type, target_count, xp_reward, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: email_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_templates (id, key, name, subject_template, body_html, body_text, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: embedding_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.embedding_jobs (id, status, total_documents, processed_documents, started_at, completed_at, error_message, created_by_id, created_at) FROM stdin;
\.


--
-- Data for Name: experiment_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.experiment_events (id, experiment_id, user_id, assignment_id, event_type, event_name, event_value, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: experiment_metric_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.experiment_metric_events (id, experiment_id, user_id, variant, metric_name, metric_value, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: experiments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.experiments (id, key, name, description, variants, is_active, start_date, end_date, created_at, created_by_id, target_audience) FROM stdin;
\.


--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_flags (id, key, name, description, is_enabled, rollout_percentage, user_whitelist, created_at, updated_at, user_blacklist, rules, created_by_id) FROM stdin;
\.


--
-- Data for Name: friend_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.friend_requests (id, from_user_id, to_user_id, status, created_at, responded_at) FROM stdin;
\.


--
-- Data for Name: guest_previews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.guest_previews (id, session_id, preview_lesson_id, started_at, completed_at, converted_to_user_id, device_info, created_at) FROM stdin;
\.


--
-- Data for Name: heart_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.heart_transactions (id, user_id, user_hearts_id, amount, reason, balance_after, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: lesson_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lesson_cache (id, user_id, lesson_id, cached_at, cache_version, file_size_bytes, is_valid, expires_at) FROM stdin;
\.


--
-- Data for Name: lesson_content; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lesson_content (id, motif_id, intro_text, description, historical_context, symbolism, fun_fact, audio_narration_url, additional_images, video_url, is_published, is_ai_generated, created_at, updated_at, status, submitted_for_review_at, reviewed_by_id, reviewed_at, review_notes, content_rating, preview_eligible, difficulty_level, estimated_time_minutes, version, last_editor_id, published_at, publish_note) FROM stdin;
4c6ceced-3acf-4562-a0de-001d13e70204	bf4a67a3-162d-4d04-98b0-adff8a1860f1	Thụy hiệu 'Cao' của vua Gia Long - người sáng lập triều Nguyễn	Chữ 'Cao' là thụy hiệu (tên tôn vinh) của vua Gia Long (1762-1820), vị hoàng đế sáng lập triều Nguyễn và thống nhất đất nước sau nhiều thế kỷ chia cắt. Cao Đỉnh được đúc vào năm 1835 dưới triều vua Minh Mạng để tưởng nhớ công lao to lớn của vua cha. Trên bề mặt đỉnh, chữ 'Cao' được chạm khắc nổi bật với nét chữ Hán uy nghiêm, thể hiện sự tôn kính của con cháu đối với tổ tiên. Xung quanh chữ 'Cao' là các họa tiết rồng phượng, mây vân và cảnh vật thiên nhiên, tượng trưng cho sự thịnh vượng và bền vững của triều đại. Cao Đỉnh không chỉ là một tác phẩm nghệ thuật đúc đồng tinh xảo mà còn là biểu tượng của lòng hiếu thảo và sự kế thừa truyền thống trong văn hóa Việt Nam.	Cửu Đỉnh được vua Minh Mạng cho đúc từ năm 1835 đến 1837, lấy cảm hứng từ Cửu Đỉnh của nhà Hạ ở Trung Quốc. Cao Đỉnh là đỉnh đầu tiên trong chín chiếc, dành riêng để tôn vinh vua Gia Long - người đã dẹp yên loạn Tây Sơn, thống nhất đất nước và mở ra triều đại Nguyễn kéo dài 143 năm (1802-1945). Việc đúc Cửu Đỉnh thể hiện khát vọng của vua Minh Mạng về một triều đại vững mạnh, trường tồn như chín chiếc đỉnh đồng bất diệt.	Chữ 'Cao' không chỉ là tên thụy hiệu mà còn mang ý nghĩa 'cao quý', 'cao cả', thể hiện đức độ và công lao vĩ đại của vua Gia Long. Trong văn hóa Việt Nam, việc đặt tên thụy hiệu cho vua sau khi băng hà là truyền thống quan trọng, thể hiện lòng tôn kính và ghi nhớ công đức của bậc tiền nhân. Cao Đỉnh đặt ở vị trí trung tâm trong Cửu Đỉnh, khẳng định vai trò nền tảng của vua Gia Long đối với triều Nguyễn.	Cao Đỉnh nặng khoảng 2.600 kg và cao 2,3 mét, là một trong những chiếc đỉnh lớn nhất. Để đúc Cửu Đỉnh, vua Minh Mạng đã thu thập đồng từ khắp cả nước, bao gồm cả vũ khí, đồ dùng cũ và đồng tiền. Điều này tượng trưng cho sự đoàn kết của toàn dân trong việc xây dựng quốc gia.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
6144b3d8-a446-4114-bedb-56e196ef5d62	9e95bea4-a087-4dc5-ade2-c4e453878f41	Con rồng - biểu tượng tối cao của quyền lực hoàng đế và sức mạnh thiên nhiên	Rồng là linh vật thiêng nhất trong văn hóa Việt Nam và Đông Á, đại diện cho quyền lực tối cao của hoàng đế. Trên Cao Đỉnh, hình ảnh rồng được chạm khắc tinh xảo với thân uốn lượn mềm mại, vảy rồng sắc nét từng chi tiết, và móng vuốt mạnh mẽ. Rồng Việt Nam có đặc điểm riêng biệt: thân dài, không cánh nhưng có thể bay nhờ sức mạnh thần thánh, thường gắn liền với nước và mây. Trong triết học phương Đông, rồng tượng trưng cho sự kết hợp giữa trời và đất, giữa âm và dương, là biểu tượng của sự sinh sôi và phồn thịnh. Vua Gia Long đã chọn hình ảnh rồng cho Cao Đỉnh để khẳng định vị thế của triều đại Nguyễn là chính thống kế thừa các triều đại trước. Hình ảnh rồng trên Cửu Đỉnh không chỉ thể hiện uy quyền hoàng gia mà còn là lời khẳng định về nguồn gốc thần thoại của dân tộc Việt - con rồng cháu tiên.	Cao Đỉnh được đúc vào năm 1835 dưới triều Minh Mạng, dành riêng để tưởng nhớ vua Gia Long - người sáng lập triều Nguyễn. Hình ảnh rồng trên đỉnh này không chỉ là biểu tượng hoàng quyền mà còn thể hiện khát vọng thống nhất đất nước sau nhiều thế kỷ chia cắt. Trong lịch sử Việt Nam, chỉ hoàng đế mới được sử dụng hình ảnh rồng năm móng, còn các quan lại và hoàng tử chỉ được dùng rồng bốn móng hoặc ba móng. Điều này thể hiện sự phân biệt đẳng cấp nghiêm ngặt trong xã hội phong kiến.	Trong văn hóa Việt Nam, rồng là con vật linh thiêng nhất trong Tứ Linh (Long - Lân - Quy - Phụng), đại diện cho sức mạnh, trí tuệ, may mắn và quyền lực. Người Việt tự hào gọi mình là 'con rồng cháu tiên', xuất phát từ truyền thuyết Lạc Long Quân và Âu Cơ. Rồng còn tượng trưng cho sự bảo vệ và phù hộ đất nước, là linh vật giữ gìn hòa bình và thịnh vượng. Trên Cửu Đỉnh, rồng được khắc họa với tư thế uy nghiêm, thể hiện sức mạnh bảo vệ giang sơn và quyền lực tối cao của hoàng đế.	Khác với rồng phương Tây có cánh và phun lửa, rồng Việt Nam có thân dài, không cánh nhưng có thể bay nhờ sức mạnh thần thánh. Rồng Việt thường gắn liền với nước và mây, tượng trưng cho sự sinh sôi và phồn thịnh. Theo truyền thuyết, rồng có thể biến hóa vô cùng: lớn thì che cả bầu trời, nhỏ thì ẩn trong hạt cát. Điều thú vị là rồng Việt Nam có râu dài và sừng hươu, khác biệt với rồng Trung Quốc.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
8b08664a-17bc-404d-b553-bb45b9051cba	036b8060-4597-4028-bded-135081787c70	Cây mít (Ba La Mật) - biểu tượng của sự sung túc và phồn thịnh trong văn hóa nông nghiệp Việt Nam	Ba La Mật là tên Hán Việt của cây mít (Artocarpus heterophyllus), một loài cây ăn quả đặc trưng của vùng nhiệt đới Đông Nam Á. Trên Cao Đỉnh, hình ảnh cây mít được khắc họa với những trái mít to lớn, lá xanh tươi và thân cây vững chãi, thể hiện sự sung túc và phồn thịnh của đất nước. Mít là loại cây ăn quả quen thuộc trong các làng quê Việt Nam, thường được trồng quanh nhà, bên ao, tạo bóng mát và cho trái quanh năm. Trái mít có thể nặng tới 30-40kg, là loại trái cây lớn nhất mọc trên cây trên thế giới. Trong văn hóa Việt Nam, cây mít tượng trưng cho sự bền bỉ, lâu dài và khả năng sinh sản mạnh mẽ. Việc khắc họa cây mít trên Cửu Đỉnh thể hiện sự trân trọng của triều đình đối với nền nông nghiệp - nền tảng kinh tế của đất nước. Tên gọi 'Ba La Mật' còn mang ý nghĩa Phật giáo, liên quan đến 'Bát Nhã Ba La Mật Đa' (Prajñāpāramitā), thể hiện sự giao thoa văn hóa Phật giáo trong xã hội Việt Nam thời phong kiến.	Cây mít có nguồn gốc từ Ấn Độ và được du nhập vào Việt Nam từ rất sớm, trở thành một phần không thể thiếu trong đời sống nông thôn. Vào thời triều Nguyễn, nông nghiệp là nền tảng kinh tế chính, và các loại cây ăn quả như mít, chuối, dừa được coi trọng. Việc khắc họa cây mít trên Cao Đỉnh phản ánh chính sách 'trọng nông' của triều đình, khuyến khích người dân phát triển sản xuất nông nghiệp. Cây mít cũng xuất hiện trong nhiều ca dao, tục ngữ Việt Nam, thể hiện sự gắn bó sâu sắc với đời sống văn hóa dân gian.	Trong văn hóa Việt Nam, cây mít tượng trưng cho sự sung túc, phồn thịnh và đoàn tụ. Trái mít to lớn với hàng trăm múi cùng chung một trái biểu trưng cho sự đoàn kết, sum họp của gia đình và cộng đồng. Gỗ mít cứng chắc, bền lâu, thường được dùng làm đồ thờ cúng và đồ gỗ cao cấp, tượng trưng cho sự trường tồn. Lá mít xanh tươi quanh năm, thể hiện sức sống bền bỉ. Trong Phật giáo, tên 'Ba La Mật' gắn liền với khái niệm 'đến bờ giác ngộ', mang ý nghĩa tâm linh sâu sắc.	Trái mít là loại trái cây lớn nhất mọc trên cây trên thế giới, có thể nặng tới 50kg! Một điều thú vị là mít có hai loại chính: mít tố (cơm mềm, ngọt) và mít nghệ (cơm giòn, thơm). Người Việt Nam sử dụng mít rất đa dạng: ăn tươi, làm mứt, nấu chè, thậm chí hạt mít còn có thể luộc ăn như hạt dẻ. Gỗ mít được coi là loại gỗ quý, có màu vàng đẹp và rất bền, thường được dùng để chạm khắc tượng Phật và đồ thờ cúng.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
af596369-390e-4404-b7fb-93d955c95220	a9d3e605-ac3e-44ef-bf07-8712b6b4eefd	Lúa tẻ - nguồn lương thực chính yếu nuôi sống người Việt từ ngàn xưa	Canh là tên Hán Việt chỉ lúa tẻ (Oryza sativa), loại cây lương thực quan trọng nhất trong nền văn minh lúa nước của người Việt và khu vực Đông Nam Á. Khác với lúa nếp (thường dùng làm bánh, đồ xôi cúng lễ), lúa tẻ là nguồn lương thực hàng ngày, nuôi sống bao thế hệ. Hình ảnh cây lúa trĩu hạt được chạm khắc trên Cao Đỉnh không chỉ thể hiện sự no ấm, phồn thịnh mà còn là lời nhắc nhở của triều đình về tầm quan trọng của 'nông vi bản' (lấy nông nghiệp làm gốc). Trong xã hội phong kiến, sự ổn định của vương triều phụ thuộc rất lớn vào sự no đủ của người dân, và cây lúa chính là thước đo của sự bình an đó. Việc khắc hình cây lúa lên đỉnh cao nhất (Cao Đỉnh) cho thấy vua Minh Mạng đặt sự an nguy của lê dân và nền nông nghiệp lên hàng đầu, ngang hàng với các biểu tượng quyền lực khác.	Vào đầu triều Nguyễn, sau nhiều năm chiến tranh loạn lạc, việc khôi phục sản xuất nông nghiệp là ưu tiên hàng đầu. Vua Gia Long và sau đó là Minh Mạng đã ban hành nhiều chính sách khuyến nông, khai hoang, lập ấp (như công cuộc khẩn hoang vùng Đồng bằng sông Cửu Long). Hình ảnh cây lúa tẻ trên Cao Đỉnh là sự ghi nhận công lao của người nông dân và khẳng định cam kết của triều đình trong việc bảo đảm an ninh lương thực quốc gia.	Cây lúa tẻ tượng trưng cho sự no ấm, bình an và ổn định. Hạt gạo được ví là 'hạt ngọc trời', kết tinh từ mồ hôi công sức của con người và tinh túy của đất trời. Trong tâm thức người Việt, lúa gạo không chỉ là thức ăn mà còn là lễ vật dâng cúng tổ tiên, thể hiện lòng biết ơn nguồn cội. Bông lúa trĩu hạt cúi đầu còn là bài học về sự khiêm cung của người quân tử.	Việt Nam là cái nôi của nền văn minh lúa nước và hiện là một trong những quốc gia xuất khẩu gạo hàng đầu thế giới. Có hàng ngàn giống lúa tẻ khác nhau, thích nghi với nhiều điều kiện thổ nhưỡng. Ngày xưa, 'cơm tẻ' là biểu tượng của bữa ăn hàng ngày, còn 'xôi nếp' thường dành cho dịp lễ tết, nên có câu 'nếp tẻ đều có' để chỉ sự đầy đủ, sung túc.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
1361c8fd-9379-476a-aa60-cd81b9526eb6	5bc76464-b9ab-4428-9462-7cd317515cde	Chim Vàng Anh - tiếng hót lảnh lót, sắc vàng hoàng gia.	Hoàng Anh (Chim vàng anh/Hoàng ly) là loài chim định cư phổ biến, nổi tiếng với bộ lông màu vàng chanh rực rỡ và tiếng hót hay như tiếng sáo. Trong truyện cổ tích Tấm Cám, cô Tấm thảo hiền đã hóa thân thành chim vàng anh để ở bên vua, thể hiện lòng chung thủy và sự tái sinh. Hình ảnh chim vàng anh trên Thuần Đỉnh vừa mang tính thẩm mỹ cao (màu vàng là màu vua chúa), vừa gợi nhắc kho tàng văn học dân gian phong phú.	Tiếng chim vàng anh hót thường báo hiệu mùa hè. Các nhà thơ xưa thường mượn hình ảnh 'Hoàng ly' để tả cảnh thanh bình nơi thôn dã hoặc chốn cung đình.	Chim vàng anh tượng trưng cho niềm vui, sự cao sang (màu vàng) và sự chung thủy. Tiếng hót của nó xua tan u sầu.	Chim vàng anh làm tổ dạng giỏ treo trên cành cây cao rất khéo léo. Chúng ăn sâu bọ và trái cây.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
a17a32d4-7ebe-4527-80ff-72e5e00eadfc	31f8cc7a-149b-40b2-9f60-3c073513673a	Cây hành - loại gia vị quen thuộc, tượng trưng cho khí dương và sự thông suốt	Chữ 'Thông' (蔥) ở đây chỉ cây hành, một loại rau gia vị không thể thiếu trong ẩm thực Việt Nam, chứ không phải cây thông (tùng). Cây hành có tính nóng, vị cay, thuộc dương, có tác dụng giải cảm, làm ấm cơ thể. Trong y học cổ truyền và ẩm thực, hành đóng vai trò cân bằng âm dương cho món ăn. Việc khắc cây hành trên Cao Đỉnh - chiếc đỉnh tôn vinh vua Gia Long - có thể mang ý nghĩa về sự 'thông suốt', minh mẫn và khả năng điều hòa, quản trị đất nước. Nó cũng cho thấy sự quan tâm của triều đình đến những sản vật gần gũi, thiết thực nhất trong đời sống dân sinh, không chỉ là những thứ cao sang quyền quý.	Vào thế kỷ 19, các loại gia vị như hành, tỏi, tiêu, ớt đóng vai trò quan trọng trong việc bảo quản thực phẩm và chữa bệnh thông thường cho binh lính và người dân. Việc đưa một loại rau gia vị bình dị lên 'bảo vật quốc gia' như Cửu Đỉnh thể hiện cái nhìn thực tế và bao quát của vua Minh Mạng: trân trọng mọi nguồn lợi của đất nước, dù nhỏ bé.	Trong văn hóa, hành (蔥) đồng âm với 'thông' (của thông minh, thông suốt). Do đó, cây hành còn là biểu tượng của trí tuệ, sự sáng suốt và sự hanh thông trong mọi việc. Hành có tính sinh trưởng mạnh, dễ trồng, tượng trưng cho sức sống mãnh liệt và khả năng thích nghi của người Việt.	Bạn có biết rằng hành lá chứa nhiều vitamin C và chất chống oxy hóa? Trong dân gian Việt Nam, bát cháo hành không chỉ là món ăn giải cảm hiệu quả (như trong tác phẩm Chí Phèo) mà còn là biểu tượng của tình người ấm áp. Việc khắc cây hành lên đỉnh đồng uy nghiêm là một nét độc đáo, cho thấy sự gần gũi giữa triều đình và đời sống dân dã.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
28c4ed45-4ce4-4f75-b0bd-189edab3cbe5	d27e9e0b-a9eb-42a2-8466-83442f48939d	Hoa tường vi - loài hoa sắc tím hồng rực rỡ, biểu tượng của sự thịnh vượng và bảo vệ	Tử Vi Hoa hay hoa tường vi (Lagerstroemia) là loài hoa thân gỗ, nở thành từng chùm lớn với màu sắc rực rỡ từ hồng, tím đến trắng. Trên Cao Đỉnh, hoa tường vi được chạm khắc tinh tế, thể hiện vẻ đẹp thanh tao nhưng cũng đầy sức sống. Loài hoa này thường được trồng trong các cung điện, đền đài và khuôn viên quyền quý thời xưa. Tên gọi 'Tử Vi' còn liên quan đến chòm sao Tử Vi trong thiên văn học phương Đông, ngôi sao chủ về quyền lực và vận mệnh đế vương. Do đó, loài hoa này mang hàm ý về sự bảo trợ của thần linh đối với hoàng tộc và sự trường tồn của vương triều.	Hoa tường vi rất được ưa chuộng trong kiến trúc cảnh quan cung đình Huế. Với khả năng chịu hạn tốt và nở hoa rực rỡ vào mùa hè, nó tượng trưng cho sức sống bền bỉ vượt qua khắc nghiệt. Việc chọn khắc hoa tường vi lên Cao Đỉnh cho thấy gu thẩm mỹ tinh tế của người xưa và mong muốn vương triều luôn rực rỡ như hoa.	Màu tím hồng của tường vi (Tử) thường gắn liền với sự cao quý, huyền bí. Trong phong thủy, cây tường vi được cho là có khả năng xua đuổi tà khí, mang lại sự bình an cho gia chủ. Nó cũng tượng trưng cho tình yêu chung thủy và sự gắn bó keo sơn trong gia đình.	Cây tường vi có thân rất nhẵn, vỏ cây thường bong ra từng mảng, nên ở một số nơi còn gọi là 'cây sờ cù' (vì sờ vào trơn láng như cù lét). Mặc dù có vẻ ngoài mong manh, cánh hoa mỏng như giấy, nhưng tường vi lại có sức sống rất mãnh liệt và thời gian nở hoa kéo dài nhiều tháng.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
7afbce58-5d0f-42d8-9ff7-aeb2da30140c	284e4bb9-a798-45a1-9926-4e9cc8debdcc	Chim trĩ - loài chim có bộ lông lộng lẫy, biểu tượng của vẻ đẹp vương giả và điềm lành	Chim trĩ (Phasianidae) là loài chim có bộ lông đuôi dài và màu sắc sặc sỡ, thường được ví với vẻ đẹp của phượng hoàng trong đời thực. Trong hệ thống quan phục triều Nguyễn, hình ảnh chim trĩ được dùng để trang trí trên áo mũ của các quan văn, biểu thị cho sự nho nhã, văn hay chữ tốt. Trên Cao Đỉnh, chim trĩ được khắc họa với dáng vẻ kiêu sa, đuôi dài uốn lượn, tượng trưng cho vẻ đẹp văn hóa và sự thịnh trị của triều đại. Người xưa tin rằng chim trĩ xuất hiện là điềm báo của thánh nhân ra đời hoặc đất nước thái bình.	Chim trĩ là một trong 12 huy hiệu trên áo cổn (loại long bào trang trọng nhất) của vua chúa phương Đông. Triều Nguyễn rất chú trọng đến lễ nghi và trang phục, nên hình ảnh chim trĩ xuất hiện nhiều trong nghệ thuật cung đình. Nó đại diện cho 'Văn' (văn hóa, văn học), bổ sung cho 'Võ' (sức mạnh quân sự), tạo nên sự cân bằng trong trị quốc.	Chim trĩ tượng trưng cho sự son sắt, thủy chung (vì trĩ thường đi có đôi). Ngoài ra, với bộ lông lộng lẫy, trĩ còn là biểu tượng của vinh hoa phú quý và tước lộc (chức tước, bổng lộc). Trong văn học, 'trĩ' thường đi đôi với 'thần' (con sò lớn) để chỉ sự biến hóa của vạn vật theo mùa.	Chim trĩ có tập tính rất thú vị: khi gặp nguy hiểm, chúng thường chui đầu vào bụi rậm nhưng để hở phần đuôi dài sặc sỡ ra ngoài. Trong tự nhiên, chim trĩ trống đẹp hơn chim mái rất nhiều để thu hút bạn tình. Lông trĩ dài và đẹp thường được dùng để trang trí mũ mão của các tướng lĩnh trong tuồng cổ.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
dd66d071-c5f6-4ae5-9c5e-d222de1d1d53	ee64b246-96ba-4a9f-87a5-524fb427d54f	Biển Đông - vùng biển rộng lớn, cửa ngõ giao thương và chủ quyền thiêng liêng của Đại Nam	Đông Hải tức Biển Đông, vùng biển bao la nằm ở phía đông nước ta, là nguồn sống và không gian sinh tồn của dân tộc Việt từ ngàn xưa. Việc khắc hình ảnh Biển Đông lên Cao Đỉnh - chiếc đỉnh cao quý nhất - là một tuyên bố đanh thép về chủ quyền biển đảo của vua Minh Mạng và triều Nguyễn. Hình ảnh sóng nước mênh mông cuộn trào trên đỉnh đồng thể hiện sự hùng vĩ của thiên nhiên và khát vọng vươn ra biển lớn. Biển Đông không chỉ cung cấp tôm cá, muối, hải sản mà còn là tuyến đường giao thương huyết mạch kết nối Đại Nam với thế giới bên ngoài. Đây là minh chứng lịch sử quan trọng khẳng định tư duy hướng biển của cha ông ta.	Dưới triều Nguyễn, đặc biệt là thời Minh Mạng, hoạt động thực thi chủ quyền trên biển rất mạnh mẽ. Vua thường xuyên cử các đội hùng binh Hoàng Sa, Bắc Hải ra đo đạc, cắm mốc và vẽ bản đồ tại hai quần đảo Hoàng Sa và Trường Sa. Việc khắc 'Đông Hải' lên Cửu Đỉnh năm 1835 là một hành động khẳng định chủ quyền lãnh thổ quốc gia bằng văn bản hình ảnh (visual text) có giá trị pháp lý cao nhất thời bấy giờ.	Biển Đông tượng trưng cho sự bao la, khoáng đạt và nguồn tài nguyên vô tận. Nó cũng đại diện cho những hiểm nguy, thử thách mà dân tộc phải vượt qua (bão tố, giặc ngoại xâm). Trong phong thủy, nước (Thủy) là yếu tố mang lại tài lộc, sự lưu thông và thịnh vượng.	Biển Đông là một trong những biển lớn nhất thế giới. Trên Cửu Đỉnh, không chỉ có Biển Đông mà còn có Nam Hải (Biển Nam) và Tây Hải (Biển Tây), cho thấy sự am hiểu tường tận về địa lý biển đảo của người xưa. Hình ảnh sóng nước trên đỉnh được chạm khắc rất sinh động, có lớp lang, thể hiện kỹ thuật đúc đồng đỉnh cao.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
acc0543d-d989-4df7-bcd0-4d982a169e19	09275995-9116-49af-8ddb-bea8c2255ca9	Kênh Vĩnh Tế - công trình thủy lợi vĩ đại nhất thời Nguyễn, biểu tượng của sức mạnh chinh phục thiên nhiên	Vĩnh Tế Hà là con kênh đào lớn nhất trong lịch sử phong kiến Việt Nam, chạy dọc biên giới Tây Nam (An Giang - Kiên Giang ngày nay). Kênh được khởi công năm 1819 dưới thời Gia Long và hoàn thành năm 1824 thời Minh Mạng, do danh tướng Thoại Ngọc Hầu chỉ huy. Việc khắc hình ảnh kênh Vĩnh Tế lên Cao Đỉnh là sự ghi nhận công lao to lớn của hàng vạn dân binh đã đổ mồ hôi, xương máu để đào kênh. Con kênh này có ý nghĩa chiến lược cực kỳ quan trọng: vừa là hào lũy bảo vệ biên giới, vừa giúp thau chua rửa phèn, phát triển nông nghiệp và giao thông đường thủy cho cả vùng Tứ giác Long Xuyên.	Kênh dài gần 90km, rộng 30m, được đào hoàn toàn bằng thủ công trong điều kiện khắc nghiệt 'muỗi kêu như sáo thổi, đỉa lội tựa bánh canh'. Tên kênh được vua Gia Long đặt theo tên vợ của Thoại Ngọc Hầu là bà Châu Thị Vĩnh Tế, để tôn vinh đức hạnh của bà. Đây là một ngoại lệ hiếm hoi trong lịch sử khi tên một phụ nữ được đặt cho một công trình quốc gia và khắc lên bảo vật triều đình.	Kênh Vĩnh Tế biểu trưng cho ý chí dời non lấp biển của người Việt, khả năng cải tạo thiên nhiên để phục vụ cuộc sống. Nó cũng là biểu tượng của sự trấn giữ biên cương và tầm nhìn chiến lược về an ninh quốc phòng của các vua đầu triều Nguyễn.	Khi đào kênh, người xưa đã dùng những cây tre dài để làm 'thước ngắm' kẻ đường thẳng tắp trên vùng đất hoang vu. Kênh Vĩnh Tế thẳng đến mức đứng từ đầu này có thể nhìn thấy ánh đuốc ở đầu kia (theo truyền thuyết). Đây là một kỳ tích về kỹ thuật trắc đạc thời bấy giờ.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
a9e80d06-51ca-48fc-a452-21fb52068e16	798e6ca7-ca19-4851-b320-889549db1096	Mặt trời - thái dương, nguồn gốc của sự sống và biểu tượng của đấng quân vương	Nhật (Mặt trời) là hình ảnh thiên văn quan trọng nhất, được khắc ở vị trí trang trọng trên Cao Đỉnh. Trong quan niệm phương Đông, mặt trời là 'Thái Dương', đại diện cho khí Dương cực thịnh, nguồn năng lượng vĩnh cửu nuôi dưỡng vạn vật. Mặt trời cũng là biểu tượng của Hoàng đế (Thiên tử - con trời), người thay trời hành đạo, mang ánh sáng văn minh và công lý đến cho muôn dân. Hình ảnh mặt trời trên đỉnh thường được thể hiện dưới dạng đĩa tròn tỏa sáng hoặc chim quạ ba chân (Tam túc ô) trong vòng tròn, tượng trưng cho huyền thoại.	Triều Nguyễn, cũng như các triều đại phong kiến khác, coi vua là trung tâm của vũ trụ nhân gian, như mặt trời là trung tâm của bầu trời. Việc đặt hình tượng Mặt trời lên đỉnh cao nhất (Cao Đỉnh) khẳng định quyền lực tập trung tuyệt đối của nhà vua và tính chính danh của triều đại.	Mặt trời tượng trưng cho sự thật, sự minh bạch (quang minh chính đại), trí tuệ và sự giác ngộ. Nó xua tan bóng tối, tà ác và mang lại sự sống ấm áp. Trong cặp phạm trù Âm - Dương, Mặt trời (Nhật) đi đôi với Mặt trăng (Nguyệt), tạo nên sự cân bằng hoàn hảo của vũ trụ.	Trên Cửu Đỉnh, Mặt trời (Nhật) ở Cao Đỉnh đối ứng với Mặt trăng (Nguyệt) ở Nhân Đỉnh. Điều này thể hiện triết lý 'Nhật Nguyệt trùng minh' (Mặt trời mặt trăng cùng chiếu sáng), ám chỉ thời đại thái bình thịnh trị, vua sáng tôi hiền.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
aa64e1c6-405f-4ee6-a78e-2811d7881094	9401eb10-9469-4b4a-963a-68041441569b	Sông Bến Nghé - huyết mạch giao thông và thương mại sầm uất của vùng đất Gia Định xưa	Ngưu Chữ Giang tức sông Bến Nghé (hay rạch Bến Nghé) tại Sài Gòn - Gia Định. Tên gọi 'Ngưu Chữ' (Bến Trâu) xuất phát từ giai thoại bến nước này xưa kia thường có trâu ra uống nước, hoặc do hình dáng sông giống bụng trâu. Đây là tuyến đường thủy quan trọng bậc nhất, cửa ngõ giao thương của vùng đất Nam Bộ trù phú. Việc khắc sông Bến Nghé lên Cao Đỉnh cho thấy tầm nhìn của triều Nguyễn về vai trò chiến lược kinh tế và quốc phòng của vùng đất Sài Gòn - Gia Định đối với cả nước. Dòng sông này đã chứng kiến quá trình khai phá, xây dựng và bảo vệ vùng đất phương Nam của cha ông ta.	Sài Gòn - Gia Định là nơi phát tích cơ nghiệp của chúa Nguyễn trong công cuộc Nam tiến. Bến Nghé là nơi tàu thuyền buôn bán tấp nập, tạo nên câu ca 'Nhà Bè nước chảy chia hai, ai về Gia Định Đồng Nai thì về'. Sự hiện diện của nó trên Cửu Đỉnh khẳng định sự thống nhất toàn vẹn lãnh thổ từ Bắc chí Nam.	Sông Bến Nghé tượng trưng cho sự phồn vinh của thương mại, sự giao lưu văn hóa và sự mở mang bờ cõi. Dòng sông hiền hòa nhưng cũng là chứng nhân lịch sử kiên cường của người dân Nam Bộ.	Có truyền thuyết kể rằng tên 'Bến Nghé' là do tiếng cá sấu kêu ban đêm nghe như tiếng trâu nghé (trâu con). Dù nguồn gốc tên gọi là gì, Bến Nghé vẫn luôn là một địa danh thân thương và quan trọng trong tâm thức người Sài Gòn.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
002ef086-3445-4162-b020-7a1376a5290f	f3a49a22-ec62-492e-a662-29419f1c2fca	Núi Thiên Tôn - ngọn núi thiêng tại vùng đất quý hương Gia Miêu, cội nguồn của vương triều Nguyễn	Thiên Tôn Sơn là ngọn núi nằm ở thôn Gia Miêu, huyện Hà Trung, tỉnh Thanh Hóa. Đây được coi là đất 'quý hương', nơi phát tích của dòng họ Nguyễn (Nguyễn Kim, Nguyễn Hoàng). Việc khắc núi Thiên Tôn lên Cao Đỉnh thể hiện đạo lý 'uống nước nhớ nguồn', sự tri ân của các vua Nguyễn đối với tổ quán và nơi khởi nghiệp của cha ông. Ngọn núi này được xem là trấn sơn, giữ gìn long mạch và vượng khí cho cả vương triều. Trong tâm thức phong kiến, sự bền vững của triều đại gắn liền với sự linh thiêng của đất tổ.	Vua Gia Long và Minh Mạng đều đã từng về bái yết lăng miếu tổ tiên tại vùng Gia Miêu Ngoại Trang này. Núi Thiên Tôn không chỉ là địa danh địa lý mà còn là không gian thiêng liêng, nơi thờ phụng các bậc tiên đế.	Núi Thiên Tôn tượng trưng cho cội nguồn, nền tảng vững chắc và sự kết nối giữa quá khứ với hiện tại. Tên gọi 'Thiên Tôn' (Cháu Trời/Đạo Trời tôn quý) cũng mang hàm ý về sự chính danh và mệnh trời của dòng họ cai trị.	Vùng đất Hà Trung, Thanh Hóa không chỉ là quê hương nhà Nguyễn mà còn liên quan đến nhiều triều đại khác trong lịch sử Việt Nam (như nhà Hồ, nhà Lê). Địa thế núi sông ở đây được các thầy phong thủy xưa đánh giá là 'địa linh nhân kiệt'.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
c918b637-0ac9-470e-9422-fa9bf3eec30f	a42b833e-c260-4293-9fca-b5c8995c5651	Cây gỗ lim - loài gỗ tứ thiết, biểu tượng của sự cứng cỏi và trường tồn	Thiết Mộc (cây gỗ sắt) thường được hiểu là cây gỗ Lim (Erythrophleum fordii), đứng đầu trong nhóm 'tứ thiết' (đinh, lim, sến, táu) của Việt Nam. Đây là loài cây thân gỗ lớn, chất gỗ cực kỳ cứng, nặng, không bị mối mọt, thường được dùng để làm cột đình, chùa, cung điện và đóng tàu thuyền chiến. Việc khắc Thiết Mộc lên Cao Đỉnh tôn vinh nguồn tài nguyên rừng phong phú của nước Nam và phẩm chất kiên định, vững chãi của quốc gia. Những cột gỗ lim hàng trăm năm tuổi trong Đại Nội Huế là minh chứng sống động cho giá trị của loài cây này.	Trong công cuộc xây dựng kinh thành Huế và hạm đội thủy quân, gỗ lim đóng vai trò tối quan trọng. Triều đình có những quy định nghiêm ngặt về việc khai thác và bảo vệ các khu rừng gỗ quý. Thiết mộc trên đỉnh đồng là sự ghi nhận vai trò của tài nguyên rừng trong kiến thiết đất nước.	Gỗ lim (Thiết mộc) tượng trưng cho sự trường thọ, sức mạnh nội tại và khả năng chống chọi với thời gian. Nó đại diện cho cốt cách cứng cỏi, không khuất phục của người quân tử và sự vững bền của xã tắc.	Gỗ lim cứng đến mức khi khô, đinh đóng vào có thể bị cong mà gỗ không nứt. Người xưa có câu 'thương cho roi cho vọt, ghét cho ngọt cho bùi' nhưng với gỗ lim thì 'cứng như lim'. Tuy nhiên, dân gian cũng kiêng dùng gỗ lim làm giường ngủ vì quan niệm gỗ có tính độc hoặc mang năng lượng quá mạnh.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
fe81d22b-0069-42d6-bd2f-53c9649822e6	dcf170b7-345a-4da8-a7fd-b9327517bdc3	Hổ - chúa sơn lâm, biểu tượng của sức mạnh oai phong và khả năng trấn tà	Hổ (Cọp, Hùm, Ông Ba Mươi) là chúa tể của rừng xanh, loài vật tượng trưng cho sức mạnh, sự dũng mãnh và uy quyền trong thế giới tự nhiên. Trên Cao Đỉnh, hình ảnh con hổ được chạm khắc với cơ bắp cuộn nổi, dáng vẻ uy nghi, sẵn sàng vồ mồi. Trong văn hóa quân sự, hổ là biểu tượng của các võ tướng (Hổ tướng), đại diện cho khí phách hiên ngang và khả năng chiến đấu phi thường. Người Việt vừa sợ vừa kính nể hổ, thường lập miếu thờ và gọi một cách tôn kính là 'Ông', 'Ngài'. Sự hiện diện của hổ trên đỉnh đồng mang ý nghĩa trấn áp tà khí, bảo vệ sự bình yên cho vương triều.	Triều Nguyễn có tổ chức các trận đấu giữa Voi và Hổ tại Hổ Quyền (Huế) để rèn luyện tinh thần chiến đấu và giải trí cho hoàng gia. Mặc dù voi thường thắng (do được hỗ trợ), nhưng hổ luôn được nể trọng vì sự hung dữ và sức mạnh. Hổ trên Cao Đỉnh khẳng định sức mạnh quân sự và uy thế của quốc gia.	Hổ tượng trưng cho dương khí, sự quyết đoán và quyền lực thực tế (khác với Rồng là quyền lực thần thánh). Hổ còn là linh vật trấn giữ phương Tây (Bạch Hổ) trong tứ tượng. Trong dân gian, tranh 'Ngũ Hổ' được treo để trừ tà ma.	Tại sao gọi hổ là 'Ông Ba Mươi'? Có nhiều cách giải thích, một trong số đó là lệ xưa ai săn được hổ thì được vua thưởng 30 quan tiền, nhưng cũng bị phạt đánh 30 roi để 'xoa dịu' linh hồn ông hổ. Hoặc do hổ hay về làng vào đêm 30 Tết.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
b11c964f-3010-4fb3-9a46-7caf70106102	d9963208-838a-45ee-a45c-3f22f1c5a157	Đa Tác Thuyền - loại thuyền buồm đi biển cỡ lớn, minh chứng cho kỹ thuật đóng tàu và giao thương hàng hải	Đa Tác Thuyền là tên gọi chỉ một loại thuyền buồm lớn, có khả năng đi biển dài ngày, vận chuyển hàng hóa hoặc dùng trong quân sự. Hình ảnh con thuyền trên Cao Đỉnh với cánh buồm no gió lướt trên sóng nước thể hiện khát vọng vươn ra biển lớn và năng lực hàng hải của người Việt xưa. Dưới triều Nguyễn, kỹ thuật đóng tàu đã có những bước tiến bộ vượt bậc, tiếp thu cả công nghệ phương Tây. Những con thuyền này đóng vai trò huyết mạch trong việc giao thương với các nước trong khu vực và bảo vệ hải đảo. Tên gọi 'Đa Tác' có thể hàm ý về sự đa năng, công phu trong chế tác hoặc 'nhiều công dụng'.	Vua Gia Long và Minh Mạng rất chú trọng phát triển thủy quân và thương cảng. Các thuyền buôn của triều đình (phái bộ) thường xuyên đi đến Singapore, Batavia (Indonesia), thậm chí sang cả phương Tây để buôn bán và mua vũ khí. Hình ảnh thuyền trên Cửu Đỉnh là sự tôn vinh ngành đóng tàu và kinh tế biển.	Con thuyền là biểu tượng của sự thuận buồm xuôi gió, sự di chuyển và giao lưu. Nó mang theo hy vọng về những chuyến đi bình an, mang về tài lộc và tri thức mới. Thuyền cũng tượng trưng cho sự chở che, nâng đỡ (như thuyền bát nhã trong Phật giáo).	Thuyền bè thời Nguyễn không chỉ dùng gỗ thường mà còn dùng các loại gỗ quý chịu nước tốt. Kỹ thuật ghép ván, trát dầu của thợ thủ công Việt Nam rất khéo léo, giúp thuyền chịu được sóng gió Biển Đông.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
23f46cd8-c433-475a-86a9-b7e85dc2b5e2	90c77d97-240a-4854-b5f3-f875362f5c8e	Súng đại bác - hỏa khí uy lực, thần hộ mệnh của kinh thành và biên cương	Đại Bác (Thần công) là loại hỏa khí hạng nặng, biểu tượng cho sức mạnh quân sự tối tân của triều Nguyễn. Hình ảnh khẩu pháo nòng dài đặt trên giá súng được khắc trên Cao Đỉnh thể hiện sự coi trọng của nhà vua đối với quốc phòng. Thời nhà Nguyễn, kỹ thuật đúc súng thần công đạt trình độ rất cao, nổi tiếng nhất là bộ 'Cửu vị thần công' (9 khẩu súng lớn) đặt trước Ngọ Môn. Đại bác không chỉ là vũ khí sát thương mà còn được coi là 'thần' bảo vệ kinh thành, thường được phong tước hiệu. Việc khắc vũ khí lên đỉnh đồng mang thông điệp răn đe kẻ thù và khẳng định khả năng bảo vệ độc lập dân tộc.	Vua Gia Long sau khi thống nhất đất nước đã cho thu thập binh khí nhà Tây Sơn để đúc Cửu vị thần công (1803). Đến thời Minh Mạng, công nghiệp quốc phòng tiếp tục được củng cố. Súng đại bác thời này thường đúc bằng đồng hoặc gang, hoa văn tinh xảo, là niềm tự hào của kỹ nghệ đúc đồng Việt Nam.	Đại bác tượng trưng cho sức mạnh, uy quyền chấn áp và sự bảo vệ an toàn tuyệt đối. Tiếng nổ của đại bác (trong các dịp lễ) được coi là tiếng sấm của triều đình, xua đuổi tà ma và báo hiệu sự uy nghiêm.	Các khẩu thần công thời Nguyễn thường được đặt tên và phong tước (như Tướng quân). Mặc dù uy lực, nhưng Cửu vị thần công trước Ngọ Môn chưa bao giờ được dùng trong chiến trận thực tế mà chỉ mang tính biểu tượng và dùng trong nghi lễ.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
defca50d-6443-4a3f-942e-bcf1ecba095d	067a0a69-1a95-4489-9a38-b4565b61c9e1	Trầm hương - 'Vua của các mùi hương', báu vật linh thiêng của núi rừng Việt Nam	Trầm hương là phần gỗ chứa nhựa thơm đặc biệt sinh ra từ cây Dó Bầu khi bị thương. Đây là một trong những sản vật quý giá nhất của Việt Nam, được mệnh danh là 'kỳ nam', 'khánh hội'. Trên Cao Đỉnh, hình ảnh cây trầm hương khẳng định sự giàu có về tài nguyên thiên nhiên quý hiếm của đất nước. Trầm hương có mùi thơm thanh tao, thoát tục, được dùng trong các nghi lễ tôn giáo, tế tự trời đất và làm thuốc quý. Giá trị của trầm hương thời xưa có thể sánh ngang với vàng, là cống phẩm quan trọng dâng lên triều đình.	Vùng đất miền Trung và Tây Nguyên nước ta nổi tiếng thế giới về trầm hương. Các thương nhân quốc tế từ Nhật Bản, Trung Quốc đến Trung Đông đều khao khát loại hương liệu này. Việc khắc Trầm hương lên đỉnh cao nhất cho thấy đây là niềm tự hào quốc gia, một báu vật đại diện cho tinh túy đất trời.	Trầm hương tượng trưng cho sự linh thiêng, sự kết nối giữa con người và thần linh. Nó cũng đại diện cho phẩm chất cao quý: 'đau thương dó biến thành trầm' - chịu đựng gian khổ (vết thương) để tỏa hương thơm cho đời. Mùi hương trầm có khả năng tịnh hóa tâm hồn, trừ tà khí.	Không phải cây Dó Bầu nào cũng sinh ra trầm. Tỷ lệ tạo trầm trong tự nhiên rất thấp và mất hàng chục năm. Loại trầm thượng hạng gọi là Kỳ Nam, cực kỳ hiếm và đắt đỏ, được ví là 'ngậm ngải tìm trầm' để nói về sự gian nan khi đi tìm nó.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
13c71450-9b64-40cd-bf03-aa47926857bb	63f7f1f5-83b9-4e43-8e94-7debbb3ed2ab	Con ba ba - loài thủy sinh quen thuộc, biểu tượng của sự kiên nhẫn và giá trị thực tiễn	Miết (tên Hán Việt) tức con ba ba, một loài bò sát thuộc bộ Rùa, sống ở các vùng nước ngọt, đầm hồ. Khác với rùa có mai cứng, ba ba có mai mềm và da trơn. Việc khắc hình con ba ba lên Cao Đỉnh - bên cạnh rồng, hổ, đại bác - cho thấy cái nhìn bao dung và thực tế của người xưa: trân trọng cả những loài vật bình dị nhưng có ích. Ba ba là nguồn thực phẩm bổ dưỡng, một vị thuốc trong đông y (tư âm bổ thận). Sự xuất hiện của nó hoàn thiện bức tranh về hệ sinh thái phong phú của sông ngòi Việt Nam.	Trong văn hóa ẩm thực và y học dân gian, ba ba luôn giữ vị trí quan trọng. Việc đưa loài vật này lên Cửu Đỉnh thể hiện sự quan tâm đến mọi khía cạnh đời sống dân sinh, từ cái ăn cái mặc đến sức khỏe. Nó cũng phản ánh sự đa dạng sinh học của vùng sông nước nhiệt đới.	Ba ba, giống như loài rùa, tượng trưng cho sự kiên nhẫn, ẩn nhẫn và tuổi thọ. Tuy nhiên, nó gần gũi với đời sống thường nhật hơn là ý nghĩa tâm linh thần thánh. Hình ảnh ba ba lặn ngụp trong nước gợi lên sự an nhiên tự tại.	Ba ba là loài vật rất hung dữ khi bị đe dọa, vết cắn của nó rất đau và lâu nhả (dân gian hay dọa 'ba ba cắn thì trời gầm mới nhả'). Tuy nhiên, thịt ba ba lại rất ngon và được coi là đặc sản. Trên Cửu Đỉnh, ba ba được khắc họa rất chân thực, sinh động.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
910293a3-1d07-4d37-a29f-f7d03f5719f5	282f77b0-b908-4785-8592-3c8dcb0b9851	Nhân Đỉnh - chiếc đỉnh tượng trưng cho lòng nhân ái và đức độ của vua Minh Mạng.	Nhân Đỉnh là chiếc đỉnh thứ hai trong Cửu Đỉnh, được đặt bên trái của Cao Đỉnh (nếu nhìn từ trong Thế Miếu ra). Chữ 'Nhân' (仁) trong Nho giáo là đức tính quan trọng nhất, đại diện cho lòng yêu thương con người, sự nhân từ và đức độ của bậc quân tử. Vua Minh Mạng (1791-1841) là vị vua thứ hai của triều Nguyễn, người đã có công hoàn thiện bộ máy hành chính và mở rộng lãnh thổ đất nước đến cực đại. Việc lấy chữ 'Nhân' làm thụy hiệu cho đỉnh của ông thể hiện sự tôn vinh đối với công đức cai trị dựa trên nền tảng nho học và lòng nhân ái. Trên thân đỉnh, các họa tiết chạm khắc tinh xảo không chỉ là nghệ thuật mà còn là sự gửi gắm khát vọng về một xã hội hài hòa, nơi người với người đối xử với nhau bằng tình thương. Nhân Đỉnh nặng khoảng 2.500kg, thể hiện sự vững chãi và trường tồn của triều đại.	Được đúc vào năm 1835 cùng với các đỉnh khác, Nhân Đỉnh tôn vinh vua Minh Mạng. Dưới thời trị vì của ông, nước Đại Nam trở thành một quốc gia hùng mạnh bậc nhất Đông Nam Á. Ông là người rất coi trọng việc học hành, thi cử và củng cố nền tảng văn hóa, giáo dục của quốc gia theo tinh thần Nho giáo.	Chữ 'Nhân' là gốc rễ của mọi đức hạnh. Trong ngũ thường (Nhân, Lễ, Nghĩa, Trí, Tín), Nhân đứng đầu. Đặt tên đỉnh là Nhân Đỉnh khẳng định triết lý cai trị của triều Nguyễn là 'đức trị', lấy dân làm gốc, mong muốn mang lại cuộc sống ấm no, hạnh phúc cho muôn dân.	Mặc dù vua Minh Mạng nổi tiếng là người nghiêm khắc trong việc điều hành đất nước, nhưng thụy hiệu của ông lại là 'Nhân', cho thấy cái nhìn của hậu thế về ông là một vị vua có tấm lòng bao dung, lo cho dân cho nước. Vị trí của Nhân Đỉnh (tả) và Chương Đỉnh (hữu) bên cạnh Cao Đỉnh tuân theo quy tắc 'tả chiêu hữu mục' trong thờ cúng tổ tiên.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
4f78eba8-f5e6-49ba-87c7-1894d78a15e5	e2bf57a0-8b09-459f-9213-40c95da2c647	Cây ngô đồng - loài cây vương giả, tương truyền là nơi chim phượng hoàng đậu.	Ngô Đồng (Firmiana simplex) là loài cây thân gỗ cao lớn, vỏ cây màu xanh, lá to xòe rộng. Trong văn hóa phương Đông, Ngô Đồng được coi là loài cây quý phái, gắn liền với huyền thoại về chim Phượng Hoàng. Người xưa có câu: 'Đất lành chim đậu', và Phượng Hoàng - loài chim chúa tể - chỉ chọn cây Ngô Đồng để đậu. Tại Kinh thành Huế, cây Ngô Đồng được trồng nhiều ở các cung điện, lăng tẩm, đặc biệt là sau lưng điện Thái Hòa. Mỗi độ xuân về, khi cây trút hết lá và nở hoa tím hồng rực rỡ cả một góc trời, nó tạo nên vẻ đẹp lộng lẫy, uy nghiêm cho chốn hoàng cung. Việc khắc cây Ngô Đồng lên Nhân Đỉnh thể hiện ước mong thu hút hiền tài (như phượng hoàng) đến giúp nước và khẳng định sự thái bình thịnh trị của vương triều.	Vua Minh Mạng rất yêu thích cây Ngô Đồng và đã cho người đem giống từ Quảng Đông về trồng trong Đại Nội. Ông còn cho khắc hình ảnh cây lên Nhân Đỉnh để lưu truyền mãi mãi. Ngô Đồng ở Huế không chỉ là cây cảnh quan mà còn là nhân chứng lịch sử, chứng kiến bao thăng trầm của triều đại.	Ngô Đồng tượng trưng cho sự cao quý, điềm lành và sự xuất hiện của thánh nhân. Nó cũng biểu thị cho lòng trung thành và sự thanh cao. Hoa Ngô Đồng nở báo hiệu mùa xuân sang, mang ý nghĩa của sự khởi đầu tốt đẹp.	Cây Ngô Đồng còn có tên là 'cây tàn dù' vì tán lá xòe ra như cái dù. Một điều thú vị là quả Ngô Đồng khi chín sẽ nứt ra, hạt rơi xuống đất rất dễ nảy mầm, tượng trưng cho sự sinh sôi nảy nở. Ở Huế, mùa hoa Ngô Đồng thường vào khoảng tháng 2-3 âm lịch, rất đẹp và lãng mạn.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
65f66ffb-8dff-4f8e-944d-512def778789	65b59624-9f96-4713-83e5-ebb5505d61ca	Kỳ Nam - loại trầm hương thượng hạng nhất, quý hơn vàng.	Kỳ Nam là loại trầm hương có phẩm chất cao nhất, được hình thành từ cây Dó Bầu qua hàng trăm năm tích tụ nhựa thơm. Nếu Trầm hương đã quý, thì Kỳ Nam còn quý hiếm gấp bội, được ví là 'vua của các loại hương'. Kỳ Nam có đặc điểm mềm, dẻo, chứa lượng tinh dầu rất lớn, nếm có vị chua, cay, đắng, ngọt, mùi thơm tỏa ra ngào ngạt tự nhiên mà không cần đốt. Xưa kia, Kỳ Nam là cống phẩm chỉ dành riêng cho vua chúa. Việc khắc Kỳ Nam lên Nhân Đỉnh không chỉ khoe sự giàu có về sản vật của nước Nam mà còn mang ý nghĩa tâm linh sâu sắc, vì mùi hương của Kỳ Nam được cho là có thể thấu đến tận trời xanh, kết nối thần linh và tổ tiên.	Dưới triều Nguyễn, triều đình quản lý rất chặt chẽ việc khai thác Kỳ Nam. Những người đi điệu (tìm trầm) nếu tìm được Kỳ Nam phải nộp ngay cho triều đình và được ban thưởng hậu hĩnh. Kỳ Nam thường được dùng làm thuốc cứu người trong những trường hợp nguy kịch hoặc làm gối, vòng tay cho vua để trừ tà, dưỡng khí.	Kỳ Nam tượng trưng cho sự tinh túy, thanh khiết nhất của đất trời ngưng tụ lại. Nó đại diện cho phẩm hạnh cao quý, sự may mắn tột bậc và khả năng xua đuổi mọi tà khí, bệnh tật.	Dân gian có câu 'Nhất Kỳ, nhì Trầm'. Giá trị của Kỳ Nam hiện nay có thể lên tới hàng tỷ đồng, thậm chí cả triệu đô la cho một khối nhỏ, đắt hơn vàng ròng rất nhiều. Kỳ Nam được phân thành 4 loại chính: Bạch Kỳ, Thanh Kỳ, Huỳnh Kỳ và Hắc Kỳ, trong đó Bạch Kỳ là quý nhất.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
87c03709-4f68-4045-a659-9bddfccbb07a	ddcc58bd-deda-4c22-b7f3-cff9f0bcbae5	Sông Lô - dòng sông lịch sử oai hùng nơi biên cương phía Bắc.	Lô Hà (Sông Lô) là một phụ lưu lớn của sông Hồng, chảy qua các tỉnh Hà Giang, Tuyên Quang, Phú Thọ. Sông Lô nổi tiếng với dòng nước trong xanh, cảnh sắc hùng vĩ và những chiến công lẫy lừng trong lịch sử giữ nước (như chiến thắng sông Lô năm 1947 sau này, và các trận thủy chiến thời phong kiến). Việc khắc Lô Hà lên Anh Đỉnh thể hiện sự bao quát lãnh thổ của triều Nguyễn tới tận vùng biên viễn phía Bắc. Dòng sông này đóng vai trò quan trọng trong việc giao thương lâm thổ sản từ miền núi xuống đồng bằng.	Thời Lê - Mạc, sông Lô là chiến trường ác liệt. Đến thời Nguyễn, đây là tuyến đường thủy huyết mạch kiểm soát vùng Đông Bắc. Tên 'Lô' có nghĩa là cái giỏ, có lẽ do địa thế sông.	Sông Lô tượng trưng cho sự hùng tráng, dòng chảy lịch sử và sự kiên cường bảo vệ biên cương. Màu nước xanh biếc của sông Lô cũng đi vào thi ca nhạc họa.	Sông Lô đổ vào sông Hồng tại ngã ba Hạc (Việt Trì). Nơi đây được coi là đất tổ Hùng Vương. Sông Lô có trữ lượng cá chiên (một loại cá da trơn quý) rất lớn và ngon.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
d72e1a8e-f639-4fcd-996b-427e6e1c269c	2ffaa5e2-8f5b-49a3-ae8a-4c28cc9ca106	Lúa nếp - nguyên liệu làm nên những món bánh truyền thống đậm đà bản sắc.	Chữ 'Noa' (糯) chỉ lúa nếp, loại lương thực quan trọng thứ hai sau lúa tẻ (Canh) trong văn hóa ẩm thực Việt Nam. Lúa nếp có hạt tròn, trắng đục, khi nấu lên rất dẻo và thơm. Nếu lúa tẻ là cơm ăn hàng ngày, thì lúa nếp là nguyên liệu chính để làm các loại xôi, bánh chưng, bánh dày, bánh tét... dùng trong các dịp lễ tết, thờ cúng tổ tiên. Hình ảnh bông lúa nếp trĩu hạt trên Nhân Đỉnh thể hiện sự sung túc, no đủ và lòng biết ơn đối với tổ tiên, đất trời. Nó cũng khẳng định nền văn minh lúa nước lâu đời và sự đa dạng của nông sản Việt Nam. Lúa nếp gắn liền với sự đoàn kết, gắn bó (như đặc tính dẻo dính của nó) trong cộng đồng làng xã.	Truyền thuyết 'Bánh chưng bánh dày' thời Hùng Vương đã tôn vinh lúa nếp như một sản vật quý giá nhất để dâng lên vua cha. Triều Nguyễn tiếp nối truyền thống đó, coi trọng việc trồng cấy lúa nếp để phục vụ các nghi lễ cung đình và đời sống dân gian.	Lúa nếp tượng trưng cho sự dẻo dai, gắn kết và lòng hiếu thảo (qua sự tích bánh chưng). Hạt nếp trắng ngần còn biểu thị sự tinh khiết và tấm lòng thơm thảo của người nông dân.	Có rất nhiều giống nếp quý ở Việt Nam như nếp cái hoa vàng, nếp nương, nếp Tú Lệ... Mỗi loại có hương vị đặc trưng riêng. Rượu nếp cũng là một đặc sản được dùng để cúng lễ và đãi khách quý.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
f86d1313-7d4f-4abc-a621-489994aca0b7	b5772322-b791-4fa2-88fa-852bfb254bc9	Trái bòn bon - 'Nam Trân' quý giá, từng cứu đói chúa Nguyễn trong lúc gian nan.	Nam Trân (ngọc quý phương Nam) là tên mỹ miều vua ban cho trái Bòn bon (Lansium parasiticum). Loài cây này mọc nhiều ở vùng núi Quảng Nam. Chuyện kể rằng khi chúa Nguyễn Ánh (sau này là vua Gia Long) bị quân Tây Sơn truy đuổi, phải ẩn náu trong rừng sâu, lương thực cạn kiệt. May thay, ông tìm được loại trái cây này mọc hoang, ăn vào vừa ngọt mát, vừa đỡ đói khát, nhờ đó mà qua cơn hoạn nạn. Khi lên ngôi, nhớ ơn loài cây cứu mạng, ông đã đặt tên là Nam Trân và cho khắc hình lên Nhân Đỉnh. Trái bòn bon mọc thành chùm, vỏ vàng, ruột trắng trong, vị chua ngọt thanh tao, là đặc sản tiến vua nổi tiếng.	Câu chuyện về Nam Trân gắn liền với giai đoạn gian khổ nằm gai nếm mật của vua Gia Long. Việc khắc nó lên đỉnh thể hiện đạo lý 'ăn quả nhớ kẻ trồng cây', không quên những gì đã giúp mình trong lúc khó khăn.	Bòn bon (Nam Trân) tượng trưng cho lòng trung thành, sự cứu rỗi và may mắn. Chùm quả sum suê cũng biểu thị sự sung túc, đông con nhiều cháu.	Dân gian truyền rằng trên vỏ quả bòn bon thường có một dấu móng tay ấn vào, đó là dấu móng tay của chúa Nguyễn Ánh khi xưa bóc vỏ ăn, nên gọi là 'dấu móng tay vua'. Ngày nay, bòn bon Tiên Phước (Quảng Nam) vẫn là thương hiệu nổi tiếng nhất.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
f605aca8-53e1-48db-b064-31538ef76d3a	6984b326-0c85-43a4-9a4d-dabbeb7e13ba	Hoa sen - quốc hoa trong tâm thức người Việt, biểu tượng của sự thanh cao.	Liên Hoa (Hoa sen) là loài hoa gần gũi và thiêng liêng nhất trong văn hóa Việt Nam. 'Gần bùn mà chẳng hôi tanh mùi bùn', hoa sen tượng trưng cho vẻ đẹp thanh khiết, khí phách kiên cường và phẩm chất cao quý của người quân tử, giữ mình trong sạch giữa chốn bụi trần. Trên Nhân Đỉnh, hoa sen được chạm khắc mềm mại, tinh tế. Trong Phật giáo, hoa sen là biểu tượng của sự giác ngộ, thoát khỏi khổ đau luân hồi. Ở Huế, sen mọc khắp các hào nước, hồ tịnh tâm trong Kinh thành, hương sen thơm ngát ướp vào trà, hạt sen làm mứt, nấu chè... Sen hiện diện trong mọi mặt đời sống vật chất và tinh thần của người dân Cố đô.	Hoa sen xuất hiện dày đặc trong kiến trúc và nghệ thuật triều Nguyễn, từ đài sen dưới chân cột, họa tiết trên long bào đến các công trình như lăng Tự Đức, hồ Tịnh Tâm. Nó phản ánh sự ảnh hưởng sâu sắc của Phật giáo và Nho giáo trong tư tưởng trị nước và tu thân.	Hoa sen biểu tượng cho sự hoàn hảo, thuần khiết và sự tái sinh (hạt sen già rơi xuống bùn lại mọc thành cây mới). Bông sen nở rộ còn tượng trưng cho quá khứ, hiện tại và tương lai nối tiếp nhau.	Tất cả các bộ phận của cây sen đều có ích: hoa để ngắm và ướp trà, hạt (liên nhục) để ăn và làm thuốc an thần, tâm sen (liên tâm) chữa mất ngủ, lá sen gói cốm, ngó sen làm nộm, củ sen hầm canh. Sen thực sự là một loài cây 'toàn năng'.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
faf4fd00-a333-40c1-82c3-af8f5fff2def	5068f86d-bfc1-41d6-b8ac-0073ff897b72	Chim công - loài chim rực rỡ, biểu tượng của văn minh và sự quyền quý.	Khổng Tước (Chim công) được mệnh danh là nữ hoàng của các loài chim với bộ lông đuôi xòe rộng rực rỡ sắc màu như những con mắt lấp lánh. Trên Nhân Đỉnh, chim công hiện lên với vẻ đẹp kiêu sa, lộng lẫy. Trong văn hóa phương Đông, Khổng Tước là biểu tượng của sự quyền quý, vinh hoa và văn minh (văn nhã). Lông công thường được dùng để cắm vào mũ quan lại cấp cao (lông công hai mắt, một mắt tùy phẩm trật) để thể hiện uy quyền. Chim công còn được cho là hiện thân của Phượng Hoàng trên mặt đất, mang lại may mắn và cát tường.	Vào thời Nguyễn, việc nuôi chim quý trong vườn ngự uyển là thú vui tao nhã của vua chúa. Chim công không chỉ để ngắm mà lông của nó còn là vật phẩm trang trí quý giá cho nghi trượng và phẩm phục.	Hoa văn trên đuôi công giống như những đồng tiền cổ nối tiếp nhau, nên công còn tượng trưng cho tài lộc, sự giàu có. Ngoài ra, chim công còn biểu thị cho sự duyên dáng và đức hạnh của người phụ nữ hoàng tộc.	Chim công trống mới có bộ đuôi đẹp để múa gọi mái. Khi múa, nó xòe đuôi thành hình quạt lớn, rung rung tạo ra tiếng xào xạc rất vui tai. Người xưa tin rằng lông công có khả năng hút năng lượng dương, điều hòa âm dương nên hay cắm lông công trong nhà.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
3d45d88c-7d7c-446d-a078-a0b79aadeda5	0b7a95ae-de5f-4e5b-a6f4-ff673d93ec2d	Biển Nam - vùng biển trù phú và chiến lược phía Nam của tổ quốc.	Nam Hải (Biển Nam) chỉ vùng biển phía Nam của nước ta, bao gồm cả vùng biển Hà Tiên, Phú Quốc và Côn Đảo. Đây là vùng biển giàu tài nguyên hải sản, ngọc trai, đồi mồi... và là cửa ngõ giao thương quan trọng với các nước trong khu vực Đông Nam Á (Xiêm, Mã Lai...). Việc khắc Nam Hải lên Nhân Đỉnh (cùng với Đông Hải trên Cao Đỉnh và Tây Hải trên Chương Đỉnh) thể hiện tư duy biển đảo toàn diện của vua Minh Mạng: nước Nam ta có bờ biển dài bao bọc, biển là nguồn sống và cũng là phên dậu bảo vệ đất nước. Khẳng định chủ quyền trên Nam Hải cũng là khẳng định vị thế làm chủ vùng đất Nam Bộ mới khai phá.	Triều Nguyễn đã thiết lập các đội thủy quân hùng mạnh để tuần tra, kiểm soát và thu thuế trên vùng biển này. Các hải đảo như Phú Quốc, Côn Đảo, Thổ Chu được coi là những tiền đồn quan trọng trấn giữ biên cương biển.	Nam Hải tượng trưng cho sự giàu có, khoáng đạt và sự mở mang. Biển cả mênh mông cũng đại diện cho tấm lòng bao dung của đấng quân vương (như thụy hiệu 'Nhân' của đỉnh).	Vùng biển phía Nam có khí hậu ôn hòa hơn miền Bắc, ít bão lớn, thuận lợi cho nghề cá và giao thương quanh năm. Đây cũng là nơi phát triển các thương cảng sầm uất như Hà Tiên thời Mạc Cửu.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
f8e2d94e-d422-420a-bc60-769012c86d9f	c6a51d0e-69d6-4b9f-8dee-48a51d46e39d	Sông Phổ Lợi - công trình thủy lợi nhân tạo mang lại lợi ích rộng khắp.	Phổ Lợi Hà là một con sông đào nằm ở huyện Phú Vang, Thừa Thiên Huế. Sông được đào vào năm 1835 dưới thời vua Minh Mạng để nối sông Hương với đầm phá Tam Giang, nhằm thoát lũ, ngăn mặn và thuận tiện cho giao thông đường thủy. Tên gọi 'Phổ Lợi' có nghĩa là 'lợi ích rộng khắp' (Phổ: rộng khắp, Lợi: lợi ích), thể hiện mong muốn của nhà vua là công trình này sẽ mang lại ấm no, thuận lợi cho muôn dân trong vùng. Việc khắc con sông đào này lên Nhân Đỉnh ghi nhận thành tựu trị thủy và sự quan tâm đến đời sống dân sinh của triều đình.	Vua Minh Mạng là người rất chú trọng đến thủy lợi. Ông đã cho đào nhiều con sông lớn nhỏ khắp cả nước. Sông Phổ Lợi không chỉ giúp tưới tiêu cho ruộng đồng mà còn là tuyến đường vận chuyển lúa gạo quan trọng về Kinh thành.	Sông Phổ Lợi tượng trưng cho trí tuệ và bàn tay cải tạo thiên nhiên của con người để phục vụ cuộc sống. Tên sông cũng là một lời chúc phúc cho nhân dân được hưởng mọi điều tốt đẹp.	Dọc hai bờ sông Phổ Lợi ngày nay vẫn còn nhiều làng mạc trù phú, phong cảnh hữu tình. Con sông này là minh chứng cho thấy người xưa đã biết kết hợp hài hòa giữa phát triển kinh tế và bảo vệ môi trường sống.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
5edc703b-ec73-45fd-8b5a-05f49f6aa648	c2c9f700-fcf1-4dc1-b9c5-58a9ce97f4b3	Mặt trăng - Thái âm, biểu tượng của vẻ đẹp dịu dàng và sự viên mãn.	Nguyệt (Mặt trăng) là thiên thể đối ứng với Nhật (Mặt trời) trên Cao Đỉnh. Nếu Mặt trời tượng trưng cho vua (Dương) thì Mặt trăng tượng trưng cho hoàng hậu hoặc bề tôi hiền đức (Âm), tạo nên sự cân bằng lưỡng nghi trong vũ trụ. Trên Nhân Đỉnh, mặt trăng được khắc họa tròn đầy, tỏa sáng dịu nhẹ, tượng trưng cho sự viên mãn, hạnh phúc và an lành. Trong văn hóa nông nghiệp, mặt trăng gắn liền với lịch âm, thủy triều và mùa màng. Người xưa ngắm trăng để đoán thời tiết, tính ngày gieo cấy. Ánh trăng còn là nguồn cảm hứng bất tận cho thi ca nhạc họa.	Vua Minh Mạng là một nhà thơ lớn, ông có rất nhiều bài thơ vịnh trăng (Nguyệt). Việc đặt Mặt trăng lên đỉnh mang thụy hiệu 'Nhân' (vốn mang tính nhu hòa) là sự sắp xếp đầy tinh tế và thâm thúy của người xưa.	Mặt trăng biểu tượng cho sự tái sinh (tròn rồi khuyết, khuyết rồi tròn), sự bất tử và cõi vĩnh hằng. Nó cũng đại diện cho tính nữ, sự dịu dàng, che chở và nuôi dưỡng.	Hình ảnh 'Nhật - Nguyệt' trên hai đỉnh cao nhất (Cao - Nhân) thể hiện mong ước 'Nhật nguyệt trùng minh' (Mặt trời mặt trăng cùng sáng), ám chỉ một thời đại thái bình thịnh trị, vua sáng tôi hiền, âm dương hòa hợp.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
8b2fc486-dec5-415d-bb3c-4442e60d1783	c75f919c-904d-483b-83ec-4debdb8e076f	Sông Hương - dòng sông thơ mộng, linh hồn của xứ Huế và vương triều Nguyễn.	Hương Giang (Sông Hương) là dòng sông biểu tượng của Huế, chảy uốn lượn qua Kinh thành, lăng tẩm và chùa chiền. Nước sông xanh biếc, êm đềm, được ví như dải lụa mềm mại vắt ngang thành phố. Tên gọi 'Sông Hương' có lẽ bắt nguồn từ hương thơm của các loài thảo mộc (thạch xương bồ) hai bên bờ thượng nguồn hòa vào dòng nước. Sông Hương không chỉ là cảnh quan thiên nhiên tuyệt mỹ mà còn là yếu tố phong thủy quan trọng ('Minh đường' thủy tụ) bảo vệ và nuôi dưỡng mạch khí cho Kinh thành Huế. Việc khắc Sông Hương lên Nhân Đỉnh khẳng định vị trí độc tôn của nó trong trái tim người dân Cố đô.	Sông Hương đã chứng kiến mọi thăng trầm lịch sử của triều Nguyễn, từ ngày đầu xây dựng kinh thành đến khi triều đại kết thúc. Dòng sông là nguồn cảm hứng cho Nhã nhạc cung đình và Ca Huế trên sông.	Sông Hương tượng trưng cho vẻ đẹp dịu dàng, sâu lắng và sự chung thủy. Nó là linh hồn của văn hóa Huế, nơi hội tụ tinh hoa đất trời và con người.	Sông Hương có hai nguồn chính là Tả Trạch và Hữu Trạch, hợp lưu tại ngã ba Tuần rồi mới chảy về xuôi. Màu nước sông Hương thay đổi theo thời tiết, nhưng đẹp nhất là lúc hoàng hôn, khi mặt nước nhuộm màu tím biếc đặc trưng của Huế.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
1a191968-1b78-48f2-acd3-eb0c9f843186	a46c369b-7b5b-4478-ad85-492725e5fccb	Núi Duệ - ngọn núi thiêng trấn giữ phía Tây Kinh thành.	Duệ Sơn (Núi Duệ/Núi Lễ) là ngọn núi thuộc thị xã Hương Trà, tỉnh Thừa Thiên Huế, nằm bên bờ sông Bạch Yến. Tuy không quá cao lớn nhưng núi Duệ có dáng vẻ thanh tú, được coi là một trong những 'chủ sơn' trong phong thủy của Kinh thành Huế. Trên núi có chùa cổ và nhiều di tích Chăm Pa. Việc khắc Duệ Sơn lên đỉnh thể hiện sự trân trọng các yếu tố địa lý phong thủy tạo nên vượng khí cho Kinh đô.	Vua Minh Mạng từng đi tuần thú qua đây và làm thơ ca ngợi cảnh đẹp. Núi Duệ cùng với sông Hương, núi Ngự tạo nên cảnh quan sơn thủy hữu tình của xứ Huế.	Núi Duệ tượng trưng cho sự thông tuệ (Duệ: sáng suốt, thông minh) và sự che chở tâm linh cho vùng đất đế đô.	Tên 'Duệ' còn có nghĩa là nhọn, sắc sảo. Dáng núi có thể trông giống như ngòi bút (văn phong).	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
cf696217-2a2d-4787-9720-c9e6bccf246d	d469214a-16e7-4120-ad15-7dece40629da	Núi Ngự Bình - bức bình phong thiên nhiên che chở cho Kinh thành Huế.	Ngự Bình Sơn là ngọn núi thấp, dáng cân đối, nằm ở phía trước Kinh thành Huế, đóng vai trò là 'Tiền án' (bức bình phong) trong phong thủy. Vua Gia Long khi chọn vị trí đóng đô đã chọn núi Ngự Bình làm bình phong để che chắn gió độc và tà khí cho Kinh thành. Cùng với sông Hương, núi Ngự Bình tạo nên bộ đôi sơn thủy hữu tình 'Sông Hương - Núi Ngự', biểu tượng vĩnh cửu của xứ Huế. Trên núi trồng nhiều cây thông, quanh năm xanh tốt, dáng vẻ uy nghiêm, tĩnh tại như một người cận vệ trung thành bảo vệ hoàng cung.	Trước khi có tên Ngự Bình, núi có tên là Hòn Mô. Vua Gia Long thấy dáng núi đẹp, bằng phẳng như cái bàn (Bình) và lại ở vị trí ngự trị phía trước nên đổi tên là Ngự Bình. Các vua Nguyễn thường lên đây vãn cảnh và làm thơ.	Núi Ngự Bình tượng trưng cho sự vững chãi, bình an và sự bảo vệ che chở. Dáng núi hình thang cân đối (như cái ấn hoặc bức bình phong) biểu thị sự ổn định và quyền uy.	Vào những ngày trời quang, đứng từ Lầu Ngũ Phụng (Ngọ Môn) nhìn ra xa sẽ thấy núi Ngự Bình nằm ngay chính giữa tầm mắt, tạo nên một trục thần đạo thẳng tắp từ Kinh thành ra thiên nhiên. Điều này cho thấy quy hoạch kiến trúc của Huế cực kỳ khoa học và nghệ thuật.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
1476a103-5e31-4b23-b78f-b9c3bf7a711f	81f3deaa-51eb-420d-bf4f-4c99584662ef	Cá Nhân Ngư (Bò biển) - sinh vật biển kỳ lạ, hiền lành, gợi liên tưởng đến nàng tiên cá.	Nhân Ngư (Cá người) tên khoa học là Dugong, dân gian thường gọi là Bò biển hay Cá Cui. Đây là loài thú biển ăn cỏ, hình dáng to lớn, bơi lội chậm chạp và rất hiền lành. Sở dĩ gọi là 'Nhân Ngư' vì chúng có vú ở ngực và khi cho con bú thường nổi đầu lên mặt nước, dùng vây ôm con giống như người mẹ bế con, khiến các thủy thủ xưa nhìn nhầm thành 'người cá'. Việc khắc loài vật này lên Nhân Đỉnh cho thấy sự hiểu biết phong phú về sinh vật biển của người Việt và lòng trân trọng đối với một loài vật hiền lành, có tình mẫu tử thiêng liêng. Đây cũng là loài vật quý hiếm cần được bảo vệ.	Vùng biển Kiên Giang, Phú Quốc của Việt Nam xưa kia có rất nhiều Bò biển sinh sống. Người dân chài tôn trọng chúng vì tin rằng chúng là loài vật linh thiêng, giúp báo hiệu bão tố.	Nhân Ngư tượng trưng cho tình mẫu tử, sự hiền hòa và bí ẩn của đại dương. Trong một số truyền thuyết, nước mắt của nhân ngư (ngọc trai) được coi là báu vật.	Dugong là nguyên mẫu của các truyền thuyết về 'Nàng tiên cá' ở phương Tây. Chúng là loài động vật biển duy nhất ăn thực vật (cỏ biển). Hiện nay, Dugong đang nằm trong sách đỏ có nguy cơ tuyệt chủng cao.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
1eabec6f-19a0-4074-b6ce-0df935d4cab2	c947cdd0-5095-45af-9abe-43762e47dbde	Rau hẹ - loài rau gia vị bình dị, biểu tượng của sự trường cửu và sức sống bền bỉ.	Chữ 'Cửu' (韭) ở đây là rau hẹ, một loại rau gia vị phổ biến, cùng họ với hành tỏi. Hẹ dễ trồng, cắt xong lại mọc, sinh sôi nảy nở không ngừng nên tượng trưng cho sự trường tồn, vĩnh cửu (đồng âm với chữ Cửu - chín, lâu dài). Trong đông y, hẹ có tính ấm, tác dụng bổ dương, chữa ho, cảm cúm rất tốt. Việc khắc rau hẹ lên Nhân Đỉnh thể hiện sự quan tâm đến sức khỏe và đời sống thường nhật của nhân dân. Món canh hẹ đậu phụ hay hẹ xào giá đỗ là những món ăn dân dã nhưng đậm đà hương vị quê hương.	Rau hẹ đã gắn bó với người Việt từ ngàn xưa. Trong các mâm cúng tổ tiên ngày Tết ở một số vùng, không thể thiếu đĩa rau hẹ cuốn bánh tráng, thể hiện mong ước con cháu đông đúc, dòng họ trường tồn.	Rau hẹ (Cửu) tượng trưng cho sự lâu dài, bền vững (trường cửu). Nó cũng đại diện cho sức sống mãnh liệt, 'cắt lại mọc', khó bị tiêu diệt.	Người xưa có câu 'Tháng giêng ăn hẹ, tháng tám ăn hành' để chỉ mùa nào thức nấy tốt cho sức khỏe. Hoa hẹ màu trắng, mọc thành chùm nhỏ cũng rất đẹp và có thể ăn được, xào với gan lợn hay tôm rất ngon.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
ba089631-9fb6-485f-9941-fe550b50ac68	1ff69a0a-4718-4f51-97f3-0df32387a8e4	Lâu thuyền - chiến hạm lầu cao, pháo đài nổi uy nghi trên sông nước.	Lâu Thuyền là loại thuyền chiến lớn, có dựng lầu cao ở trên để tướng chỉ huy quan sát và binh lính bắn tên hoặc súng xuống đối phương. Đây được coi là 'pháo đài nổi' của thủy quân thời xưa. Trên Nhân Đỉnh, Lâu Thuyền được chạm khắc chi tiết với cấu trúc tầng lầu vững chãi, thể hiện sức mạnh và kỹ thuật đóng tàu điêu luyện của triều Nguyễn. Loại thuyền này thường được dùng trong các cuộc diễu binh, nghênh đón sứ thần hoặc các trận thủy chiến lớn trên sông, thể hiện uy thế áp đảo của triều đình.	Vua Minh Mạng rất tự hào về thủy quân của mình. Ông đã cho đóng nhiều loại thuyền lớn, trong đó có Lâu Thuyền, trang bị đại bác để tăng cường khả năng phòng thủ bờ biển và sông ngòi. Sự hiện diện của Lâu Thuyền trên đỉnh là lời khẳng định về sức mạnh quân sự trên sông nước.	Lâu Thuyền tượng trưng cho uy quyền, sự chỉ huy sáng suốt và thế thượng phong. Nó cũng là biểu tượng của sự tráng lệ và quy mô của quân đội hoàng gia.	Lâu Thuyền tuy to lớn, uy nghi nhưng di chuyển khá chậm chạp, chủ yếu dựa vào sức chèo của nhiều binh lính. Do đó, nó thường đi cùng các thuyền nhỏ linh hoạt (như Mông Đồng) để hộ vệ.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
2cc675c6-cb43-4c68-bd35-24455de3d8eb	e39d9f9b-27d0-458e-a307-f00ff4c64293	Cây Quế - 'Ngọc quế' xứ Thanh, dược liệu quý giá.	Quế (Cinnamomum cassia) là loài cây thân gỗ, vỏ có vị cay ngọt, mùi thơm nồng, dùng làm gia vị và thuốc. Quế Thanh Hóa (Quế Thanh) được mệnh danh là 'Châu thường' (Ngọc quế), tốt nhất thế giới, từng được dâng lên vua chúa và xuất khẩu đi khắp nơi. Vỏ quế có tác dụng trợ dương, thông huyết mạch, chữa cảm lạnh. Thân cây quế thẳng, tán lá xanh quanh năm. Hình ảnh cây quế trên đỉnh tôn vinh nguồn dược liệu quý báu của nước Nam.	Câu ca dao 'Quế Thanh, Sâm Cao Ly' đã khẳng định vị thế của quế Việt Nam ngang hàng với nhân sâm Triều Tiên. Quế là cống phẩm bắt buộc của các triều đại phong kiến.	Cây Quế tượng trưng cho sự nồng ấm, sức khỏe và sự quý giá (vỏ quế đắt như vàng - 'Ăn bát cơm dẻo nhớ nẻo đường đi/ Ăn bát cơm quế nhớ người ra đi').	Người xưa có câu 'Nhất mẹo, nhì Quế' (Mẹo là tre, Quế là cây quế) để chỉ độ dẻo dai. Nhưng về giá trị dược liệu thì 'Sâm - Nhung - Quế - Phụ' là 4 vị thuốc đại bổ (Tứ đại danh dược).	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
8a077a15-759f-4e48-9842-858f2ba77ca7	9f26573f-3fef-4130-884e-b2a10664513c	Pháo xa - súng thần công đặt trên bánh xe, vũ khí cơ động hiện đại.	Luân Xa Pháo là loại súng đại bác được đặt trên giá súng có bánh xe (luân xa) để dễ dàng di chuyển. Khác với súng thần công cố định trên thành lũy, Luân Xa Pháo có tính cơ động cao, có thể kéo theo đội hình hành quân để chi viện hỏa lực trên chiến trường. Việc khắc loại vũ khí này lên Nhân Đỉnh cho thấy sự tiến bộ trong tư duy quân sự của triều Nguyễn: không chỉ chú trọng hỏa lực mạnh mà còn quan tâm đến tính linh hoạt, cơ động. Đây là minh chứng cho nỗ lực hiện đại hóa quân đội, tiếp thu kỹ thuật phương Tây thời bấy giờ.	Thời Minh Mạng, kỹ thuật chế tạo súng đạn của Việt Nam đã đạt trình độ cao. Các xưởng đúc súng (Súng xưởng) hoạt động nhộn nhịp. Luân Xa Pháo là một trong những thành tựu đó, giúp tăng cường đáng kể sức chiến đấu của bộ binh.	Luân Xa Pháo tượng trưng cho sức mạnh tấn công, sự linh hoạt và khả năng làm chủ chiến trường. Bánh xe (Luân) còn gợi ý về sự chuyển động không ngừng, sự tiến lên phía trước.	Để kéo được những khẩu pháo này, người xưa thường dùng sức ngựa hoặc sức voi, đôi khi là sức lính. Việc chế tạo bánh xe chịu lực cho pháo cũng đòi hỏi kỹ thuật mộc và rèn sắt rất cao.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
1c66a58a-2e7a-4242-8c5f-181d8afeeec4	9a7cac22-df1b-4150-9db3-a3420b48fd9f	Con báo - mãnh thú rừng xanh, biểu tượng của sự uyển chuyển và dũng mãnh.	Báo là loài mãnh thú thuộc họ Mèo, nổi tiếng với tốc độ, sự dẻo dai và khả năng leo trèo, săn mồi điêu luyện. Nếu Hổ là chúa sơn lâm sức mạnh vô song, thì Báo là sát thủ rừng xanh với sự khéo léo và tốc độ kinh hoàng. Hình ảnh con báo đốm khắc trên Nhân Đỉnh với dáng vẻ uyển chuyển, cơ bắp săn chắc, thể hiện vẻ đẹp hoang dã và sức sống mãnh liệt. Trong quân sự, da báo thường được dùng làm yên ngựa, bao kiếm cho các tướng lĩnh, tượng trưng cho sự oai phong lẫm liệt ('Báo thao' - lược thao của loài báo).	Rừng núi Việt Nam xưa kia có nhiều báo (báo hoa mai, báo gấm). Chúng vừa là nỗi khiếp sợ vừa là đối tượng săn bắn để lấy da lông quý. Việc khắc Báo lên đỉnh thể hiện sự tôn trọng sức mạnh tự nhiên và làm phong phú thêm bộ sưu tập động vật trên Cửu Đỉnh.	Con báo tượng trưng cho sự dũng cảm, mưu trí và tốc độ. Trong văn hóa, 'Quân tử biến như báo' (Người quân tử thay đổi nhanh chóng, rõ rệt như văn hoa của da báo) để chỉ sự đổi mới, tiến bộ không ngừng.	Báo hoa mai có thể kéo con mồi nặng hơn cơ thể mình lên cây để tránh bị các loài thú khác cướp mất. Đây là loài vật có khả năng thích nghi rất tốt với nhiều môi trường sống.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
5ec42212-70e9-40f8-8c6b-736a78512ed7	80ffc309-19f9-42ee-89fe-256c6b2ca88e	Đồi mồi - loài rùa biển có mai tuyệt đẹp, báu vật của đại dương.	Đại Mạo là tên gọi của con Đồi mồi (Eretmochelys imbricata), một loài rùa biển quý hiếm. Điểm đặc biệt nhất của Đồi mồi là bộ mai có hoa văn vân vảy màu vàng nâu hổ phách cực kỳ đẹp mắt và trong suốt. Mai đồi mồi (người xưa gọi là vảy đồi mồi) là nguyên liệu quý giá để chế tác đồ mỹ nghệ như lược, trâm cài tóc, gọng kính, hộp đựng... dành cho vua chúa và giới quý tộc. Hình ảnh Đại Mạo trên Nhân Đỉnh bơi lội tung tăng trong sóng nước không chỉ tôn vinh vẻ đẹp của loài vật này mà còn khẳng định sự phong phú của tài nguyên biển Việt Nam.	Đồi mồi từng là sản phẩm cống nạp quan trọng và là hàng hóa xuất khẩu có giá trị cao của Việt Nam sang Trung Quốc và phương Tây. Tuy nhiên, vì vẻ đẹp của bộ mai, chúng đã bị săn bắt quá mức.	Đồi mồi (Đại Mạo) tượng trưng cho sự sang trọng, quý phái và trường thọ (giống như loài rùa nói chung). Nó cũng là biểu tượng của may mắn và sự bảo vệ (mai cứng).	Mai đồi mồi là loại vật liệu dẻo khi gia nhiệt, có thể uốn cong thành nhiều hình dạng phức tạp. Tuy nhiên, ngày nay việc buôn bán các sản phẩm từ đồi mồi bị cấm trên toàn thế giới để bảo vệ loài vật này khỏi tuyệt chủng.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
0842e0dc-936d-4810-9936-81851f0fd456	645bd72c-715f-448e-8db2-131340664238	Chương Đỉnh - chiếc đỉnh tượng trưng cho vẻ đẹp rực rỡ và sự văn minh của triều đại.	Chương Đỉnh là chiếc đỉnh thứ ba trong Cửu Đỉnh, được đặt bên phải của Cao Đỉnh (đối xứng với Nhân Đỉnh). Chữ 'Chương' (章) có ý nghĩa là rực rỡ, sáng tỏ, hay chương pháp, lề lối. Đây là thụy hiệu của vua Thiệu Trị (1807-1847), vị vua thứ ba của triều Nguyễn, nổi tiếng là một nhà thơ lớn và người kế thừa xuất sắc di sản của vua cha Minh Mạng. Chương Đỉnh thể hiện mong muốn của triều đình về một nền văn hóa rực rỡ, pháp luật nghiêm minh và xã hội có kỷ cương. Đỉnh nặng khoảng 2.000kg, được đúc với kỹ thuật tinh xảo, các họa tiết trên đỉnh không chỉ mang tính thẩm mỹ cao mà còn chứa đựng những thông điệp sâu sắc về thiên nhiên và con người.	Đúc năm 1835, Chương Đỉnh tôn vinh vua Thiệu Trị. Dù thời gian trị vì không dài (7 năm), nhưng vua Thiệu Trị đã để lại dấu ấn đậm nét trong văn hóa, kiến trúc và ngoại giao. Ông là người rất trân trọng những giá trị truyền thống và tiếp tục củng cố sự thịnh trị của đất nước.	Tên 'Chương' gợi lên hình ảnh của ánh sáng lan tỏa, sự văn minh và trí tuệ. Nó cũng hàm ý sự rõ ràng, minh bạch trong cai trị (chương pháp). Vị trí của Chương Đỉnh bên phải Cao Đỉnh (hữu) thể hiện vai trò phò tá đắc lực và sự nối tiếp xứng đáng.	Vua Thiệu Trị là tác giả của tập thơ 'Thần Kinh Nhị Thập Cảnh' nổi tiếng, ca ngợi 20 cảnh đẹp của đất Thần Kinh (Huế). Ông là vị vua thi sĩ để lại nhiều tác phẩm văn học nhất triều Nguyễn.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
d04c1415-f4f8-4001-aeaa-afefd152ae17	31832650-6463-405a-9ce3-8ac267c1c9da	Hoa nhài - loài hoa trắng tinh khôi với hương thơm nồng nàn quyến rũ.	Mạt Lị là tên Hán Việt của hoa nhài (Jasminum sambac), loài hoa nhỏ bé nhưng có hương thơm nồng nàn, lan tỏa xa. Hoa nhài màu trắng tinh khiết, thường nở vào ban đêm hoặc sáng sớm, tượng trưng cho vẻ đẹp thanh tao, dịu dàng của người phụ nữ. Trên Chương Đỉnh, hoa nhài được khắc họa giản dị nhưng đầy sức gợi. Người Việt rất yêu chuộng hoa nhài, thường trồng trong vườn nhà để ướp trà (trà nhài), làm thuốc hoặc dâng cúng lễ phật. Hương thơm của hoa nhài giúp thư giãn tinh thần, giảm căng thẳng.	Trà nhài là một trong những loại trà ướp hương nổi tiếng của Việt Nam, được dùng để tiếp khách quý trong cung đình cũng như dân gian. Sự hiện diện của hoa nhài trên đỉnh đồng cho thấy sự trân trọng những giá trị tinh thần giản dị nhưng thanh cao.	Hoa nhài tượng trưng cho sự tinh khiết, tình bạn và lòng kính trọng. Trong tình yêu, nó biểu thị sự ngọt ngào và quyến rũ. Màu trắng của hoa còn đại diện cho sự ngây thơ và thánh thiện.	Hoa nhài là quốc hoa của nhiều nước như Philippines (Sampaguita), Indonesia (Melati Putih). Ở Việt Nam, hoa nhài còn đi vào ca dao: 'Chẳng thơm cũng thể hoa nhài / Dẫu không thanh lịch cũng người Tràng An', ca ngợi nét đẹp thanh lịch của người Hà Nội.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
4ad4c8e3-550d-404a-9b4d-6ae068e966da	dac97c73-f54d-4208-b262-b19034d979d3	Trái xoài - vua của các loại trái cây nhiệt đới, ngọt ngào và bổ dưỡng.	Am La là tên gọi cổ của cây Xoài (Mangifera indica), một loại cây ăn quả nhiệt đới phổ biến và được yêu thích bậc nhất. Cây xoài thân gỗ lớn, tán rộng che bóng mát, quả khi chín có màu vàng hấp dẫn, vị ngọt đậm đà và hương thơm quyến rũ. Trên Chương Đỉnh, chùm quả xoài căng mọng thể hiện sự sung túc, ngọt ngào của hoa trái phương Nam. Xoài không chỉ ngon miệng mà còn chứa nhiều vitamin, tốt cho sức khỏe. Ở Việt Nam, có rất nhiều giống xoài ngon như xoài Cát Hòa Lộc, xoài Tượng, xoài Thanh Ca...	Vua Minh Mạng từng có thơ vịnh về cây xoài (Am la), ca ngợi hương vị thơm ngon của nó. Việc khắc xoài lên Cửu Đỉnh là sự công nhận giá trị kinh tế và ẩm thực của loài cây này trong đời sống người dân.	Cây xoài tượng trưng cho sự thành đạt và viên mãn (do quả chín vàng ươm). Trong Phật giáo, cây xoài cũng có ý nghĩa linh thiêng (Đức Phật từng nghỉ ngơi dưới bóng cây xoài).	Xoài được mệnh danh là 'Vua của các loại trái cây' ở nhiều nơi trên thế giới. Một cây xoài cổ thụ có thể sống hàng trăm năm và vẫn cho quả. Lá xoài non cũng được dùng như một loại rau ăn kèm ở một số vùng miền Tây.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
dd02b47e-986b-4df5-9f21-dd6c6b257f8d	dc61f122-27eb-4f8c-84df-55c697f1eb12	Đậu khấu - vị thuốc quý và gia vị thơm nồng từ rừng già.	Đậu Khấu (thường chỉ Bạch đậu khấu hoặc Nhục đậu khấu) là một loài cây dược liệu và gia vị quý. Quả đậu khấu có mùi thơm cay nồng, ấm áp, được dùng để chữa các bệnh về tiêu hóa, lạnh bụng và làm gia vị cho các món ăn cao cấp. Trên Chương Đỉnh, hình ảnh cây đậu khấu nhắc nhở về sự phong phú của nguồn dược liệu nước nhà. Trong đông y, đậu khấu được ví như một vị tướng quân có khả năng 'thông quan khai khiếu', đánh tan hàn khí. Loài cây này thường mọc dưới tán rừng già ẩm ướt, việc thu hái cũng không dễ dàng.	Đậu khấu từng là mặt hàng cống nạp và xuất khẩu quan trọng. Các triều đại phong kiến rất chú trọng việc thu mua và dự trữ các loại hương liệu, dược liệu quý như đậu khấu, quế, hồi.	Đậu khấu tượng trưng cho sự ấm áp, chữa lành và tinh túy ẩn giấu (hạt thơm nằm sâu trong vỏ quả). Nó còn biểu thị cho sự chăm sóc sức khỏe và sự trường thọ.	Trong văn học cổ, 'tuổi đậu khấu' dùng để chỉ các cô gái trẻ khoảng 13-14 tuổi (tương lai rực rỡ như hoa đậu khấu đầu cành). Đậu khấu còn là một thành phần không thể thiếu trong món Phở truyền thống để tạo nên hương vị đặc trưng.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
acbbbd48-81a5-4e66-bfcf-35002352fe75	15bb211a-d1df-47df-8409-ea51d4cbb899	Đậu xanh - hạt ngọc xanh mát lành, giải nhiệt cuộc sống.	Lục Đậu (Đậu xanh) là loại ngũ cốc quen thuộc và thiết yếu trong đời sống người Việt. Hạt đậu nhỏ, vỏ xanh ruột vàng, có tính mát, giải độc, thanh nhiệt rất tốt. Đậu xanh được chế biến thành vô vàn món ăn: nấu chè, đồ xôi, làm nhân bánh chưng, bánh phu thê, làm miến, ủ giá đỗ... Hình ảnh cây đậu xanh trên Chương Đỉnh tôn vinh giá trị của nông sản bình dị nhưng hữu ích này. Trong văn hóa ẩm thực, đậu xanh đóng vai trò cân bằng, làm dịu đi cái béo ngậy của thịt mỡ (trong bánh chưng) hay cái nóng của thời tiết (chè đậu xanh).	Nông nghiệp thời Nguyễn rất coi trọng việc trồng các loại đậu (đậu xanh, đậu đen, đậu nành) để luân canh tăng độ phì nhiêu cho đất và bổ sung nguồn đạm thực vật cho bữa ăn hàng ngày.	Đậu xanh tượng trưng cho sự thanh khiết, lành mạnh và sự nảy mầm mạnh mẽ (giá đỗ). Màu xanh của vỏ và màu vàng của nhân gợi lên sự hài hòa, sung túc.	Vỏ đậu xanh cũng là một vị thuốc tốt, giúp giải độc. Dân gian có câu 'Con kiến mà leo cành đa, leo phải cành cụt leo ra leo vào. Con kiến mà leo cành đào, leo phải cành cụt leo vào leo ra' nhưng cũng có câu đố về đậu xanh: 'Da cóc mà bọc trứng gà, bổ ra thơm phức cả nhà muốn ăn' (là bánh gì? Bánh đậu xanh/Bánh chưng nhân đậu).	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
0f9ac204-92fd-49c3-ba8c-cf12fe5b771e	d4d34f66-7825-4cfc-a5f3-7b6ca7dd5e29	Cây kiệu - loại rau gia vị đặc trưng của ngày Tết cổ truyền.	Chữ 'Giới' (Giai) ở đây được hiểu là Cây Kiệu (Allium chinense), một loài cây thuộc họ hành tỏi, có củ màu trắng, lá nhỏ. Củ kiệu muối chua ngọt là món ăn không thể thiếu trong mâm cỗ Tết của người Việt, đặc biệt là ở miền Nam, ăn kèm với tôm khô, bánh tét thì tuyệt hảo. Vị hăng nồng, cay nhẹ của kiệu giúp kích thích tiêu hóa, chống ngán. Việc khắc cây kiệu lên Chương Đỉnh cho thấy sự tinh tế của người xưa khi đưa những nét văn hóa ẩm thực đặc sắc vào bảo vật quốc gia. Cây kiệu dễ trồng, chịu được đất khô cằn, thể hiện sức sống bền bỉ.	Củ kiệu đã có mặt trong ẩm thực Việt từ rất lâu đời. Tục ngữ có câu 'Thịt mỡ dưa hành câu đối đỏ' (miền Bắc) và tương ứng miền Nam là 'Thịt kho củ kiệu'. Nó là một phần của bản sắc văn hóa Tết.	Cây kiệu tượng trưng cho sự đầm ấm, sum vầy ngày Tết. Vị cay nồng của nó cũng tượng trưng cho những hương vị đa dạng của cuộc sống.	Củ kiệu nhìn rất giống củ hành nhưng thon dài hơn và vị thanh hơn. Lá kiệu cũng có thể ăn được nhưng người ta chủ yếu lấy củ. Để có hũ kiệu ngon, người làm phải phơi kiệu qua một nắng cho héo bớt rồi mới đem muối, kiệu sẽ giòn và trắng trong.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
90ea1e71-978d-4f20-80d8-e68840e3c1bc	4736fd9a-1a7c-4561-9fa4-eb99b80613b7	Đậu ván - thức quà bình dị, bổ dưỡng của chốn điền viên.	Biển Đậu (Cây đậu ván/Bạch biển đậu) là loài dây leo, quả dẹt, hạt hình thận. Đậu ván trắng là vị thuốc nam có tác dụng giải nhiệt, giải độc, chữa nôn mửa, đau bụng. Chè đậu ván là món ăn chơi nổi tiếng của xứ Huế, vị ngọt bùi, thanh mát. Hình ảnh cây đậu ván leo giàn trĩu quả trên Nghị Đỉnh gợi lên khung cảnh làng quê thanh bình, no ấm và đề cao giá trị của cây lương thực.	Nông nghiệp là gốc của triều đại ('Dĩ nông vi bản'). Các loài cây ngũ cốc, hoa màu như lúa, ngô, đậu luôn được khắc trên Cửu Đỉnh để nhắc nhở vua quan quan tâm đến đời sống dân sinh.	Đậu ván tượng trưng cho sự sinh sôi, nảy nở và sự gắn kết (dây leo quấn quýt). Hạt đậu (Tử) còn đồng âm với 'con cái', mang ý nghĩa cầu tự.	Ở Huế, món chè đậu ván đặc biệt ở chỗ hạt đậu không bị nát mà vẫn mềm, nước chè đặc sánh. Đây từng là món tráng miệng trong Cung đình.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
37dbd3ae-c130-4df1-84e4-48535dc81a04	0c986397-4987-4b29-afea-42355d79d00a	Con gà - loài vật thân thuộc báo hiệu bình minh, biểu tượng của ngũ đức.	Kê (Con gà) là loài gia cầm gần gũi nhất với đời sống nông thôn Việt Nam. Tiếng gà gáy sáng xua tan bóng tối, báo hiệu một ngày mới bắt đầu, là biểu tượng của mặt trời và ánh sáng. Trong văn hóa, gà trống (Hùng kê) được ca ngợi là có đủ 'Ngũ đức': Văn (mào đỏ như mũ quan), Võ (cựa sắc nhọn), Dũng (gặp địch là đánh), Nhân (có mồi gọi nhau cùng ăn), Tín (gáy sáng đúng giờ). Hình ảnh con gà trên Chương Đỉnh được khắc họa sinh động, gần gũi, thể hiện ước vọng về sự chăm chỉ, nề nếp và tín nghĩa trong xã hội.	Gà không chỉ là nguồn thực phẩm (thịt, trứng) mà còn là vật phẩm tế lễ quan trọng nhất (gà luộc ngậm hoa hồng). Tranh Đông Hồ 'Gà đàn', 'Vinh hoa' (bé ôm gà) thể hiện mong ước con đàn cháu đống, vinh hiển.	Gà tượng trưng cho sự khởi đầu (bình minh), sự bảo vệ (trừ tà ma) và sự no đủ. Gà trống còn là biểu tượng của người quân tử với 5 đức tính quý báu.	Năm Dậu (Con Gà) là một trong 12 con giáp. Gà Đông Tảo (Hưng Yên) với đôi chân to xù xì từng là vật phẩm tiến vua nổi tiếng. Trong phong thủy, tượng gà trống bằng đồng thường được dùng để hóa giải 'đào hoa sát' hoặc tà khí.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
4c46c915-0567-40f2-8ca2-a2c28f71e385	d71a8ff0-be8c-4ecb-8e4c-5a6308fa8edb	Núi Thượng - ngọn núi Kim Phụng uy nghi trấn giữ phía Tây Nam kinh thành.	Thượng Sơn, tên thường gọi là núi Kim Phụng, là ngọn núi cao nhất trong hệ thống núi non bao quanh Kinh thành Huế. Núi có dáng vẻ hùng vĩ, đỉnh nhọn vươn lên trời xanh như hình chim phượng hoàng đang bay (Kim Phụng). Đây được coi là ngọn chủ sơn (núi chúa) trong phong thủy của kinh đô, nơi hội tụ linh khí đất trời. Việc khắc Thượng Sơn lên Chương Đỉnh khẳng định vị thế tối cao và vai trò trấn trạch của ngọn núi đối với sự bình an của vương triều. Vua Minh Mạng thường lên đây để quan sát địa thế và thưởng ngoạn cảnh đẹp.	Núi Kim Phụng gắn liền với nhiều huyền thoại và là mốc giới tự nhiên quan trọng. Người Huế tin rằng mây phủ đỉnh Kim Phụng là báo hiệu trời sắp mưa ('Mây phủ Kim Phụng, mưa đụng giàn trò').	Núi Thượng (Kim Phụng) tượng trưng cho quyền lực tối cao, sự vững chãi và sự kết nối với thiên đình. Hình dáng chim phượng hoàng của núi cũng là điềm lành cho triều đại.	Mặc dù là núi cao, nhưng trên đỉnh Kim Phụng lại có một cái giếng nước không bao giờ cạn, gọi là Giếng Tiên. Đây là chi tiết nhuốm màu sắc huyền bí, thu hút nhiều người ưa khám phá.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
f0ac660e-c584-4171-92fb-88fe63a48006	8aa3cbbd-b36e-4ab0-8167-979d2562c5de	Sông Lợi Nông - dòng sông An Cựu 'nắng đục mưa trong' nổi tiếng xứ Huế.	Lợi Nông Hà chính là sông An Cựu, một chi lưu của sông Hương chảy qua phía Nam Kinh thành Huế. Tên 'Lợi Nông' do vua Minh Mạng đặt, có nghĩa là dòng sông mang lại lợi ích cho nông nghiệp (tưới tiêu ruộng đồng). Điểm đặc biệt của sông An Cựu là hiện tượng 'nắng đục mưa trong' (ngược lại với các sông bình thường), đã đi vào ca dao: 'Núi Ngự Bình trước tròn sau méo / Sông An Cựu nắng đục mưa trong'. Sông không chỉ phục vụ sản xuất mà còn là tuyến giao thông thủy quan trọng và là nơi có nhiều phủ đệ, nhà vườn tuyệt đẹp của các ông hoàng bà chúa ven bờ.	Sông An Cựu ban đầu là sông tự nhiên nhưng sau đó được khơi thông, nạo vét nhiều lần để phục vụ tưới tiêu và thoát lũ. Dọc bờ sông là không gian văn hóa đặc sắc của tầng lớp quý tộc Huế xưa.	Sông Lợi Nông tượng trưng cho sự ích nước lợi dân, sự cần mẫn phục vụ đời sống. Dòng sông hiền hòa chảy bên cạnh cuộc sống sôi động của phố thị nhưng vẫn giữ nét trầm mặc.	Tại sao 'nắng đục mưa trong'? Có lý giải cho rằng khi nắng hạn, nước sông cạn, thủy triều đưa nước đục từ nơi khác vào. Còn khi mưa, nước nguồn đổ về nhiều đẩy lùi nước bẩn nên sông trong. Đây là nét độc đáo thiên nhiên thú vị.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
75b4fe35-330a-4475-a4d3-abe74f0ec356	43e66fe4-29b4-49bd-b492-4f5823a34b77	Ngũ Tinh - năm hành tinh Kim, Mộc, Thủy, Hỏa, Thổ vận hành vũ trụ.	Ngũ Tinh là hình ảnh 5 ngôi sao (hành tinh) sáng nhất có thể quan sát bằng mắt thường, tương ứng với ngũ hành: Kim tinh (Sao Kim), Mộc tinh (Sao Mộc), Thủy tinh (Sao Thủy), Hỏa tinh (Sao Hỏa) và Thổ tinh (Sao Thổ). Trong thiên văn học cổ đại và chiêm tinh học, sự vận động của Ngũ Tinh có ảnh hưởng to lớn đến vận mệnh quốc gia và đời sống con người. Trên Chương Đỉnh, hình ảnh 3 ngôi sao lớn và 2 ngôi sao nhỏ xếp thành chùm thể hiện sự hội tụ của tinh hoa vũ trụ. Triều đình thường quan sát Ngũ Tinh (qua Khâm Thiên Giám) để dự báo điềm lành dữ.	Hiện tượng 'Ngũ tinh liên châu' (năm hành tinh xếp thẳng hàng) được coi là điềm đại cát, báo hiệu thời kỳ thái bình thịnh trị rực rỡ. Việc khắc Ngũ Tinh lên đỉnh thể hiện sự tôn trọng quy luật thiên nhiên và mong cầu vận hội tốt đẹp cho đất nước.	Ngũ Tinh đại diện cho Ngũ Hành - 5 yếu tố cấu thành nên vạn vật. Sự hài hòa của Ngũ Tinh tượng trưng cho sự cân bằng, trật tự và sự phát triển bền vững của vũ trụ và xã hội.	Sao Kim (Thái Bạch) là ngôi sao sáng nhất trong Ngũ Tinh, thường gọi là sao Mai (buổi sáng) hoặc sao Hôm (buổi chiều). Người xưa nhìn màu sắc sao để đoán định: sao sáng trắng là điềm lành, sao đỏ lòm hoặc tối là điềm dữ.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
32ccfbc5-33be-4fa5-9c6b-dfd878a6953f	aa34527e-3a15-41da-8ebe-cfd35ac09a0b	Hoa Hải Đường - sắc đỏ phú quý, báo hiệu xuân sang.	Hải Đường (Camellia amplexicaulis) là loài hoa quý, thường nở vào dịp Tết Nguyên Đán. Hoa có màu đỏ thắm, cánh dày mịn màng, nhụy vàng, trông rất đẫy đà và sang trọng. Người xưa có câu 'Phú quý chơi Hải Đường', vì vậy loài hoa này thường được trồng trong chậu đặt ở phòng khách để cầu may mắn, giàu sang. Khác với Hải đường Trung Quốc (chi Malus - Táo tây), Hải đường Việt Nam thuộc chi Trà (Camellia), không có hương thơm nhưng sắc đẹp thì mặn mà khó quên.	Hải đường là loài hoa bản địa của Việt Nam, được ưa chuộng từ lâu đời. Nó thường xuất hiện trong tranh tết, câu đối đỏ.	Hải đường tượng trưng cho phú quý, viên mãn và tình anh em hòa thuận (do hoa mọc thành chùm). Chữ 'Đường' còn có nghĩa là nhà lớn, hàm ý gia đình hạnh phúc.	Dù tên là 'Hải Đường' (nghĩa đen có thể hiểu là Đường ra biển?) nhưng nó là cây bụi sống trên cạn. Hoa hải đường rất lâu tàn, có thể chơi được cả tháng Tết.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
ce461341-41b9-4e5a-bce0-fab07e13b8c9	e7fd33e8-7cae-4557-ba91-a1a6f4641e69	Sông Gianh - dòng sông lịch sử, ranh giới chia cắt Đàng Trong - Đàng Ngoài một thời.	Linh Giang tức sông Gianh, con sông lớn chảy qua tỉnh Quảng Bình. Trong lịch sử Việt Nam, sông Gianh (cùng với Lũy Thầy) là ranh giới chia cắt đất nước thành Đàng Trong và Đàng Ngoài suốt gần 200 năm thời Trịnh - Nguyễn phân tranh. Dòng sông này đã chứng kiến bao cuộc chiến tranh ác liệt nhưng cũng là 'bức tường thành' tự nhiên che chở cho cơ nghiệp của các chúa Nguyễn. Việc khắc Linh Giang lên Chương Đỉnh không chỉ ghi nhận vị thế địa lý quan trọng của nó mà còn là sự tưởng niệm một giai đoạn lịch sử đau thương nhưng hào hùng, nhắc nhở về giá trị của sự thống nhất non sông ngày nay.	Sông Gianh có dòng chảy sâu, nước xiết, địa thế hiểm trở. Chúa Nguyễn đã dựa vào đây để chống lại các cuộc tấn công của quân Trịnh đông hơn gấp bội. Tên 'Linh Giang' (Sông thiêng) có lẽ xuất phát từ sự tôn kính đối với dòng sông đã bảo vệ vương triều.	Linh Giang tượng trưng cho sự chia cắt và thống nhất, cho nỗi đau chiến tranh và khát vọng hòa bình. Nó là chứng nhân lịch sử bi tráng của dân tộc.	Ngày nay, cầu Gianh bắc qua sông đã nối liền mạch máu giao thông Bắc - Nam, xóa nhòa hoàn toàn sự chia cắt địa lý năm xưa. Vùng hạ lưu sông Gianh có đặc sản 'rượu Ba Đồn' rất nổi tiếng.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
b56b591d-bf73-477b-996a-912bf0fefb73	f405213c-8093-4196-8479-95c8851d6f95	Biển Tây - vùng biển phía Tây Nam giàu tiềm năng của tổ quốc.	Tây Hải (Biển Tây) chỉ vùng biển nằm ở phía Tây Nam nước ta, thuộc Vịnh Thái Lan, bao gồm vùng biển Kiên Giang, Cà Mau. Đây là vùng biển yên bình hơn so với Biển Đông, có nhiều hải đảo đẹp và nguồn tôm cá dồi dào. Việc khắc Tây Hải lên Chương Đỉnh (hoàn thiện bộ ba Đông Hải - Nam Hải - Tây Hải trên 3 đỉnh lớn nhất) là tuyên bố trọn vẹn về chủ quyền biển đảo quốc gia bao trùm ba mặt Đông, Nam, Tây. Nó khẳng định tầm nhìn chiến lược của triều Nguyễn: Việt Nam là một quốc gia biển, làm chủ biển là làm chủ vận mệnh đất nước.	Vùng biển Tây thời xưa là nơi giao thương nhộn nhịp với các nước Xiêm (Thái Lan), Chân Lạp (Campuchia). Các trấn Hà Tiên, Rạch Giá là những trung tâm kinh tế quan trọng. Triều đình thường xuyên cử thủy quân tuần tiễu để chống cướp biển và bảo vệ ngư dân.	Tây Hải tượng trưng cho sự bình yên, trù phú và sự mở rộng giao thương hướng ngoại. Biển Tây với những hòn đảo như Phú Quốc là viên ngọc quý của quốc gia.	Biển Tây có đặc điểm là nước khá nông, nhiều phù sa, thuận lợi cho nuôi trồng thủy sản nhưng ít bão lớn. Đây là nơi ngắm hoàng hôn trên biển đẹp nhất Việt Nam (vì mặt trời lặn xuống biển ở phía Tây).	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
6b2ef974-bd1d-405f-88f7-f6e241f3b795	9edc5858-1b2a-404a-bf9a-fe4b70f3eb62	Cây gỗ Sưa - 'Thuận mộc' quý giá, lõi đỏ như ngọc, giá trị liên thành.	Thuận Mộc (Cây gỗ thuận/hòa thuận) thường được xác định là cây Gỗ Sưa (Huỳnh đàn đỏ - Dalbergia tonkinensis), một loại gỗ cực kỳ quý hiếm. Gỗ sưa có lõi màu đỏ thẫm hoặc tím, vân gỗ tuyệt đẹp như mây bay (vân mây), thớ mịn, mùi thơm nhẹ thoang thoảng như trầm. Gỗ rất bền, không bao giờ bị mối mọt hay nứt nẻ. Xưa kia, gỗ sưa được dùng để đóng đồ nội thất cho vua chúa hoặc làm đồ thờ cúng. Tên 'Thuận' có lẽ hàm ý gỗ này có thớ thuận, dễ chế tác hoặc mang lại sự hòa thuận, may mắn. Ngày nay, gỗ sưa được ví đắt hơn vàng.	Cây sưa mọc rải rác trong các cánh rừng nhiệt đới mưa mùa. Do giá trị quá cao, nó đã bị khai thác cạn kiệt. Việc khắc lên đỉnh là cách người xưa lưu danh một giống cây quý của nước Nam.	Gỗ sưa tượng trưng cho sự phú quý, sang trọng tột bậc và sự trường tồn. Màu đỏ của gỗ mang lại may mắn, trừ tà khí. Người ta tin rằng để gỗ sưa trong nhà sẽ giúp gia đạo hưng vượng.	Gỗ sưa đỏ có giá trị cao nhất. Người ta đồn rằng bột gỗ sưa có thể cầm máu, giảm đau. Giá một kg lõi gỗ sưa già hiện nay có thể lên tới hàng chục, hàng trăm triệu đồng.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
30d6fc63-bf89-46e5-b728-c1550cc9b3fb	7eb70120-14da-4020-85d5-9aea2501c838	Cá sấu - sát thủ đầm lầy, bá chủ vùng sông nước hoang sơ.	Ngạc Ngư là tên Hán Việt của Cá sấu (Crocodylus porosus - cá sấu hoa cà). Đây là loài bò sát ăn thịt khổng lồ, từng sinh sống rất nhiều ở các vùng đầm lầy, cửa sông ven biển miền Nam Việt Nam ('xuống sông hốt trứng cá sấu, lên rừng cọp rình'). Hình ảnh cá sấu trên Chương Đỉnh với bộ hàm sắc nhọn, lớp da sần sùi gai góc thể hiện sự hung dữ và sức mạnh đáng sợ của thiên nhiên. Tuy nhiên, người xưa khắc nó lên đỉnh cũng để tỏ lòng kính sợ ('Ông Năm Chèo' trong tín ngưỡng dân gian Nam Bộ) và mong muốn chế ngự được loài vật nguy hiểm này để an cư lạc nghiệp.	Vùng đất Nam Bộ xưa kia hoang vu, nhiều 'sấu lội cọp um'. Quá trình khai hoang mở đất là quá trình con người chiến đấu và thích nghi với những loài thú dữ này. Cá sấu là biểu tượng của những thử thách thiên nhiên khắc nghiệt mà cha ông ta đã vượt qua.	Cá sấu tượng trưng cho sức mạnh tàn bạo, sự nguy hiểm rình rập dưới mặt nước. Nhưng nó cũng đại diện cho sự thích nghi và quyền lực của kẻ thống trị vùng đầm lầy.	Da cá sấu rất bền và đẹp, ngày nay là sản phẩm thời trang cao cấp. Cá sấu không thể nhai, chúng xé mồi và nuốt chửng. Chúng cũng hay 'khóc' (nước mắt cá sấu) khi ăn, thực ra là để bôi trơn mắt chứ không phải vì thương xót con mồi.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
88d1597a-02df-4c7d-add8-c0f94cbd0b2d	617cbc43-a7ec-4826-b089-57b886a14996	Cá lóc - loài cá quen thuộc, sức sống dẻo dai.	Lục Hoa Ngư (Cá lóc/Cá quả/Cá chuối) là loài cá nước ngọt phổ biến nhất ở Việt Nam. Cá lóc có thân thuôn dài, vảy màu đen vàng giống hoa văn (lục hoa?), đầu to bẹt giống đầu rắn. Đây là loài cá ăn thịt, rất khỏe và có khả năng chịu đựng môi trường khắc nghiệt (sống trong bùn lầy, thiếu oxy). Thịt cá lóc nạc, ngọt, lành tính, là món ăn bổ dưỡng (cháo cá lóc, cá kho tộ, canh chua) và là bài thuốc cho người ốm dậy. Hình ảnh cá lóc trên đỉnh tôn vinh nguồn thủy sản phong phú của sông ngòi Việt Nam.	Cá lóc gắn liền với nền văn minh lúa nước. Người dân thường tát đìa bắt cá lóc sau mùa gặt. Cá lóc nướng trui là đặc sản khẩn hoang phương Nam.	Cá lóc tượng trưng cho sức khỏe, sự kiên cường (cá mẹ bảo vệ con rất dữ) và sự no đủ trong bữa ăn hàng ngày.	Cá lóc có thể trườn trên cạn để tìm nguồn nước mới. Tên 'Lục Hoa' có thể miêu tả màu sắc vảy cá (xanh đen có hoa văn).	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
a2375bde-377a-4646-99f9-60c5fe82a369	e82b3077-b323-4835-a4d9-da22e28eccd5	Thuyền Mông Đồng - chiến thuyền cơ động, mũi nhọn của thủy quân Đại Việt.	Mông Đồng Thuyền là loại thuyền chiến hạng nhẹ, dài và hẹp, mũi nhọn, có nhiều tay chèo, di chuyển cực nhanh và linh hoạt trên sông rạch. Đây là loại thuyền chủ lực của thủy quân Việt Nam qua nhiều triều đại (Lý, Trần, Lê, Nguyễn). Thuyền thường được trang bị mái chèo, buồm và vũ khí (giáo mác, súng hỏa mai). Nhờ khả năng luồn lách giỏi và tốc độ cao, thuyền Mông Đồng rất hiệu quả trong các trận phục kích, truy đuổi hoặc tác chiến ở vùng sông nước chằng chịt. Hình ảnh trên đỉnh cho thấy dáng thuyền thanh thoát, sẵn sàng xé nước lao đi.	Trong các chiến thắng thủy chiến lẫy lừng của dân tộc (như Bạch Đằng), thuyền Mông Đồng đóng vai trò quan trọng. Đến thời Nguyễn, dù có tàu lớn, thuyền Mông Đồng vẫn được duy trì để tuần tra và tác chiến ven bờ.	Thuyền Mông Đồng tượng trưng cho sự nhanh nhẹn, mưu trí và tinh thần thượng võ trên sông nước. Nó là niềm tự hào của nghệ thuật quân sự Việt Nam: 'lấy nhỏ thắng lớn, lấy ít địch nhiều'.	Tên 'Mông Đồng' có thể xuất phát từ cấu trúc thuyền được bọc đồng hoặc hình dáng giống con thuyền độc mộc (Mông: thuyền, Đồng: cùng/chung - thuyền làm từ một thân gỗ lớn? - Thuyết này chưa chắc chắn). Một số tài liệu cho rằng Mông Đồng là loại thuyền đáy nông, mũi thuyền bịt đồng nhọn để đâm thủng thuyền địch.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
96a8f6ae-f865-43bd-b8db-8e4f08eb9f32	7f091ed9-06f5-46a7-a030-6341c0d293f8	Súng Điểu thương - súng hỏa mai cầm tay, vũ khí cá nhân sắc bén của binh lính.	Điểu Thương (Súng chim/Súng bắn chim) là tên gọi của loại súng hỏa mai nòng dài, độ chính xác cao, thường dùng để trang bị cho bộ binh thời Nguyễn. Sở dĩ gọi là 'Điểu thương' vì súng có nòng nhỏ, dài, bắn chính xác như bắn chim, hoặc báng súng có hình mỏ chim. Đây là bước tiến lớn từ vũ khí lạnh (gươm giáo) sang vũ khí nóng (hỏa khí). Binh lính nhà Nguyễn được huấn luyện sử dụng súng này rất thành thạo. Việc khắc súng lên đỉnh thể hiện sự coi trọng công nghệ quân sự và sức mạnh quốc phòng của triều đại.	Vào thế kỷ 17-18, súng hỏa mai phương Tây du nhập vào Việt Nam và được cải tiến. Quân đội nhà Nguyễn nổi tiếng trong khu vực nhờ tỷ lệ trang bị súng hỏa mai rất cao, khiến các nước lân cận phải kiêng nể.	Điểu thương tượng trưng cho sự chính xác, sắc bén và sức mạnh của người lính. Nó cũng đại diện cho sự tiếp thu cái mới để bảo vệ tổ quốc.	Người Việt xưa bắn súng rất giỏi. Giáo sĩ phương Tây từng ghi chép rằng lính Việt Nam bắn súng hỏa mai chính xác không kém gì lính châu Âu, dù súng của họ thô sơ hơn.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
c1a975b5-767d-4120-9db3-c7019adda5c0	5f05c475-8e53-4554-a667-c841614d78ef	Tê giác - mãnh thú một sừng, biểu tượng của sự dũng mãnh và linh thiêng.	Tê (Tê ngưu/Tê giác) là loài thú lớn, da dày, có sừng nhọn ở mũi, từng sinh sống ở rừng núi Việt Nam (Tê giác Java một sừng). Trên Chương Đỉnh, hình ảnh tê giác lầm lũi, chắc nịch thể hiện sức mạnh không gì ngăn cản nổi. Sừng tê giác xưa kia được coi là vật phẩm cực kỳ quý giá, có thể giải độc (ly sừng tê) và trừ tà. Trong văn hóa, Tê giác (Tê) đồng âm với 'Tây' (phía Tây) hoặc 'Tề' (cai trị), mang hàm ý tốt đẹp. Sự hiện diện của nó trên đỉnh bổ sung vào bộ sưu tập thú quý, khẳng định sự giàu có của tài nguyên thiên nhiên.	Đáng buồn là Tê giác một sừng ở Việt Nam đã chính thức tuyệt chủng vào năm 2010. Hình ảnh trên Cửu Đỉnh giờ đây trở thành tư liệu lịch sử quý giá về một loài vật từng tồn tại trên đất nước ta.	Tê giác tượng trưng cho sự kiên định, sức mạnh nội tại và khả năng phòng vệ (da dày). Sừng tê (Linh sừng) là biểu tượng của sự linh nghiệm và cứu sinh (giải độc).	Người xưa tin rằng 'Tê ngưu vọng nguyệt' (Trâu tê ngắm trăng) là hình ảnh rất đẹp và lãng mạn. Sừng tê giác thực chất cấu tạo từ keratin (giống tóc, móng tay) chứ không phải xương, nhưng lại bị đồn thổi có công dụng thần kỳ quá mức khiến chúng bị săn bắt đến tuyệt chủng.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
d2d3eb21-dbbb-4da4-a4fc-34c6fa7b6291	883b8388-7f3d-466e-ba88-9659dfbe3b4b	Linh Quy - rùa thần, biểu tượng của sự trường thọ và trí tuệ ngàn năm.	Linh Quy (Rùa thiêng) là một trong Tứ Linh (Long - Lân - Quy - Phụng). Rùa là loài vật có tuổi thọ rất cao, chịu đựng được đói khát, mai rùa khum khum tượng trưng cho bầu trời, bụng phẳng tượng trưng cho mặt đất. Trên Chương Đỉnh, Linh Quy được khắc họa với dáng vẻ chậm rãi, vững chãi, thường đội bia đá hoặc sách quý (Lạc Thư). Rùa biểu thị cho sự trường tồn của quốc gia, sự kiên nhẫn và trí tuệ tích lũy qua thời gian. Truyền thuyết Thần Kim Quy giúp An Dương Vương xây thành Cổ Loa cho thấy rùa luôn là vị thần bảo hộ đất nước.	Hình ảnh rùa đội bia đá trong Văn Miếu - Quốc Tử Giám là biểu tượng tôn vinh sự học và tri thức. Việc khắc Linh Quy lên đỉnh là sự trân trọng đối với hiền tài và mong muốn nền văn hiến nước nhà mãi mãi vững bền như bàn thạch.	Quy (Rùa) tượng trưng cho sự trường thọ, sự ổn định (vững như bàn thạch) và sự nhẫn nại. Mai rùa với các họa tiết bát quái được coi là chứa đựng bí mật của vũ trụ.	Rùa là loài duy nhất trong Tứ Linh là con vật có thật trong tự nhiên (Long, Lân, Phụng là tưởng tượng). Điều này làm cho hình tượng Rùa vừa linh thiêng lại vừa gần gũi.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
0d593fe9-609d-41e1-bf22-39b67faa1ca6	e823f581-e98e-412e-a901-baf5918ed599	Anh Đỉnh - chiếc đỉnh tượng trưng cho tài năng xuất chúng và sự vinh hiển của vua Tự Đức.	Anh Đỉnh là chiếc đỉnh thứ tư trong Cửu Đỉnh, được đặt bên trái của Nhân Đỉnh (từ trong nhìn ra). Chữ 'Anh' (英) trong tên đỉnh có nghĩa là tài năng xuất chúng, tốt đẹp, hay tinh hoa (như trong từ anh hùng, anh minh). Đây là thụy hiệu của vua Tự Đức (1829-1883), vị vua có thời gian trị vì lâu nhất triều Nguyễn (36 năm). Vua Tự Đức nổi tiếng là người hay chữ, giỏi văn thơ, hiếu thảo nhưng cuộc đời ông cũng gắn liền với nhiều bi kịch và biến động lớn của lịch sử dân tộc khi thực dân Pháp bắt đầu xâm lược. Anh Đỉnh nặng khoảng 2.600kg, thể hiện mong muốn về một triều đại rực rỡ, hội tụ những gì tinh túy nhất của đất trời và con người.	Anh Đỉnh được đúc năm 1835, dự báo cho thế hệ vua thứ tư. Vua Tự Đức là người kế thừa ngai vàng trong bối cảnh đất nước bắt đầu đối mặt với họa ngoại xâm. Dù triều đại của ông gặp nhiều khó khăn, nhưng những giá trị văn hóa, sử học để lại (như bộ Khâm định Việt sử thông giám cương mục) vẫn rất đồ sộ.	Chữ 'Anh' tượng trưng cho vẻ đẹp của loài hoa (anh hoa) và tài năng vượt trội. Đặt tên đỉnh là Anh Đỉnh thể hiện kỳ vọng vào sự phát triển văn hóa và sự xuất hiện của những nhân tài kiệt xuất giúp nước.	Vua Tự Đức là vị vua để lại nhiều bài thơ nhất trong lịch sử Việt Nam, được khắc rất nhiều trên các kiến trúc cung đình Huế. Lăng Tự Đức (Khiêm Lăng) cũng được đánh giá là lăng tẩm thơ mộng và đẹp nhất.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
628241d0-d20f-4411-a7ba-6c0691ad6453	f043389a-e5aa-4092-9cba-4ede2943e761	Con ve sầu - nhạc sĩ mùa hè, biểu tượng của sự tái sinh và thanh khiết.	Thiền (Con ve sầu) là loài côn trùng quen thuộc gắn liền với mùa hạ ở Việt Nam. Tiếng ve kêu râm ran báo hiệu hè về, gợi lên bao cảm xúc bồi hồi. Ve sầu có vòng đời rất đặc biệt: ấu trùng sống nhiều năm dưới lòng đất, sau đó mới chui lên lột xác hóa thành ve, sống cuộc đời ngắn ngủi nhưng rực rỡ trên cành cây, chỉ uống sương mai và ca hát. Chính vì đặc điểm này, ve sầu (Thiền) được người xưa coi là biểu tượng của sự thanh khiết (uống sương), sự thoát tục và sự tái sinh (thoát xác). Hình ảnh ve sầu trên Anh Đỉnh được chạm khắc tinh tế, từng đường gân cánh mỏng manh hiện lên sống động trên nền đồng.	Trong văn hóa cổ, ngọc thiền (ve sầu bằng ngọc) thường được đặt trong miệng người đã khuất với mong ước về sự tái sinh ở thế giới bên kia. Trong thơ ca, tiếng ve thường gợi nỗi buồn ly biệt hoặc hoài niệm.	Ve sầu tượng trưng cho sự bất tử, sự phục sinh và sự thanh cao. Tiếng ve vang xa còn biểu thị cho danh tiếng lan truyền.	Ve sầu đực mới là những 'ca sĩ' thực thụ, chúng có bộ phận phát thanh ở bụng để kêu gọi bạn tình. Ve sầu cái không kêu được nên còn gọi là 've câm'. Ve sầu lột xác (Kim thiền thoát xác) còn là một kế sách trong binh pháp (giả chết để trốn thoát).	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
c7911836-1783-41e4-a296-41ec846305ab	c7de7984-89a9-456c-ad39-eb28a0625771	Cây Tô Hợp - loài cây cho nhựa thơm quý giá dùng làm thuốc và hương liệu.	Tô Hợp (Liquidambar formosana) hay còn gọi là cây Sau Sau, Bạch giao hương. Đây là loài cây thân gỗ lớn, lá hình chân vịt giống lá phong, chuyển màu đỏ rất đẹp vào mùa thu. Nhựa của cây (Tô hợp hương) là một vị thuốc quý và hương liệu đắt tiền, dùng để chữa bệnh (khai khiếu, giải uất) và chế tạo nước hoa. Việc khắc cây Tô Hợp lên Anh Đỉnh không chỉ ghi nhận vẻ đẹp của loài cây này mà còn tôn vinh giá trị y học và kinh tế của nó. Rừng cây Sau Sau vào mùa thay lá tạo nên cảnh quan thơ mộng không kém gì mùa thu phương Bắc.	Tô hợp hương từng là cống phẩm quan trọng. Trong y học cổ truyền, nó được dùng trong các bài thuốc cấp cứu trúng phong, đau ngực. Vua Minh Mạng rất quan tâm đến việc tìm kiếm và bảo tồn các loài dược liệu quý trong nước.	Cây Tô Hợp tượng trưng cho sự chữa lành và hương thơm đức hạnh. Sự thay đổi màu lá theo mùa cũng gợi lên quy luật tuần hoàn của thời gian và vẻ đẹp biến ảo của thiên nhiên.	Quả của cây Sau Sau có hình cầu với nhiều gai nhỏ, trông như quả chôm chôm, khi khô rụng xuống thường được trẻ con nhặt chơi hoặc dùng làm thuốc. Lá non của cây có vị chát, chua nhẹ, có thể ăn sống như rau ghém với các món cuốn.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
61ec085b-360b-4cf4-a8f9-4f4fa7a81c78	257959d8-ce69-4701-99a7-252c5e02eacb	Củ nghệ - 'Uất kim' vàng óng, gia vị và vị thuốc không thể thiếu trong mỗi gia đình.	Uất Kim (trong đông y gọi phần củ con là Uất kim, củ cái là Khương hoàng) chính là cây Nghệ (Curcuma longa). Đây là loài cây thân thảo, củ có màu vàng cam rực rỡ, chứa hoạt chất curcumin quý giá. Nghệ vừa là gia vị tạo màu và mùi thơm đặc trưng cho các món ăn (cá kho, cà ri, bánh xèo...), vừa là thần dược chữa bệnh dạ dày, làm lành vết thương, làm đẹp da cho phụ nữ. Tên 'Uất Kim' (Vàng uất tích) miêu tả màu vàng đậm đà ẩn giấu trong lòng đất. Việc khắc cây nghệ lên Anh Đỉnh thể hiện sự trân trọng đối với những cây thuốc nam gần gũi nhưng công dụng phi thường.	Nghệ đã được người Việt sử dụng hàng ngàn năm nay. Trong quân đội xưa, bột nghệ và vôi được dùng để chữa vết thương cho binh lính. Nghệ cũng là cây trồng kinh tế quan trọng ở nhiều vùng.	Màu vàng của nghệ tượng trưng cho hành Thổ (trung tâm), sự ôn hòa và chữa lành. Nó cũng biểu thị cho sự quý giá tiềm ẩn (vàng trong đất).	Nghệ là thành phần chính tạo nên màu vàng của cà ri. Ngoài nghệ vàng, Việt Nam còn có nghệ đen (Nga truật) và nghệ trắng, mỗi loại có công dụng chữa bệnh khác nhau. Uất kim (củ nhánh) có tác dụng hành khí giải uất, còn Khương hoàng (củ cái) có tác dụng phá huyết.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
0ac345dd-8593-4de6-98a7-a073311db14e	4ba1f6ce-ac67-4389-87a3-4d44b09486a9	Cây cau - biểu tượng của tình yêu đôi lứa và văn hóa trầu cau.	Tân Lang là tên Hán Việt của cây Cau (Areca catechu). Cây cau có thân thẳng đứng, cao vút, không cành lá xum xuê ở dưới mà tập trung trên ngọn, tượng trưng cho sự ngay thẳng, khí tiết của người quân tử. Quả cau cùng với lá trầu và vôi tạo nên miếng trầu 'là đầu câu chuyện', mở đầu cho mọi lễ nghi cưới hỏi, giao tiếp của người Việt. Sự tích 'Trầu Cau' ca ngợi tình anh em, nghĩa phu thê son sắt. Hình ảnh cây cau trên Anh Đỉnh là sự tôn vinh nét đẹp văn hóa truyền thống sâu sắc của dân tộc.	Tục ăn trầu đã có từ thời Hùng Vương và phổ biến khắp Đông Nam Á. Ngày xưa, 'miếng trầu là đầu câu chuyện', vua chúa cũng dùng trầu cau để tiếp khách. Cây cau thường được trồng trước nhà ('Trước cau sau chuối') để đón gió mát và tạo cảnh quan trang nghiêm.	Cây cau (Tân lang) tượng trưng cho người chồng (Tân lang - Chàng rể), sự thủy chung và lòng ngay thẳng. Nó cũng biểu thị cho sự vươn lên mạnh mẽ, không khuất phục trước bão tố.	Hoa cau có mùi thơm rất dịu và thanh khiết. Bẹ cau (mo cau) rụng xuống thường được người dân quê dùng làm quạt (quạt mo) hoặc gáo múc nước. Thân cau già rất cứng, dùng làm rui mè nhà tranh rất tốt.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
02db0f7e-99f8-4913-8532-3c9c891a660b	9293bbac-360e-42c6-af8a-0470e8a39204	Đuông dừa - đặc sản dân dã, nỗi ám ảnh của cây dừa.	Hồ Da Tử (Con đuông dừa/Mọt dừa) là ấu trùng của loài bọ kiến dương. Chúng sống trong ngọn cây dừa (hoặc cau, chà là), ăn củ hủ dừa làm cây chết. Tuy là loài phá hoại cây trồng (Hồ da: vỏ dừa?), nhưng đuông dừa lại là món ăn đặc sản béo ngậy, giàu dinh dưỡng của người dân Nam Bộ và Nam Trung Bộ. Việc khắc loài côn trùng nhỏ bé này lên đỉnh cho thấy cái nhìn thực tế và đa dạng về thế giới sinh vật của người xưa, bao gồm cả những loài vật gây hại nhưng lại có giá trị thực phẩm.	Đuông dừa từng được coi là cống phẩm 'Sơn hào hải vị' dâng lên vua chúa. Món đuông dừa tắm nước mắm là thử thách ẩm thực thú vị.	Sự xuất hiện của Hồ Da Tử nhắc nhở về việc bảo vệ mùa màng (phòng trừ sâu bệnh) và sự phong phú của ẩm thực dân gian.	Một con đuông dừa có thể to bằng ngón chân cái. Người ta phải áp tai vào thân cây dừa để nghe tiếng đuông ăn lạo xạo bên trong mới bắt được.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
41a0c0d7-803a-419a-b259-f1558ce312a2	d81a0c2d-947b-4379-b82e-cc8efddbf185	Chim hạc - nhất phẩm điểu, biểu tượng của sự trường thọ và thanh cao.	Khôi Hạc (Chim hạc lớn/Hạc tiên) được coi là 'nhất phẩm điểu' - đứng đầu các loài chim (chỉ sau Phượng hoàng). Hạc có dáng đi thanh thoát, cổ cao, chân dài, bộ lông thường màu trắng hoặc xám tro. Trong văn hóa phương Đông, hạc là vật cưỡi của thần tiên, tượng trưng cho sự trường thọ (tùng hạc diên niên) và phẩm chất thanh cao, thoát tục của người quân tử. Hạc không ăn tạp, tiếng kêu lảnh lót thấu trời xanh. Hình ảnh Khôi Hạc trên Anh Đỉnh thể hiện ước vọng về một xã hội thịnh trị, nơi đạo đức và văn hóa được đề cao.	Hạc thường xuất hiện trên lưng rùa trong các đình chùa (Hạc ngự long quy), biểu thị sự hòa hợp âm dương và trường tồn. Trong triều đình, hình bổ tử (miếng vải vuông trước ngực áo quan) của quan văn nhất phẩm thường thêu hình chim hạc.	Hạc tượng trưng cho tuổi thọ, sự thông tuệ và cuộc sống ẩn dật thanh tao. Hạc còn biểu thị cho lòng trung thành và sự tận tụy.	Mặc dù Hạc rất nổi tiếng trong văn hóa, nhưng loài Sếu đầu đỏ ở Tràm Chim (Đồng Tháp Mười) mới thực sự là loài chim quý hiếm ngoài đời thực có dáng vẻ giống hạc nhất ở Việt Nam. Hạc trong nghệ thuật thường được cách điệu hóa.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
ce3f57c6-89f8-40c3-8d5a-2f6206fc66c9	7e398757-b356-4a0b-8457-4c2006160b7a	Hoa hồng - 'Mai khôi' kiêu sa, hương sắc vẹn toàn.	Mai Khôi Hoa (hoặc Mân Côi/Hồng) chính là hoa hồng (Rosa). Tên gọi 'Mai Khôi' là cách gọi cổ, chỉ loại đá quý màu đỏ, sau dùng để chỉ loài hoa có màu đỏ thắm quyến rũ này. Hoa hồng có hương thơm nồng nàn, cánh hoa mịn màng xếp lớp nhưng thân lại có gai nhọn, tượng trưng cho vẻ đẹp kiêu sa nhưng khó chạm tới. Trên Anh Đỉnh, hoa hồng được khắc họa mềm mại, tôn vinh vẻ đẹp của thiên nhiên. Người xưa cũng dùng hoa hồng để làm thuốc (nụ hoa hồng khô chữa đau bụng, giải uất) và làm hương liệu, mỹ phẩm cung đình (nước hoa hồng, phấn nụ).	Dưới triều Nguyễn, các giống hồng quý (hồng nhung, hồng quế, hồng bạch) được trồng nhiều trong Thượng Uyển để vua chúa thưởng lãm. Tinh dầu hoa hồng là thứ xa xỉ phẩm.	Hoa hồng (Mai Khôi) tượng trưng cho tình yêu, sắc đẹp và sự phú quý. Gai của hoa hồng nhắc nhở rằng cái đẹp luôn cần được bảo vệ và không dễ gì chiếm đoạt.	Tên 'Mai Khôi' (Mân Côi) còn được dùng trong Thiên Chúa giáo (Kinh Mân Côi - Chuỗi hoa hồng), cho thấy sự giao thoa văn hóa thú vị. Hoa hồng bản địa Việt Nam thường có bông nhỏ hơn nhưng hương thơm đậm đà hơn các giống hồng lai hiện đại.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
0bb902eb-d090-4ebe-90e3-162d15b68f69	b974a9c9-47ce-405c-b398-ec026ec08b00	Dải Ngân Hà - sông bạc trên trời, cầu nối của Ngưu Lang Chức Nữ.	Ngân Hán (hay Thiên Hà, Ngân Hà) là dải sáng vắt ngang bầu trời đêm, được người xưa hình dung như một dòng sông bạc (Ngân: bạc, Hán: sông) chảy giữa các vì sao. Trong thần thoại Á Đông, Ngân Hà gắn liền với sự tích Ngưu Lang - Chức Nữ, đôi vợ chồng bị chia cắt đôi bờ sông Ngân và chỉ được gặp nhau một lần mỗi năm vào ngày Thất Tịch (7/7 âm lịch) qua cầu Ô Thước. Hình ảnh Ngân Hán trên Anh Đỉnh thể hiện sự quan sát tinh tế về vũ trụ và trí tưởng tượng lãng mạn của người xưa. Nó đại diện cho sự bao la, bí ẩn của bầu trời và những quy luật thiên văn huyền diệu.	Việc quan sát Ngân Hà giúp người xưa định hướng và xác định mùa vụ. Sự sáng tỏ hay mờ nhạt của sông Ngân cũng được các quan Khâm Thiên Giám dùng để dự báo thời tiết và vận mệnh.	Ngân Hán tượng trưng cho sự chia xa, nỗi nhớ mong nhưng cũng là niềm hy vọng về sự đoàn tụ. Nó là ranh giới giữa cõi trần và cõi tiên.	Thực chất, Ngân Hà là thiên hà chứa Hệ Mặt Trời của chúng ta, gồm hàng tỷ ngôi sao. Nhìn từ Trái Đất, nó giống như một dải sữa (Milky Way) đổ tràn trên bầu trời đêm.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
9e7b6878-d71d-4eed-b082-89b9f78793b5	df8114b8-be0e-4223-a2ce-e4e4b5c06d1c	Sông Mã - dòng sông hùng vĩ của núi rừng Tây Bắc và Thanh Hóa.	Mã Giang (Sông Mã) là con sông lớn bắt nguồn từ Tây Bắc, chảy qua Lào rồi về Thanh Hóa đổ ra biển. Sông Mã nổi tiếng với dòng chảy xiết, ghềnh thác hiểm trở, gắn liền với hình ảnh đoàn quân Tây Tiến hào hùng sau này. Tên 'Sông Mã' được cho là do tiếng nước chảy mạnh như tiếng ngựa hí (Mã: ngựa), hoặc do nước sông chảy xiết nhanh như ngựa phi. Việc khắc Mã Giang lên Anh Đỉnh khẳng định chủ quyền lãnh thổ miền Tây và ghi nhận vai trò quan trọng của dòng sông này trong lịch sử và đời sống cư dân Thanh Hóa - vùng đất phát tích của nhà Nguyễn.	Thanh Hóa là đất tổ của các chúa Nguyễn (Gia Miêu Ngoại Trang). Sông Mã là huyết mạch giao thông và thủy lợi của vùng này. 'Sông Mã gầm lên khúc độc hành' đã trở thành biểu tượng của sự dữ dội và kiêu hãnh.	Sông Mã tượng trưng cho sức mạnh hoang dã, sự kiên cường và ý chí bất khuất. Dòng sông cũng bồi đắp phù sa tạo nên đồng bằng trù phú.	Sông Mã là nơi có đặc sản 'Cá Lăng sông Mã' nổi tiếng. Đây cũng là dòng sông duy nhất ở Việt Nam chảy sang nước bạn Lào rồi lại quay về Việt Nam.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
c1b2f4e6-39fe-49bd-8e1c-de78c4f6a62a	0524c8dc-ca80-4fd8-bc24-06898135d9f4	Sao Bắc Đẩu - chòm sao chỉ đường, biểu tượng của sự định hướng và quyền lực.	Bắc Đẩu (Bắc Đẩu Thất Tinh) là chòm sao gồm 7 ngôi sao sáng xếp thành hình cái gáo (hoặc cái đấu) nằm ở phương Bắc. Đây là chòm sao quan trọng nhất để xác định phương hướng (tìm sao Bắc Cực) trong hàng hải và đi lại ban đêm. Trong văn hóa tâm linh, Nam Tào (coi sổ sinh) và Bắc Đẩu (coi sổ tử) là hai vị thần thân cận của Ngọc Hoàng, nắm giữ vận mệnh con người. Trên Anh Đỉnh, chòm sao Bắc Đẩu được khắc rõ nét, thể hiện sự am hiểu thiên văn và niềm tin vào sự bảo trợ của thần linh đối với vương triều. Bắc Đẩu còn được ví như ngôi sao của bậc đế vương, mọi sao khác đều chầu về.	Người xưa quan niệm 'Thiên nhân tương cảm', nhìn sao Bắc Đẩu sáng hay tối, đổi màu hay không để đoán biết điềm lành dữ của quốc gia. Nó là kim chỉ nam cho cả nghĩa đen (phương hướng) và nghĩa bóng (đạo trị nước).	Sao Bắc Đẩu tượng trưng cho sự dẫn đường, công lý (xét xử sống chết) và quyền lực trung tâm. Nó là biểu tượng của sự ổn định và trường tồn.	Hình dáng của Bắc Đẩu giống cái gáo múc nước. Trong 7 ngôi sao này, ngôi sao ở đầu gáo (Thiên Xu) và ngôi thứ hai (Thiên Tuyền) tạo thành đường thẳng chỉ về sao Bắc Cực (Polaris) - ngôi sao luôn đứng yên ở phương Bắc.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
dd6233dd-9c9d-4588-9e3f-a97766bb4226	129ee8ff-9912-4562-987c-bf1df6079dc0	Núi Hồng Lĩnh - biểu tượng thiêng liêng 'Hoan Châu đệ nhất danh thắng'.	Hồng Sơn (Núi Hồng Lĩnh) là dãy núi huyền thoại thuộc tỉnh Hà Tĩnh, được mệnh danh là hồn thiêng sông núi của xứ Nghệ. Núi có 99 ngọn, gắn liền với truyền thuyết 100 con chim phượng hoàng tìm nơi đậu (nhưng thiếu một ngọn nên bay đi). Hồng Lĩnh soi bóng xuống dòng sông Lam tạo nên bức tranh sơn thủy hữu tình tuyệt đẹp. Trên Anh Đỉnh, núi Hồng Lĩnh hiện lên uy nghi, trầm mặc. Đây là nơi hội tụ nhiều di tích lịch sử, chùa chiền (như Chùa Hương Tích) và là cái nôi của nhiều danh nhân văn hóa.	Vua Minh Mạng đã cho khắc Hồng Lĩnh vào danh sách các núi thiêng (được thờ tự) của đất nước. Núi là căn cứ địa quan trọng của nhiều cuộc khởi nghĩa trong lịch sử.	Núi Hồng Lĩnh tượng trưng cho khí phách kiên trung, hiếu học và tài hoa của con người xứ Nghệ. Số 99 ngọn núi biểu thị sự trường tồn và gần đạt đến sự hoàn hảo.	Có câu ca 'Đường vô xứ Nghệ quanh quanh / Non xanh nước biếc như tranh họa đồ' chính là tả cảnh núi Hồng sông Lam. Chùa Hương Tích trên núi Hồng Lĩnh được mệnh danh là 'Hoan Châu đệ nhất danh lam'.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
0848dca7-40fe-4e9e-bd89-fafd7d12d904	99a0d77c-c789-4ee4-a7ba-3b714e817315	Con ngựa - chiến mã trung thành, biểu tượng của sự thành công và tốc độ.	Mã (Con ngựa) là loài vật gắn bó mật thiết với con người trong chiến tranh và di chuyển. Ngựa tượng trưng cho sức bền, tốc độ và lòng trung thành tuyệt đối với chủ nhân. Trên Anh Đỉnh, hình ảnh con ngựa đang phi nước đại (Mã đáo) thể hiện khí thế hừng hực và sự thăng tiến. Trong quân đội triều Nguyễn, kỵ binh và tượng binh là hai binh chủng chủ lực. Ngựa chiến (chiến mã) được chăm sóc rất kỹ lưỡng. Hình tượng ngựa còn gắn với câu chúc 'Mã đáo thành công' - mong muốn mọi việc thuận lợi, nhanh chóng.	Ngựa dùng trong cung đình và quân đội thường được tuyển chọn từ các giống ngựa quý trong nước hoặc nhập từ nước ngoài (ngựa Bắc thảo). Hệ thống trạm ngựa (Trạm dịch) thời Nguyễn hoạt động rất hiệu quả để truyền tin tức.	Ngựa tượng trưng cho khí Dương, sự mạnh mẽ, tự do và thăng tiến. Nó cũng đại diện cho sự tận tụy và khả năng vượt qua đường xa gian khổ.	Ngựa ngủ đứng. Một con ngựa khỏe có thể chạy với tốc độ 60-80km/h. Trong 12 con giáp, ngựa (Ngọ) ứng với giờ giữa trưa (11h-13h), lúc dương khí thịnh nhất.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
5127f69a-a747-43c7-8b70-e69f1affb987	2d339750-6ffc-4e07-b35b-b8d10cb0fe53	Cây dâu tằm - nguồn gốc của nghề ươm tơ dệt lụa truyền thống.	Tang (Cây dâu tằm) là loài cây không thể thiếu trong nghề nông trang truyền thống: trồng dâu, nuôi tằm, dệt lụa. Hình ảnh cây dâu trên Anh Đỉnh tôn vinh nghề thủ công nghiệp và sự cần cù của người phụ nữ Việt Nam. Lá dâu dùng để nuôi tằm, quả dâu (tang thầm) ăn ngon và làm thuốc, vỏ rễ dâu (tang bạch bì) chữa ho, cành dâu (tang chi) chữa đau nhức xương khớp. Cây dâu gắn liền với đời sống vật chất và cả tâm linh (dùng roi dâu để trừ tà) của người dân. Sự hiện diện của nó khẳng định tầm quan trọng của ngành dệt may nước nhà.	Lụa tơ tằm Việt Nam từng là mặt hàng xuất khẩu giá trị trên Con đường tơ lụa trên biển. Các làng nghề trồng dâu nuôi tằm như Vạn Phúc, Tân Châu đã có từ lâu đời.	Cây dâu tượng trưng cho sự tần tảo, hi sinh và tình nghĩa vợ chồng (ruộng dâu nương dâu - bãi bể nương dâu). Nó cũng mang ý nghĩa trừ tà ma, bảo vệ trẻ em.	Thành ngữ 'Bãi bể nương dâu' (Thương hải tang điền) dùng để chỉ sự thay đổi to lớn của cuộc đời và thế sự (biển xanh biến thành ruộng dâu và ngược lại).	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
5361e80b-6c1b-4d38-8829-89149a5720a3	052469aa-b188-41d7-8e77-4b9ab6465683	Lá cờ - hiệu lệnh quân sự và biểu tượng của quốc gia.	Kỳ (Lá cờ) là vật dụng quan trọng trong nghi lễ và quân sự. Trong chiến trận, lá cờ dùng để ra hiệu lệnh (tiến, lui, dàn trận), tập hợp binh sĩ và khích lệ tinh thần chiến đấu ('Cờ phấp phới', 'Trảm tướng đoạt kỳ'). Trên Anh Đỉnh, hình ảnh lá cờ tung bay trong gió thể hiện uy thế và sự chính quy của quân đội triều đình. Mỗi loại cờ có màu sắc và hình vẽ khác nhau (cờ rồng, cờ hổ, cờ ngũ hành...) quy định rõ cấp bậc và chức năng. Cờ còn là biểu tượng của chủ quyền lãnh thổ trên các vùng đất và biển đảo.	Triều Nguyễn có quy định rất nghiêm ngặt về cờ quạt, nghi trượng. Cờ Long tinh (cờ vàng hình chữ nhật, viền tua, giữa có hình rồng) là quốc kỳ của Đại Nam thời bấy giờ.	Lá cờ tượng trưng cho sự tập hợp, sự dẫn dắt và niềm tự hào. Giữ vững lá cờ là giữ vững tinh thần và danh dự.	Trong các trò chơi dân gian như Cờ người, các quân cờ di chuyển theo hiệu lệnh cờ đuôi nheo. Thành ngữ 'Cờ đến tay ai người ấy phất' nói về việc nắm bắt cơ hội.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
4b356aea-472d-445e-9b66-3b4f93540237	25a42e96-5aa0-4f57-9192-a4e3bdc9e137	Đạn Hồ điệp - vũ khí nổ độc đáo, uy lực như đàn bướm bay tỏa.	Hồ Điệp Tử (Đạn bươm bướm) là một loại đạn pháo đặc biệt của quân đội nhà Nguyễn. Tên gọi này xuất phát từ cơ chế nổ hoặc hình dáng của đạn: khi bắn ra, đạn mẹ nổ tung phóng ra nhiều mảnh đạn nhỏ hoặc đạn con bay tản ra tứ phía như đàn bướm (hồ điệp) bay, gây sát thương diện rộng cho đội hình địch. Cũng có thể đây là một loại đạn chùm (grapeshot) hoặc đạn ria. Việc chế tạo được loại đạn này chứng tỏ trình độ kỹ thuật quân sự rất cao của người Việt thời đó. Hình ảnh trên đỉnh là sự ghi nhận những sáng tạo quốc phòng độc đáo.	Sách 'Binh chế chí' và các tài liệu quân sự triều Nguyễn có nhắc đến nhiều loại súng đạn, hỏa cầu phong phú. Hồ Điệp Tử là minh chứng cho tư duy chiến thuật 'lấy 1 địch 10', dùng hỏa lực diện rộng để chặn đứng quân thù đông đảo.	Tên gọi mỹ miều 'Hồ Điệp' (Bướm) tương phản với sức hủy diệt của vũ khí, gợi lên sự biến ảo khôn lường của chiến tranh. Nó tượng trưng cho sự lan tỏa và hiệu quả sát thương.	Đây là một trong những loại vũ khí bí hiểm ít được biết đến. Nó cho thấy cha ông ta không chỉ dùng vũ khí thô sơ mà đã nghiên cứu các loại đạn dược phức tạp.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
5e5e5480-2717-4afb-b09b-ef0c7e3ea04d	c981ef78-19cc-49aa-90e3-95e2f9b6b85a	Con trăn - loài bò sát khổng lồ, biểu tượng của sức mạnh cuộn siết.	Nhiêm Xà (Con trăn) là loài bò sát lớn nhất trong họ nhà rắn, không có nọc độc nhưng có sức mạnh cơ bắp khủng khiếp. Trăn săn mồi bằng cách quấn chặt (siết) con mồi cho đến khi tắt thở rồi nuốt chửng. Ở Việt Nam có trăn đất và trăn gấm (trăn hoa) với kích thước rất lớn. Hình ảnh trăn trên Anh Đỉnh với thân mình cuộn khúc, da có vân hoa đẹp mắt, thể hiện sự uy nghi và sức mạnh tiềm ẩn của rừng già. Mỡ trăn, mật trăn và da trăn đều là những vị thuốc và sản phẩm có giá trị.	Trong tín ngưỡng dân gian, trăn thường được coi là 'Ông Trăn', 'Bà Trăn', có linh tính. Việc khắc trăn lên đỉnh bên cạnh các loài thú dữ khác như hổ, báo, tê giác làm phong phú thêm bức tranh sinh thái.	Trăn tượng trưng cho sự kiên nhẫn (rình mồi), sức mạnh mềm dẻo (nhu thắng cương) và khả năng nuốt trọn những điều to lớn. Nó cũng gợi lên vẻ đẹp bí ẩn và đáng sợ của thiên nhiên.	Trăn có thể nhịn ăn hàng tháng trời sau một bữa no. Da trăn gấm có hoa văn hình mắt lưới rất đẹp, thường bị săn bắt để làm túi xách, giày dép, đàn nhị... khiến số lượng giảm sút nghiêm trọng.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
a139cca1-c5f0-4f28-a4cf-91f35bf15c62	34768841-3aad-4d97-bf82-16e7e7dda5c0	Cây gỗ kiến - loài cây chủ nuôi cánh kiến đỏ, cho sản phẩm sơn cánh kiến quý giá.	Tử Mộc (Cây gỗ kiến/Cây chủ cánh kiến) là tên gọi chỉ các loài cây mà bọ cánh kiến đỏ (Laccifer lacca) ký sinh để tiết ra nhựa cánh kiến (lacquer/shellac). Đây có thể là cây Cọ phèn (Schleichera oleosa) hoặc một số loài cây rừng khác. Nhựa cánh kiến đỏ là nguyên liệu quý để chế biến véc-ni đánh bóng gỗ, làm chất cách điện, dược phẩm và nhuộm màu (màu đỏ). Việc khắc cây Tử Mộc lên Anh Đỉnh ghi nhận một nghề thủ công độc đáo và nguồn lợi lâm sản đặc biệt của Việt Nam. Tên 'Tử' (màu tím đỏ) có thể ám chỉ màu của nhựa cánh kiến.	Sơn cánh kiến (Shellac) từng là mặt hàng xuất khẩu quan trọng. Nghề nuôi thả cánh kiến đỏ ở các vùng núi phía Bắc và miền Trung đem lại thu nhập cao cho người dân. Nhựa cánh kiến được dùng để nhuộm răng đen, nhuộm vải và trang trí đồ gỗ.	Tử Mộc tượng trưng cho sự cống hiến thầm lặng (làm vật chủ cho loài khác) và giá trị kết tinh từ sự cộng sinh của thiên nhiên. Màu đỏ của cánh kiến tượng trưng cho may mắn.	Cánh kiến đỏ thực chất là nhựa do con bọ cái tiết ra để bao bọc cơ thể và trứng. Để thu hoạch, người ta phải bẻ cả cành cây có bám nhựa. Shellac ngày nay vẫn được dùng để làm lớp phủ bóng cho kẹo, dược phẩm và nhạc cụ.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
05910db6-fbab-4df6-9ffc-77cef114303f	33f759ab-d17d-4e24-9f74-369e14336bf3	Nghị Đỉnh - biểu tượng của sự kiên nghị và kỷ cương triều chính.	Nghị Đỉnh là chiếc đỉnh thứ sáu trong Cửu Đỉnh, nằm ở phía trái (nhìn từ trong ra), đối diện với Thuần Đỉnh. Chữ 'Nghị' (毅) mang ý nghĩa quả quyết, cứng cỏi, kiên định. Đây là thụy hiệu của vua Kiến Phúc (1869-1884), một vị vua lên ngôi khi còn rất trẻ và trị vì trong thời gian ngắn ngủi (8 tháng) giữa bối cảnh triều đình đầy biến động. Nghị Đỉnh nặng khoảng 2.500kg, tượng trưng cho mong muốn về sự vững vàng, nghiêm minh trong việc giữ gìn cơ nghiệp của tổ tông.	Nghị Đỉnh đúc năm 1836, trước khi vua Kiến Phúc ra đời rất lâu. Việc ghép tên đỉnh với miếu hiệu/thụy hiệu vua thường là sự suy tôn của hậu thế (hoặc sự trùng hợp ngẫu nhiên được gán ghép sau này). Vua Kiến Phúc lên ngôi sau cuộc đảo chính lật đổ vua Hiệp Hòa, là giai đoạn rối ren nhất của triều Nguyễn trước sức ép của thực dân Pháp.	Chữ 'Nghị' tượng trưng cho đức tính cương trực, không dao động trước khó khăn. Đỉnh thể hiện sự uy nghiêm và ý chí sắt đá cần có của một bậc quân vương.	Nghị Đỉnh có trọng lượng nhẹ hơn một chút so với các đỉnh khác (như Cao Đỉnh, Nhân Đỉnh) nhưng hoa văn chạm khắc lại vô cùng tinh xảo và sắc nét.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
791d1c09-5f58-4278-9917-2ee9dacc8d55	0e90ba70-f73b-43ce-b3cb-0cf57a2c349b	Hoa Mai - cốt cách thanh cao, báo hiệu mùa xuân về.	Mai (Ochna integerrima - Hoàng mai/Mai vàng) là loài hoa đặc trưng của mùa xuân phương Nam và xứ Huế. Cây mai có dáng vẻ gầy guộc nhưng cứng cáp, chịu đựng sương gió mùa đông để bung nở những cánh hoa vàng rực rỡ khi xuân sang. Trong văn hóa, Mai đứng đầu bộ Tứ quý (Mai - Lan - Cúc - Trúc hoặc Tùng - Cúc - Trúc - Mai), tượng trưng cho người quân tử thanh cao. Hình ảnh hoa mai trên Nghị Đỉnh được chạm khắc mềm mại, thể hiện vẻ đẹp tinh tế và sức sống mãnh liệt.	Vua chúa nhà Nguyễn rất yêu thích hoa mai. Có giống 'Mai Ngự' nổi tiếng chỉ trồng trong cung. Người Huế coi việc chơi mai ngày Tết là một nét văn hóa tao nhã không thể thiếu.	Hoa mai 5 cánh tượng trưng cho ngũ phúc (vui vẻ, hạnh phúc, trường thọ, thuận lợi, hòa bình). Màu vàng của mai tượng trưng cho hành Thổ (trung tâm) và sự phú quý hoàng gia.	Khác với hoa Mơ (cũng gọi là Mai - Prunus mume) ở miền Bắc có màu trắng hoặc hồng, 'Mai' trên Cửu Đỉnh Huế thường được hiểu là Hoàng mai (mai vàng) đặc hữu của miền Trung và Nam Bộ.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
0d7cacfa-5bf2-4563-aafe-6487bd84ff53	c448233e-7507-4ba5-b707-f445eed4fee2	Cây Đàn hương - hương thơm vương giả, gỗ quý ngàn năm.	Đàn Mộc (Cây Đàn hương/Hoàng đàn) là loài cây thân gỗ quý hiếm, nổi tiếng với mùi thơm dịu nhẹ, bền lâu. Gỗ đàn mộc rất cứng, không bị mối mọt, được dùng để chế tác đồ mỹ nghệ cao cấp, tượng Phật và làm hương liệu. Trong y học, tinh dầu đàn hương giúp an thần, thư giãn. Hình ảnh cây Đàn mộc trên Nghị Đỉnh khẳng định sự phong phú của nguồn lâm sản quý và gu thẩm mỹ tinh tế của triều đình.	Gỗ Đàn hương xưa kia chỉ dành cho vua chúa (Ngự dụng). Các vật dụng trong cung như quạt, hộp đựng đồ trang sức thường làm bằng gỗ này để tỏa hương thơm tự nhiên.	Đàn mộc tượng trưng cho sự thanh tịnh, cao quý và phúc đức. Hương thơm của nó được coi là cầu nối với thế giới tâm linh.	Cây Đàn hương là loài bán ký sinh, rễ của nó phải bám vào rễ cây khác để hút dinh dưỡng mới phát triển được. Đây là điều thú vị về sinh học của loài 'vương mộc' này.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
2bd9144d-d186-4c3b-aafc-ce749b7a7ced	5d296943-0b9a-42ea-ba1f-d9901cc391c6	Quảng Bình Quan - chốt chặn chiến lược trên đường thiên lý Bắc Nam.	Quảng Bình Quan là một công trình kiến trúc quân sự kiên cố nằm trong hệ thống Lũy Thầy (Lũy Đào Duy Từ), thuộc thành phố Đồng Hới, tỉnh Quảng Bình. Được xây dựng năm 1639, đây là một trong những cửa ải quan trọng nhất kiểm soát con đường huyết mạch Bắc - Nam. Quảng Bình Quan vừa là chiến lũy phòng thủ, vừa là trạm kiểm soát giao thông. Hình ảnh cổng thành uy nghi trên Nghị Đỉnh khẳng định tầm quan trọng của việc phòng thủ đất nước và sự ổn định của hệ thống giao thông quốc gia.	Quảng Bình Quan gắn liền với thời kỳ Trịnh - Nguyễn phân tranh. Chúa Nguyễn đã dựa vào địa thế hiểm yếu nơi đây để ngăn chặn quân Trịnh trong suốt gần 2 thế kỷ. Câu ca 'Khôn ngoan qua được Thanh Hà / Dẫu rằng có cánh khó qua Lũy Thầy' nói lên sự kiên cố này.	Cửa ải tượng trưng cho sự an ninh, sự bảo vệ và quyền lực kiểm soát lãnh thổ. Nó là chứng nhân lịch sử của bao cuộc binh lửa và thống nhất.	Quảng Bình Quan ngày nay nằm ngay trung tâm thành phố Đồng Hới, xe cộ có thể đi vòng qua. Nó đã được phục dựng lại sau khi bị phá hủy trong chiến tranh.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
8584cc98-bc6b-4249-ba07-8f59534219aa	1765de7a-fb29-4c9a-b769-370883202181	Sông Cửu An - dòng sông tưới tiêu quan trọng của vùng đồng bằng Bắc Bộ.	Cửu An Hà (Sông Cửu An) là một phân lưu của sông Luộc, chảy qua địa phận hai tỉnh Hưng Yên và Hải Dương. Con sông này đóng vai trò quan trọng trong hệ thống thủy lợi (Bắc Hưng Hải ngày nay), cung cấp nước tưới cho vựa lúa đồng bằng sông Hồng và tiêu thoát nước mùa mưa lũ. Tên 'Cửu An' (Chín sự bình an/Yên ổn lâu dài) thể hiện mong ước trị thủy thành công, mưa thuận gió hòa để dân chúng an cư lạc nghiệp.	Vùng Hải Dương, Hưng Yên là vựa lúa lớn. Việc khơi dòng Cửu An giúp khai thác tiềm năng nông nghiệp và giao thông đường thủy, nối liền các vùng kinh tế.	Dòng sông tượng trưng cho sự trù phú, sự nuôi dưỡng (nguồn nước) và sự bình yên của làng quê.	Hệ thống thủy nông Bắc Hưng Hải (trong đó có sông Cửu An) là công trình thủy lợi lớn nhất miền Bắc thời kỳ sau 1954, nhưng tầm quan trọng của dòng sông đã được triều Nguyễn ghi nhận từ trước đó.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
5530e7d6-73ef-43ed-8d05-b70f963a523f	c3fb5c56-a8b9-43e8-9ddb-22385193cec6	Sao Nam Đẩu - chòm sao ban phúc, chủ về sự sống.	Nam Đẩu (Nam Đẩu Lục Tinh) là chòm sao gồm 6 ngôi sao nằm ở phương Nam (trong chòm Nhân Mã theo thiên văn phương Tây). Đối lập với Bắc Đẩu (chủ về cái chết), Nam Đẩu được coi là chòm sao chủ về sự sống (Nam Tào coi sổ sinh). Người xưa tin rằng cầu khẩn sao Nam Đẩu có thể được tăng thêm tuổi thọ. Hình ảnh Nam Đẩu trên Nghị Đỉnh thể hiện ước vọng trường thọ và sự cân bằng âm dương (Bắc - Nam, Sinh - Tử) trong vũ trụ quan của người Việt.	Trong triều đình, các nghi lễ tế Nam Giao thường cúng tế các vị tinh tú, trong đó có Nam Đẩu tinh quân. Văn hóa dân gian có câu 'Nam Tào Bắc Đẩu' chỉ hai vị thần giúp việc cho Ngọc Hoàng.	Sao Nam Đẩu tượng trưng cho dương khí, sự sinh sôi, phúc lộc và tuổi thọ. Nó mang lại niềm tin và hy vọng cho con người.	Trong truyện Tam Quốc, có chi tiết Quản Lộ xem tướng và chỉ cách cho một chàng trai dâng rượu thịt cho hai ông già ngồi đánh cờ (Nam Tào, Bắc Đẩu) để xin sửa tuổi thọ từ 19 lên 99 tuổi.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
dcdfede2-af5a-4734-a1bb-9a0a32502747	cc1a79bb-8da0-4462-8914-43ccb471cc39	Sông Bạch Đằng - dòng sông của những chiến công hiển hách chống ngoại xâm.	Bạch Đằng Giang (Sông Bạch Đằng/Sông Rừng) là con sông lịch sử chảy qua Quảng Ninh và Hải Phòng. Đây là nơi diễn ra ba trận thủy chiến lừng lẫy trong lịch sử Việt Nam: Ngô Quyền đánh tan quân Nam Hán (938), Lê Hoàn phá Tống (981) và Trần Hưng Đạo diệt Nguyên Mông (1288). Những bãi cọc ngầm trên sông Bạch Đằng đã trở thành biểu tượng của trí tuệ và nghệ thuật quân sự Việt Nam. Khắc Bạch Đằng Giang lên Nghị Đỉnh là lời nhắc nhở hào hùng về truyền thống đánh giặc giữ nước của dân tộc.	Vua Minh Mạng rất coi trọng lịch sử, ông thường sai người tìm hiểu và ghi chép về các chiến tích cũ. Sông Bạch Đằng được coi là 'con sông định mệnh' chôn vùi mộng xâm lăng của kẻ thù phương Bắc.	Sông Bạch Đằng tượng trưng cho lòng yêu nước, mưu lược quân sự (trận địa cọc) và khí phách anh hùng ('Giang san vượng khí Bạch Đằng thâu' - Sắc khí non sông thu cả vào Bạch Đằng).	Tên 'Bạch Đằng' có nghĩa là 'Sóng trắng' (Sóng cuộn trào bọt trắng xóa). Hiện nay vẫn còn di tích bãi cọc Bạch Đằng ở Quảng Yên.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
4ad31dd8-e7f3-4461-a993-58ae5e36a25a	eb8f7cdb-fe49-48dc-ad7f-2d8923e100de	Cửa biển Thuận An - yết hầu của Kinh thành Huế.	Thuận An Hải Khẩu là cửa biển chính nơi sông Hương đổ ra biển Đông, cách kinh thành Huế khoảng 13km. Đây là vị trí chiến lược sống còn (yết hầu) để bảo vệ Kinh đô từ phía biển và là cửa ngõ giao thương quốc tế quan trọng nhất của triều Nguyễn. Mọi tàu thuyền ra vào Kinh thành đều phải qua đây. Triều đình đã cho xây dựng hệ thống đồn lũy (Trấn Hải Thành) kiên cố tại cửa biển này. Việc khắc Thuận An lên đỉnh khẳng định tầm quan trọng đặc biệt của nó đối với an ninh quốc gia.	Năm 1883, Pháp tấn công cửa Thuận An, buộc triều đình Huế phải ký Hiệp ước Harmand, đánh dấu sự thất thủ của nhà Nguyễn. Cửa biển này đã chứng kiến những thăng trầm đau thương của lịch sử.	Thuận An tượng trưng cho cửa ngõ, sự giao lưu và cũng là tuyến phòng thủ trọng yếu. Tên 'Thuận An' mang ước vọng sóng yên biển lặng, mọi sự hanh thông.	Cửa Thuận An thường bị thay đổi dòng chảy và bồi lấp do bão lũ (hiện tượng 'biển lấp'). Vua chúa xưa thường phải làm lễ cầu đảo để khơi thông cửa biển này.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
d66c2b65-99cf-474e-bf90-f69f187a4e68	8096eca9-bea4-42ab-a96f-36f7e373c017	Rau Cải - vị thuốc và món ăn dân dã không thể thiếu.	Giới (Cây rau cải/Cải canh) là loại rau ăn lá phổ biến, thuộc họ Thập tự. Có nhiều loại cải như cải bẹ xanh, cải ngọt, cải cúc... Rau cải dễ trồng, chịu lạnh tốt, là nguồn cung cấp vitamin dồi dào cho người dân, nhất là trong mùa đông. Hạt cải (Giới tử) còn là vị thuốc chữa ho, đau khớp và làm gia vị (mù tạt). Việc khắc rau cải lên Nghị Đỉnh thể hiện sự quan tâm đến những loại nông sản thiết yếu nhất, đảm bảo đời sống hàng ngày của muôn dân.	Rau cải xuất hiện trong ca dao 'Gió đưa cây cải về trời / Rau răm ở lại chịu lời đắng cay'. Nó gắn liền với bữa cơm đạm bạc nhưng ấm cúng của người Việt.	Rau cải tượng trưng cho sự giản dị, thanh đạm và sức sống bền bỉ. Nó nhắc nhở về đạo lý tiết kiệm và trân trọng thành quả lao động.	Hạt cải rất nhỏ ('nhỏ như hạt cải'), thường được dùng để ví von về kích thước li ti (vi trần) trong Phật giáo.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
15e23376-d4d2-49de-8c6e-1f837ca821da	4cbb533d-b417-477c-a075-d4c1bce38ad2	Ngọn giáo dài - vũ khí cơ bản tạo nên sức mạnh bộ binh.	Trường Thương (Giáo dài) là loại vũ khí cận chiến cổ điển, gồm cán dài (thường bằng tre, gỗ hoặc sắt) và mũi nhọn bằng kim loại. Đây là vũ khí chủ lực của bộ binh thời phong kiến nhờ lợi thế tầm xa, dễ chế tạo và dễ sử dụng. Đội quân dùng trường thương có thể lập đội hình 'thương trận' để ngăn cản kỵ binh và đẩy lùi đối phương. Trên Nghị Đỉnh, hình ảnh cây thương sắc bén thể hiện sự sẵn sàng chiến đấu và kỷ luật quân đội.	Trong 'Thập bát ban võ nghệ' (18 môn võ), thương pháp luôn được coi trọng. Quân đội nhà Nguyễn được trang bị trường thương kết hợp với hỏa súng để tăng hiệu quả tác chiến.	Trường thương tượng trưng cho sự dũng cảm, khí phách ngang tàng và khả năng tấn công trực diện. 'Đơn thương độc mã' là hình ảnh người anh hùng xông pha trận mạc.	Thương khác với Kích và Mâu ở hình dáng mũi. Mũi thương thường hình lá lúa, sắc bén hai cạnh. Danh tướng Triệu Tử Long nổi tiếng với cây thương.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
1de81251-8b24-458e-ba3d-cd955de4fa8b	cb8421e4-3199-40e6-b7b3-9dfe5f571092	Thuyền Hải Đạo - chiến thuyền linh hoạt giữ yên biển cả.	Hải Đạo là tên một loại thuyền chiến (hoặc thuyền công vụ) cỡ nhỏ và vừa của thủy quân nhà Nguyễn. Thuyền có dáng thon dài, nhiều tay chèo, di chuyển rất nhanh và linh hoạt trên biển và sông lớn. Loại thuyền này thường dùng để tuần tra, truy đuổi cướp biển (hải tặc) và trinh sát. Sự hiện diện của thuyền Hải Đạo trên Nghị Đỉnh khẳng định sức mạnh làm chủ biển khơi và chú trọng xây dựng lực lượng thủy quân tinh nhuệ của triều đình.	Vua Gia Long và Minh Mạng rất chú trọng đóng tàu thuyền. Có nhiều loại thuyền như Ô thuyền, Mông đồng, Hải đạo... được biên chế rõ ràng. Thủy quân Nguyễn từng được đánh giá là mạnh nhất khu vực Đông Nam Á thời bấy giờ.	Thuyền Hải Đạo tượng trưng cho tốc độ, sự cơ động và an ninh hàng hải. Nó là 'đôi mắt' và 'cánh tay' của triều đình trên biển.	Mặc dù tên là 'Hải Đạo' (nghĩa đen có thể hiểu là kẻ cướp biển - Đạo tặc), nhưng ở đây 'Đạo' có thể hiểu là con đường hoặc một đơn vị hành chính/quân sự. Đây là thuyền của quân triều đình.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
e6f281ae-4efb-43a6-85d1-24752e39e988	54c162b8-7bb5-4761-b763-bb60c4293d0d	Chim Uyên Ương - biểu tượng vĩnh cửu của tình yêu đôi lứa.	Uyên Ương (Chim uyên ương) là loài chim nước có bộ lông sặc sỡ (con trống) rất đẹp. Chúng thường bơi lội và bay cùng nhau từng đôi một, không rời xa. Trong văn hóa phương Đông, Uyên Ương là biểu tượng cao nhất của tình yêu chung thủy, hạnh phúc vợ chồng (Uyên là chim mái, Ương là chim trống). Hình ảnh đôi chim Uyên Ương bơi lội trên sóng nước được khắc trên Nghị Đỉnh gợi lên vẻ đẹp thanh bình và ước mong về sự hòa hợp, hạnh phúc lứa đôi bền vững.	Họa tiết Uyên Ương thường xuất hiện trên chăn màn, gốm sứ cưới hỏi. Sự xuất hiện của chúng trên Cửu Đỉnh cho thấy sự trân trọng các giá trị tình cảm gia đình - tế bào của xã hội.	Uyên ương tượng trưng cho lòng chung thủy, sự gắn bó keo sơn 'có đôi có cặp'. Nếu một con chết đi, con kia sẽ sống cô độc suốt đời (theo truyền thuyết).	Thực tế, vịt Uyên Ương ngoài tự nhiên chỉ bắt cặp theo mùa sinh sản, không hẳn là 'chung thủy trọn đời' như con người lãng mạn hóa. Nhưng vẻ đẹp của chúng thì không thể phủ nhận.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
939f4bc9-63ad-404d-af08-0c204e6cf3c0	ce7718a7-ddae-4917-aca4-fad6e8a3de9a	Con Voi - sức mạnh vô địch, linh vật của đại ngàn.	Tượng (Con voi) là loài động vật lớn nhất trên cạn, thông minh và có sức khỏe phi thường. Ở Việt Nam, voi được thuần hóa để kéo gỗ, vận chuyển và tham gia chiến trận (Tượng binh). Voi chiến là nỗi khiếp sợ của quân thù với sức càn lướt mạnh mẽ. Hình ảnh con voi trên Nghị Đỉnh được chạm khắc uy nghi, thể hiện sức mạnh quốc gia và sự thuần phục của thiên nhiên trước con người. Voi cũng là con vật linh thiêng trong Phật giáo và văn hóa Tây Nguyên.	Triều Nguyễn có đội Tượng binh rất hùng hậu. Các vua thường tổ chức lễ hội Hổ Quyền (voi đấu hổ) để rèn luyện tinh thần thượng võ. Voi cũng tham gia các nghi lễ long trọng của triều đình.	Voi tượng trưng cho sức mạnh, sự vững chãi (chân cứng đá mềm) và quyền uy. Nó cũng biểu thị cho sự trường thọ và trí nhớ tốt.	Voi là loài vật rất tình cảm, chúng biết khóc và nhớ ơn người giúp đỡ. Hai Bà Trưng và Bà Triệu đều cưỡi voi ra trận, tạo nên hình ảnh nữ tướng oai hùng.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
8ca014d9-c85c-4d6d-a641-4057e2934b3b	f24dff99-3868-48eb-8df3-06e9b9585590	Sông Vĩnh Điện - dòng sông nối liền di sản Quảng Nam.	Vĩnh Điện Hà là con sông chảy qua thị xã Điện Bàn, tỉnh Quảng Nam, nối sông Thu Bồn với sông Hàn (Đà Nẵng). Sông đóng vai trò quan trọng trong việc giao thương, vận chuyển hàng hóa giữa cảng Hội An và Đà Nẵng xưa kia. Vua Minh Mạng đã cho nạo vét dòng sông này để khơi thông huyết mạch kinh tế miền Trung. Tên 'Vĩnh Điện' mang ý nghĩa sự vững bền của vùng đất Điện Bàn.	Quảng Nam là vùng đất trù phú ('Đất Quảng Nam chưa mưa đã thấm'). Sông Vĩnh Điện giúp tưới tiêu cho những cánh đồng dâu, ruộng lúa xanh tốt.	Dòng sông tượng trưng cho sự kết nối, sự lưu thông và mạch sống của vùng đất.	Sông Vĩnh Điện từng bị bồi lấp nhiều lần, việc khơi thông nó tốn nhiều công sức của triều đình và nhân dân.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
daadb9e1-5977-4efe-872a-3dc456235592	61826813-bed7-49ff-b54a-7a1ef85a812f	Thuần Đỉnh - biểu tượng của sự thuần khiết và đức tính giản dị.	Thuần Đỉnh là chiếc đỉnh thứ sáu (đối diện với Nghị Đỉnh) trong Cửu Đỉnh. Chữ 'Thuần' (純) có nghĩa là thuần khiết, ròng (không pha tạp), cũng có nghĩa là đôn hậu, chất phác. Đây là thụy hiệu của vua Đồng Khánh (1864-1889) - Cảnh Tông Thuần Hoàng đế. Vua Đồng Khánh lên ngôi trong bối cảnh triều đình đã mất quyền tự chủ vào tay thực dân Pháp, nhưng ông vẫn cố gắng duy trì lễ nghi và văn hóa cung đình. Thuần Đỉnh nặng khoảng 1.900kg, là chiếc đỉnh nhẹ nhất trong Cửu Đỉnh.	Thuần Đỉnh đúc năm 1836. Việc ứng nghiệm với thụy hiệu vua Đồng Khánh (lên ngôi năm 1885) được coi là sự sắp đặt của định mệnh. Vua Đồng Khánh là người ưa chuộng văn minh phương Tây nhưng vẫn giữ gìn bản sắc dân tộc.	Chữ 'Thuần' tượng trưng cho sự tinh khiết, chân thật và sự hoàn thiện đạo đức (phản bộc quy chân). Đỉnh nhắc nhở về lối sống giản dị, thanh cao.	Mặc dù là chiếc đỉnh nhẹ nhất, nhưng Thuần Đỉnh lại có vị trí rất trang trọng và các họa tiết chạm khắc trên đỉnh rất tinh xảo, thể hiện gu thẩm mỹ cao.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
73733717-4400-44df-aa0f-e1ce26bc4d3a	61a7b0da-2123-4bda-be59-b004e2d9a452	Hoa Đào - sắc hồng báo xuân, biểu tượng của sự sinh sôi.	Đào (Prunus persica) là loài hoa đặc trưng của mùa xuân miền Bắc Việt Nam. Cây đào có thân gỗ nhỏ, hoa màu hồng thắm hoặc hồng phai, nở rộ vào dịp Tết Nguyên Đán. Trong văn hóa, hoa đào được coi là tinh hoa của Ngũ hành, có thể xua đuổi bách quỷ và mang lại may mắn, bình an. Quả đào (đào tiên) còn là biểu tượng của sự trường thọ trong truyền thuyết. Hình ảnh cây đào trên Thuần Đỉnh gợi nhớ về mùa xuân ấm áp và ước vọng an lành.	Vua Quang Trung sau khi đại phá quân Thanh đã sai người cưỡi ngựa trạm mang cành đào bích từ Thăng Long về Phú Xuân (Huế) để tặng công chúa Ngọc Hân, báo tin thắng trận và mang mùa xuân phương Bắc về.	Hoa đào tượng trưng cho sự đổi mới, sức sống mãnh liệt (trải qua mùa đông lạnh giá để nở hoa) và tình duyên (số đào hoa).	Ở Nhật Bản, hoa đào (Momo) thường bị nhầm với hoa anh đào (Sakura). Hoa đào thường nở sớm hơn và cánh hoa nhọn hơn.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
d229a542-d61f-40b6-b71b-1cca22c17992	42d0ddb9-5f03-4970-8627-22b229615b01	Súc Sa Mật - cây sa nhân quý, hương liệu của rừng già.	Súc Sa Mật (hay Sa nhân - Amomum villosum) là loài cây thảo mọc dưới tán rừng ẩm. Quả sa nhân mọc thành chùm sát gốc, có gai mềm, khi chín màu đỏ nâu, hạt có mùi thơm hắc rất đặc trưng. Sa nhân là vị thuốc quý chuyên trị các bệnh đường tiêu hóa (đau bụng, đầy hơi) và an thai. Nó cũng là gia vị cao cấp được dùng trong ẩm thực và làm hương liệu. Việc khắc Súc Sa Mật lên đỉnh thể hiện sự trân trọng nguồn dược liệu phong phú của rừng nhiệt đới Việt Nam.	Sa nhân từng là mặt hàng xuất khẩu chủ lực của Việt Nam sang Trung Quốc và các nước phương Tây. Những vùng trồng sa nhân nổi tiếng như Bát Xát (Lào Cai) hay miền núi Nghệ An.	Súc Sa Mật tượng trưng cho sự ẩn dật (mọc dưới tán rừng), giá trị nội tại (hạt thơm) và khả năng chữa lành.	Tên 'Súc Sa Mật' có nghĩa là hạt (Mật/Mễ) của cây Sa nhân (Súc sa). Hoa sa nhân mọc từ gốc lên, trông như những con bọ lạ mắt.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
5ba753ba-8166-43eb-84eb-1d1c48adb283	ef926c95-6c55-4374-8788-4552e2ad8152	Hương Nhu - vị thuốc giải cảm, hương thơm đồng nội.	Hướng Nhu (Hương nhu tía/É tía) là loài cây thân thảo, toàn thân có lông và mùi thơm dễ chịu. Hương nhu là vị thuốc nam quen thuộc trong vườn nhà, chuyên dùng để nấu nước xông giải cảm, chữa đau đầu, hạ sốt. Tinh dầu hương nhu có tính sát khuẩn cao, dùng làm thuốc và mỹ phẩm (dầu gội đầu giúp mượt tóc). Hình ảnh cây Hương nhu trên Thuần Đỉnh gợi lên sự gần gũi, chăm sóc sức khỏe từ những loài cây cỏ quanh ta.	Nồi nước xông lá hương nhu, lá bưởi, lá sả... là phương pháp trị bệnh truyền thống hiệu quả của người Việt, nhất là trong những ngày trái gió trở trời.	Hương nhu tượng trưng cho sự thanh sạch, giải tỏa (giải cảm) và sự quan tâm bình dị. Mùi hương của nó giúp thư giãn tinh thần.	Hương nhu tía và Hương nhu trắng là hai loài khác nhau. Hương nhu tía thường dùng làm thuốc, hương nhu trắng thường dùng để chưng cất tinh dầu.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
fff8a756-3ff6-4b54-b065-98e42da84de8	3ce87650-7d3c-4135-81ec-f083f855ed56	Đậu nành - 'thịt' của người nghèo, nguồn dinh dưỡng vàng.	Hoàng Đậu (Đậu tương/Đậu nành) là loài cây ngũ cốc quan trọng hàng đầu. Hạt đậu nành giàu protein và dầu thực vật, được dùng để chế biến đậu phụ (đậu hũ), sữa đậu nành, nước tương (xì dầu) và tương bần. Đây là nguồn cung cấp đạm chủ yếu trong các bữa ăn chay và của người dân lao động xưa. Cây đậu nành còn có tác dụng cải tạo đất (cố định đạm). Khắc Hoàng Đậu lên đỉnh là sự tôn vinh vai trò của nông nghiệp và an ninh lương thực.	Tương là món ăn truyền thống lâu đời ('Anh đi anh nhớ quê nhà / Nhớ canh rau muống nhớ cà dầm tương'). Nghề làm tương ở Bần Yên Nhân (Hưng Yên) hay Cự Đà (Hà Nội) rất nổi tiếng.	Hạt đậu vàng tượng trưng cho sự no ấm, sung túc và sức khỏe. Nó là biểu tượng của sự chắt chiu và giá trị dinh dưỡng cao từ những điều giản dị.	Đậu nành là loại hạt thực vật duy nhất chứa đầy đủ các axit amin thiết yếu như thịt động vật.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
4cdc166e-9941-47a2-a658-d74ecc5efa13	01e7d41a-a4f3-49d3-972a-0fbd6a9c8117	Hoa Hướng Dương - loài hoa luôn hướng về mặt trời.	Quỳ Hoa (Hoa Hướng dương) là loài hoa có kích thước lớn, màu vàng rực rỡ, luôn quay theo hướng mặt trời. Hạt hướng dương là món ăn vặt phổ biến và dùng để ép dầu. Trong văn hóa, Quỳ hoa tượng trưng cho lòng trung thành, sự kiên định và niềm tin vào ánh sáng (chân lý). Hình ảnh hoa hướng dương trên Thuần Đỉnh thể hiện tinh thần hướng thượng và lòng trung quân ái quốc.	Hoa hướng dương vốn có nguồn gốc từ châu Mỹ, du nhập vào Việt Nam. Việc nó xuất hiện trên Cửu Đỉnh (đúc năm 1836) cho thấy sự giao lưu văn hóa và sinh học đã diễn ra từ sớm.	Hoa hướng dương tượng trưng cho mặt trời, sự ấm áp, lòng thủy chung (luôn hướng về một phía) và sự lạc quan.	Thực chất, chỉ có nụ hoa và lá non mới hướng theo mặt trời (quang hướng động). Khi hoa đã nở rộ và già đi, nó thường đứng yên quay về hướng Đông.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
bb0524c2-f1b0-4074-a9d1-6d9519a70ef2	1b519b34-f4a1-4014-9db8-ed29dcb8b3d1	Núi Tản Viên - Thánh địa của Sơn Tinh, ngọn núi thiêng nước Việt.	Tản Viên Sơn (Núi Tản/Núi Ba Vì) là ngọn núi linh thiêng bậc nhất (Đệ nhất phúc thần), nằm ở phía Tây Hà Nội. Ngọn núi có hình dáng như chiếc tán (ô) xòe ra nên gọi là Tản Viên. Đây là nơi ngự trị của Thánh Tản Viên (Sơn Tinh) - vị thần đứng đầu Tứ bất tử trong tín ngưỡng Việt Nam, người đã chiến thắng Thủy Tinh để bảo vệ mùa màng. Khắc Tản Viên Sơn lên đỉnh là khẳng định sức mạnh tâm linh và ước vọng chế ngự thiên nhiên của dân tộc.	Thánh Tản Viên được thờ phụng rộng rãi ở vùng Bắc Bộ. Ngài không chỉ là thần núi mà còn là anh hùng văn hóa dạy dân trị thủy, săn bắn. Các triều đại phong kiến đều sắc phong cho ngài.	Núi Tản Viên tượng trưng cho sự vững chãi, sự bảo trợ thần thánh và tinh thần đoàn kết chống thiên tai (chống lụt bão).	Trên đỉnh núi Ba Vì hiện nay vẫn còn đền thờ Bác Hồ và tháp Báo Thiên. Truyền thuyết Hùng Vương kén rể cũng diễn ra tại đây.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
f9ee779c-8a5c-4493-9de6-b942a2b1a00d	c5a0a5ec-5ebe-4d7f-be43-dd88f0e184e1	Sông Vĩnh Định - con sông đào mang lại sự yên bình vĩnh cửu.	Vĩnh Định Hà là con sông đào nằm ở tỉnh Quảng Trị, được khơi thông dưới thời vua Minh Mạng (1825). Sông nối liền các thủy đạo quan trọng, giúp tiêu úng cho ruộng đồng, thau chua rửa mặn và thuận tiện cho giao thông đường thủy. Tên 'Vĩnh Định' (Định yên mãi mãi) thể hiện mong muốn của triều đình về sự ổn định xã hội và phát triển bền vững của vùng đất phên dậu miền Trung.	Công cuộc đào sông, đắp đê là thành tựu nổi bật của nhà Nguyễn. Sông Vĩnh Định cùng với sông Vĩnh Điện, sông Lợi Nông... tạo nên mạng lưới thủy lợi hoàn chỉnh.	Sông Vĩnh Định tượng trưng cho trí tuệ trị thủy của con người, sự cải tạo thiên nhiên để phục vụ cuộc sống và ước mơ thái bình.	Quảng Trị là vùng đất khắc nghiệt 'Gió Lào, cát trắng'. Việc đào sông Vĩnh Định là một nỗ lực phi thường để cải thiện đời sống nhân dân nơi đây.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
7d67ec60-c59d-44ba-a9f0-ff22e8bf0ca3	29366526-461d-4127-ae32-8a7fa46fe020	Gió - hơi thở của đất trời, sự chuyển động vô hình.	Phong (Gió) là hiện tượng thiên nhiên quen thuộc nhưng đầy uy lực. Gió giúp điều hòa khí hậu, thụ phấn cho cây, đẩy thuyền buồm ra khơi (Thuận buồm xuôi gió). Nhưng gió cũng có thể gây ra bão tố tàn phá. Trên Thuần Đỉnh, hình tượng Gió được nhân cách hóa hoặc thể hiện qua sự chuyển động của mây và cây cỏ, tượng trưng cho sự lan tỏa ân đức của nhà vua đến muôn dân (như gió thổi cỏ rạp - 'Quân tử chi đức phong').	Người xưa có Thần Gió (Phong Bá). Việc cúng tế thần Gió để cầu mong mưa thuận gió hòa là nghi lễ quan trọng trong nông nghiệp và hàng hải.	Gió tượng trưng cho sự thay đổi, tin tức (tin gió), sự tự do và sức mạnh vô hình. Gió lành (hòa phong) mang lại sự dễ chịu, gió độc gây bệnh tật.	Có 8 loại gió chính (Bát phong). Gió Đông (Đông phong) thường được mong đợi trong trận Xích Bích để Gia Cát Lượng dùng hỏa công.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
48c1debd-6157-4f90-b02e-a0b1b4d4f049	5ff35034-ef86-4daf-b01c-38fd5398d5b4	Sông Thạch Hãn - dòng sông bi tráng và hào hùng của Quảng Trị.	Thạch Hãn Giang (Sông Thạch Hãn) là con sông lớn nhất tỉnh Quảng Trị. Sông bắt nguồn từ dãy Trường Sơn, chảy qua thị xã Quảng Trị rồi đổ ra biển. Dòng sông này nổi tiếng không chỉ vì vẻ đẹp mà còn là chứng nhân của lịch sử bi tráng, đặc biệt là trong cuộc chiến 81 ngày đêm bảo vệ Thành Cổ Quảng Trị (1972). Hàng ngàn chiến sĩ đã nằm lại dưới đáy sông, biến Thạch Hãn thành 'dòng sông máu và hoa'. Trên Thuần Đỉnh, sông Thạch Hãn hiện lên hiền hòa, là mạch nguồn sự sống.	Thời Nguyễn, Quảng Trị là dinh trực lệ kinh sư. Sông Thạch Hãn là tuyến đường thủy huyết mạch vận chuyển lương thực, quân nhu.	Sông Thạch Hãn tượng trưng cho sự hy sinh, lòng kiên trung và nỗi đau chia cắt nhưng cũng là biểu tượng của hòa bình và thống nhất.	Câu thơ nổi tiếng: 'Đò lên Thạch Hãn ơi chèo nhẹ / Đáy sông còn đó bạn tôi nằm' đã khiến bao người rơi lệ khi nhắc về dòng sông này.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
fabb4231-056c-4a48-80d1-9a576639c72b	5d18cf10-4dc4-4bbe-9ee3-b0b70362a69f	Cửa biển Cần Giờ - cửa ngõ giao thương sầm uất của đất Gia Định.	Cần Giờ Hải Khẩu là cửa biển quan trọng nơi sông Soài Rạp và sông Lòng Tàu đổ ra biển Đông, thuộc thành phố Hồ Chí Minh ngày nay. Đây là yết hầu đường thủy dẫn vào cảng Sài Gòn, trung tâm kinh tế của Nam Bộ. Cần Giờ nổi tiếng với hệ sinh thái rừng ngập mặn phong phú (Rừng Sác) và vị trí chiến lược trong phòng thủ cũng như kinh tế. Việc khắc Cần Giờ lên đỉnh cho thấy tầm nhìn xa rộng của nhà Nguyễn về tiềm năng của vùng đất phương Nam.	Các tàu buôn phương Tây muốn vào Gia Định (Sài Gòn) đều phải đi qua cửa Cần Giờ. Pháo đài Phước Thắng từng được xây dựng tại đây để kiểm soát tàu bè.	Cần Giờ tượng trưng cho sự mở cửa, sự phồn thịnh của thương mại và sự giàu có của tài nguyên biển (rừng ngập mặn).	Rừng ngập mặn Cần Giờ hiện là Khu dự trữ sinh quyển thế giới đầu tiên của Việt Nam, được ví là 'lá phổi xanh' của TP.HCM.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
0be14197-e47b-4f27-bf85-e6111057fb12	bb1779dc-38f6-4ad5-8b92-431869075aa1	Cá rô đồng - loài cá kiên cường vượt cạn tìm sự sống.	Đăng Sơn Ngư (Cá leo núi/Cá rô đồng - Anabas testudineus) là loài cá nước ngọt rất phổ biến ở ruộng đồng Việt Nam. Tên gọi 'Đăng Sơn' (leo núi) xuất phát từ khả năng đặc biệt của chúng: vào những ngày mưa rào, cá rô có thể dùng vây ngực cứng và nắp mang để trườn (leo) trên bờ, vượt qua đê đập để tìm đến nguồn nước mới. Thịt cá rô đồng thơm, béo, là nguyên liệu cho món canh cải cá rô hay miến cá rô nổi tiếng. Hình ảnh cá rô vượt cạn tượng trưng cho ý chí vươn lên nghịch cảnh.	Cá rô đồng gắn bó mật thiết với đời sống nông nghiệp lúa nước. Sau những cơn mưa rào mùa hạ, người dân thường đi bắt cá rô 'rạch' trên đường đi.	Đăng Sơn Ngư tượng trưng cho sự nỗ lực, khả năng thích nghi phi thường và khát vọng sống mãnh liệt (cá chép hóa rồng, cá rô vượt cạn).	Cá rô đồng có cơ quan hô hấp phụ (mê lộ) giúp chúng hít thở khí trời, nên có thể sống trên cạn trong thời gian khá dài nếu giữ được độ ẩm.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
989a51d6-4c1c-448a-ba62-fe0dce77ff1f	7929755c-2737-4f1d-be93-c9c9bb17e726	Con Ngao/Trai - ẩn chứa ngọc quý, âm thầm cống hiến.	Bạng (Con ngao/Trai sông) là loài nhuyễn thể hai mảnh vỏ sống ở đáy sông, biển. Bạng có lớp vỏ cứng bảo vệ phần thịt mềm bên trong. Một số loài trai có khả năng tạo ngọc (ngọc trai) - báu vật của biển cả. Thịt ngao, trai ngọt mát, dùng nấu canh chua rất ngon. Hình ảnh con Bạng trên đỉnh nhắc nhở về những giá trị tiềm ẩn, vẻ đẹp nội tâm và sự kiên nhẫn (trai ngậm cát thành ngọc).	Điển tích 'Trai cò đánh nhau, ngư ông đắc lợi' (Bạng duật tương trì) là bài học sâu sắc về sự tranh chấp vô ích. Vỏ trai xưa còn dùng để khảm xà cừ lên đồ gỗ rất tinh xảo.	Bạng tượng trưng cho sự kín đáo, đức tính nhẫn nại và sự tinh túy (ngọc trong đá). Nó cũng đại diện cho nguồn lợi thủy sản phong phú.	Ngọc trai tự nhiên được hình thành khi một hạt cát lọt vào cơ thể con trai, nó tiết ra chất xà cừ bao bọc lấy dị vật đó qua nhiều năm.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
ca13762f-1129-44a8-aee6-8eabc86a2420	a7c53882-c22b-4e79-bf13-2d0c66888558	Giá gác đao - sự quy củ, uy nghiêm của võ đường.	Bài Đao (Giá gác đao/Kệ đao) là vật dụng dùng để trưng bày hoặc cất giữ các loại binh khí (đao, kiếm) một cách trang trọng và gọn gàng. Trong các võ đường hoặc nơi làm việc của quan võ, giá đao thể hiện sự uy nghiêm, sẵn sàng chiến đấu nhưng cũng rất kỷ luật (binh khí được xếp đặt ngăn nắp). Hình ảnh này trên Thuần Đỉnh tôn vinh tinh thần thượng võ và sự chính quy của quân đội triều đình.	Đao là vũ khí quan trọng của kỵ binh và bộ binh. 'Đại đao' thường dành cho tướng soái. Giá đao thường làm bằng gỗ quý, chạm trổ rồng phượng.	Bài Đao tượng trưng cho quyền lực quân sự, sự trấn áp kẻ gian và trật tự kỷ cương (vũ khí nằm trên giá là thời bình).	Trong phong thủy, cách đặt giá kiếm/đao cũng ảnh hưởng đến khí vận. Kiếm rút ra khỏi vỏ mang sát khí, kiếm nằm trên giá mang tính trấn trạch.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
b0b33c5b-0759-4384-972f-1c0b16614fb2	192e0b2e-dfc3-423f-805f-b717ec39de16	Thuyền Đỉnh - chiến thuyền thon nhỏ, lướt sóng như bay.	Đỉnh (Thuyền Đỉnh/Thuyền đua) là loại thuyền nhỏ, dáng thon dài hình lá tre, có nhiều tay chèo, chuyên dùng để đua tốc độ hoặc tác chiến nhanh trên sông. Trong các lễ hội cầu ngư hay hội đua thuyền truyền thống, loại thuyền này được trang trí rực rỡ. Trong quân sự, nó đóng vai trò là thuyền trinh sát hoặc xung kích. Việc khắc thuyền Đỉnh lên Thuần Đỉnh (trùng tên) là sự chơi chữ thú vị, đồng thời tôn vinh kỹ thuật đóng thuyền và nghệ thuật sông nước của người Việt.	Hội đua thuyền ở Huế và các vùng ven biển miền Trung là nét văn hóa đặc sắc, rèn luyện sức khỏe và tinh thần đoàn kết. Thủy quân Nguyễn thường tuyển chọn lính giỏi từ các hội đua này.	Thuyền Đỉnh tượng trưng cho tốc độ, sự cạnh tranh lành mạnh và tinh thần tập thể (cùng chèo về đích).	Thuyền đua thường được làm rất nhẹ và sơn mắt rồng hoặc mắt phượng ở mũi thuyền để 'thấy đường' và uy hiếp thủy quái.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
17d67cbf-0cb4-46d0-9ab8-e9fa7808ccd0	f9ff3e74-297f-4ae3-a586-d0c2b84209b7	Cây gỗ Chò/Nam - cột trụ chống trời, gỗ quý xây cung điện.	Nam Mộc (thường được hiểu là cây Gỗ Chò/Kháo/Bời lời - thuộc chi Machilus hoặc Persea) là loài cây gỗ lớn, thân thẳng tắp, thớ gỗ mịn và bền. Gỗ Nam (Gỗ Chò) được mệnh danh là loại gỗ không mối mọt, chuyên dùng để làm cột đình, chùa, cung điện (như ở Cố đô Huế). Tên 'Nam' còn gợi ý đây là loài cây gỗ quý của phương Nam. Hình ảnh cây gỗ lớn tỏa bóng trên đỉnh khẳng định sự vững bền của các công trình kiến trúc và sự giàu có của rừng vàng.	Cột cờ Phu Văn Lâu hay các cột trong Đại Nội Huế thường được làm bằng gỗ lim hoặc gỗ chò nguyên khối. Việc khai thác và vận chuyển những cây gỗ khổng lồ này về kinh đô là kỳ tích của người xưa.	Nam Mộc tượng trưng cho sự vững chãi (cột trụ), sự trường tồn và phẩm chất ngay thẳng của người quân tử (thân cây thẳng).	Gỗ Chò chỉ có mùi thơm nhẹ khi mới cắt. Có loại 'Chò chỉ' rất quý, thớ gỗ màu hồng nhạt, mịn màng.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
2d10088e-a065-426e-9f00-426a31bd0bb3	27f1d92f-b653-4088-a19d-2867460cfc0d	Bò Tót - mãnh thú rừng xanh, sức mạnh vô song.	Ly Ngưu (Con bò tót - Bos gaurus) là loài bò rừng lớn nhất thế giới, sống ở các khu rừng nhiệt đới Việt Nam. Bò tót có thân hình vạm vỡ, cặp sừng cong vút và tính khí hung dữ, được coi là chúa sơn lâm chỉ sau hổ (thậm chí hổ cũng ngại va chạm với bò tót trưởng thành). Tên 'Ly' chỉ loài thú dữ, 'Ngưu' là bò. Hình ảnh bò tót trên Thuần Đỉnh thể hiện sức mạnh hoang dã, sự uy nghi và sự đa dạng sinh học của rừng Việt Nam.	Bò tót từng phân bố rộng khắp Việt Nam nhưng nay đã trở nên rất quý hiếm (Sách Đỏ). Trong quá khứ, săn được bò tót là chiến công lớn của thợ săn.	Ly Ngưu tượng trưng cho sức mạnh thể chất, sự dũng mãnh và khả năng tự vệ tuyệt vời. Nó đại diện cho vẻ đẹp hùng vĩ của thiên nhiên.	Bò tót không có u trên lưng như bò nhà (bò u), nhưng có sống lưng nhô cao rất đặc trưng. Mắt bò tót khi giận dữ chuyển sang màu đỏ ngầu.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
7b26884c-dc24-4923-b2fb-f934078739ca	7e10639b-e0d4-4f5e-9263-24b005596d85	Tuyên Đỉnh - sự sáng tỏ, tuyên cáo ân đức vua ban.	Tuyên Đỉnh là chiếc đỉnh thứ bảy trong Cửu Đỉnh, nằm ở phía bên phải (đối diện với Dụ Đỉnh). Chữ 'Tuyên' (宣) có nghĩa là tuyên bố, truyền đạt rộng rãi, hoặc thông thoáng, sáng tỏ. Đây là thụy hiệu của vua Khải Định (1885-1925) - Hoằng Tông Tuyên Hoàng đế. Vua Khải Định là vị vua thứ 12 của triều Nguyễn, nổi tiếng với lăng tẩm có kiến trúc độc đáo kết hợp Á - Âu. Tuyên Đỉnh nặng khoảng 2.000kg, thể hiện mong muốn ân đức và mệnh lệnh của triều đình được truyền đi khắp bốn phương.	Tuyên Đỉnh đúc năm 1836. Việc ứng với thụy hiệu vua Khải Định (lên ngôi năm 1916) cũng là một sự trùng hợp lịch sử thú vị của Cửu Đỉnh.	Chữ 'Tuyên' tượng trưng cho sự minh bạch, cởi mở và quyền uy trong việc ban hành chiếu chỉ. Đỉnh cũng đại diện cho sự kết nối giữa vua và dân.	Vua Khải Định là vị vua đầu tiên của triều Nguyễn đi máy bay và sang Pháp. Lăng Khải Định (Ứng Lăng) được coi là đỉnh cao của nghệ thuật khảm sành sứ Huế.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
32c3e221-4541-448b-a542-db3b0113f4e9	7a4c0e26-fe4e-4885-ad47-3765a24856a8	Chim Yểng - loài chim thông minh biết nói tiếng người.	Tần Cát Liễu (Chim Yểng/Nhồng - Gracula religiosa) là loài chim thuộc họ Sáo, có bộ lông màu đen bóng, mỏ vàng cam và đặc biệt là hai mấu thịt màu vàng sau gáy (tích). Yểng rất thông minh, có khả năng bắt chước tiếng người và các âm thanh khác rất giỏi. Chúng thường sống ở bìa rừng, ăn trái cây và côn trùng. Vì khả năng 'nói' hóm hỉnh, Yểng được nuôi làm cảnh rất phổ biến trong cung đình và dân gian. Hình ảnh chim Yểng trên đỉnh thể hiện sự vui tươi và trí tuệ của loài vật.	Sách Đại Nam Nhất Thống Chí có ghi chép về loài chim này. Thời xưa, những con chim biết nói thường được coi là điềm lành hoặc vật giải trí cho vua chúa.	Chim Yểng tượng trưng cho sự thông minh, khả năng giao tiếp và sự hòa hợp giữa con người với thiên nhiên.	Chim Yểng có thể bắt chước tiếng người rõ hơn cả vẹt. Tên 'Tần Cát Liễu' (hoặc Tần Kết) là tên Hán Việt mỹ miều của nó.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
5b1c68c7-22cf-4523-83b0-64f5f1d926b6	bef239ca-da7e-4bf0-8353-10a092dd6091	Tổ Yến - 'Vàng trắng' của biển khơi, món quà sức khỏe.	Yến Oa (Tổ chim yến - Collocalia fuciphaga) là sản vật quý giá được làm từ nước dãi của loài chim yến hàng (yến đảo). Chim yến làm tổ trên các vách đá cheo leo ngoài hải đảo (như Khánh Hòa, Hội An). Tổ yến (Yến sào) là một trong 'Bát trân' (8 món ăn quý) của cung đình xưa, có tác dụng bồi bổ sức khỏe, tăng cường hệ miễn dịch và làm đẹp da. Việc khai thác tổ yến rất nguy hiểm nhưng đem lại giá trị kinh tế cực lớn. Khắc Yến Oa lên đỉnh là ghi nhận nguồn tài nguyên biển đảo vô giá.	Ngành nghề khai thác yến sào ở Đàng Trong đã có từ lâu đời. Các chúa Nguyễn nắm độc quyền buôn bán yến sào với thương nhân nước ngoài, thu về nguồn lợi lớn cho ngân khố.	Tổ yến tượng trưng cho sự chắt chiu (chim yến nhả từng sợi nước dãi), sự hi sinh của cha mẹ và sự giàu có, sang trọng.	Chim yến có đôi chân rất yếu, không thể đậu trên mặt đất mà phải treo mình trên vách đá. Chúng kiếm ăn (bắt côn trùng) ngay khi đang bay.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
ff2762a9-c618-4e75-b7b3-a8d3233c5902	371a21e2-afc3-4b7f-b365-439a19111af4	Quả Nhãn - 'Mắt rồng' ngọt lịm, đặc sản tiến vua.	Long Nhãn (Cây nhãn/Quả nhãn - Dimocarpus longan) là loài cây ăn quả nổi tiếng, đặc biệt là Nhãn lồng Hưng Yên. Quả nhãn có vỏ vàng nâu, cùi trắng trong mọng nước, hạt đen nhánh, trông giống như mắt con rồng (Long nhãn). Nhãn không chỉ là trái cây ngon mà cùi nhãn sấy khô (Long nhãn nhục) còn là vị thuốc bổ huyết, an thần rất tốt. Hình ảnh chùm nhãn sai trĩu trên Tuyên Đỉnh ca ngợi sự trù phú của vườn tược và hương vị ngọt ngào của sản vật quê hương.	Nhãn lồng Hưng Yên xưa là vật phẩm tiến vua ('Nhãn tiến'). Lê Quý Đôn từng ca ngợi nhãn Hưng Yên là ngon nhất nước. Cây nhãn tổ ở chùa Hiến (Hưng Yên) đã có hàng trăm năm tuổi.	Long nhãn tượng trưng cho sự tinh anh (mắt rồng), sự ngọt ngào và phúc lộc viên mãn (chùm quả sum suê).	Tên 'Nhãn lồng' xuất phát từ việc người dân xưa phải đan lồng tre chụp vào chùm nhãn để bảo vệ khỏi chim dơi ăn, cũng là để giữ mã quả cho đẹp.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
576718ea-2357-4900-bf5a-ee719965095a	a7cd9650-61f4-4e9f-8d8b-48beb32b3bcb	Hoa Sói - những hạt ngọc thơm ngát dùng để ướp trà.	Trân Châu Hoa (Hoa Sói - Chloranthus spicatus) là loài cây bụi nhỏ, lá xanh bóng, hoa nhỏ màu trắng ngà mọc thành bông dài giống như chuỗi hạt ngọc trai (trân châu). Hoa sói có mùi thơm dịu, ngọt ngào, thường được trồng làm cảnh hoặc dùng để ướp trà (trà hoa sói) giống như hoa nhài, hoa sen. Tuy không rực rỡ nhưng hoa sói lại có vẻ đẹp thanh tao, quý phái. Khắc hoa sói lên đỉnh là tôn vinh nét văn hóa thưởng trà tinh tế của người Việt.	Vua chúa triều Nguyễn rất cầu kỳ trong việc thưởng trà. Các loại hoa ướp trà như sói, ngâu, nhài, sen đều được trồng trong Ngự uyển.	Hoa sói tượng trưng cho vẻ đẹp kín đáo, không phô trương nhưng đầy giá trị (như ngọc). Hương thơm của nó tượng trưng cho đức hạnh lan tỏa.	Gọi là 'Hoa Sói' nhưng nó không liên quan gì đến con sói. Tên Hán Việt 'Trân Châu' (Ngọc trai) miêu tả chính xác hình dáng của hoa.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
648861de-0cde-4257-8372-0df2fd5fc5cb	10e81a65-2e1b-4d1f-8d8a-0b6a0811a71d	Củ Lạc - hạt đậu trong lòng đất, bùi ngậy tình quê.	Địa Đậu (Cây lạc/Đậu phộng - Arachis hypogaea) là loài cây hoa màu quan trọng. Tên 'Địa Đậu' nghĩa là đậu mọc dưới đất, vì sau khi thụ phấn, hoa lạc tàn và cuống hoa dài ra đâm xuống đất để phát triển thành củ (quả). Hạt lạc giàu dầu và protein, là món ăn dân dã (lạc rang, lạc luộc, muối vừng) và nguyên liệu ép dầu ăn. Cây lạc dễ trồng, cải tạo đất bạc màu. Hình ảnh cây lạc trên Tuyên Đỉnh thể hiện sự quan tâm đến các loại cây công nghiệp ngắn ngày thiết thực.	Cây lạc có nguồn gốc Nam Mỹ, du nhập vào Việt Nam từ thế kỷ 17-18 và nhanh chóng trở thành cây trồng phổ biến nhờ phù hợp với đất cát pha ven biển, ven sông.	Địa đậu tượng trưng cho sự khiêm tốn (củ giấu trong đất), sự bất ngờ và thành quả lao động cần cù. Hạt lạc còn gọi là 'hạt trường sinh' vì giá trị dinh dưỡng của nó.	Nhiều người nhầm củ lạc là rễ, nhưng thực chất nó là quả phát triển dưới mặt đất. Đây là đặc điểm sinh học rất độc đáo gọi là 'geocarpy'.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
2618b47d-4be2-4d2f-8428-9146c816f95e	616daaaa-e9f8-4e7b-a967-ec7b46df5dc1	Cây Trắc Bách Diệp - dáng cây quân tử, lá thuốc cầm máu.	Bá (Trắc bách diệp/Trắc bá - Platycladus orientalis) là loài cây lá kim, dáng tháp hình nón, lá dẹt xếp sít nhau theo chiều thẳng đứng. Cây xanh tốt quanh năm, chịu được khắc nghiệt nên thường được trồng làm cảnh ở đình chùa, lăng tẩm để tạo vẻ trang nghiêm. Trong đông y, lá và hạt (bá tử nhân) của cây là vị thuốc cầm máu, an thần, chữa mất ngủ. Hình ảnh cây Bá trên đỉnh tượng trưng cho khí tiết ngay thẳng, kiên định của người quân tử ('Tùng Bá').	Câu nói 'Tuế hàn chi tùng bá' (Năm lạnh mới biết cây tùng cây bách) ý nói trong gian khó mới biết người trung nghĩa. Cây Bá là biểu tượng của sự trường tồn, vĩnh cửu.	Cây Bá tượng trưng cho sự trường thọ (sống lâu), sự tưởng nhớ (trồng ở mộ) và đức tính kiên trung, bất khuất.	Lá cây Trắc bách diệp mọc đối chéo chữ thập nhưng do ép dẹt nên trông như mọc trên một mặt phẳng nghiêng (Trắc: nghiêng).	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
9711211d-4413-4877-b031-34cdc6ac6021	62b76d4a-9f9c-48c5-8a48-bd0e0be00d61	Sông Hồng - dòng sông Mẹ, cái nôi của văn minh lúa nước.	Nhĩ Hà (Sông Nhĩ/Sông Hồng) là con sông lớn nhất miền Bắc Việt Nam, bắt nguồn từ Vân Nam (Trung Quốc) chảy vào Việt Nam và đổ ra biển Đông qua 9 cửa (nay ít hơn). Tên 'Nhĩ' (cái tai) có thể do hình dáng sông uốn lượn giống vành tai, hoặc là tên gọi cổ. Sông Hồng bồi đắp phù sa màu mỡ tạo nên đồng bằng Bắc Bộ trù phú. Dòng sông mang sắc đỏ của phù sa này gắn liền với lịch sử dựng nước và giữ nước ngàn năm của dân tộc (Thăng Long - Hà Nội nằm bên sông Hồng).	Sông Hồng xưa còn gọi là sông Cái (Sông Mẹ). Hệ thống đê sông Hồng là công trình thủy lợi vĩ đại của người Việt để trị thủy, phòng lụt.	Nhĩ Hà tượng trưng cho nguồn sống, sự sinh sôi (phù sa), văn hóa cội nguồn và sức mạnh vĩ đại của thiên nhiên.	Nước sông Hồng đỏ ngầu quanh năm là do chứa lượng phù sa khổng lồ (khoảng 100 triệu tấn/năm), rất tốt cho cây trồng.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
10b7a730-86db-4970-b69c-7173f78cce36	84039e96-9ff0-4303-a8e0-472f04ffe222	Mây - vẻ đẹp biến ảo, điềm lành từ trời cao.	Vân (Mây) là hơi nước ngưng tụ trôi lơ lửng trên bầu trời. Trong nghệ thuật và tín ngưỡng Á Đông, mây (Vân) là họa tiết trang trí phổ biến (vân mây, long vân), tượng trưng cho cõi tiên, sự thanh cao và điềm lành (Khánh vân - mây ngũ sắc). Mây mang mưa đến tưới mát ruộng đồng ('Mây xanh thì nắng, mây trắng thì mưa'). Hình ảnh mây trên Tuyên Đỉnh được chạm khắc mềm mại, bay bổng, thể hiện ước vọng về mưa thuận gió hòa.	Vua chúa thường tự ví mình như rồng (Long), rồng luôn đi kèm với mây (Long vân khánh hội). Mây là phương tiện di chuyển của thần tiên.	Mây tượng trưng cho sự tự do, phiêu du, sự thăng hoa và phúc lành (phúc ấm). 'Vân ám' (mây che) là điềm xấu, 'Quang vân' (mây sáng) là điềm tốt.	Có nhiều loại mây báo hiệu thời tiết khác nhau. Người nông dân nhìn mây để đoán biết nắng mưa mà sắp xếp việc đồng áng ('Vàng mây thì gió, đỏ mây thì mưa').	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
4aaf60e6-de15-4927-a041-a7124fd50f62	1a597969-b683-4ccb-beb5-8397de37a0cf	Mũi Đại Lãnh - nơi đón ánh bình minh đầu tiên trên đất liền.	Đại Lãnh (Mũi Đại Lãnh/Mũi Điện) thuộc tỉnh Phú Yên, là một trong những điểm cực Đông của Tổ quốc trên đất liền, nơi đón ánh mặt trời đầu tiên trong ngày. Nơi đây có phong cảnh hùng vĩ với núi đâm ra biển, bãi Môn cát trắng tuyệt đẹp. Đại Lãnh từng được vua Minh Mạng cho khắc vào Tuyên Đỉnh vì vị trí địa lý đặc biệt và tầm quan trọng trong việc đánh dấu lãnh hải. Ngọn hải đăng Đại Lãnh ngày nay vẫn soi đường cho tàu bè qua lại.	Năm 1836, vua Minh Mạng cho dựng bia đá tại đây để khẳng định chủ quyền. Đại Lãnh là danh thắng tiêu biểu của miền Trung.	Đại Lãnh tượng trưng cho sự khởi đầu (bình minh), sự vững chãi trước sóng gió biển khơi và chủ quyền thiêng liêng.	Tên 'Đại Lãnh' có nghĩa là cái đèo lớn/đỉnh núi lớn. Đây là nơi giao hòa tuyệt đẹp giữa núi và biển.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
88d680e0-2749-4742-991c-da78abff6464	0ae0148e-d9ac-4549-bdfd-8884967c621e	Sông Lam - dòng sông xanh xứ Nghệ, biểu tượng của sự hiếu học.	Lam Giang (Sông Lam/Sông Cả) là con sông lớn nhất xứ Nghệ (Nghệ An - Hà Tĩnh). Nước sông trong xanh (màu lam) chảy qua những vùng đất địa linh nhân kiệt, nơi sinh ra nhiều danh nhân, thi hào (như Nguyễn Du) và các vị lãnh tụ. Sông Lam cùng với núi Hồng Lĩnh tạo nên biểu tượng 'Non Hồng - Nước Lam' của vùng đất học này. Khắc Lam Giang lên đỉnh là tôn vinh truyền thống văn hóa và con người xứ Nghệ.	Sông Lam là đường giao thông thủy quan trọng nối miền ngược với miền xuôi. Đôi bờ sông Lam có những điệu hò ví giặm đằm thắm được UNESCO công nhận là di sản văn hóa.	Sông Lam tượng trưng cho sự trong sáng, lòng kiên trung và dòng chảy văn hóa bất tận. Màu xanh của sông là màu của hy vọng và tri thức.	Sông Lam còn có tên là Sông Cả (Sông Mẹ). Món 'nhút Thanh Chương, tương Nam Đàn' nổi tiếng gắn liền với dòng sông này.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
fb1fa809-4dab-42c5-ae97-6f944447893a	8e2b8abb-d36a-4176-b130-cb1c9631078a	Con Sam - tình nghĩa vợ chồng sắt son 'như sam'.	Hậu Ngư (Con Sam - Tachypleus tridentatus) là loài động vật chân khớp biển có vỏ cứng hình móng ngựa và đuôi nhọn dài. Sam luôn đi có đôi (con đực nhỏ bám trên lưng con cái lớn), nếu tách rời chúng sẽ chết hoặc rất khó sống. Vì đặc tính này, dân gian có câu 'dính như sam' để chỉ sự gắn bó khăng khít, đặc biệt là tình vợ chồng. Máu sam có màu xanh dương và được dùng trong y học để kiểm tra độc tố. Thịt sam (trứng sam) là món đặc sản biển hấp dẫn.	Sam là loài vật cổ đại còn sót lại (hóa thạch sống). Việc khắc sam lên đỉnh cho thấy sự quan sát tinh tế của người xưa về tập tính sinh học mang ý nghĩa nhân văn.	Con Sam tượng trưng cho tình yêu chung thủy, sự gắn bó không rời và hạnh phúc lứa đôi. Nó cũng nhắc nhở về đạo lý phu thê.	Cần phân biệt con Sam (đuôi hình tam giác, có gai, ăn được) với con So (đuôi tròn, không gai, rất độc, ăn vào có thể chết người). Câu tục ngữ 'Thấy sam thì bắt, thấy so thì kiêng'.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
c583b4d6-a27a-49aa-8699-6ee1efe8f974	fd43425d-1e0b-44bf-9be9-bf6fbfe94168	Củ Gừng - gia vị cay nồng, vị thuốc ấm áp.	Khương (Sinh khương/Can khương - Cây Gừng) là loài cây gia vị quen thuộc trong mọi gian bếp Việt. Củ gừng có vị cay, tính ấm, mùi thơm nồng, dùng để khử mùi tanh thực phẩm và làm ấm tỳ vị. Trong y học, gừng tươi (sinh khương) chữa cảm lạnh, nôn mửa; gừng khô (can khương) hồi dương cứu nghịch. Mứt gừng là món ngon ngày Tết. Hình ảnh cây gừng trên Tuyên Đỉnh gợi lên sự ấm cúng và sự chăm sóc sức khỏe thường ngày.	Gừng được trồng và sử dụng từ hàng ngàn năm nay. 'Gừng càng già càng cay' là câu tục ngữ nói về kinh nghiệm và bản lĩnh của người lớn tuổi.	Củ gừng tượng trưng cho sự nồng ấm, lòng thủy chung (muối mặn gừng cay) và sự từng trải, vững vàng.	Trà gừng mật ong là thức uống tuyệt vời để giữ ấm cơ thể mùa đông và tăng cường hệ miễn dịch.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
3ec596cd-cab5-4b2f-b3f3-fde5ec170f70	4bbd7497-e84d-46c8-871f-62a42a7c9465	Cái Nỏ - vũ khí thần diệu của An Dương Vương.	Nỗ (Cái nỏ) là loại vũ khí bắn tên cơ học, có lẫy cò, uy lực mạnh và bắn xa hơn cung tên thông thường. Nỏ gắn liền với truyền thuyết Nỏ thần (Linh Quang Kim Quy) của An Dương Vương giữ thành Cổ Loa, một phát bắn ra ngàn mũi tên. Trong quân đội triều Nguyễn, nỗ vẫn được sử dụng song song với súng, đặc biệt hiệu quả trong tay các binh lính người dân tộc thiểu số hoặc trong các trận phục kích im lặng. Hình ảnh cái nỏ trên đỉnh nhắc nhở về lịch sử giữ nước và trí tuệ chế tạo vũ khí của cha ông.	Người Việt cổ rất giỏi dùng nỏ. Các lẫy nỏ bằng đồng tìm thấy ở Cổ Loa chứng minh trình độ kỹ thuật cao từ thời Đông Sơn.	Cái Nỏ tượng trưng cho sự chính xác, sức mạnh bí mật và khả năng bảo vệ đất nước trước kẻ thù đông đảo.	Nỏ có thể bắn xuyên giáp ở khoảng cách gần. Các chiến binh Tây Nguyên cũng rất thiện nghệ trong việc dùng nỏ săn thú và đánh giặc.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
6f07c80a-5561-40cd-9902-8948930d2c22	db5621b4-394c-4edc-924c-e3110b1c9941	Lê Thuyền - thuyền chiến thon dài, lướt nhanh trên sông.	Lê Thuyền là một loại thuyền chiến hạng nhẹ của thủy quân nhà Nguyễn. Thuyền có dáng thon, dài, mũi nhọn, thường có 12-16 tay chèo, di chuyển rất linh hoạt và nhanh chóng trên sông rạch. Loại thuyền này thường dùng để tuần tra, hộ tống hoặc tác chiến ở vùng sông nước chằng chịt. Tên 'Lê' có thể liên quan đến hình dáng hoặc nguồn gốc địa phương. Sự hiện diện của Lê Thuyền trên Tuyên Đỉnh bổ sung vào bộ sưu tập phong phú các loại tàu thuyền của triều đình.	Vua Gia Long rất coi trọng thủy chiến. Ông đã cho đóng hàng trăm chiến thuyền các loại, trong đó có Lê Thuyền, để thống nhất đất nước và bảo vệ lãnh thổ.	Lê Thuyền tượng trưng cho sự cơ động, tinh thần thượng võ và khả năng làm chủ sông nước của người Việt.	Thuyền của vua chúa thường được sơn son thếp vàng, chạm rồng (Long thuyền), còn thuyền chiến như Lê Thuyền thường sơn đen hoặc đỏ, chú trọng vào tính năng chiến đấu.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
983975dd-1bd8-433c-9439-6107e3d35908	1f9addcc-52d4-416f-80b0-a10cc3de6da2	Con Lợn - biểu tượng của sự no đủ, phồn thực.	Thỉ (Con lợn/Heo) là gia súc quan trọng nhất trong nông nghiệp cổ truyền, cung cấp thịt và phân bón cho cây trồng. Hình ảnh con lợn béo tốt trên Tuyên Đỉnh (cũng như trong tranh Đông Hồ) tượng trưng cho sự sung túc, no đủ, sinh sôi nảy nở (lợn đẻ nhiều con). Lợn cũng là vật phẩm không thể thiếu trong các mâm cỗ cúng tế ('đầu heo', 'heo quay') để tạ ơn thần linh. Việc khắc con lợn lên đỉnh cao quý thể hiện cái nhìn trân trọng đối với đời sống thực tế của người dân.	Nuôi lợn là nghề phụ gia đình phổ biến ('Giàu lợn nái, lãi gà con'). Con lợn ỉ móng cái, lợn mọi là những giống lợn bản địa quý.	Con lợn tượng trưng cho tài lộc, sự an nhàn (ăn no ngủ kỹ) và sự mắn đẻ. Trong 12 con giáp, Hợi (Lợn) đứng cuối cùng, hưởng phúc lộc.	Lợn là loài vật rất thông minh (hơn cả chó) và sạch sẽ (nếu có điều kiện).	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
f3d3738b-282d-4ad4-8151-d22795d27649	d14077fe-7eee-4829-8a7b-ecfd8f3936ef	Con Vích - rùa biển khổng lồ, sứ giả của đại dương.	Ngoan (Con Vích - Chelonia mydas/Rùa xanh) là loài rùa biển lớn, có mai cứng, bơi lội giỏi trong đại dương. Vích thường lên bãi cát ven biển để đẻ trứng vào ban đêm. Thịt và trứng vích từng là nguồn thực phẩm, mai vích (đồi mồi) dùng làm đồ mỹ nghệ (lược, hộp). Tuy nhiên, hiện nay Vích là loài nguy cấp cần được bảo vệ nghiêm ngặt. Hình ảnh con Vích trên đỉnh là minh chứng cho sự đa dạng sinh học biển Việt Nam và sự quan tâm của người xưa đến các loài thủy tộc.	Vích và Đồi mồi là những sản vật biển quý giá thường được cống nạp. Côn Đảo là nơi có quần thể rùa biển sinh sản lớn nhất Việt Nam.	Vích (Rùa biển) tượng trưng cho sự trường thọ, sự kiên trì (vượt đại dương để về nơi sinh ra đẻ trứng) và sự bình yên của biển cả.	Rùa biển có thể sống hàng trăm năm. Khi lên bờ đẻ trứng, chúng thường 'khóc' (thực ra là tiết muối thừa qua tuyến lệ).	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
dbf8a56b-d89e-44d0-a63e-3c739283a0c1	96577e61-6e05-4640-92b0-3c1e025f9fb9	Dụ Đỉnh - ước vọng về sự giàu có, dư dả cho muôn dân.	Dụ Đỉnh là chiếc đỉnh thứ tám trong Cửu Đỉnh, nằm ở phía bên trái (đối diện với Huyền Đỉnh). Chữ 'Dụ' (裕) có nghĩa là giàu có, sung túc, dư dả (như trong từ 'phú dụ'). Khác với các đỉnh khác thường ứng với thụy hiệu của một vị vua, Dụ Đỉnh (và Huyền Đỉnh) được cho là dự báo cho các thế hệ vua tiếp theo hoặc mang ý nghĩa cầu mong sự thịnh vượng chung cho đất nước. Dụ Đỉnh nặng khoảng 2.000kg, thể hiện khát vọng về một quốc gia 'dân giàu, nước mạnh'.	Dụ Đỉnh đúc năm 1836. Sau vua Khải Định (Tuyên Đỉnh), nhà Nguyễn còn có vua Bảo Đại, nhưng triều đại đã suy tàn nên không có thêm miếu hiệu ứng với các đỉnh còn lại một cách rõ ràng.	Chữ 'Dụ' tượng trưng cho sự khoan dung, rộng lượng và sự thịnh vượng về vật chất lẫn tinh thần.	Có giả thuyết cho rằng Dụ Đỉnh sau này được liên hệ với vua Bảo Đại, nhưng ông là vị vua thoái vị nên không có miếu hiệu chính thức để 'ứng' vào đỉnh theo quy tắc của các vua trước.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
e793f355-6e85-4c53-8d14-8fa6e6a6b202	51180b9a-6c5a-48fd-9784-229c979352b2	Chim Vẹt - sứ giả sắc màu, khéo léo và thông minh.	Anh Vũ (Chim Vẹt/Két) là loài chim có bộ lông sặc sỡ và chiếc mỏ quặp đặc trưng. Vẹt nổi tiếng với khả năng bắt chước tiếng người và các âm thanh khác rất tài tình. Ở Việt Nam có nhiều loài vẹt như vẹt ngực đỏ, vẹt đầu hồng... Chúng sống thành đàn, bay lượn tạo nên cảnh tượng vui mắt trong rừng già. Hình ảnh chim Anh Vũ trên Dụ Đỉnh thể hiện sự phong phú của thế giới sinh vật và vẻ đẹp tươi vui của thiên nhiên.	Chim Anh Vũ thường được các nước phương Nam cống nạp cho triều đình Trung Hoa xưa như một sản vật lạ. Ở Việt Nam, chúng cũng được nuôi làm cảnh trong cung vua phủ chúa.	Chim Vẹt tượng trưng cho tài ăn nói, màu sắc rực rỡ và điềm lành. Trong Phật giáo, chim Anh Vũ cũng xuất hiện trong các điển tích về lòng hiếu thảo.	Vẹt là một trong những loài chim thông minh nhất thế giới, chúng có thể giải được các câu đố đơn giản và dùng công cụ.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
800e0e55-e4f7-47c0-8d4a-9d66542f611f	31eab81a-d2b3-491d-9157-42e3ee5c3ef9	Quả Lê - vị ngọt thanh tao, sản vật vùng cao.	Lê (Pyrus) là loài cây ăn quả ôn đới, trồng nhiều ở các vùng núi cao phía Bắc Việt Nam (như Lạng Sơn, Cao Bằng). Quả lê có vỏ vàng hoặc nâu, thịt trắng, giòn, nhiều nước và có vị ngọt mát. Trong đông y, quả lê có tính mát, giúp nhuận phế, giảm ho, tiêu đờm. Hình ảnh quả lê trên Dụ Đỉnh cho thấy sự bao quát của triều đình đối với các sản vật đặc trưng của mọi vùng miền, từ đồng bằng đến miền núi.	Lê (mắc coọc) là đặc sản của vùng biên cương. Việc khắc nó lên đỉnh thể hiện chủ quyền và sự trân trọng tài nguyên vùng cao.	Cây lê tượng trưng cho sự thanh khiết (hoa lê trắng), tuổi thọ và tình cảm anh em (chia ngọt sẻ bùi).	Hoa lê nở trắng xóa vào mùa xuân tạo nên cảnh sắc tuyệt đẹp cho núi rừng Tây Bắc, thường đi vào thơ ca ('Ngày xuân con én đưa thoi / Thiều quang chín chục đã ngoài sáu mươi / Cỏ non xanh tận chân trời / Cành lê trắng điểm một vài bông hoa' - Truyện Kiều).	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
9e798317-cd74-4634-b3e9-35134daf2531	e3690c96-2f06-426b-8409-b2edc01f5349	Dây Trầu không - biểu tượng của tình nghĩa anh em, vợ chồng.	Phù Lưu (Cây Trầu không - Piper betle) là loài dây leo thân thảo, lá hình tim, có vị cay nồng. Trầu không cùng với cau và vôi tạo nên miếng trầu, nét văn hóa đặc sắc 'miếng trầu là đầu câu chuyện' của người Việt. Lá trầu còn có tính sát khuẩn cao, dùng để rửa vết thương, chữa nước ăn chân. Hình ảnh dây trầu leo quanh thân cau là biểu tượng bất hủ của sự gắn bó, thủy chung trong văn hóa dân gian.	Tục ăn trầu nhuộm răng đen là phong tục lâu đời của người Việt (để phân biệt với người phương Bắc). Trong các đám cưới, mâm trầu cau là sính lễ quan trọng nhất.	Trầu không tượng trưng cho sự vun đắp, che chở (lá trầu bao bọc miếng cau) và nghĩa tình son sắt (Sự tích Trầu Cau).	Tên 'Phù Lưu' là tên cổ ít người biết. Người ta thường gọi là 'Trầu' (từ chữ Nôm) hoặc 'Trầu không'.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
8344ac5a-f11d-416c-9d78-22a7c843dee9	4f795d28-a54d-4e16-8e5e-deceae503114	Đậu trắng - hạt ngọc của người ăn chay, món ngon thanh đạm.	Bạch Đầu (Đậu trắng/Bạch đậu) là một loại đậu có hạt màu trắng, giàu tinh bột và protein. Đậu trắng thường được dùng để nấu chè, nấu súp (như món súp đậu trắng hầm) hoặc làm nhân bánh. Trong ẩm thực, đậu trắng mang lại vị bùi, béo. Khắc Bạch Đầu lên đỉnh tiếp tục khẳng định sự quan tâm của triều đình đối với các loại lương thực, thực phẩm nuôi sống nhân dân.	Các loại đậu (ngũ cốc) luôn được coi trọng trong xã hội nông nghiệp. Đậu trắng cũng là nguồn thực phẩm dự trữ quan trọng.	Màu trắng của đậu tượng trưng cho sự tinh khiết. Hạt đậu biểu thị cho sự nảy mầm và tiềm năng phát triển.	Có một loài chim cũng tên là 'Bạch đầu' (Bạch đầu ông) vì có chỏm lông trắng trên đầu, nhưng trong nhóm cây cối lương thực trên đỉnh thì đây là cây đậu.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
eabacc71-ac9e-4cf8-b6de-862752c174e3	c2ed38c9-e06d-479c-98ec-e3058575a6b7	Hoa Dâm Bụt - sắc đỏ rực rỡ nơi hàng rào quê hương.	Thuần Hoa (Hoa Dâm bụt/Bông bụt - Hibiscus rosa-sinensis) là loài cây bụi có hoa lớn màu đỏ tươi (hoặc hồng, vàng), nhụy dài nổi bật. Cây dâm bụt rất dễ trồng, thường được người dân trồng làm hàng rào xanh quanh nhà. Mặc dù ít hương thơm ('Hữu sắc vô hương'), nhưng vẻ đẹp rực rỡ và sức sống bền bỉ của nó khiến ai cũng phải chú ý. Lá và hoa dâm bụt cũng được dùng trong y học dân gian để chữa mụn nhọt, giải nhiệt.	Dâm bụt gắn liền với hình ảnh làng quê Việt Nam yên bình. Trong văn học, nó thường được ví von với vẻ đẹp phô trương nhưng thiếu chiều sâu, tuy nhiên trên Cửu Đỉnh nó được ghi nhận như một loài hoa đẹp của đất nước.	Hoa dâm bụt tượng trưng cho danh vọng vinh hiển (màu đỏ) và sự che chở (hàng rào). Cái tên 'Thuần' (trong sáng, ròng) có thể ngụ ý vẻ đẹp thuần khiết của màu đỏ.	Ở Malaysia, hoa Dâm bụt là quốc hoa. Trẻ em Việt Nam xưa thường dùng hoa dâm bụt để chơi đồ hàng, làm lồng đèn.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
319693af-84ed-4e81-9d0b-3d6e409111e8	2dcbf913-dcf1-4f01-b722-4a7f3719959c	Cây Tùng - khí phách hiên ngang, trường tồn cùng tuế nguyệt.	Tùng (Cây thông/Tùng) là loài cây lá kim, sống trên núi cao, đất đai khô cằn nhưng vẫn xanh tốt quanh năm. Cây tùng chịu được sương tuyết, bão gió, tượng trưng cho khí tiết của người quân tử: ngay thẳng, kiên cường, không khuất phục trước cường quyền hay nghịch cảnh. Tùng cũng là biểu tượng của sự trường thọ (Tùng hạc diên niên). Hình ảnh cây tùng cổ thụ hiên ngang trên Dụ Đỉnh là bài học về đạo đức và nhân cách.	Tùng, Cúc, Trúc, Mai là bộ Tứ quý nổi tiếng. Người xưa thường trồng tùng trong vườn hoặc chậu cảnh (bonsai) để thưởng lãm cốt cách của nó.	Tùng tượng trưng cho người quân tử, đấng trượng phu, sự trường tồn và khả năng vượt khó.	Gỗ tùng (gỗ thông) có mùi thơm đặc trưng và được dùng nhiều trong xây dựng, làm đồ gia dụng. Nhựa thông cũng là một sản phẩm giá trị.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
f4c59960-a75f-44f0-af9e-354067ef164b	c3fc424f-3325-4801-9608-03cd6de1a20d	Hải Vân Quan - 'Thiên hạ đệ nhất hùng quan' giữa mây trời.	Hải Vân Quan là cửa ải nằm trên đỉnh đèo Hải Vân, ranh giới giữa Thừa Thiên Huế và Đà Nẵng. Được xây dựng từ thời Trần và trùng tu lớn vào năm Minh Mạng thứ 7 (1826), cửa ải này giữ vị trí chiến lược xung yếu trên con đường thiên lý Bắc Nam. Vua Lê Thánh Tông từng phong tặng nơi đây là 'Thiên hạ đệ nhất hùng quan'. Đứng từ đây có thể nhìn bao quát cả biển trời và núi non hùng vĩ. Khắc Hải Vân Quan lên đỉnh là khẳng định sự hiểm yếu và vẻ đẹp tráng lệ của non sông.	Hải Vân Quan là chốt chặn phòng thủ quan trọng bảo vệ Kinh đô Huế từ phía Nam. Nơi đây mây phủ quanh năm, tạo nên khung cảnh huyền ảo.	Hải Vân Quan tượng trưng cho sự hiểm trở, sự phân chia địa lý (khí hậu hai miền Nam - Bắc khác nhau qua đèo này) và quyền lực kiểm soát lãnh thổ.	Trên cửa vòm của Hải Vân Quan quay về hướng Huế có biển đề 'Hải Vân Quan', cửa quay về hướng Đà Nẵng đề 'Thiên hạ đệ nhất hùng quan'.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
db4f7bdf-5efa-4620-8a42-9a56c19f2832	0c5ee60c-60d8-452d-9944-c1d87c17cc48	Sấm - tiếng thét của bầu trời, hiệu lệnh của mưa.	Lôi (Sấm) là âm thanh vang rền do sự phóng điện trong các đám mây dông. Người xưa coi sấm là tiếng nói của Thiên lôi (Thần Sấm), thể hiện sự uy nghiêm và trừng phạt cái ác. Tiếng sấm đầu mùa (Xuân lôi) báo hiệu mưa thuận gió hòa, vạn vật sinh sôi. Hình ảnh Sấm trên Dụ Đỉnh thường được thể hiện bằng các đường vân xoắn ốc mạnh mẽ hoặc hình tượng trống sấm, tượng trưng cho uy quyền của nhà vua và sức mạnh thiên nhiên.	Trong nông nghiệp, 'Lúa chiêm lấp ló đầu bờ / Hễ nghe tiếng sấm phất cờ mà lên'. Sấm sét mang theo đạm khí trời giúp cây cối tốt tươi.	Sấm tượng trưng cho sự thức tỉnh, chấn động, uy lực và sự khởi đầu mới.	Ánh sáng (chớp) đi nhanh hơn âm thanh (sấm), nên ta thường thấy chớp trước rồi mới nghe tiếng sấm.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
492553eb-045a-476b-9753-a73d8c2e5561	b1df8b65-1219-483d-9e41-6e8943b76a03	Sông Vệ - dòng sông êm đềm tưới mát đồng ruộng Quảng Ngãi.	Vệ Giang (Sông Vệ) là một trong những con sông chính của tỉnh Quảng Ngãi. Sông chảy qua các vùng đồng bằng trù phú, cung cấp nước tưới cho nông nghiệp và là nguồn sống của cư dân đôi bờ. Dòng sông Vệ êm đềm, gắn liền với những rặng tre, bến nước, con đò, tạo nên vẻ đẹp bình dị của làng quê miền Trung. Việc khắc Vệ Giang lên đỉnh thể hiện sự quan tâm đến hệ thống thủy lợi và đời sống nông nghiệp của đất nước.	Quảng Ngãi nổi tiếng với nghề trồng mía làm đường, bờ xe nước. Sông Vệ góp phần quan trọng vào sự phát triển của các làng nghề này.	Sông Vệ tượng trưng cho sự nuôi dưỡng thầm lặng và sự gắn bó của con người với quê hương.	Vùng hạ lưu sông Vệ có nhiều cồn bãi đẹp, là nơi trú ngụ của nhiều loài chim nước.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
f9ac3839-7c2b-4027-8c45-f85817ee37cb	a473c901-10b7-4d38-82fa-cbbacd08a06f	Cửa biển Đà Nẵng - cửa Hàn, thương cảng sầm uất bậc nhất.	Đà Nẵng Hải Khẩu (Cửa biển Đà Nẵng/Cửa Hàn) là nơi sông Hàn đổ ra vịnh Đà Nẵng. Đây là một trong những hải cảng sâu và kín gió tốt nhất miền Trung, thuận lợi cho tàu thuyền lớn neo đậu. Từ thời nhà Nguyễn, Đà Nẵng đã trở thành thương cảng quốc tế quan trọng thay thế dần cho Hội An. Cửa biển này cũng có vị trí quân sự chiến lược (trận chiến Đà Nẵng 1858 chống Pháp). Khắc Đà Nẵng Hải Khẩu lên đỉnh là khẳng định tầm nhìn chiến lược về kinh tế biển và quốc phòng.	Năm 1835, vua Minh Mạng ra dụ chỉ quy định các tàu phương Tây chỉ được phép neo đậu và buôn bán tại cửa Hàn, biến nơi đây thành cửa ngõ giao thương độc tôn.	Cửa biển Đà Nẵng tượng trưng cho sự mở cửa, giao lưu hội nhập và sự phát triển năng động.	Ngày nay, Đà Nẵng được mệnh danh là 'Thành phố của những cây cầu' bắc qua sông Hàn, ngay tại khu vực cửa biển này.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
0626a248-bcc3-4178-9a28-2282abd49812	06288f6c-521d-4ae8-943c-3c11336a2159	Cá Mú/Cá Song - đặc sản biển quý giá, thịt thơm ngon.	Thạch Thủ Ngư (Cá đầu đá - thường được hiểu là Cá Mú/Cá Song hoặc Cá Lù đù). Cá Mú là loài cá biển sống ở các rạn san hô, hốc đá (Thạch), có thịt trắng, dai, ngọt, rất được ưa chuộng trong ẩm thực. Tên 'Thạch thủ' (đầu đá) có thể mô tả đặc điểm đầu to và cứng của loài cá này hoặc nơi sống của chúng. Đây là loài hải sản có giá trị kinh tế cao, được ngư dân đánh bắt và nuôi trồng nhiều. Hình ảnh cá trên đỉnh tôn vinh nguồn lợi thủy sản phong phú của biển Việt Nam.	Cá Mú hấp xì dầu, nấu cháo là những món ăn thượng hạng. Vùng biển miền Trung và Nam Bộ rất nổi tiếng với các loại cá Mú (mú đỏ, mú đen, mú nghệ).	Cá Mú tượng trưng cho sự giàu có của biển cả (kho vàng sống) và sức khỏe.	Cá Mú là loài cá dữ, ăn thịt. Chúng có thể thay đổi giới tính từ cái sang đực khi trưởng thành.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
c538f886-7c6c-4004-95a6-369cbdf6e5fe	ca189580-e780-4a1b-b058-72fed51694f4	Tía Tô - rau gia vị giải cảm, màu tím đặc trưng.	Tử Tô (Cây Tía tô - Perilla frutescens) là loài cây thảo, lá có màu tím (tử) hoặc xanh tím, mép răng cưa, mùi thơm nồng đặc biệt. Tía tô là loại rau gia vị phổ biến ăn kèm với cháo, bún, gỏi. Trong đông y, tía tô (cả lá, cành, hạt) là vị thuốc quý chữa cảm cúm, ho, hen suyễn, an thai và giải độc cua cá. Hình ảnh cây tía tô trên Dụ Đỉnh thể hiện sự trân trọng những cây thuốc nam giản dị nhưng công hiệu.	Cháo hành tía tô là món ăn giải cảm kinh điển (như trong tác phẩm 'Chí Phèo'). Người Nhật cũng dùng tía tô (Shiso) rất nhiều trong ẩm thực (ăn sashimi).	Tía tô tượng trưng cho sự ấm áp, giải tỏa (giải cảm) và sự hòa hợp (khử mùi tanh, cân bằng món ăn).	Lá tía tô có thể dùng để nhuộm màu thực phẩm (như làm mơ muối umeboshi) tạo ra màu đỏ tím rất đẹp.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
6903a8fe-696b-4e55-9016-0c407c3ac06c	07b1be33-af84-4928-82c4-405f27fb3875	Ô Thuyền - chiến thuyền sơn đen, dũng mãnh trên biển.	Ô Thuyền (Thuyền đen) là loại thuyền chiến của thủy quân nhà Nguyễn, được sơn màu đen (Ô) từ thân đến cánh buồm để ngụy trang và tạo vẻ uy nghiêm. Thuyền có kích thước trung bình, trang bị nhiều tay chèo và súng thần công, chuyên dùng để tác chiến trên biển và các cửa sông lớn. Màu đen của thuyền giúp nó khó bị phát hiện vào ban đêm. Khắc Ô Thuyền lên đỉnh là ghi nhận sức mạnh và sự đa dạng của hạm đội hải quân triều Nguyễn.	Vua Gia Long đặt tên các loại thuyền theo màu sắc: Thanh thuyền (xanh), Xích thuyền (đỏ), Ô thuyền (đen)... để phân biệt các hạm đội.	Ô Thuyền tượng trưng cho sự bí mật, sức mạnh tiềm ẩn và kỷ luật quân đội (màu đen huyền bí).	Sơn thuyền màu đen thường được làm từ nhựa cây sơn trộn với than muội, có tác dụng chống thấm nước và hà ăn rất tốt.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
e3786b62-6fc7-461e-8574-8923bb86e962	bc0cc630-57db-4918-a144-5ab55b9b2ab2	Phác Đao - vũ khí cán dài, uy lực của bộ binh.	Phác Đao (hoặc Phạc đao) là loại vũ khí lạnh có lưỡi đao to bản, sắc bén gắn trên một cán dài (cán gỗ hoặc sắt). Đây là vũ khí kết hợp giữa đao và thương, cho phép lính bộ binh có thể chém, bổ với lực rất mạnh, thậm chí có thể chặt chân ngựa của kỵ binh đối phương. Phác đao là vũ khí phổ biến trong quân đội phong kiến Á Đông. Hình ảnh Phác đao trên Dụ Đỉnh thể hiện khí thế mạnh mẽ và trang bị vũ khí đầy đủ của quân đội.	Trong võ thuật cổ truyền, bài 'Phác đao' là một bài binh khí uy dũng. Quân đội nhà Nguyễn dùng phác đao cho các đội vệ binh và lính thú.	Phác Đao tượng trưng cho sức mạnh tấn công, sự dũng cảm (xáp lá cà) và khả năng trấn áp kẻ thù.	Lưỡi phác đao thường rộng hơn lưỡi thương, trọng lượng cũng nặng hơn nên đòi hỏi người sử dụng phải có sức khỏe tốt.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
192962e8-5bc4-48d5-a7cf-6c0a378c45c1	de7364d9-540b-4930-847e-660e19b01b42	Con Sò - sản vật vùi mình trong cát, ngon ngọt vị biển.	Cáp (Con Sò/Ngao) là tên gọi chung cho các loài nhuyễn thể hai mảnh vỏ sống ở vùng biển và cửa sông. Thịt sò giàu dinh dưỡng, là nguồn thực phẩm quan trọng của cư dân ven biển. Vỏ sò có thể dùng nung vôi hoặc làm đồ thủ công. Hình ảnh con Sò trên Dụ Đỉnh đại diện cho sự phong phú của hải sản và cuộc sống gắn liền với biển cả của người dân Việt Nam.	Sò huyết đầm Ô Loan (Phú Yên) là đặc sản tiến vua nổi tiếng. Các đống vỏ sò (cồn sò) tìm thấy trong di chỉ khảo cổ cho thấy người Việt cổ đã khai thác sò từ hàng ngàn năm trước.	Con Sò tượng trưng cho sự kín đáo, sự bảo vệ (vỏ cứng) và nguồn tài nguyên vô tận của biển.	Chữ 'Cáp' (Sò) đồng âm với 'Hợp' (hòa hợp), nên sò cũng mang ý nghĩa may mắn, thuận hòa.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
197dbd95-c742-40e3-9464-c375c17fd902	2c276f27-89b1-415f-a842-2441a0a04586	Con Dê - biểu tượng của sự ôn hòa và lộc tài.	Dương (Con Dê) là loài gia súc được nuôi để lấy thịt và sữa. Dê có tính tình ôn hòa, nhanh nhẹn, thích leo trèo trên núi đá. Trong văn hóa, Dê (Mùi) là con giáp thứ 8, tượng trưng cho sự cát tường (chữ Dương và chữ Tường có bộ chữ giống nhau). 'Tam dương khai thái' là câu chúc xuân ý nghĩa, mong đợi những điều tốt lành, may mắn sẽ đến. Hình ảnh con Dê trên Dụ Đỉnh thể hiện sự thanh bình và sung túc của đời sống chăn nuôi.	Dê thường được dùng làm vật tế thần (Tam sinh: Trâu, Dê, Lợn) trong các nghi lễ quan trọng của triều đình (như tế Nam Giao).	Dê tượng trưng cho điềm lành, sự sinh sôi và tính nhẫn nại. Dê quỳ bú sữa mẹ còn là biểu tượng của lòng hiếu thảo.	Dê có đồng tử mắt hình chữ nhật nằm ngang, giúp chúng có tầm nhìn rộng để phát hiện kẻ thù.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
f7da57f8-b4ff-4134-9bcd-f16de11865d5	b57e45b6-98c6-4315-86f6-7bc6be066a30	Huyền Đỉnh - sự sâu sắc, huyền diệu và vĩnh cửu.	Huyền Đỉnh là chiếc đỉnh cuối cùng trong Cửu Đỉnh, nằm ở phía bên phải (đối diện với Dụ Đỉnh). Chữ 'Huyền' (玄) có nghĩa là màu đen, sâu xa, huyền diệu, u tịch (như trong 'Huyền bí', 'Huyền cơ'). Cũng giống như Dụ Đỉnh, Huyền Đỉnh không ứng với thụy hiệu của vị vua nào cụ thể vào thời điểm đúc, mà mang ý nghĩa về sự trường tồn, sâu sắc của triều đại và vũ trụ. Huyền Đỉnh nặng khoảng 1.900kg, hoàn thiện bộ Cửu Đỉnh uy nghi.	Huyền Đỉnh đúc năm 1836. Tên đỉnh gợi nhắc đến triết lý đạo Lão (Huyền chi hựu huyền) hoặc màu sắc của trời (Thiên huyền Địa hoàng). Đây là chiếc đỉnh khép lại công trình nghệ thuật vĩ đại của vua Minh Mạng.	Chữ 'Huyền' tượng trưng cho trời, phương Bắc, màu đen và sự sâu thẳm của trí tuệ. Đỉnh thể hiện sự kết thúc viên mãn và sự bí ẩn của tạo hóa.	Vị trí của Huyền Đỉnh nằm ngoài cùng bên phải, tương ứng với Dụ Đỉnh bên trái, tạo thế cân bằng và bao quát toàn bộ không gian sân chầu.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
ffdefd3a-ecac-4e20-8a7c-5c90fdcc6aa6	89b9b2fe-c54a-4a46-b6d5-748d03e7c854	Hoa Ngọc Lan - hương thơm tinh khiết, dịu dàng.	Ngũ Điệp Lan (thường gọi là Ngọc Lan - Michelia alba) là loài cây thân gỗ, hoa màu trắng ngà, cánh thon dài, có mùi thơm nồng nàn rất quyến rũ. Cây Ngọc Lan thường được trồng trong sân chùa, đền hoặc vườn nhà để lấy bóng mát và hương thơm ('Thơm như ngọc lan'). Hoa ngọc lan còn được dùng để trưng bày trong đĩa, cài lên tóc hoặc chiết xuất tinh dầu nước hoa. Khắc Ngọc Lan lên đỉnh là tôn vinh vẻ đẹp thanh cao của loài hoa này.	Ngọc Lan có nguồn gốc từ Ấn Độ, du nhập vào Việt Nam từ lâu và trở thành loài cây quen thuộc. Trong cung đình Huế, Ngọc Lan được trồng nhiều để tạo hương thơm thanh khiết.	Ngọc Lan tượng trưng cho sự thánh thiện, lòng hiếu thảo và sự may mắn. Mùi hương của nó giúp thanh lọc tâm hồn.	Mặc dù tên Hán Việt là 'Ngũ Điệp Lan' (Lan 5 cánh/bướm?), nhưng dân gian quen gọi là Ngọc Lan. Hoa của nó rất lâu tàn hương.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
89365957-acd1-4b10-800c-80e1b7fd1009	322f9cff-9b9f-4929-8aac-131652a7dca0	Quả Vải - ngọt ngào hương vị mùa hè, đặc sản tiến vua.	Lệ Chi (Cây Vải/Quả Vải - Litchi chinensis) là loài cây ăn quả nhiệt đới nổi tiếng. Quả vải khi chín vỏ đỏ sần sùi, cùi trắng mọng nước, vị ngọt lịm. Vải thiều Thanh Hà (Hải Dương) là giống vải ngon nhất, hạt nhỏ, cùi dày. Vải là loại quả quý từng gây ra bao nỗi gian truân cho người dân trong lịch sử (nộp cống vải). Hình ảnh chùm vải trên Huyền Đỉnh gợi nhớ về vụ án Lệ Chi Viên (Vườn Vải) oan khuất của Nguyễn Trãi, nhưng cũng tôn vinh một sản vật tuyệt vời của đất Việt.	Dương Quý Phi đời Đường rất thích ăn vải, khiến đường sá vận chuyển vải từ phương Nam về Tràng An tấp nập ngựa xe ('Nhất kỵ hồng trần phi tử tiếu' - Một con ngựa bụi hồng phi tới làm phi tử cười).	Lệ Chi tượng trưng cho sự ngọt ngào, tình yêu và cả những bi kịch lịch sử. Cây vải cũng biểu thị sự sum suê con cháu.	Vải sấy khô (vải khô) là một vị thuốc bổ và món ăn vặt ngon. Hạt vải (Lệ chi hạch) cũng được dùng làm thuốc chữa đau bụng.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
1dcf6e44-8e9c-4124-83a8-76533db91b29	88c71d23-5d73-40dd-93e7-8a01b28d2b16	Củ Tỏi - gia vị trừ tà, kháng sinh tự nhiên.	Toán (Cây Tỏi - Allium sativum) là loài cây gia vị thuộc họ Hành. Củ tỏi gồm nhiều tép, có mùi hăng nồng, vị cay. Tỏi là gia vị không thể thiếu trong nhiều món ăn (rau xào, nước chấm) và là vị thuốc kháng sinh tự nhiên cực mạnh, giúp tăng cường hệ miễn dịch, trị cảm cúm, sát trùng. Trong tín ngưỡng dân gian, tỏi còn được dùng để trừ tà ma, bùa ngải. Hình ảnh cây tỏi trên Huyền Đỉnh thể hiện sự trân trọng những giá trị thiết thực trong đời sống.	Tỏi Lý Sơn (Quảng Ngãi) nổi tiếng thơm ngon, tép nhỏ, trắng, được mệnh danh là 'Vương quốc tỏi'. Tỏi đen (tỏi lên men) ngày nay được coi là thần dược.	Củ tỏi tượng trưng cho sự bảo vệ (trừ tà), sức khỏe và sự nồng đượm. Nó là 'vũ khí' của người dân chống lại bệnh tật.	Mùi hăng của tỏi là do hợp chất lưu huỳnh (allicin) được giải phóng khi tỏi bị đập dập hoặc cắt nhỏ. Chính chất này tạo nên công dụng chữa bệnh của tỏi.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
937d788a-f9a7-4a7a-ac7f-6b3e21b113ac	9a6da058-cd77-4cf3-8442-394cd39f958a	Sâm Nam - linh dược nước Nam, bồi bổ nguyên khí.	Nam Sâm (Sâm ta/Sâm Bố Chính/Đinh Lăng) là tên gọi chỉ các loài thảo dược có tác dụng bồi bổ giống nhân sâm nhưng mọc ở nước Nam. Nổi tiếng nhất thời xưa là Sâm Bố Chính (trồng ở Bố Trạch, Quảng Bình) được danh y Hải Thượng Lãn Ông khuyên dùng. Ngày nay, Sâm Ngọc Linh hay cây Đinh Lăng (Ginseng của người nghèo) cũng được gọi là Nam Sâm. Hình ảnh Nam Sâm trên đỉnh khẳng định quan điểm 'Nam dược trị Nam nhân' - dùng thuốc Nam chữa bệnh cho người Nam.	Sâm Bố Chính từng là cống phẩm tiến vua, được đánh giá có công dụng ngang ngửa với sâm Cao Ly (Triều Tiên) nếu biết cách chế biến.	Nam Sâm tượng trưng cho sức khỏe, sự trường thọ và niềm tự hào về nền y học cổ truyền dân tộc.	Hải Thượng Lãn Ông đã dùng Sâm Bố Chính kết hợp với các vị thuốc khác để chữa khỏi bệnh cho nhiều người, chứng minh giá trị của thuốc Nam.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
ae9dfbe5-6e78-477f-9d75-e67b2a04b00e	40e651b8-3308-462b-bbd0-c64f64023591	Cây Bông - nguyên liệu dệt vải, che thân ấm áp.	Miên (Cây Bông/Bông vải - Gossypium) là loài cây công nghiệp quan trọng, quả bông khi chín nứt ra để lộ những sợi bông trắng xốp bên trong. Sợi bông được kéo thành chỉ để dệt vải, may quần áo. Cây bông đã gắn bó với nghề dệt thủ công truyền thống của người Việt từ ngàn xưa. Khắc cây Bông lên Huyền Đỉnh thể hiện sự quan tâm đến nhu cầu 'mặc' ấm của nhân dân, bên cạnh nhu cầu 'ăn' (lúa gạo).	Trước khi có vải sợi tổng hợp, vải bông (cotton) là chất liệu chính để may mặc. Nghề trồng bông dệt vải rất phát triển ở các làng nghề như Nha Xá, Vạn Phúc.	Cây Bông tượng trưng cho sự ấm áp, sự che chở (manh áo) và sự mềm mại nhưng bền bỉ (sợi chỉ).	Từ 'Miên' còn dùng để chỉ giấc ngủ (giấc miên man), có lẽ vì bông mềm mại như giấc ngủ êm đềm.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
43cdb931-e3fa-4678-9226-f6c707e9ab6c	063b1479-5e88-47c5-9a39-1161e3ee04e9	Chim Già Đẫy - loài chim kỳ lạ của vùng đất ngập nước.	Thốc Thu (Chim Già đẫy/Cò sói - Leptoptilos javanicus) là loài chim nước lớn thuộc họ Hạc, có cái đầu và cổ trụi lông (hói/thốc) trông rất già nua và khắc khổ, nên gọi là 'Già đẫy'. Chúng sống ở các vùng đất ngập nước, rừng tràm (như U Minh, Đồng Tháp Mười), ăn cá và sinh vật nhỏ. Hình ảnh loài chim có vẻ ngoài kỳ dị này trên đỉnh cho thấy sự đa dạng của hệ sinh thái đất ngập nước phương Nam.	Chim Già đẫy hiện là loài quý hiếm cần bảo tồn. Sự xuất hiện của chúng trên Cửu Đỉnh là tư liệu quý về sự phân bố loài này trong quá khứ.	Thốc Thu tượng trưng cho sự trường thọ (dáng vẻ già nua), sự điềm tĩnh và sự gắn bó với môi trường tự nhiên hoang dã.	Cái túi da dưới cổ chim Già đẫy (túi khí) có thể phồng lên xẹp xuống, giúp chúng phát ra âm thanh lạ để giao tiếp.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
2bd0ad59-5ae6-4b33-9611-4c9b20a8e0d4	703b31cf-271c-44a8-9225-a97b11c598d4	Cầu Vồng - nhịp cầu sắc màu nối đất với trời.	Hồng (Cầu vồng/Mống) là hiện tượng tán sắc ánh sáng mặt trời qua các giọt mưa, tạo thành dải màu rực rỡ trên bầu trời. Người xưa gọi cầu vồng là 'Hồng' hoặc 'Mống', coi đó là dấu hiệu của rồng uống nước hoặc sự giao hòa âm dương. Cầu vồng xuất hiện sau cơn mưa mang lại cảm giác tươi mới, hy vọng. Hình ảnh cầu vồng trên Huyền Đỉnh được chạm khắc cách điệu, thể hiện sự quan sát tinh tế các hiện tượng khí tượng.	Tục ngữ có câu 'Mống đông vồng tây, chẳng mưa dây cũng bão giật' dùng để dự báo thời tiết. Cầu vồng đôi (Mống cụt) cũng thường được nhắc đến.	Cầu vồng tượng trưng cho niềm hy vọng, sự nối kết (nhịp cầu), vẻ đẹp huyền ảo và sự bình yên sau giông bão.	Cầu vồng thực chất là một vòng tròn khép kín, nhưng từ mặt đất ta thường chỉ nhìn thấy một nửa vòng cung.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
a3672bb1-466d-47fd-8d3f-3af4e7a7e769	a418ffb9-bc04-46b0-a6e3-d70ab13e4f39	Sông Tiền, Sông Hậu - chín rồng cuộn sóng phương Nam.	Tiền Giang và Hậu Giang là hai nhánh sông chính của sông Cửu Long (Mekong) chảy vào Việt Nam, bồi đắp nên vùng đồng bằng sông Cửu Long trù phú, vựa lúa lớn nhất cả nước. Sông Tiền và Sông Hậu mang lượng phù sa khổng lồ và nguồn thủy sản dồi dào, tạo nên nền văn minh sông nước miệt vườn độc đáo. Việc khắc cả hai dòng sông lên cùng một hình trên Huyền Đỉnh khẳng định chủ quyền lãnh thổ và tầm quan trọng sống còn của vùng đất Nam Bộ đối với quốc gia.	Vùng đất Nam Bộ được khai phá mạnh mẽ dưới thời các chúa Nguyễn. Hệ thống kênh rạch chằng chịt nối liền hai con sông này giúp giao thương và nông nghiệp phát triển rực rỡ.	Hai dòng sông tượng trưng cho sự giàu có, phì nhiêu và hào phóng của thiên nhiên (Cửu Long tranh châu). Nó là mạch máu của miền Nam.	Sông Cửu Long đổ ra biển qua 9 cửa (nay đã bị bồi lấp bớt), được ví như 9 con rồng phun nước. Chợ nổi là nét văn hóa đặc trưng trên các dòng sông này.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
67aa9d9c-5392-4ddb-97e0-455e9b56ca32	da2973be-78ac-4988-9e37-723d1c862eae	Mưa - nguồn nước mát lành nuôi dưỡng sự sống.	Vũ (Mưa) là hiện tượng ngưng tụ hơi nước rơi xuống mặt đất. Đối với nền nông nghiệp lúa nước, mưa là yếu tố quan trọng bậc nhất ('Nhất nước, nhì phân...'). Mưa thuận gió hòa là ước mơ ngàn đời của người nông dân. Hình ảnh mưa trên Huyền Đỉnh được thể hiện bằng những vạch chấm rơi xuống, tượng trưng cho ân trạch của trời đất ban xuống trần gian, mang lại sự sinh sôi nảy nở.	Lễ Cầu đảo (cầu mưa) là nghi lễ quan trọng của triều đình khi gặp hạn hán. Vua đích thân lập đàn tế trời cầu mưa để cứu lúa, cứu dân.	Mưa tượng trưng cho sự gột rửa, tái sinh, sự mát lành và ân huệ (mưa móc).	Mưa ngâu (tháng 7 âm lịch) gắn liền với sự tích Ngưu Lang Chức Nữ gặp nhau khóc tạo thành mưa. Mưa xuân lất phất giúp cây cối đâm chồi nảy lộc.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
250a5b13-f4c8-4ca2-a575-83ca60e65cda	6640dd03-34a0-4968-afc4-c5c87006b5b1	Đèo Ngang - Hoành Sơn quan, cửa ải thơ mộng và hiểm trở.	Hoàng Sơn (Núi Hoành Sơn/Đèo Ngang) là dãy núi chạy ngang ra biển, chia cắt Hà Tĩnh và Quảng Bình. Trên đỉnh đèo có Hoành Sơn Quan (Cổng trời), di tích lịch sử nổi tiếng. Đèo Ngang đi vào thơ ca với bài 'Qua Đèo Ngang' của Bà Huyện Thanh Quan ('Bước tới Đèo Ngang bóng xế tà...'). Đây là ranh giới tự nhiên và lịch sử quan trọng (thời Trịnh - Nguyễn phân tranh). Khắc Hoàng Sơn lên đỉnh là ghi nhận vẻ đẹp sơn thủy hữu tình và vị thế địa lý của nó.	Hoành Sơn Quan được xây dựng dưới thời vua Minh Mạng (1833). Người xưa có câu 'Hoành Sơn nhất đái, vạn đại dung thân' (Một dải Hoành Sơn, có thể dung thân muôn đời) - lời sấm Trạng Trình giúp chúa Nguyễn gây dựng cơ nghiệp đàng Trong.	Hoành Sơn tượng trưng cho sự chia cắt nhưng cũng là nơi nương tựa, che chở (bức tường thành tự nhiên). Nó gợi lên nỗi buồn hoài cổ.	Đèo Ngang ngày nay đã có hầm đường bộ xuyên qua, nhưng nhiều du khách vẫn thích đi đường đèo để ngắm cảnh biển Vũng Chùa - Đảo Yến.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
7cea5f5e-913a-4c35-bb66-95bd464104ff	9ed204bb-61b1-4796-9159-a93d1e5be3e3	Sông Thao - đoạn sông Hồng đỏ nặng phù sa chảy qua đất Tổ.	Thao Hà (Sông Thao) là tên gọi đoạn chính lưu của sông Hồng chảy qua địa phận tỉnh Phú Thọ (đất tổ Hùng Vương) và Yên Bái. Sông Thao nước chảy xiết, màu đỏ ngầu phù sa ('Sông Thao nước đục người đen'). Đây là dòng sông gắn liền với truyền thuyết Âu Cơ - Lạc Long Quân và các vua Hùng dựng nước. Hình ảnh Thao Hà trên đỉnh nhắc nhở về cội nguồn dân tộc và vùng đất trung du Bắc Bộ.	Chiến khu Vần - Hiền Lương bên sông Thao là căn cứ quan trọng trong kháng chiến. Sông Thao cũng đi vào bài hát 'Du kích sông Thao' nổi tiếng.	Sông Thao tượng trưng cho dòng máu Lạc Hồng, cội nguồn sức mạnh và sự trở về nguồn cội.	Gọi là sông Thao nhưng thực chất nó là đoạn thượng nguồn của sông Hồng. Tại Việt Trì, sông Thao hợp lưu với sông Lô và sông Đà tạo thành sông Hồng rộng lớn chảy về xuôi.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
32a75ed6-eb22-46d6-8de9-b72a102791c5	4e87a6eb-b18a-4a41-9ebf-d7e1479f07a9	Cà Cuống - hương vị nồng nàn của ẩm thực Hà thành.	Quế Đỏ (thường được hiểu là con Cà Cuống - Lethocerus indicus/Sâu Quế). Đây là loài côn trùng sống dưới nước, kích thước lớn. Con đực có túi tinh dầu ở ngực cho mùi thơm hăng cay giống mùi quế (nên gọi là Quế), rất đặc biệt. Tinh dầu cà cuống là gia vị 'quý tộc' không thể thiếu trong các món ăn tinh tế như bún thang, bánh cuốn Hà Nội. Hình ảnh Cà Cuống trên đỉnh tôn vinh nét văn hóa ẩm thực độc đáo và sự đa dạng sinh học.	Cà cuống từng là cống phẩm tiến vua ('Sơn hào hải vị'). Ngày nay, do môi trường ô nhiễm, cà cuống ngoài tự nhiên rất hiếm và trở thành đặc sản đắt đỏ.	Cà Cuống tượng trưng cho hương vị truyền thống, sự tinh túy (nhỏ mà có võ - túi hương) và ký ức về môi trường trong sạch.	Chỉ có con cà cuống đực mới có bọng tinh dầu thơm để quyến rũ con cái. Một giọt tinh dầu cà cuống đủ làm dậy mùi cả bát nước chấm.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
97274d85-eb4a-469f-8207-9df5bb8c81dc	904b3781-be62-4b6a-87d8-4a613a1693a2	Cỗ Xe - phương tiện di chuyển và vận tải quan trọng.	Xa (Xe/Cỗ xe) là phương tiện giao thông có bánh, dùng sức người hoặc súc vật (ngựa, trâu, bò) kéo. Trên Cửu Đỉnh, hình ảnh chiếc xe (có thể là xe tứ mã, xe bò hoặc xe đẩy) đại diện cho sự phát triển của giao thông vận tải và hậu cần (quân lương). 'Xa thư đồng văn' (xe cùng trục, sách cùng văn) là biểu tượng của sự thống nhất đất nước về mặt hành chính và văn hóa. Cỗ xe cũng thể hiện sự uy nghi của các chuyến tuần du của vua chúa.	Hệ thống đường Thiên lý (Quốc lộ 1 xưa) được nhà Nguyễn tu bổ để xe ngựa đi lại thông suốt Bắc Nam, phục vụ trạm dịch và vận chuyển hàng hóa.	Xa tượng trưng cho sự chuyển động, sự kết nối, thống nhất và quyền lực (cỗ xe vương giả).	Thời xưa, quy định về màu sắc, kiểu dáng xe cho vua, quan lại và dân thường rất nghiêm ngặt để phân biệt đẳng cấp.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
62a5d550-8c06-4ef2-a59c-a294a3a9f1c3	a532c055-3b0c-449c-a5dd-1af1d5b8a0e7	Mãng Xà - loài rắn khổng lồ, linh vật huyền bí.	Mãng Xà (Rắn lớn/Trăn khổng lồ) là loài bò sát đáng sợ trong tự nhiên và truyền thuyết. Mãng xà thường được miêu tả với kích thước khổng lồ, có thể nuốt chửng thú lớn. Trong văn hóa dân gian (như Thạch Sanh chém Chằn tinh - Mãng xà), nó đại diện cho thế lực hắc ám, thiên tai cần bị chinh phục. Tuy nhiên, hình ảnh Mãng Xà trên đỉnh cũng thể hiện sự kính sợ của con người trước sức mạnh bí ẩn của rừng thiêng nước độc.	Vùng rừng núi Việt Nam xưa kia rất hoang vu, nhiều rắn rết. 'Rừng thiêng nước độc, thú bầy' là nỗi ám ảnh của người đi mở cõi.	Mãng Xà tượng trưng cho hiểm họa thiên nhiên, sự thử thách lòng dũng cảm và sức mạnh hoang dã. Trong y học, nọc rắn và thịt rắn lại là thuốc quý.	Khác với Rồng (Long) là linh vật tưởng tượng, Mãng Xà thường dựa trên hình mẫu có thật là các loài trăn lớn (Trăn gấm, Trăn đất).	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
6e953590-9fce-4380-97d9-1a7a64e471e9	9308802b-a83f-4509-95e3-b4124bb24d3b	Ống Phun Lửa - vũ khí hỏa công lợi hại.	Hỏa Phún Đồng (Ống đồng phun lửa) là một loại vũ khí hỏa công của quân đội nhà Nguyễn. Thiết bị này gồm một ống bằng đồng chứa thuốc súng và chất cháy, khi kích hoạt sẽ phun ra luồng lửa mạnh về phía địch, gây cháy và hoảng loạn. Đây là tiền thân của súng phun lửa hiện đại. Việc chế tạo được Hỏa Phún Đồng chứng tỏ trình độ kỹ thuật quân sự (nhất là về thuốc súng) của cha ông ta rất đáng nể.	Hồ Nguyên Trừng (thời Hồ) đã sáng chế ra Súng thần cơ. Đến thời Nguyễn, công nghệ hỏa khí tiếp tục được kế thừa và phát triển, kết hợp với kỹ thuật phương Tây.	Hỏa Phún Đồng tượng trưng cho sức mạnh hủy diệt của lửa, trí tuệ khoa học quân sự và khả năng áp chế kẻ thù.	Loại vũ khí này rất hiệu quả trong các trận thủy chiến (đốt thuyền địch) hoặc công thành (đốt chòi canh).	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
db9772a9-79f6-4fef-abca-1c501fa87e88	2cbe63e8-fa98-4fda-bf14-665d50f5b826	Con Mang/Hoẵng - loài thú nhút nhát của rừng xanh.	Sơn Mã (Con Mang/Hoẵng - Muntiacus) là loài thú móng guốc nhỏ thuộc họ Hươu, sống phổ biến trong các khu rừng Việt Nam. Sơn Mã có bộ lông vàng sẫm, dáng đi nhanh nhẹn nhưng tính tình rất nhút nhát ('ngơ ngác như con nai vàng'). Tiếng kêu của chúng vang vọng trong rừng như tiếng chó sủa (nên tiếng Anh gọi là Barking Deer). Thịt mang là món ăn ngon, da dùng thuộc. Hình ảnh con mang trên đỉnh làm phong phú thêm bức tranh động vật rừng.	Săn bắt thú rừng (đi săn) là thú vui của vua chúa và quan lại xưa. Rừng cấm (Thượng uyển) thường thả nuôi nhiều hươu nai, mang.	Sơn Mã tượng trưng cho sự hiền lành, cảnh giác và tốc độ lẩn trốn. Trong thơ ca, nó gợi lên vẻ đẹp hoang sơ, tĩnh lặng của rừng chiều.	Con Mang đực có cặp sừng ngắn và răng nanh dài chìa ra ngoài mép, dùng để tự vệ hoặc tranh giành lãnh thổ.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
c9aba57a-24be-4312-a2fd-7753230e7a14	ed00c1fe-9a20-4781-815d-d320c4e353fa	Cây Sơn - nhựa quý làm nên nghệ thuật sơn mài lộng lẫy.	Tất Mộc (Cây Sơn ta - Toxicodendron succedaneum) là loài cây công nghiệp đặc biệt, trồng để lấy nhựa (sơn). Nhựa sơn khi mới chích có màu trắng đục, sau chuyển màu nâu đen, dùng để chế biến thành sơn then, sơn cánh gián... phục vụ nghề sơn mài và sơn son thếp vàng đồ thờ cúng, hoành phi câu đối. Nghề sơn là một nghề độc hại (sơn ăn tùy mặt) nhưng tạo ra những tác phẩm nghệ thuật bền đẹp với thời gian. Khắc Tất Mộc lên đỉnh là tôn vinh nghề thủ công tinh xảo của dân tộc.	Sơn mài Việt Nam nổi tiếng thế giới. Các vật dụng trong cung đình Huế đều được sơn son thếp vàng lộng lẫy nhờ nhựa của loài cây này.	Cây Sơn tượng trưng cho sự bền bỉ, vẻ đẹp sang trọng (sơn son) và sự hy sinh (nhựa cây). Nó cũng nhắc nhở về sự cẩn trọng (sơn ăn da).	Người ta thường phải kiêng kỵ khi đi lấy sơn hoặc tiếp xúc với sơn sống để tránh bị dị ứng nặng. Nhựa sơn ta rất bền, chịu được nước mặn và mối mọt.	\N	\N	\N	t	t	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	everyone	f	\N	\N	1	\N	\N	\N
\.


--
-- Data for Name: lesson_prerequisites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lesson_prerequisites (id, lesson_id, prerequisite_lesson_id, is_strict, created_at) FROM stdin;
\.


--
-- Data for Name: motifs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.motifs (id, urn_id, mesh_name, name, name_en, category, rarity, pos_x, pos_y, pos_z, bounding_radius, cam_pos_x, cam_pos_y, cam_pos_z, cam_look_at_x, cam_look_at_y, cam_look_at_z, thumbnail_url, silhouette_url, is_demo, is_active, display_order, created_at, updated_at, content_rating) FROM stdin;
282f77b0-b908-4785-8592-3c8dcb0b9851	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_01_v1	Nhân Đỉnh	The Urn of Benevolence	kien_truc	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/NH%C3%82N%20%C4%90%E1%BB%88NH.jpg	\N	f	t	1	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
e2bf57a0-8b09-459f-9213-40c95da2c647	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_02_v1	Ngô Đồng	Chinese Parasol Tree	thao_moc	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/NG%C3%94%20%C4%90%E1%BB%92NG.jpg	\N	f	t	2	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
65b59624-9f96-4713-83e5-ebb5505d61ca	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_03_v1	Kỳ Nam	Kyara (Highest Grade Agarwood)	thao_moc	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/K%E1%BB%B2%20NAM.jpg	\N	f	t	3	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
2ffaa5e2-8f5b-49a3-ae8a-4c28cc9ca106	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_04_v1	Noa	Glutinous Rice	nong_nghiep	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/NOA.jpg	\N	f	t	4	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
b5772322-b791-4fa2-88fa-852bfb254bc9	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_05_v1	Nam Trân	Langsat (Bon Bon Fruit)	thao_moc	uncommon	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/NAM%20TR%C3%82N.jpg	\N	f	t	5	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
6984b326-0c85-43a4-9a4d-dabbeb7e13ba	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_06_v1	Liên Hoa	Lotus	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/LI%C3%8AN%20HOA.jpg	\N	f	t	6	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
5068f86d-bfc1-41d6-b8ac-0073ff897b72	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_07_v1	Khổng Tước	Peacock	dong_vat	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/KH%E1%BB%94NG%20T%C6%AF%E1%BB%9AC.jpg	\N	f	t	7	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
0b7a95ae-de5f-4e5b-a6f4-ff673d93ec2d	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_08_v1	Nam Hải	South Sea	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/NAM%20H%E1%BA%A2I.jpg	\N	f	t	8	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
c6a51d0e-69d6-4b9f-8dee-48a51d46e39d	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_09_v1	Phổ Lợi Hà	Pho Loi River	dia_ly	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/PH%E1%BB%94%20L%E1%BB%A2I%20H%C3%80.jpg	\N	f	t	9	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
c2c9f700-fcf1-4dc1-b9c5-58a9ce97f4b3	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_10_v1	Nguyệt	The Moon	thien_van	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/NGUY%E1%BB%86T.jpg	\N	f	t	10	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
c75f919c-904d-483b-83ec-4debdb8e076f	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_11_v1	Hương Giang	Perfume River	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/HU%C6%A0U%20GIANG.jpg	\N	f	t	11	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
d469214a-16e7-4120-ad15-7dece40629da	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_12_v1	Ngự Bình Sơn	Ngu Binh Mountain	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/NG%E1%BB%B0%20B%C3%8CNH%20S%C6%A0N.jpg	\N	f	t	12	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
81f3deaa-51eb-420d-bf4f-4c99584662ef	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_13_v1	Nhân Ngư	Dugong (Sea Cow)	dong_vat	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/NH%C3%82N%20NG%C6%AF.jpg	\N	f	t	13	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
c947cdd0-5095-45af-9abe-43762e47dbde	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_14_v1	Cửu	Chinese Chives	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/C%E1%BB%ACU.jpg	\N	f	t	14	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
1ff69a0a-4718-4f51-97f3-0df32387a8e4	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_15_v1	Lâu Thuyền	Tower Ship	giao_thuong	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/L%C3%82U%20THUY%E1%BB%80N.jpg	\N	f	t	15	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
9f26573f-3fef-4130-884e-b2a10664513c	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_16_v1	Luân Xa Pháo	Cannon on Wheels	vo_bi	uncommon	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/LU%C3%82N%20XA%20PH%C3%81O.jpg	\N	f	t	16	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
9a7cac22-df1b-4150-9db3-a3420b48fd9f	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_17_v1	Báo	Leopard	dong_vat	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/B%C3%81O.jpg	\N	f	t	17	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
80ffc309-19f9-42ee-89fe-256c6b2ca88e	ffa42b96-fdb3-4804-816c-29628d93792f	mesh_urn_nhan_dinh_18_v1	Đại Mạo	Hawksbill Turtle	dong_vat	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NHAN%20DINH/%C4%90%E1%BA%A0I%20MAO.jpg	\N	f	t	18	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
645bd72c-715f-448e-8db2-131340664238	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_01_v1	Chương Đỉnh	The Urn of Radiance	kien_truc	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/CH%C6%AF%C6%A0NG%20%C4%90%E1%BB%88NH.jpg	\N	f	t	1	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
31832650-6463-405a-9ce3-8ac267c1c9da	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_02_v1	Mạt Lị	Jasmine	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/M%E1%BA%A0T%20LI.jpg	\N	f	t	2	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
dac97c73-f54d-4208-b262-b19034d979d3	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_03_v1	Am La	Mango	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/AM%20LA.jpg	\N	f	t	3	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
dc61f122-27eb-4f8c-84df-55c697f1eb12	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_04_v1	Đậu Khấu	Cardamom	thao_moc	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/%C4%90%E1%BA%ACU%20KH%E1%BA%A4U.jpg	\N	f	t	4	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
15bb211a-d1df-47df-8409-ea51d4cbb899	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_05_v1	Lục Đậu	Mung Bean	nong_nghiep	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/L%E1%BB%A4C%20%C4%90%E1%BA%ACU.jpg	\N	f	t	5	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
d4d34f66-7825-4cfc-a5f3-7b6ca7dd5e29	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_06_v1	Giới	Chinese Scallion (Rakkyo)	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/GI%E1%BB%9AI.jpg	\N	f	t	6	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
0c986397-4987-4b29-afea-42355d79d00a	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_07_v1	Kê	Chicken	dong_vat	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/K%C3%8A.jpg	\N	f	t	7	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
d71a8ff0-be8c-4ecb-8e4c-5a6308fa8edb	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_08_v1	Thượng Sơn	Thuong Mountain (Kim Phung)	dia_ly	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/TH%C6%AF%E1%BB%A2NG%20S%C6%A0N.jpg	\N	f	t	8	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
8aa3cbbd-b36e-4ab0-8167-979d2562c5de	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_09_v1	Lợi Nông Hà	Loi Nong River (An Cuu)	dia_ly	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/L%E1%BB%A2I%20N%C3%94NG%20H%C3%80.jpg	\N	f	t	9	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
43e66fe4-29b4-49bd-b492-4f5823a34b77	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_10_v1	Ngũ Tinh	Five Planets	thien_van	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/M%E1%BB%98C%20TINH%20-%20HO%E1%BA%A2%20TINH%20-%20TH%E1%BB%94%20TINH%20-%20KIM%20TINH%20-%20THU%E1%BB%B6%20TINH.jpg	\N	f	t	10	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
e7fd33e8-7cae-4557-ba91-a1a6f4641e69	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_11_v1	Linh Giang	Gianh River	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/LINH%20GIANG.jpg	\N	f	t	11	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
f405213c-8093-4196-8479-95c8851d6f95	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_12_v1	Tây Hải	West Sea	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/T%C3%82Y%20H%E1%BA%A2I.jpg	\N	f	t	12	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
9edc5858-1b2a-404a-bf9a-fe4b70f3eb62	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_13_v1	Thuận Mộc	Rosewood (Sua Tree)	thao_moc	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/THU%E1%BA%ACN%20M%E1%BB%98C.jpg	\N	f	t	13	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
7eb70120-14da-4020-85d5-9aea2501c838	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_14_v1	Ngạc Ngư	Crocodile	dong_vat	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/NG%E1%BA%A0C%20NG%C6%AF.jpg	\N	f	t	14	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
e82b3077-b323-4835-a4d9-da22e28eccd5	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_15_v1	Mông Đồng Thuyền	Mong Dong Warboat	vo_bi	uncommon	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/M%C3%94NG%20%C4%90%E1%BB%92NG%20THUY%E1%BB%80N.jpg	\N	f	t	15	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
7f091ed9-06f5-46a7-a030-6341c0d293f8	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_16_v1	Điểu Thương	Musket (Bird Gun)	vo_bi	uncommon	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/%C4%90I%E1%BB%82U%20TH%C6%AF%C6%A0NG.jpg	\N	f	t	16	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
5f05c475-8e53-4554-a667-c841614d78ef	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_17_v1	Tê	Rhinoceros	dong_vat	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/T%C3%8A.jpg	\N	f	t	17	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
883b8388-7f3d-466e-ba88-9659dfbe3b4b	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	mesh_urn_chuong_dinh_18_v1	Linh Quy	Sacred Turtle	linh_thu	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CHUONG%20DINH/LINH%20QUY.jpg	\N	f	t	18	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
e823f581-e98e-412e-a901-baf5918ed599	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_01_v1	Anh Đỉnh	The Urn of Brilliance	kien_truc	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/ANH%20%C4%90%E1%BB%88NH.jpg	\N	f	t	1	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
f043389a-e5aa-4092-9cba-4ede2943e761	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_02_v1	Thiền	Cicada	dong_vat	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/THI%E1%BB%80N.jpg	\N	f	t	2	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
c7de7984-89a9-456c-ad39-eb28a0625771	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_03_v1	Tô Hợp	Storax Tree	thao_moc	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/T%C3%94%20H%E1%BB%A2P.jpg	\N	f	t	3	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
257959d8-ce69-4701-99a7-252c5e02eacb	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_04_v1	Uất Kim	Turmeric	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/U%E1%BA%A4T%20KIM.jpg	\N	f	t	4	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
4ba1f6ce-ac67-4389-87a3-4d44b09486a9	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_05_v1	Tân Lang	Areca Palm	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/T%C3%82N%20LANG.jpg	\N	f	t	5	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
d81a0c2d-947b-4379-b82e-cc8efddbf185	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_06_v1	Khôi Hạc	Demoiselle Crane	dong_vat	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/KH%C3%94I%20H%E1%BA%A0C.jpg	\N	f	t	6	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
7e398757-b356-4a0b-8457-4c2006160b7a	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_07_v1	Mai Khôi Hoa	Rose	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/MAI%20KH%C3%94I%20HOA.jpg	\N	f	t	7	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
b974a9c9-47ce-405c-b398-ec026ec08b00	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_08_v1	Ngân Hán	The Milky Way	thien_van	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/NG%C3%82N%20H%C3%81N.jpg	\N	f	t	8	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
df8114b8-be0e-4223-a2ce-e4e4b5c06d1c	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_09_v1	Mã Giang	Ma River	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/M%C3%83%20GIANG.jpg	\N	f	t	9	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
0524c8dc-ca80-4fd8-bc24-06898135d9f4	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_10_v1	Bắc Đẩu	The Big Dipper	thien_van	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/B%E1%BA%AEC%20%C4%90%E1%BA%A8U.jpg	\N	f	t	10	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
ddcc58bd-deda-4c22-b7f3-cff9f0bcbae5	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_11_v1	Lô Hà	Lo River	dia_ly	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/L%C3%94%20H%C3%80.jpg	\N	f	t	11	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
129ee8ff-9912-4562-987c-bf1df6079dc0	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_12_v1	Hồng Sơn	Hong Linh Mountain	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/H%E1%BB%92NG%20S%C6%A0N.jpg	\N	f	t	12	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
99a0d77c-c789-4ee4-a7ba-3b714e817315	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_13_v1	Mã	Horse	dong_vat	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/M%C3%83.jpg	\N	f	t	13	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
2d339750-6ffc-4e07-b35b-b8d10cb0fe53	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_14_v1	Tang	Mulberry	nong_nghiep	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/TANG.jpg	\N	f	t	14	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
052469aa-b188-41d7-8e77-4b9ab6465683	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_15_v1	Kỳ	Flag	vo_bi	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/K%E1%BB%B2.jpg	\N	f	t	15	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
25a42e96-5aa0-4f57-9192-a4e3bdc9e137	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_16_v1	Hồ Điệp Tử	Butterfly Shot	vo_bi	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/H%E1%BB%92%20%C4%90I%E1%BB%86P%20T%E1%BB%AC.jpg	\N	f	t	16	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
c981ef78-19cc-49aa-90e3-95e2f9b6b85a	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_17_v1	Nhiêm Xà	Python	dong_vat	uncommon	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/NHI%C3%8AM%20X%C3%80.jpg	\N	f	t	17	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
34768841-3aad-4d97-bf82-16e7e7dda5c0	c669187e-adb8-432a-b79f-c5fc00ebcd20	mesh_urn_anh_dinh_18_v1	Tử Mộc	Lac Tree Host	thao_moc	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/ANH%20DINH/T%E1%BB%AC%20M%E1%BB%98C.jpg	\N	f	t	18	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
33f759ab-d17d-4e24-9f74-369e14336bf3	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_01_v1	Nghị Đỉnh	The Urn of Determination	kien_truc	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/NGHI%20DINH.jpg	\N	f	t	1	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
0e90ba70-f73b-43ce-b3cb-0cf57a2c349b	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_02_v1	Mai	Apricot Blossom	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/MAI.jpg	\N	f	t	2	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
c448233e-7507-4ba5-b707-f445eed4fee2	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_03_v1	Đàn Mộc	Sandalwood	thao_moc	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/%C4%90%C3%80N%20M%E1%BB%98C.jpg	\N	f	t	3	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
e39d9f9b-27d0-458e-a307-f00ff4c64293	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_04_v1	Quế	Cinnamon	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/QU%E1%BA%BE.jpg	\N	f	t	4	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
4736fd9a-1a7c-4561-9fa4-eb99b80613b7	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_05_v1	Biển Đậu	Hyacinth Bean	nong_nghiep	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/BI%E1%BB%82N%20%C4%90%E1%BA%ACU.jpg	\N	f	t	5	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
aa34527e-3a15-41da-8ebe-cfd35ac09a0b	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_06_v1	Hải Đường Hoa	Camellia	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/H%E1%BA%A2I%20%C4%90%C6%AF%E1%BB%9CNG%20HOA.jpg	\N	f	t	6	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
9293bbac-360e-42c6-af8a-0470e8a39204	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_07_v1	Hồ Da Tử	Coconut Worm	dong_vat	uncommon	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/H%E1%BB%92%20DA%20T%E1%BB%AC.jpg	\N	f	t	7	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
5d296943-0b9a-42ea-ba1f-d9901cc391c6	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_08_v1	Quảng Bình Quan	Quang Binh Gate	kien_truc	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/QU%E1%BA%A2NG%20B%C3%8CNH%20QUAN.jpg	\N	f	t	8	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
1765de7a-fb29-4c9a-b769-370883202181	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_09_v1	Cửu An Hà	Cuu An River	dia_ly	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/C%E1%BB%ACU%20AN%20H%C3%80.jpg	\N	f	t	9	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
c3fb5c56-a8b9-43e8-9ddb-22385193cec6	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_10_v1	Nam Đẩu	The Southern Dipper	thien_van	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/NAM%20%C4%90%E1%BA%A8U.jpg	\N	f	t	10	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
cc1a79bb-8da0-4462-8914-43ccb471cc39	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_11_v1	Bạch Đằng Giang	Bach Dang River	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/B%E1%BA%A0CH%20%C4%90%E1%BA%B0NG%20GIANG.jpg	\N	f	t	11	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
eb8f7cdb-fe49-48dc-ad7f-2d8923e100de	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_12_v1	Thuận An Hải Khẩu	Thuan An Estuary	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/THU%E1%BA%ACN%20AN%20H%E1%BA%A2I%20KH%E1%BA%A8U.png	\N	f	t	12	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
617cbc43-a7ec-4826-b089-57b886a14996	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_13_v1	Lục Hoa Ngư	Snakehead Fish	dong_vat	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/L%E1%BB%A4C%20HOA%20NG%C6%AF.jpg	\N	f	t	13	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
8096eca9-bea4-42ab-a96f-36f7e373c017	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_14_v1	Giới	Mustard Greens	nong_nghiep	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/GI%E1%BB%9AI.jpg	\N	f	t	14	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
4cbb533d-b417-477c-a075-d4c1bce38ad2	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_15_v1	Trường Thương	Long Spear	vo_bi	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/TR%C6%AF%E1%BB%9CNG%20TH%C6%AF%C6%A0NG.jpg	\N	f	t	15	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
cb8421e4-3199-40e6-b7b3-9dfe5f571092	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_16_v1	Hải Đạo	Naval Vessel	vo_bi	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/H%E1%BA%A2I%20%C4%90AO.jpg	\N	f	t	16	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
54c162b8-7bb5-4761-b763-bb60c4293d0d	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_17_v1	Uyên Ương	Mandarin Duck	dong_vat	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/UY%C3%8AN%20%C6%AF%C6%A0NG.jpg	\N	f	t	17	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
ce7718a7-ddae-4917-aca4-fad6e8a3de9a	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	mesh_urn_nghi_dinh_18_v1	Tượng	Elephant	dong_vat	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/NGHI%20DINH/T%C6%AF%E1%BB%A2NG.jpg	\N	f	t	18	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
61826813-bed7-49ff-b54a-7a1ef85a812f	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_01_v1	Thuần Đỉnh	The Urn of Purity	kien_truc	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/THU%E1%BA%A6N%20%C4%90%E1%BB%88NH.jpg	\N	f	t	1	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
61a7b0da-2123-4bda-be59-b004e2d9a452	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_02_v1	Đào	Peach Blossom	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/%C4%90%C3%80O.jpg	\N	f	t	2	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
42d0ddb9-5f03-4970-8627-22b229615b01	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_03_v1	Súc Sa Mật	Cardamom	thao_moc	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/S%C3%9AC%20SA%20M%E1%BA%ACT.jpg	\N	f	t	3	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
ef926c95-6c55-4374-8788-4552e2ad8152	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_04_v1	Hướng Nhu	Vietnamese Balm	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/H%C6%AF%C6%A0NG%20NHU.jpg	\N	f	t	4	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
3ce87650-7d3c-4135-81ec-f083f855ed56	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_05_v1	Hoàng Đậu	Soybean	nong_nghiep	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/HO%C3%80NG%20%C4%90%C3%82U.jpg	\N	f	t	5	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
01e7d41a-a4f3-49d3-972a-0fbd6a9c8117	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_06_v1	Quỳ Hoa	Sunflower	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/QU%E1%BB%B2%20HOA.jpg	\N	f	t	6	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
5bc76464-b9ab-4428-9462-7cd317515cde	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_07_v1	Hoàng Anh	Oriole	dong_vat	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/HO%C3%80NG%20ANH.jpg	\N	f	t	7	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
1b519b34-f4a1-4014-9db8-ed29dcb8b3d1	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_08_v1	Tản Viên Sơn	Tan Vien Mountain	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/T%E1%BA%A2N%20VI%C3%8AN%20S%C6%A0N.jpg	\N	f	t	8	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
c5a0a5ec-5ebe-4d7f-be43-dd88f0e184e1	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_09_v1	Vĩnh Định Hà	Vinh Dinh River	dia_ly	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/V%C4%A8NH%20%C4%90%E1%BB%8ANH%20H%C3%80.jpg	\N	f	t	9	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
29366526-461d-4127-ae32-8a7fa46fe020	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_10_v1	Phong	Wind	thien_van	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/PHONG.jpg	\N	f	t	10	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
5ff35034-ef86-4daf-b01c-38fd5398d5b4	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_11_v1	Thạch Hãn Giang	Thach Han River	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/TH%E1%BA%A0CH%20H%C3%83N%20GIANG.jpg	\N	f	t	11	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
5d18cf10-4dc4-4bbe-9ee3-b0b70362a69f	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_12_v1	Cần Giờ Hải Khẩu	Can Gio Estuary	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/C%E1%BA%A6N%20GI%E1%BB%9C%20H%E1%BA%A2I%20KH%E1%BA%A8U.jpg	\N	f	t	12	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
bb1779dc-38f6-4ad5-8b92-431869075aa1	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_13_v1	Đăng Sơn Ngư	Climbing Fish	dong_vat	uncommon	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/%C4%90%E1%BA%B6NG%20S%C6%A0N%20NG%C6%AF.jpg	\N	f	t	13	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
7929755c-2737-4f1d-be93-c9c9bb17e726	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_14_v1	Bạng	Clam	dong_vat	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/B%E1%BA%A0NG.jpg	\N	f	t	14	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
a7c53882-c22b-4e79-bf13-2d0c66888558	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_15_v1	Bài Đao	Sword Rack	vo_bi	uncommon	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/B%C3%80I%20%C4%90AO.jpg	\N	f	t	15	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
192e0b2e-dfc3-423f-805f-b717ec39de16	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_16_v1	Đỉnh	Racing Boat	vo_bi	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/%C4%90%E1%BB%88NH.jpg	\N	f	t	16	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
f9ff3e74-297f-4ae3-a586-d0c2b84209b7	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_17_v1	Nam Mộc	Machilus Tree	thao_moc	uncommon	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/NAM%20M%E1%BB%98C.jpg	\N	f	t	17	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
27f1d92f-b653-4088-a19d-2867460cfc0d	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	mesh_urn_thuan_dinh_18_v1	Ly Ngưu	Gaur	dong_vat	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/THUAN%20DINH/LY%20NG%C6%AFU.jpg	\N	f	t	18	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
7e10639b-e0d4-4f5e-9263-24b005596d85	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_01_v1	Tuyên Đỉnh	The Urn of Proclamation	kien_truc	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/TUYEN%20DINH.jpg	\N	f	t	1	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
7a4c0e26-fe4e-4885-ad47-3765a24856a8	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_02_v1	Tần Cát Liễu	Myna Bird	dong_vat	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/T%E1%BA%A6N%20C%C3%81T%20LI%E1%BB%84U.jpg	\N	f	t	2	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
bef239ca-da7e-4bf0-8353-10a092dd6091	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_03_v1	Yến Oa	Edible Bird's Nest	dong_vat	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/Y%E1%BA%BEN%20OA.jpg	\N	f	t	3	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
371a21e2-afc3-4b7f-b365-439a19111af4	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_04_v1	Long Nhãn	Longan	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/LONG%20NH%C3%83N.jpg	\N	f	t	4	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
a7cd9650-61f4-4e9f-8d8b-48beb32b3bcb	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_05_v1	Trân Châu Hoa	Chloranthus	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/TR%C3%82N%20CH%C3%82U%20HOA.jpg	\N	f	t	5	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
10e81a65-2e1b-4d1f-8d8a-0b6a0811a71d	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_06_v1	Địa Đậu	Peanut	nong_nghiep	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/%C4%90%E1%BB%8AA%20%C4%90%E1%BA%ACU.jpg	\N	f	t	6	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
616daaaa-e9f8-4e7b-a967-ec7b46df5dc1	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_07_v1	Bá	Cypress	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/B%C3%81.jpg	\N	f	t	7	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
a46c369b-7b5b-4478-ad85-492725e5fccb	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_08_v1	Duệ Sơn	Due Mountain	dia_ly	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/DU%E1%BB%86%20S%C6%A0N.png	\N	f	t	8	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
62b76d4a-9f9c-48c5-8a48-bd0e0be00d61	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_09_v1	Nhĩ Hà	Red River	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/NH%C4%A8%20H%C3%80.jpg	\N	f	t	9	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
84039e96-9ff0-4303-a8e0-472f04ffe222	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_10_v1	Vân	Cloud	thien_van	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/V%C3%82N.jpg	\N	f	t	10	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
1a597969-b683-4ccb-beb5-8397de37a0cf	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_11_v1	Đại Lãnh	Dai Lanh Cape	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/%C4%90%E1%BA%A0I%20L%C3%83NH.jpg	\N	f	t	11	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
0ae0148e-d9ac-4549-bdfd-8884967c621e	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_12_v1	Lam Giang	Lam River	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/LAM%20GIANG.jpg	\N	f	t	12	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
8e2b8abb-d36a-4176-b130-cb1c9631078a	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_13_v1	Hậu Ngư	Horseshoe Crab	dong_vat	uncommon	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/H%E1%BA%ACU%20NG%C6%AF.jpg	\N	f	t	13	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
fd43425d-1e0b-44bf-9be9-bf6fbfe94168	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_14_v1	Khương	Ginger	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/KH%C6%AF%C6%A0NG.jpg	\N	f	t	14	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
4bbd7497-e84d-46c8-871f-62a42a7c9465	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_15_v1	Nỗ	Crossbow	vo_bi	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/N%E1%BB%96.jpg	\N	f	t	15	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
db5621b4-394c-4edc-924c-e3110b1c9941	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_16_v1	Lê Thuyền	Le Boat	vo_bi	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/L%C3%8A%20THUY%E1%BB%80N.jpg	\N	f	t	16	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
1f9addcc-52d4-416f-80b0-a10cc3de6da2	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_17_v1	Thỉ	Pig	dong_vat	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/TH%E1%BB%88.jpg	\N	f	t	17	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
d14077fe-7eee-4829-8a7b-ecfd8f3936ef	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	mesh_urn_tuyen_dinh_18_v1	Ngoan	Sea Turtle	dong_vat	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/TUYEN%20DINH/NGOAN.jpg	\N	f	t	18	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
96577e61-6e05-4640-92b0-3c1e025f9fb9	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_01_v1	Dụ Đỉnh	The Urn of Abundance	kien_truc	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/D%E1%BB%A4%20%C4%90%E1%BB%88NH.jpg	\N	f	t	1	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
51180b9a-6c5a-48fd-9784-229c979352b2	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_02_v1	Anh Vũ	Parrot	dong_vat	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/ANH%20V%C5%A8.jpg	\N	f	t	2	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
31eab81a-d2b3-491d-9157-42e3ee5c3ef9	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_03_v1	Lê	Pear	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/L%C3%8A.jpg	\N	f	t	3	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
e3690c96-2f06-426b-8409-b2edc01f5349	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_04_v1	Phù Lưu	Betel Pepper	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/PH%C3%99%20L%C6%AFU.jpg	\N	f	t	4	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
4f795d28-a54d-4e16-8e5e-deceae503114	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_05_v1	Bạch Đầu	White Bean	nong_nghiep	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/B%E1%BA%A0CH%20%C4%90%E1%BA%A6U.jpg	\N	f	t	5	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
c2ed38c9-e06d-479c-98ec-e3058575a6b7	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_06_v1	Thuần Hoa	Hibiscus	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/THU%E1%BA%A6N%20HOA.jpg	\N	f	t	6	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
2dcbf913-dcf1-4f01-b722-4a7f3719959c	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_07_v1	Tùng	Pine Tree	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/T%C3%99NG.jpg	\N	f	t	7	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
c3fc424f-3325-4801-9608-03cd6de1a20d	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_08_v1	Hải Vân Quan	Hai Van Pass Gate	kien_truc	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/H%E1%BA%A2I%20V%C3%82N%20QUAN.jpg	\N	f	t	8	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
f24dff99-3868-48eb-8df3-06e9b9585590	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_09_v1	Vĩnh Điện Hà	Vinh Dien River	dia_ly	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/V%C4%A8NH%20%C4%90I%E1%BB%86N%20H%C3%80.jpg	\N	f	t	9	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
0c5ee60c-60d8-452d-9944-c1d87c17cc48	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_10_v1	Lôi	Thunder	thien_van	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/L%C3%94I.jpg	\N	f	t	10	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
b1df8b65-1219-483d-9e41-6e8943b76a03	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_11_v1	Vệ Giang	Ve River	dia_ly	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/V%E1%BB%86%20GIANG.jpg	\N	f	t	11	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
a473c901-10b7-4d38-82fa-cbbacd08a06f	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_12_v1	Đà Nẵng Hải Khẩu	Da Nang Estuary	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/%C4%90%C3%80%20N%E1%BA%B4NG%20H%E1%BA%A2I%20KH%E1%BA%A8U.jpg	\N	f	t	12	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
06288f6c-521d-4ae8-943c-3c11336a2159	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_13_v1	Thạch Thủ Ngư	Grouper	dong_vat	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/TH%E1%BA%A0CH%20TH%E1%BB%A6%20NG%C6%AF.jpg	\N	f	t	13	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
ca189580-e780-4a1b-b058-72fed51694f4	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_14_v1	Tử Tô	Perilla	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/T%E1%BB%AC%20T%C3%94.jpg	\N	f	t	14	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
07b1be33-af84-4928-82c4-405f27fb3875	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_15_v1	Ô Thuyền	Raven Boat	vo_bi	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/%C3%94%20THUY%E1%BB%80N.jpg	\N	f	t	15	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
bc0cc630-57db-4918-a144-5ab55b9b2ab2	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_16_v1	Phác Đao	Podao	vo_bi	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/PH%C3%81C%20%C4%90AO.jpg	\N	f	t	16	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
de7364d9-540b-4930-847e-660e19b01b42	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_17_v1	Cáp	Clam	dong_vat	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/C%C3%81P.jpg	\N	f	t	17	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
2c276f27-89b1-415f-a842-2441a0a04586	c2c33771-6473-4745-ba26-dd1d32cce0c6	mesh_urn_du_dinh_18_v1	Dương	Goat	dong_vat	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/DU%20DINH/D%C6%AF%C6%A0NG.jpg	\N	f	t	18	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
b57e45b6-98c6-4315-86f6-7bc6be066a30	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_01_v1	Huyền Đỉnh	The Urn of Mystery	kien_truc	legendary	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/HUYEN%20DINH.jpg	\N	f	t	1	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
89b9b2fe-c54a-4a46-b6d5-748d03e7c854	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_02_v1	Ngũ Điệp Lan	White Champaca	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/NG%E1%BB%AE%20%C4%90I%E1%BB%86P%20LAN.jpg	\N	f	t	2	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
322f9cff-9b9f-4929-8aac-131652a7dca0	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_03_v1	Lệ Chi	Lychee	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/L%E1%BB%86%20CHI.jpg	\N	f	t	3	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
88c71d23-5d73-40dd-93e7-8a01b28d2b16	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_04_v1	Toán	Garlic	thao_moc	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/TO%C3%81N.jpg	\N	f	t	4	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
9a6da058-cd77-4cf3-8442-394cd39f958a	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_05_v1	Nam Sâm	Southern Ginseng	thao_moc	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/NAM%20S%C3%82M.jpg	\N	f	t	5	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
40e651b8-3308-462b-bbd0-c64f64023591	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_06_v1	Miên	Cotton	nong_nghiep	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/MI%C3%8AN.jpg	\N	f	t	6	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
063b1479-5e88-47c5-9a39-1161e3ee04e9	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_07_v1	Thốc Thu	Lesser Adjutant	dong_vat	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/TH%E1%BB%90C%20THU.jpg	\N	f	t	7	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
703b31cf-271c-44a8-9225-a97b11c598d4	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_08_v1	Hồng	Rainbow	thien_van	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/H%E1%BB%92NG.jpg	\N	f	t	8	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
a418ffb9-bc04-46b0-a6e3-d70ab13e4f39	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_09_v1	Hậu Giang, Tiền Giang	Mekong Delta Rivers	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/H%E1%BA%ACU%20GIANG%20-%20TI%E1%BB%80N%20GIANG.jpg	\N	f	t	9	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
da2973be-78ac-4988-9e37-723d1c862eae	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_10_v1	Vũ	Rain	thien_van	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/V%C5%A8.jpg	\N	f	t	10	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
6640dd03-34a0-4968-afc4-c5c87006b5b1	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_11_v1	Hoàng Sơn	Hoang Son Mountain	dia_ly	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/HO%C3%80NG%20S%C6%A0N.jpg	\N	f	t	11	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
9ed204bb-61b1-4796-9159-a93d1e5be3e3	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_12_v1	Thao Hà	Thao River	dia_ly	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/THAO%20H%C3%80.jpg	\N	f	t	12	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
4e87a6eb-b18a-4a41-9ebf-d7e1479f07a9	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_13_v1	Quế Đỏ	Giant Water Bug	dong_vat	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/QU%E1%BA%BE%20%C4%90%E1%BB%8E.jpg	\N	f	t	13	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
904b3781-be62-4b6a-87d8-4a613a1693a2	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_14_v1	Xa	Carriage	vo_bi	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/XA.jpg	\N	f	t	14	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
a532c055-3b0c-449c-a5dd-1af1d5b8a0e7	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_15_v1	Mãng Xà	Giant Snake	dong_vat	epic	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/M%C3%83NG%20X%C3%80.jpg	\N	f	t	15	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
9308802b-a83f-4509-95e3-b4124bb24d3b	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_16_v1	Hỏa Phún Đồng	Flamethrower	vo_bi	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/HO%E1%BA%A2%20PH%C3%9AN%20%C4%90%E1%BB%92NG.jpg	\N	f	t	16	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
2cbe63e8-fa98-4fda-bf14-665d50f5b826	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_17_v1	Sơn Mã	Muntjac	dong_vat	common	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/S%C6%A0N%20M%C3%83.jpg	\N	f	t	17	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
ed00c1fe-9a20-4781-815d-d320c4e353fa	90805a09-3a38-49e4-8827-e57da439d1a6	mesh_urn_huyen_dinh_18_v1	Tất Mộc	Lacquer Tree	thao_moc	rare	0	0	0	1	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/HUYEN%20DINH/T%E1%BA%A4T%20M%E1%BB%98C.jpg	\N	f	t	18	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
036b8060-4597-4028-bded-135081787c70	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_03_v1	Ba La Mật	Jackfruit (Paramita)	thao_moc	uncommon	-1.0882239918518042	0.7935606108352063	-0.08588156866485357	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/BA%20LA%20M%E1%BA%ACT.jpg	\N	t	t	3	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
067a0a69-1a95-4489-9a38-b4565b61c9e1	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_17_v1	Trầm Hương	Agarwood	thao_moc	rare	1.075950567056262	0.23162659065368874	-0.007364296367156228	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/TR%E1%BA%A6M%20H%C6%AF%C6%A0NG.jpg	\N	t	t	17	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
09275995-9116-49af-8ddb-bea8c2255ca9	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_09_v1	Vĩnh Tế Hà	Vinh Te Canal	dia_ly	epic	-0.9805553606202025	0.4398174116535003	-0.6356118506456917	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/V%C4%A8NH%20T%E1%BA%BE%20H%C3%80.jpg	\N	t	t	9	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
284e4bb9-a798-45a1-9926-4e9cc8debdcc	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_07_v1	Trĩ	Pheasant	dong_vat	rare	0.5879267650672756	0.8677716380554719	0.8783399018703302	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/TR%C4%A8.jpg	\N	t	t	7	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
31f8cc7a-149b-40b2-9f60-3c073513673a	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_05_v1	Thông	Scallion	thao_moc	common	0.5823912052707503	0.7174642311212104	-1.0446982913316094	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/TH%C3%94NG.jpg	\N	t	t	5	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
63f7f1f5-83b9-4e43-8e94-7debbb3ed2ab	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_18_v1	Miết	Soft-shelled Turtle	dong_vat	common	0.5444515293235955	0.30285911910571867	0.8953134672114189	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/MI%E1%BA%BET.jpg	\N	t	t	18	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
798e6ca7-ca19-4851-b320-889549db1096	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_10_v1	Nhật	The Sun	thien_van	legendary	0.05673156856783691	0.368221556501426	-1.2226943996738895	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/NH%E1%BA%ACT.jpg	\N	t	t	10	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
90c77d97-240a-4854-b5f3-f875362f5c8e	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_16_v1	Đại Bác	Cannon	vo_bi	epic	0.5684226586653739	0.12291245618942563	-0.9488855007047088	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/%C4%90%E1%BA%A0I%20B%C3%81C.jpg	\N	t	t	16	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
9401eb10-9469-4b4a-963a-68041441569b	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_11_v1	Ngưu Chữ Giang	Ben Nghe River	dia_ly	rare	1.0297107974466961	0.4387734145269959	-0.650742996375418	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/NG%C6%AFU%20CH%E1%BB%AE%20GIANG.jpg	\N	t	t	11	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
9e95bea4-a087-4dc5-ade2-c4e453878f41	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_02_v1	Long	Dragon	linh_thu	legendary	-0.5000829551205324	0.9046839075890194	0.8732417042823537	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/LONG.jpg	\N	t	t	2	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
a42b833e-c260-4293-9fca-b5c8995c5651	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_13_v1	Thiết Mộc	Ironwood	thao_moc	rare	-0.5055434592629419	0.29227224002802127	0.8724834702677216	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/THI%E1%BA%BET%20M%E1%BB%98C.jpg	\N	t	t	13	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
a9d3e605-ac3e-44ef-bf07-8712b6b4eefd	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_04_v1	Canh	Rice	nong_nghiep	common	-0.5278875796026324	0.7038275138465205	-1.0491007507847194	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/CANH.jpg	\N	t	t	4	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
bf4a67a3-162d-4d04-98b0-adff8a1860f1	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_01_v1	Cao Đỉnh	The Urn of Height	kien_truc	legendary	0.00496560768293052	0.6417533398688602	1.0898653990289742	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/CAO%20DINH.jpg	\N	t	t	1	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
d27e9e0b-a9eb-42a2-8466-83442f48939d	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_06_v1	Tử Vi Hoa	Crape Myrtle	thao_moc	uncommon	1.153897400834117	0.7760149046306966	-0.06297482425088925	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/T%E1%BB%AC%20VI%20HOA.jpg	\N	t	t	6	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
d9963208-838a-45ee-a45c-3f22f1c5a157	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_15_v1	Đa Tác Thuyền	Merchant Ship	giao_thuong	uncommon	-0.48320695734084845	0.11221217647592253	-0.9621006785058689	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/%C4%90A%20T%C3%81C%20THUY%E1%BB%80N.jpg	\N	t	t	15	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
dcf170b7-345a-4da8-a7fd-b9327517bdc3	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_14_v1	Hổ	Tiger	dong_vat	epic	-1.022942232362345	0.19697962338559274	-0.057401334719647965	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/H%E1%BB%94.jpg	\N	t	t	14	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
ee64b246-96ba-4a9f-87a5-524fb427d54f	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_08_v1	Đông Hải	East Sea	dia_ly	epic	-0.9805469724591374	0.5331056757827836	0.5275305841945664	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/%C4%90%C3%94NG%20H%E1%BA%A2I.jpg	\N	t	t	8	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
f3a49a22-ec62-492e-a662-29419f1c2fca	5dee75b5-558b-44ce-81da-6a44673927db	mesh_urn_cao_dinh_12_v1	Thiên Tôn Sơn	Thien Ton Mountain	dia_ly	rare	1.0345306298375119	0.5561559082682939	0.5340906220965631	0.08	\N	\N	\N	\N	\N	\N	/assets/ban-duc-noi/CAO%20DINH/THI%C3%8AN%20T%C3%94N%20S%C6%A0N.jpg	\N	t	t	12	2026-01-08 14:55:01.200388+00	2026-01-09 05:27:39.208488+00	everyone
\.


--
-- Data for Name: push_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.push_notifications (id, user_id, title, body, notification_type, data_payload, status, scheduled_for, sent_at, delivered_at, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: quest_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quest_assignments (id, class_id, quest_id, assigned_by_id, due_at, assigned_at, points_override, notes) FROM stdin;
\.


--
-- Data for Name: quest_objectives; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quest_objectives (id, quest_step_id, objective_type, target_value, params, display_order) FROM stdin;
73f2bfbe-86da-4fdc-9e13-d72d0773de55	6b1c854e-7500-47dc-b304-82ac179b0917	discover_category	3	{"category": "linh_thu"}	1
3effd079-c923-4b8d-8818-b46822bf283b	6b1c854e-7500-47dc-b304-82ac179b0917	discover_category	3	{"category": "dong_vat"}	2
d0bb54a9-7f4d-4149-b584-adccfdcdd49b	98c1e3ec-e286-45a2-913a-d242b25a4f55	quiz_pass_count	2	{"category": "dong_vat"}	1
36d9945c-f73d-4dfa-b24d-2044d4749262	5fb51cb5-9c3f-4ac2-b8c1-24214155a525	discover_any	3	{}	1
d30b621b-da99-4775-ab14-f34521d56a18	16511a15-32b8-4855-a12e-52043552db27	complete_lesson	1	{}	1
22ad764e-0369-4455-8a17-aac4121e5067	4ce12fdf-90c2-43b3-8d9e-4bb44e159d46	discover_category	5	{"category": "nong_nghiep"}	1
295220a1-f931-4e32-8b15-43d0856ff414	052706a1-c15d-44ca-a0e6-db558721a774	discover_category	10	{"category": "thao_moc"}	1
93c6094b-5160-4786-9d60-684a85a569f0	488af87c-995b-4660-96e5-8c8cfb985401	quiz_pass_count	3	{"category": "nong_nghiep"}	1
f7eb4a9c-389c-42f4-b9e4-f145d76edef6	86d55848-f753-4216-aab6-3471cf6eee77	discover_category	2	{"category": "linh_thu"}	1
fafc2f77-7f45-4656-a5a2-ba8a8cbc55d9	fbd06db7-0309-43b6-b6ff-d7f0bb3806fd	complete_lesson_category	2	{"category": "linh_thu"}	1
08e1c45f-ba99-46f5-9847-8449243a2c90	0e1b75b0-7cf2-4649-b042-9144c70a0a6b	discover_category	15	{"category": "dong_vat"}	1
84be7656-debb-4541-9535-bffd6d20ab3f	959680f2-e4fc-4f46-aa8c-d7f0d65b84fb	complete_lesson_category	5	{"category": "dong_vat"}	1
7a7794bc-5811-4f11-8361-871b69c21e32	936777c5-5410-4475-9baf-67776f5608dd	quiz_pass_count	5	{"category": "dong_vat"}	1
0bc2accc-f512-4eb6-9a57-117fbb36b395	e51feb72-bc2e-4748-b20a-6f899f7458ab	discover_category	15	{"category": "dia_ly"}	1
d07da3ef-9a98-413d-bb81-9ab2d48f9c4c	665eb728-47ba-47ec-aa7a-d8cecb5e6417	complete_lesson_category	5	{"category": "dia_ly"}	1
4acff1ec-fb88-488e-9deb-9d4c1197abe2	33177626-589b-479b-89b6-8cf48fe3c0c7	quiz_pass_count	3	{"category": "dia_ly"}	1
0226972b-067e-412a-93b5-b7f4b939b067	ba6f35bd-c630-4b87-a5f6-3061956c3d40	discover_category	20	{"category": "thao_moc"}	1
100753b2-03bf-49c7-bc80-fa4ba22612bd	3e443b69-58d4-4085-b9ed-8553b46c737c	complete_lesson_category	10	{"category": "thao_moc"}	1
e8f5394d-4cad-42e2-a58c-78fa0b826775	62adc5af-ce42-4256-9453-695bbb739614	master_category	5	{"category": "thao_moc"}	1
71a25e13-736a-4855-ba4f-fdfbabdd9522	c2286d80-4c3b-4130-9e0f-9598a6184dda	discover_category	10	{"category": "vo_bi"}	1
f0271b28-e61d-4f39-95b2-ff65db4fecc0	264a3b47-c14a-427f-8487-64077cd7272c	complete_lesson_category	5	{"category": "vo_bi"}	1
f931f97c-a32d-4501-b877-c146966400e5	efc201a5-6c30-4baa-aea2-ddd99fb759d6	quiz_pass_count	3	{"category": "vo_bi"}	1
f57479b4-df80-4bf0-ad60-ebdf92ebc788	5a01f2d8-5c13-4300-b9f2-5912e89aae05	discover_category	8	{"category": "thien_van"}	1
65f1f83f-7602-4ba6-ae05-553abbeabcea	3c6bd65b-42c5-4d22-aaa6-5b43dd1193ce	complete_lesson_category	4	{"category": "thien_van"}	1
986a61b2-6dbf-4d3c-bc9a-5893fc3e28d7	69d96e30-ba1b-4e0e-aed8-7742a5b1cf04	discover_category	8	{"category": "kien_truc"}	1
bf515901-0c4a-4174-9a66-e60fd63ae8aa	4b5b8a5a-3f89-4bb5-8295-ccc5a0e765fb	complete_lesson_category	4	{"category": "kien_truc"}	1
65304744-1c2d-4f78-b9ba-97dee727c099	de069764-d8b2-4488-ad27-d99b1b1874c6	discover_category	2	{"category": "giao_thuong"}	1
96ffc3e1-fb01-44a3-a40d-f1c90e8c31b1	e76c25eb-b04e-49fa-9606-375159c3a585	complete_lesson_category	2	{"category": "giao_thuong"}	1
8ba5a3ae-1b2b-4cba-96f5-876209db84a1	c9010c56-4ecc-481c-a1c1-d517e52e3497	discover_urn	100	{"percent": true, "urn_slug": "cao-dinh"}	1
d70b8f2d-3c54-4198-be06-b22c8c1af1f0	98edc9f5-f4e5-4e24-9f64-5c1c9f876f6d	complete_lesson_urn	5	{"urn_slug": "cao-dinh"}	1
f213da99-845a-4b96-b0a9-1b2f43e7848c	a8995ae5-ec29-4b0c-8655-77d08ccdb663	discover_urn	100	{"percent": true, "urn_slug": "nhan-dinh"}	1
1718f35e-84bf-4830-88c2-0ce43e7dc56b	89b5e4f9-ff22-458d-8075-5d4009f77296	complete_lesson_urn	5	{"urn_slug": "nhan-dinh"}	1
f856ce55-8ee1-4d49-bdcf-788aa9f01692	1dba8a74-2904-4a86-b670-c2de376bf515	discover_urn	100	{"percent": true, "urn_slug": "chuong-dinh"}	1
e4f4e6a1-8aaf-4da7-8820-78abae13b280	caafcf74-438b-4f37-980f-edcd641f19be	complete_lesson_urn	5	{"urn_slug": "chuong-dinh"}	1
6452dd3c-29d7-486f-818a-fb1e3fa26af6	95d77982-d9b1-4421-9825-dcd93060cb5c	discover_urn	100	{"percent": true, "urn_slug": "anh-dinh"}	1
1b3737ef-93d7-458e-a1fd-610e5fd0d47f	62119030-3c86-4fb6-a3a9-22fe3c4bc5ad	complete_lesson_urn	5	{"urn_slug": "anh-dinh"}	1
8c725f98-7960-4273-a366-fa5c2885abcf	ac11f34c-4568-40d7-9d8a-d82f284f8cad	discover_urn	100	{"percent": true, "urn_slug": "nghi-dinh"}	1
968c1f5a-73f1-4e0e-be7b-02d210941d30	89b8cd5b-ce82-4c4e-bfcc-995861b03a70	complete_lesson_urn	5	{"urn_slug": "nghi-dinh"}	1
9d5bff8c-ebfc-4ddc-8c62-912030ee0449	93b7939f-9adc-414f-a0ba-cac7695a2a4f	discover_urn	100	{"percent": true, "urn_slug": "thuan-dinh"}	1
e20def94-c405-4e48-ab79-dd58fc4b21ac	91c73865-a9dd-40b3-bdf7-7cf26aca6510	complete_lesson_urn	5	{"urn_slug": "thuan-dinh"}	1
4ce5a933-809b-4665-b603-96ca134f72d4	a1b64280-37c4-4b62-8d1e-9d921c590651	discover_urn	100	{"percent": true, "urn_slug": "tuyen-dinh"}	1
0a3ec4eb-3be7-41cf-bea7-de3139a704f2	102a51ed-fec4-4511-8170-f14d4064e6ff	complete_lesson_urn	5	{"urn_slug": "tuyen-dinh"}	1
c00156a1-2b70-49c0-a8fd-76cfdc37081a	95743380-dd0a-425d-a8ab-61a2ebc8f1fa	discover_urn	100	{"percent": true, "urn_slug": "du-dinh"}	1
7cd172bf-68f8-4d6d-ae73-174233249d7c	dbab8d2c-42aa-46ef-a089-8d24a5f8a519	complete_lesson_urn	5	{"urn_slug": "du-dinh"}	1
c3a010e2-6bc5-45f2-b115-a19311ffbdae	e0bf6226-e40d-409b-9421-771c1382efe4	discover_urn	100	{"percent": true, "urn_slug": "huyen-dinh"}	1
190369a2-9b1c-42a8-a7d0-6128d74ef72d	02e2af2f-66f1-4bd5-90fb-11911c348d96	complete_lesson_urn	5	{"urn_slug": "huyen-dinh"}	1
1c6f2df8-6522-4202-9bdb-ccdc4c1202d5	314ca61b-8f58-4c9e-90ae-4a81eb82274a	complete_lesson	50	{}	1
2b3a205b-b799-4579-9da9-c33e0c4ecb6b	b7ab761e-9e5d-4120-ad9d-cbf7183e202a	urn_exam_pass	1	{}	1
0f208b59-d7d4-491b-9e80-aba7dee8b098	322020c1-384f-4259-a1ca-bd1c9af7d428	discover_all_urns	9	{}	1
3d6b93ef-9675-41ea-915a-e7f62d72a187	900a9962-4df5-4bcf-84ee-11b8e7547bcc	complete_lesson	100	{}	1
7bde6d05-096f-4ca4-ba40-c637c71b8365	02d8db49-a41d-4d77-bbe9-725baa15092d	master_any	50	{}	1
af8f9f95-abc5-4a45-bb98-bb4787a367f4	292cc567-c00d-4197-8b1f-b731fdc16a31	quiz_perfect_score	20	{}	1
3812e4bc-6e1f-4b4c-879e-b778816ff425	9435a7eb-d1a9-4ee7-884a-921abbb59416	streak_days	30	{}	1
4bde0da2-42de-42d2-9862-3c93ba878419	1ce76506-54cf-4393-8f6a-b4ccfd27dd96	quiz_speed	5	{"max_seconds": 30}	1
e9602581-96f5-4143-9a72-b771d9eb8ae0	ded6bc13-1bdf-4e53-82b1-ac5de901687b	visit_all_urns	9	{}	1
25b8fe50-1336-488c-8953-4ecbd32f6e5c	a6f856ac-3587-4b2a-9e56-32f714d258b4	discover_all_categories	9	{}	1
cd9ec5e9-e17b-47c5-bee1-ff9b74f1c350	2135a718-4397-4ced-b365-c42bc1630ebd	streak_days	7	{}	1
4ac33a5d-a994-4f38-8f5d-000b7c34a861	dd200570-3bcb-4b1c-8bd2-468bd6c71866	daily_lesson	7	{}	1
\.


--
-- Data for Name: quest_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quest_progress (id, user_id, quest_id, status, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: quest_rewards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quest_rewards (id, quest_id, reward_type, amount, badge_slug, metadata) FROM stdin;
6d0b4835-2b92-4e5d-a7ab-aae96b4b3b7a	7bbe7d40-6b28-457d-b4de-2774f5f1a08e	xp	250	\N	null
4aadf390-3fe1-4ff3-b252-03854bf1b383	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	xp	100	\N	null
fac5dbae-165a-4e41-b6bb-e0e7ebc9c16c	3bddead6-ba0b-44c9-a232-8556f710fe0b	xp	200	\N	null
26850625-09e1-4e64-b4d3-0f988733d60a	3bddead6-ba0b-44c9-a232-8556f710fe0b	badge	\N	nong-dan	null
f3eebdd3-fd77-4212-9712-1c9cbc1c87d7	3be7357c-e8b3-4f2d-80f2-5054716fdb3b	xp	250	\N	null
d1b94cc0-2070-45c0-8264-bd059ae08d8d	c1837802-0866-4991-95da-750b81788781	xp	300	\N	null
de9a14cd-50ae-4661-ad35-64eda5b3d23e	c1837802-0866-4991-95da-750b81788781	badge	\N	thu-hoang-gia	null
1527dd71-c4e0-4b54-853c-b0ff375548fb	482fedb1-2f92-4610-a992-84876b84b875	xp	300	\N	null
ef32963e-09f2-4ce9-97e2-d764766d1542	482fedb1-2f92-4610-a992-84876b84b875	badge	\N	nha-dia-ly	null
44185385-5a39-46e8-ae4b-4df011b81c33	d8e9494b-a60e-427a-ba4d-9281750f718b	xp	350	\N	null
8e02bd02-b42b-4f8e-b26a-34b064c07ced	d8e9494b-a60e-427a-ba4d-9281750f718b	badge	\N	nha-thao-hoc	null
0cfb6016-c046-46e5-aece-48c69c270069	fbbe7233-b5b8-41f8-b29d-2f504286a5d4	xp	280	\N	null
5f1f7ad6-daaa-42db-87fc-d83edcf06e95	fbbe7233-b5b8-41f8-b29d-2f504286a5d4	badge	\N	chien-binh	null
acff70ae-5450-44ca-84d0-933fbbb6d573	6d7b92fe-b69a-4c99-b4a5-831e5016f8dd	xp	250	\N	null
df608747-8ab1-435a-af84-493425d65681	6d7b92fe-b69a-4c99-b4a5-831e5016f8dd	badge	\N	nha-thien-van	null
944d963f-0ae2-414b-980a-becd3097c0be	5ffa0c2d-6776-4c74-834e-a9f531c2b406	xp	250	\N	null
9ca6f35b-ecca-4af9-ae58-6b0e6d733bfc	5ffa0c2d-6776-4c74-834e-a9f531c2b406	badge	\N	kien-truc-su	null
f5fe8e3e-7725-403f-a131-6a65ae06dcc5	327631f3-a8b9-47e6-a87e-0c2e943a3318	xp	200	\N	null
5d311bb9-149a-4c6e-9bfd-25c18ec77219	8d86cabe-7f75-409a-923c-0d9ab5cfffb8	xp	300	\N	null
d7269711-aa50-4df5-b12f-0be1b91ae756	8d86cabe-7f75-409a-923c-0d9ab5cfffb8	badge	\N	cao-dinh-master	null
2e7f2913-33d3-456a-bf14-611ed8c784dc	2c893229-ab60-49e6-b39f-2fce247cf0cc	xp	300	\N	null
2022f375-4375-4a3e-aa8d-e9f7e9845119	2c893229-ab60-49e6-b39f-2fce247cf0cc	badge	\N	nhan-dinh-master	null
58a38677-6668-4c96-8a70-735b0faa9c07	ad7371dc-abb5-41ac-a519-cb39b5be9e32	xp	300	\N	null
4e3ff811-5820-4989-857b-784819d4a9b6	ad7371dc-abb5-41ac-a519-cb39b5be9e32	badge	\N	chuong-dinh-master	null
05ccbb45-e063-4965-a52e-39a8e0dad13c	110de5b7-dddd-4c1f-8d92-6448a979c74c	xp	300	\N	null
817e859b-bed8-4d0a-8b83-cf1b483eb28b	110de5b7-dddd-4c1f-8d92-6448a979c74c	badge	\N	anh-dinh-master	null
bc923988-25e4-4c90-bf8c-966b8905e3e4	558cfb8b-1885-4a04-bb8b-4fba121cf548	xp	300	\N	null
72c30f8b-d59e-49e2-b4da-efe80bd55afd	558cfb8b-1885-4a04-bb8b-4fba121cf548	badge	\N	nghi-dinh-master	null
62df463f-eafa-4e88-9909-1c117a5e69f0	50a326d9-e770-4c52-b353-6ea719fe7aca	xp	300	\N	null
c16c2459-3cff-409d-865a-8169246f2e19	50a326d9-e770-4c52-b353-6ea719fe7aca	badge	\N	thuan-dinh-master	null
817cad75-1b2d-43d9-86c8-72d3df020bea	6712dd46-4ca2-459d-880f-dd1af544b06e	xp	300	\N	null
40a2d5f6-6721-4a72-8499-9cfd35cc731a	6712dd46-4ca2-459d-880f-dd1af544b06e	badge	\N	tuyen-dinh-master	null
01e02c9f-4b9f-4a6e-8d16-410ac4feaadc	a349ad23-e04c-4b8c-9828-4b7617e825fe	xp	300	\N	null
d5aeedeb-c79e-4e36-9d54-bb15694585ca	a349ad23-e04c-4b8c-9828-4b7617e825fe	badge	\N	du-dinh-master	null
c5bc0912-5474-43eb-8256-819447be92de	0edd4e67-330d-4fe4-a31d-929c4bc5ae60	xp	300	\N	null
cf11e296-b373-40a4-bd1a-e4e36d66bc38	0edd4e67-330d-4fe4-a31d-929c4bc5ae60	badge	\N	huyen-dinh-master	null
0997324b-45b6-4589-a28b-771d035f7f33	5842df49-7251-4a62-a3f4-323287ef061a	xp	500	\N	null
00f13645-b91f-40da-bba5-d45970820c01	5842df49-7251-4a62-a3f4-323287ef061a	badge	\N	cuu-dinh-expert	null
e652eba3-1508-4be3-a1eb-7948d3fd25b2	91dc0f99-8cca-42ff-9207-6d8d5fccf6bd	xp	1000	\N	null
f7a5b850-3b76-4589-9852-d33f6b22868d	91dc0f99-8cca-42ff-9207-6d8d5fccf6bd	badge	\N	grand-collector	null
da9ea570-1d69-4067-892a-5d581cd63a53	03d1dfbb-23c3-4849-98f7-7ba01ccb1e69	xp	2000	\N	null
25af9128-3b17-4dad-a0de-194797540ef8	03d1dfbb-23c3-4849-98f7-7ba01ccb1e69	badge	\N	cuu-dinh-scholar	null
b1e4815a-5add-44c3-9b77-508f6271a0d8	438e347f-800f-4952-8d71-4bade2dd4067	xp	300	\N	null
5a2c83f2-375b-479c-8751-371d67fccfa5	438e347f-800f-4952-8d71-4bade2dd4067	badge	\N	speed-demon	null
8390cbaf-f1d2-4383-b0d8-e7000a1e989c	ad72c618-7024-4311-b5ff-b8f4902eccbd	xp	400	\N	null
97405182-10be-4fb4-b139-07ba151a0922	ad72c618-7024-4311-b5ff-b8f4902eccbd	badge	\N	explorer-all-urns	null
cda389dd-209c-4b09-ae68-3084469b0de8	204efdb0-e432-4fc1-92d9-2ecaf4657ea1	xp	250	\N	null
4998d593-5d30-4a22-9726-ff28fae22587	204efdb0-e432-4fc1-92d9-2ecaf4657ea1	badge	\N	streak-7	null
\.


--
-- Data for Name: quest_steps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quest_steps (id, quest_id, title, description, display_order, created_at) FROM stdin;
6b1c854e-7500-47dc-b304-82ac179b0917	7bbe7d40-6b28-457d-b4de-2774f5f1a08e	Tìm linh thú	\N	1	2026-01-08 14:55:45.216358+00
98c1e3ec-e286-45a2-913a-d242b25a4f55	7bbe7d40-6b28-457d-b4de-2774f5f1a08e	Thử thách linh thú	\N	2	2026-01-08 14:55:45.216358+00
5fb51cb5-9c3f-4ac2-b8c1-24214155a525	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	Chào mừng đến Cửu Đỉnh	Khám phá đỉnh đầu tiên và mở khóa 3 họa tiết bất kỳ.	1	2026-01-15 12:42:42.223767+00
16511a15-32b8-4855-a12e-52043552db27	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	Bài học đầu tiên	Hoàn thành bài học cho một họa tiết.	2	2026-01-15 12:42:42.223767+00
4ce12fdf-90c2-43b3-8d9e-4bb44e159d46	3bddead6-ba0b-44c9-a232-8556f710fe0b	Dấu ấn nông nghiệp	Mở khóa các họa tiết nông nghiệp cơ bản.	1	2026-01-15 12:42:42.223767+00
052706a1-c15d-44ca-a0e6-db558721a774	3bddead6-ba0b-44c9-a232-8556f710fe0b	Cây cỏ hoa lá	Tìm hiểu về thảo mộc trên Cửu Đỉnh.	2	2026-01-15 12:42:42.223767+00
488af87c-995b-4660-96e5-8c8cfb985401	3bddead6-ba0b-44c9-a232-8556f710fe0b	Kiểm tra mùa màng	Vượt qua các câu hỏi liên quan nông nghiệp.	3	2026-01-15 12:42:42.223767+00
86d55848-f753-4216-aab6-3471cf6eee77	3be7357c-e8b3-4f2d-80f2-5054716fdb3b	Rồng & Phượng	Tìm kiếm Long và Phượng - hai linh thú tối cao.	1	2026-01-15 12:42:42.223767+00
fbd06db7-0309-43b6-b6ff-d7f0bb3806fd	3be7357c-e8b3-4f2d-80f2-5054716fdb3b	Hiểu về linh thú	Hoàn thành bài học về linh thú.	2	2026-01-15 12:42:42.223767+00
0e1b75b0-7cf2-4649-b042-9144c70a0a6b	c1837802-0866-4991-95da-750b81788781	Tìm muông thú	Khám phá 15 họa tiết động vật.	1	2026-01-15 12:42:42.223767+00
959680f2-e4fc-4f46-aa8c-d7f0d65b84fb	c1837802-0866-4991-95da-750b81788781	Học về động vật	Hoàn thành bài học về 5 loài động vật.	2	2026-01-15 12:42:42.223767+00
936777c5-5410-4475-9baf-67776f5608dd	c1837802-0866-4991-95da-750b81788781	Thử thách động vật	Vượt qua quiz về động vật.	3	2026-01-15 12:42:42.223767+00
e51feb72-bc2e-4748-b20a-6f899f7458ab	482fedb1-2f92-4610-a992-84876b84b875	Núi sông Việt Nam	Khám phá 15 họa tiết địa lý.	1	2026-01-15 12:42:42.223767+00
665eb728-47ba-47ec-aa7a-d8cecb5e6417	482fedb1-2f92-4610-a992-84876b84b875	Địa danh lịch sử	Hoàn thành bài học về các địa danh.	2	2026-01-15 12:42:42.223767+00
33177626-589b-479b-89b6-8cf48fe3c0c7	482fedb1-2f92-4610-a992-84876b84b875	Kiểm tra địa lý	Vượt qua quiz về địa lý Việt Nam.	3	2026-01-15 12:42:42.223767+00
ba6f35bd-c630-4b87-a5f6-3061956c3d40	d8e9494b-a60e-427a-ba4d-9281750f718b	Vườn hoa	Khám phá 20 họa tiết thảo mộc.	1	2026-01-15 12:42:42.223767+00
3e443b69-58d4-4085-b9ed-8553b46c737c	d8e9494b-a60e-427a-ba4d-9281750f718b	Ý nghĩa cây cỏ	Hoàn thành bài học về 10 loài thảo mộc.	2	2026-01-15 12:42:42.223767+00
62adc5af-ce42-4256-9453-695bbb739614	d8e9494b-a60e-427a-ba4d-9281750f718b	Bậc thầy thảo mộc	Mastered 5 họa tiết thảo mộc.	3	2026-01-15 12:42:42.223767+00
c2286d80-4c3b-4130-9e0f-9598a6184dda	fbbe7233-b5b8-41f8-b29d-2f504286a5d4	Khám phá võ bị	Tìm 10 họa tiết về võ bị.	1	2026-01-15 12:42:42.223767+00
264a3b47-c14a-427f-8487-64077cd7272c	fbbe7233-b5b8-41f8-b29d-2f504286a5d4	Lịch sử quân sự	Hoàn thành bài học về võ bị.	2	2026-01-15 12:42:42.223767+00
efc201a5-6c30-4baa-aea2-ddd99fb759d6	fbbe7233-b5b8-41f8-b29d-2f504286a5d4	Thử thách võ bị	Vượt qua quiz về võ bị.	3	2026-01-15 12:42:42.223767+00
5a01f2d8-5c13-4300-b9f2-5912e89aae05	6d7b92fe-b69a-4c99-b4a5-831e5016f8dd	Bầu trời sao	Khám phá 8 họa tiết thiên văn.	1	2026-01-15 12:42:42.223767+00
3c6bd65b-42c5-4d22-aaa6-5b43dd1193ce	6d7b92fe-b69a-4c99-b4a5-831e5016f8dd	Hiểu về thiên văn	Hoàn thành bài học về thiên văn.	2	2026-01-15 12:42:42.223767+00
69d96e30-ba1b-4e0e-aed8-7742a5b1cf04	5ffa0c2d-6776-4c74-834e-a9f531c2b406	Công trình cổ	Khám phá 8 họa tiết kiến trúc.	1	2026-01-15 12:42:42.223767+00
4b5b8a5a-3f89-4bb5-8295-ccc5a0e765fb	5ffa0c2d-6776-4c74-834e-a9f531c2b406	Kiến trúc Nguyễn triều	Hoàn thành bài học về kiến trúc.	2	2026-01-15 12:42:42.223767+00
de069764-d8b2-4488-ad27-d99b1b1874c6	327631f3-a8b9-47e6-a87e-0c2e943a3318	Con đường tơ lụa	Khám phá họa tiết giao thương.	1	2026-01-15 12:42:42.223767+00
e76c25eb-b04e-49fa-9606-375159c3a585	327631f3-a8b9-47e6-a87e-0c2e943a3318	Lịch sử thương mại	Hoàn thành bài học về giao thương.	2	2026-01-15 12:42:42.223767+00
c9010c56-4ecc-481c-a1c1-d517e52e3497	8d86cabe-7f75-409a-923c-0d9ab5cfffb8	Khám phá Cao Đỉnh	Mở khóa tất cả họa tiết trên Cao Đỉnh.	1	2026-01-15 12:42:42.223767+00
98edc9f5-f4e5-4e24-9f64-5c1c9f876f6d	8d86cabe-7f75-409a-923c-0d9ab5cfffb8	Học hỏi	Hoàn thành bài học cho 5 họa tiết.	2	2026-01-15 12:42:42.223767+00
a8995ae5-ec29-4b0c-8655-77d08ccdb663	2c893229-ab60-49e6-b39f-2fce247cf0cc	Khám phá Nhân Đỉnh	Mở khóa tất cả họa tiết trên Nhân Đỉnh.	1	2026-01-15 12:42:42.223767+00
89b5e4f9-ff22-458d-8075-5d4009f77296	2c893229-ab60-49e6-b39f-2fce247cf0cc	Học hỏi	Hoàn thành bài học cho 5 họa tiết.	2	2026-01-15 12:42:42.223767+00
1dba8a74-2904-4a86-b670-c2de376bf515	ad7371dc-abb5-41ac-a519-cb39b5be9e32	Khám phá Chương Đỉnh	Mở khóa tất cả họa tiết trên Chương Đỉnh.	1	2026-01-15 12:42:42.223767+00
caafcf74-438b-4f37-980f-edcd641f19be	ad7371dc-abb5-41ac-a519-cb39b5be9e32	Học hỏi	Hoàn thành bài học cho 5 họa tiết.	2	2026-01-15 12:42:42.223767+00
95d77982-d9b1-4421-9825-dcd93060cb5c	110de5b7-dddd-4c1f-8d92-6448a979c74c	Khám phá Anh Đỉnh	Mở khóa tất cả họa tiết trên Anh Đỉnh.	1	2026-01-15 12:42:42.223767+00
62119030-3c86-4fb6-a3a9-22fe3c4bc5ad	110de5b7-dddd-4c1f-8d92-6448a979c74c	Học hỏi	Hoàn thành bài học cho 5 họa tiết.	2	2026-01-15 12:42:42.223767+00
ac11f34c-4568-40d7-9d8a-d82f284f8cad	558cfb8b-1885-4a04-bb8b-4fba121cf548	Khám phá Nghị Đỉnh	Mở khóa tất cả họa tiết trên Nghị Đỉnh.	1	2026-01-15 12:42:42.223767+00
89b8cd5b-ce82-4c4e-bfcc-995861b03a70	558cfb8b-1885-4a04-bb8b-4fba121cf548	Học hỏi	Hoàn thành bài học cho 5 họa tiết.	2	2026-01-15 12:42:42.223767+00
93b7939f-9adc-414f-a0ba-cac7695a2a4f	50a326d9-e770-4c52-b353-6ea719fe7aca	Khám phá Thuần Đỉnh	Mở khóa tất cả họa tiết trên Thuần Đỉnh.	1	2026-01-15 12:42:42.223767+00
91c73865-a9dd-40b3-bdf7-7cf26aca6510	50a326d9-e770-4c52-b353-6ea719fe7aca	Học hỏi	Hoàn thành bài học cho 5 họa tiết.	2	2026-01-15 12:42:42.223767+00
a1b64280-37c4-4b62-8d1e-9d921c590651	6712dd46-4ca2-459d-880f-dd1af544b06e	Khám phá Tuyên Đỉnh	Mở khóa tất cả họa tiết trên Tuyên Đỉnh.	1	2026-01-15 12:42:42.223767+00
102a51ed-fec4-4511-8170-f14d4064e6ff	6712dd46-4ca2-459d-880f-dd1af544b06e	Học hỏi	Hoàn thành bài học cho 5 họa tiết.	2	2026-01-15 12:42:42.223767+00
95743380-dd0a-425d-a8ab-61a2ebc8f1fa	a349ad23-e04c-4b8c-9828-4b7617e825fe	Khám phá Dụ Đỉnh	Mở khóa tất cả họa tiết trên Dụ Đỉnh.	1	2026-01-15 12:42:42.223767+00
dbab8d2c-42aa-46ef-a089-8d24a5f8a519	a349ad23-e04c-4b8c-9828-4b7617e825fe	Học hỏi	Hoàn thành bài học cho 5 họa tiết.	2	2026-01-15 12:42:42.223767+00
e0bf6226-e40d-409b-9421-771c1382efe4	0edd4e67-330d-4fe4-a31d-929c4bc5ae60	Khám phá Huyền Đỉnh	Mở khóa tất cả họa tiết trên Huyền Đỉnh.	1	2026-01-15 12:42:42.223767+00
02e2af2f-66f1-4bd5-90fb-11911c348d96	0edd4e67-330d-4fe4-a31d-929c4bc5ae60	Học hỏi	Hoàn thành bài học cho 5 họa tiết.	2	2026-01-15 12:42:42.223767+00
314ca61b-8f58-4c9e-90ae-4a81eb82274a	5842df49-7251-4a62-a3f4-323287ef061a	Thu thập kiến thức	Hoàn thành ít nhất 50 bài học.	1	2026-01-15 12:42:42.223767+00
b7ab761e-9e5d-4120-ad9d-cbf7183e202a	5842df49-7251-4a62-a3f4-323287ef061a	Thi chứng nhận	Vượt qua kỳ thi chứng nhận.	2	2026-01-15 12:42:42.223767+00
322020c1-384f-4259-a1ca-bd1c9af7d428	91dc0f99-8cca-42ff-9207-6d8d5fccf6bd	Khám phá tất cả	Mở khóa tất cả họa tiết trên 9 đỉnh.	1	2026-01-15 12:42:42.223767+00
900a9962-4df5-4bcf-84ee-11b8e7547bcc	91dc0f99-8cca-42ff-9207-6d8d5fccf6bd	Hoàn thành tất cả bài học	Hoàn thành bài học cho tất cả họa tiết.	2	2026-01-15 12:42:42.223767+00
02d8db49-a41d-4d77-bbe9-725baa15092d	91dc0f99-8cca-42ff-9207-6d8d5fccf6bd	Thành thạo	Mastered 50 họa tiết.	3	2026-01-15 12:42:42.223767+00
292cc567-c00d-4197-8b1f-b731fdc16a31	03d1dfbb-23c3-4849-98f7-7ba01ccb1e69	Quiz Master	Đạt điểm tối đa trong 20 quiz.	1	2026-01-15 12:42:42.223767+00
9435a7eb-d1a9-4ee7-884a-921abbb59416	03d1dfbb-23c3-4849-98f7-7ba01ccb1e69	Streak legend	Duy trì streak 30 ngày.	2	2026-01-15 12:42:42.223767+00
1ce76506-54cf-4393-8f6a-b4ccfd27dd96	438e347f-800f-4952-8d71-4bade2dd4067	Quiz nhanh	Hoàn thành 5 quiz trong dưới 30 giây mỗi quiz.	1	2026-01-15 12:42:42.223767+00
ded6bc13-1bdf-4e53-82b1-ac5de901687b	ad72c618-7024-4311-b5ff-b8f4902eccbd	Ghé thăm mọi đỉnh	Khám phá ít nhất 1 họa tiết trên mỗi đỉnh.	1	2026-01-15 12:42:42.223767+00
a6f856ac-3587-4b2a-9e56-32f714d258b4	ad72c618-7024-4311-b5ff-b8f4902eccbd	Đa dạng danh mục	Khám phá họa tiết từ tất cả 9 danh mục.	2	2026-01-15 12:42:42.223767+00
2135a718-4397-4ced-b365-c42bc1630ebd	204efdb0-e432-4fc1-92d9-2ecaf4657ea1	7 ngày liên tiếp	Duy trì streak 7 ngày.	1	2026-01-15 12:42:42.223767+00
dd200570-3bcb-4b1c-8bd2-468bd6c71866	204efdb0-e432-4fc1-92d9-2ecaf4657ea1	Học mỗi ngày	Hoàn thành ít nhất 1 bài học mỗi ngày trong 7 ngày.	2	2026-01-15 12:42:42.223767+00
\.


--
-- Data for Name: quests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quests (id, slug, name, description, category, display_order, is_active, prerequisite_id, created_at, updated_at, content_rating) FROM stdin;
7bbe7d40-6b28-457d-b4de-2774f5f1a08e	linh-thu	Linh Thú & Động Vật	Thu thập dấu tích của linh thú và động vật trên các đỉnh.	linh_thu	2	t	3bddead6-ba0b-44c9-a232-8556f710fe0b	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	everyone
5842df49-7251-4a62-a3f4-323287ef061a	cuu-dinh-thu-thach	Thử Thách Cửu Đỉnh	Vượt qua kỳ kiểm tra Cửu Đỉnh để nhận chứng nhận.	tong_hop	20	t	482fedb1-2f92-4610-a992-84876b84b875	2026-01-08 14:55:01.200388+00	2026-01-08 16:07:16.959774+00	everyone
2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	khoi-dau-hanh-trinh	Khởi Đầu Hành Trình	Làm quen với Cửu Đỉnh và khám phá những họa tiết đầu tiên.	starter	1	t	\N	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
3bddead6-ba0b-44c9-a232-8556f710fe0b	dat-mua-mang	Đất & Mùa Màng	Khám phá họa tiết về nông nghiệp và mùa vụ - nền tảng của văn hóa Việt Nam.	nong_nghiep	2	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 14:55:01.200388+00	2026-01-08 16:07:16.959774+00	everyone
3be7357c-e8b3-4f2d-80f2-5054716fdb3b	linh-thu-huyen-bi	Linh Thú Huyền Bí	Thu thập dấu tích của các linh thú thiêng liêng trên Cửu Đỉnh.	linh_thu	3	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
c1837802-0866-4991-95da-750b81788781	the-gioi-dong-vat	Thế Giới Động Vật	Khám phá các loài động vật được khắc họa trên Cửu Đỉnh.	dong_vat	4	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
482fedb1-2f92-4610-a992-84876b84b875	son-ha-xa-tac	Sơn Hà Xã Tắc	Khám phá các họa tiết về địa lý, núi sông của đất Việt.	dia_ly	5	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 14:55:01.200388+00	2026-01-08 16:07:16.959774+00	everyone
d8e9494b-a60e-427a-ba4d-9281750f718b	thao-moc-thien-nhien	Thảo Mộc Thiên Nhiên	Khám phá thế giới cây cỏ hoa lá trên Cửu Đỉnh.	thao_moc	6	t	3bddead6-ba0b-44c9-a232-8556f710fe0b	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
fbbe7233-b5b8-41f8-b29d-2f504286a5d4	vo-bi-quan-su	Võ Bị & Quân Sự	Tìm hiểu về các họa tiết liên quan đến võ bị và quân sự.	vo_bi	7	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
6d7b92fe-b69a-4c99-b4a5-831e5016f8dd	thien-van-vu-tru	Thiên Văn & Vũ Trụ	Khám phá các họa tiết về thiên văn và vũ trụ.	thien_van	8	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
5ffa0c2d-6776-4c74-834e-a9f531c2b406	kien-truc-co	Kiến Trúc Cổ	Tìm hiểu về các họa tiết kiến trúc truyền thống.	kien_truc	9	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
327631f3-a8b9-47e6-a87e-0c2e943a3318	giao-thuong-buon-ban	Giao Thương & Buôn Bán	Khám phá các họa tiết liên quan đến thương mại.	giao_thuong	10	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
8d86cabe-7f75-409a-923c-0d9ab5cfffb8	kham-pha-cao-dinh	Khám Phá Cao Đỉnh	Cao Đỉnh - đỉnh đầu tiên, tôn vinh vua Gia Long.	urn	11	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
2c893229-ab60-49e6-b39f-2fce247cf0cc	kham-pha-nhan-dinh	Khám Phá Nhân Đỉnh	Nhân Đỉnh - tôn vinh vua Minh Mạng.	urn	12	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
ad7371dc-abb5-41ac-a519-cb39b5be9e32	kham-pha-chuong-dinh	Khám Phá Chương Đỉnh	Chương Đỉnh - tôn vinh vua Thiệu Trị.	urn	13	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
110de5b7-dddd-4c1f-8d92-6448a979c74c	kham-pha-anh-dinh	Khám Phá Anh Đỉnh	Anh Đỉnh - tôn vinh vua Tự Đức.	urn	14	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
558cfb8b-1885-4a04-bb8b-4fba121cf548	kham-pha-nghi-dinh	Khám Phá Nghị Đỉnh	Nghị Đỉnh - tôn vinh vua Kiến Phúc.	urn	15	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
50a326d9-e770-4c52-b353-6ea719fe7aca	kham-pha-thuan-dinh	Khám Phá Thuần Đỉnh	Thuần Đỉnh - tôn vinh vua Đồng Khánh.	urn	16	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
6712dd46-4ca2-459d-880f-dd1af544b06e	kham-pha-tuyen-dinh	Khám Phá Tuyên Đỉnh	Tuyên Đỉnh - tôn vinh vua Khải Định.	urn	17	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
a349ad23-e04c-4b8c-9828-4b7617e825fe	kham-pha-du-dinh	Khám Phá Dụ Đỉnh	Dụ Đỉnh - tôn vinh vua Bảo Đại.	urn	18	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
0edd4e67-330d-4fe4-a31d-929c4bc5ae60	kham-pha-huyen-dinh	Khám Phá Huyền Đỉnh	Huyền Đỉnh - đỉnh cuối cùng trong Cửu Đỉnh.	urn	19	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
91dc0f99-8cca-42ff-9207-6d8d5fccf6bd	nha-suu-tam-vi-dai	Nhà Sưu Tầm Vĩ Đại	Thu thập và thành thạo tất cả họa tiết trên Cửu Đỉnh.	collection	21	t	5842df49-7251-4a62-a3f4-323287ef061a	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
03d1dfbb-23c3-4849-98f7-7ba01ccb1e69	hoc-gia-cuu-dinh	Học Giả Cửu Đỉnh	Đạt thành tích cao nhất trong tất cả các lĩnh vực.	master	22	t	91dc0f99-8cca-42ff-9207-6d8d5fccf6bd	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
438e347f-800f-4952-8d71-4bade2dd4067	speed-runner	Speed Runner	Hoàn thành các thử thách với tốc độ nhanh nhất.	special	23	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
ad72c618-7024-4311-b5ff-b8f4902eccbd	nguoi-kham-pha	Người Khám Phá	Khám phá mọi ngóc ngách của Cửu Đỉnh.	exploration	24	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
204efdb0-e432-4fc1-92d9-2ecaf4657ea1	hoc-sinh-cham-chi	Học Sinh Chăm Chỉ	Thể hiện sự kiên trì trong học tập.	streak	25	t	2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f	2026-01-08 16:07:16.959774+00	2026-01-08 16:07:16.959774+00	everyone
\.


--
-- Data for Name: quiz_attempts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_attempts (id, user_id, motif_id, score, max_score, percentage, answers, time_taken_seconds, completed_at) FROM stdin;
28569d82-963e-40f2-a8c4-e0208a7ceb9e	1df31222-3934-471c-8624-a87034fd017d	bf4a67a3-162d-4d04-98b0-adff8a1860f1	2	3	67	[{"answer": "A. Vua Gia Long", "question_id": "d1a4c5fc-8a2a-4116-998c-398e2200347e"}, {"answer": "C. 1835-1837", "question_id": "22f67819-1ac2-4ade-99d9-0ecebfc42c9a"}, {"answer": "Đúng", "question_id": "44febf12-7a8c-4f9c-a58a-835da40b7154"}]	11	2026-01-12 07:58:34.994829+00
4cc42609-1e65-4268-bf98-80b2549fdfaa	1df31222-3934-471c-8624-a87034fd017d	798e6ca7-ca19-4851-b320-889549db1096	2	2	100	[{"answer": "B. Hoàng đế", "question_id": "6c5d548a-8fd2-4bad-8b22-53a1adebb5e9"}, {"answer": "Đúng", "question_id": "2cab4221-04cf-45e6-b8e9-7f4477cf170f"}]	8	2026-01-12 08:02:16.298053+00
\.


--
-- Data for Name: quiz_hint_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_hint_requests (id, user_id, question_id, hint_type, hint_text, heart_cost, rag_sources, created_at) FROM stdin;
\.


--
-- Data for Name: quiz_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_questions (id, motif_id, urn_id, question_type, question_text, options, correct_answer, target_mesh_name, difficulty, explanation, is_published, is_active, created_at, status, submitted_for_review_at, reviewed_by_id, reviewed_at, review_notes, created_by_id, skill_type) FROM stdin;
d1a4c5fc-8a2a-4116-998c-398e2200347e	bf4a67a3-162d-4d04-98b0-adff8a1860f1	\N	multiple_choice	Chữ 'Cao' trên Cao Đỉnh là thụy hiệu của vị vua nào?	["A. Vua Gia Long", "B. Vua Minh Mạng", "C. Vua Thiệu Trị", "D. Vua Tự Đức"]	A. Vua Gia Long	\N	1	Chữ 'Cao' là thụy hiệu của vua Gia Long, người sáng lập triều Nguyễn. Cao Đỉnh được vua Minh Mạng cho đúc để tưởng nhớ công lao của vua cha.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
22f67819-1ac2-4ade-99d9-0ecebfc42c9a	bf4a67a3-162d-4d04-98b0-adff8a1860f1	\N	multiple_choice	Cửu Đỉnh được đúc vào thời gian nào?	["A. 1802-1805", "B. 1820-1825", "C. 1835-1837", "D. 1850-1855"]	C. 1835-1837	\N	2	Cửu Đỉnh được vua Minh Mạng cho đúc từ năm 1835 đến 1837, sau khi vua Gia Long băng hà (1820) và vua Minh Mạng đã củng cố được triều đại.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
44febf12-7a8c-4f9c-a58a-835da40b7154	bf4a67a3-162d-4d04-98b0-adff8a1860f1	\N	true_false	Cao Đỉnh là chiếc đỉnh lớn nhất trong Cửu Đỉnh.	["Đúng", "Sai"]	Sai	\N	2	Cao Đỉnh là một trong những chiếc đỉnh lớn nhất nhưng không phải lớn nhất. Các đỉnh trong Cửu Đỉnh có kích thước tương đương nhau, mỗi chiếc nặng khoảng 2.500-2.600 kg.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
bdc95002-4317-4f1b-9fd4-ecc8a149acdd	9e95bea4-a087-4dc5-ade2-c4e453878f41	\N	multiple_choice	Rồng trên Cao Đỉnh tượng trưng cho điều gì?	["A. Sức mạnh quân sự", "B. Quyền lực hoàng đế", "C. Sự giàu có", "D. Trí tuệ học vấn"]	B. Quyền lực hoàng đế	\N	1	Rồng là biểu tượng tối cao của hoàng quyền trong văn hóa Việt Nam. Chỉ hoàng đế mới được sử dụng hình ảnh rồng năm móng, thể hiện quyền lực tuyệt đối.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
fb8a7eb6-5d4a-4545-9ccd-a1361f9d8b89	9e95bea4-a087-4dc5-ade2-c4e453878f41	\N	multiple_choice	Người Việt Nam tự hào gọi mình là gì?	["A. Con rồng cháu tiên", "B. Con lân cháu phượng", "C. Con rùa cháu rồng", "D. Con phượng cháu lân"]	A. Con rồng cháu tiên	\N	1	Người Việt tự hào gọi mình là 'con rồng cháu tiên', xuất phát từ truyền thuyết Lạc Long Quân (rồng) và Âu Cơ (tiên), thể hiện nguồn gốc thần thoại của dân tộc.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
b9524fe0-55cc-4350-9f29-09e1fd942ee5	9e95bea4-a087-4dc5-ade2-c4e453878f41	\N	multiple_choice	Rồng Việt Nam khác rồng phương Tây ở điểm nào?	["A. Rồng Việt có cánh và phun lửa", "B. Rồng Việt không cánh, gắn liền với nước và mây", "C. Rồng Việt có hai đầu", "D. Rồng Việt không có móng vuốt"]	B. Rồng Việt không cánh, gắn liền với nước và mây	\N	2	Khác với rồng phương Tây có cánh và phun lửa, rồng Việt Nam có thân dài, không cánh nhưng có thể bay nhờ sức mạnh thần thánh, thường gắn liền với nước và mây.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
8b21bc06-46aa-4b58-a7c0-a62a266dab8a	9e95bea4-a087-4dc5-ade2-c4e453878f41	\N	true_false	Chỉ hoàng đế mới được sử dụng hình ảnh rồng năm móng.	["Đúng", "Sai"]	Đúng	\N	2	Trong lịch sử Việt Nam, chỉ hoàng đế mới được sử dụng hình ảnh rồng năm móng. Các quan lại và hoàng tử chỉ được dùng rồng bốn móng hoặc ba móng, thể hiện sự phân biệt đẳng cấp.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
a0171638-31f6-482d-a2f2-299e0053663b	036b8060-4597-4028-bded-135081787c70	\N	multiple_choice	Cây mít trên Cao Đỉnh tượng trưng cho điều gì?	["A. Quyền lực hoàng gia", "B. Sự sung túc và phồn thịnh", "C. Trí tuệ và học vấn", "D. Sức mạnh quân sự"]	B. Sự sung túc và phồn thịnh	\N	1	Cây mít với trái to lớn tượng trưng cho sự sung túc, phồn thịnh và đoàn kết trong văn hóa nông nghiệp Việt Nam. Việc khắc họa cây mít trên Cửu Đỉnh thể hiện sự trân trọng của triều đình đối với nền nông nghiệp.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
1fa1302e-ec51-43a9-88f7-64362e1d8455	036b8060-4597-4028-bded-135081787c70	\N	multiple_choice	Trái mít có đặc điểm gì đặc biệt?	["A. Là loại trái cây nhỏ nhất thế giới", "B. Là loại trái cây lớn nhất mọc trên cây trên thế giới", "C. Chỉ có ở Việt Nam", "D. Chỉ có thể ăn khi nấu chín"]	B. Là loại trái cây lớn nhất mọc trên cây trên thế giới	\N	2	Trái mít là loại trái cây lớn nhất mọc trên cây trên thế giới, có thể nặng tới 50kg. Đây là một đặc điểm nổi bật khiến mít trở thành biểu tượng của sự sung túc.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
bd49fcda-b2c5-4a54-9070-f6e7718702b9	036b8060-4597-4028-bded-135081787c70	\N	multiple_choice	'Ba La Mật' trong Phật giáo có ý nghĩa gì?	["A. Tên của một vị Phật", "B. Liên quan đến 'đến bờ giác ngộ'", "C. Tên của một ngôi chùa", "D. Tên của một kinh Phật"]	B. Liên quan đến 'đến bờ giác ngộ'	\N	3	Tên 'Ba La Mật' gắn liền với 'Bát Nhã Ba La Mật Đa' (Prajñāpāramitā) trong Phật giáo, có nghĩa là 'đến bờ giác ngộ', thể hiện sự giao thoa văn hóa Phật giáo trong xã hội Việt Nam.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
124057df-a75f-4eb1-8bc0-076ae546dc01	036b8060-4597-4028-bded-135081787c70	\N	true_false	Gỗ mít được coi là loại gỗ quý, thường dùng để chạm khắc tượng Phật.	["Đúng", "Sai"]	Đúng	\N	2	Gỗ mít có màu vàng đẹp, cứng chắc và rất bền, được coi là loại gỗ quý, thường được sử dụng để chạm khắc tượng Phật và làm đồ thờ cúng cao cấp.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
55fce007-a57c-45ab-b154-85f1d88674af	a9d3e605-ac3e-44ef-bf07-8712b6b4eefd	\N	multiple_choice	Chữ 'Canh' trên Cao Đỉnh chỉ loại cây gì?	["A. Lúa nếp", "B. Lúa tẻ", "C. Ngô", "D. Khoai lang"]	B. Lúa tẻ	\N	1	'Canh' là tên Hán Việt chỉ lúa tẻ, nguồn lương thực chính hàng ngày của người Việt.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
278611c3-2dba-49f4-a3c5-c1d1730b87c5	a9d3e605-ac3e-44ef-bf07-8712b6b4eefd	\N	true_false	Lúa tẻ được khắc trên Cao Đỉnh để thể hiện chính sách 'nông vi bản' của triều Nguyễn.	["Đúng", "Sai"]	Đúng	\N	2	Đúng. Việc khắc lúa tẻ lên đỉnh cao nhất thể hiện sự coi trọng nông nghiệp là gốc rễ của sự ổn định quốc gia.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
2a182fd2-7843-4f59-81d3-3b7421ec439a	a9d3e605-ac3e-44ef-bf07-8712b6b4eefd	\N	multiple_choice	Biệt danh nào thường được dùng để gọi hạt gạo trong văn hóa Việt?	["A. Hạt vàng", "B. Hạt ngọc trời", "C. Hạt bạc", "D. Hạt kim cương"]	B. Hạt ngọc trời	\N	1	Người Việt ví hạt gạo là 'hạt ngọc trời' để thể hiện sự trân quý đối với nguồn lương thực nuôi sống con người.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
5905f6a0-02b0-44a6-81ae-c568bbb8fbd3	31f8cc7a-149b-40b2-9f60-3c073513673a	\N	multiple_choice	Chữ 'Thông' trên Cao Đỉnh chỉ loại cây gì?	["A. Cây thông (gỗ)", "B. Cây hành (gia vị)", "C. Cây tùng", "D. Cây trúc"]	B. Cây hành (gia vị)	\N	2	Chữ 'Thông' (蔥) trên Cửu Đỉnh là cây hành, một loại gia vị, phân biệt với cây tùng (thông gỗ).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
cc47f34d-d21f-4008-a563-9d87ef376548	31f8cc7a-149b-40b2-9f60-3c073513673a	\N	multiple_choice	Cây hành có ý nghĩa biểu tượng gì nhờ hiện tượng đồng âm?	["A. Sự giàu có", "B. Sự trường thọ", "C. Sự thông minh, thông suốt", "D. Sự quyền lực"]	C. Sự thông minh, thông suốt	\N	2	Hành (蔥) đồng âm với 'thông' trong thông minh, thông suốt, mang ý nghĩa chúc tụng trí tuệ và sự thuận lợi.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
d2f22f1e-185e-4e84-bdcf-b8eb8ea66719	d27e9e0b-a9eb-42a2-8466-83442f48939d	\N	multiple_choice	Hoa Tử Vi (Tường Vi) thường có màu gì?	["A. Chỉ màu trắng", "B. Hồng, tím, trắng", "C. Chỉ màu vàng", "D. Xanh dương"]	B. Hồng, tím, trắng	\N	1	Hoa tường vi có nhiều màu sắc rực rỡ, phổ biến nhất là các sắc độ hồng và tím.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f850eb02-e457-4964-afef-4b5d6d495978	d27e9e0b-a9eb-42a2-8466-83442f48939d	\N	multiple_choice	Tên 'Tử Vi' của loài hoa này gợi liên tưởng đến điều gì trong văn hóa phương Đông?	["A. Một loại thuốc quý", "B. Chòm sao Tử Vi (đế vương)", "C. Một món ăn cung đình", "D. Một loại vải lụa"]	B. Chòm sao Tử Vi (đế vương)	\N	3	Tên hoa gợi nhắc đến sao Tử Vi, ngôi sao chủ mệnh đế vương trong tử vi đẩu số, mang ý nghĩa quyền quý.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
709aa738-ffb7-42cd-930a-7232777d90b2	284e4bb9-a798-45a1-9926-4e9cc8debdcc	\N	multiple_choice	Chim trĩ thường được dùng làm biểu tượng cho quan lại thuộc ban nào?	["A. Quan Võ", "B. Quan Văn", "C. Thái giám", "D. Ngự y"]	B. Quan Văn	\N	2	Chim trĩ với vẻ đẹp nho nhã thường là biểu tượng trên phẩm phục của quan văn, trong khi các loài thú dữ như hổ, báo thường đại diện cho quan võ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
d2e72d86-65ba-471f-8029-e7029a60b312	284e4bb9-a798-45a1-9926-4e9cc8debdcc	\N	true_false	Chim trĩ được xem là điềm báo của đất nước thái bình.	["Đúng", "Sai"]	Đúng	\N	2	Cổ nhân tin rằng chim trĩ là loài chim lành, sự xuất hiện của nó báo hiệu điềm lành và sự thịnh trị.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
714a19ac-7add-4398-a349-cedc5297df9b	ee64b246-96ba-4a9f-87a5-524fb427d54f	\N	multiple_choice	Việc khắc 'Đông Hải' lên Cao Đỉnh có ý nghĩa quan trọng gì về mặt lịch sử?	["A. Để trang trí cho đẹp", "B. Khẳng định chủ quyền biển đảo quốc gia", "C. Đánh dấu nơi vua hay đi nghỉ mát", "D. Thể hiện kỹ thuật đúc đồng"]	B. Khẳng định chủ quyền biển đảo quốc gia	\N	1	Đây là bằng chứng lịch sử quan trọng khẳng định ý thức và hành động thực thi chủ quyền của triều Nguyễn đối với vùng biển đảo của Tổ quốc.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
7740cea8-1b56-4a30-b2e7-7941c5bd41e6	ee64b246-96ba-4a9f-87a5-524fb427d54f	\N	true_false	Vua Minh Mạng là người rất chú trọng đến việc đo đạc và vẽ bản đồ biển đảo.	["Đúng", "Sai"]	Đúng	\N	1	Vua Minh Mạng đã cử nhiều đoàn khảo sát ra Hoàng Sa, Trường Sa để cắm mốc chủ quyền và vẽ bản đồ chi tiết.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
734fe18d-c335-4339-9a39-361a48b2a218	09275995-9116-49af-8ddb-bea8c2255ca9	\N	multiple_choice	Kênh Vĩnh Tế được đặt theo tên của ai?	["A. Vua Gia Long", "B. Danh tướng Thoại Ngọc Hầu", "C. Bà Châu Thị Vĩnh Tế (vợ Thoại Ngọc Hầu)", "D. Một vị thần sông"]	C. Bà Châu Thị Vĩnh Tế (vợ Thoại Ngọc Hầu)	\N	2	Vua Gia Long đã ban tên kênh theo tên vợ của người chỉ huy đào kênh để vinh danh đức hạnh của bà.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0638b19b-8482-4eaf-ae0b-d2bd7e10fd01	09275995-9116-49af-8ddb-bea8c2255ca9	\N	multiple_choice	Vai trò chính của kênh Vĩnh Tế là gì?	["A. Chỉ để tưới tiêu", "B. Chỉ để đi lại", "C. Quốc phòng, giao thông và thủy lợi", "D. Làm cảnh quan du lịch"]	C. Quốc phòng, giao thông và thủy lợi	\N	2	Kênh Vĩnh Tế có vai trò đa năng: là hào phòng thủ biên giới, tuyến giao thông thủy huyết mạch và công trình thủy lợi quan trọng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
6c5d548a-8fd2-4bad-8b22-53a1adebb5e9	798e6ca7-ca19-4851-b320-889549db1096	\N	multiple_choice	Trong văn hóa phong kiến, Mặt trời là biểu tượng của ai?	["A. Hoàng hậu", "B. Hoàng đế", "C. Tể tướng", "D. Thái tử"]	B. Hoàng đế	\N	1	Mặt trời (Thái dương) là biểu tượng của khí Dương và quyền lực tối cao, đại diện cho Hoàng đế.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
2cab4221-04cf-45e6-b8e9-7f4477cf170f	798e6ca7-ca19-4851-b320-889549db1096	\N	true_false	Hình ảnh Mặt trời trên Cao Đỉnh thường đi cặp với Mặt trăng trên Nhân Đỉnh.	["Đúng", "Sai"]	Đúng	\N	2	Đây là sự sắp xếp có chủ ý theo triết lý Âm Dương và vũ trụ quan của người xưa.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
d1601326-9b36-41c9-ba5a-826476220607	9401eb10-9469-4b4a-963a-68041441569b	\N	multiple_choice	Ngưu Chữ Giang là tên chữ của con sông nào ngày nay?	["A. Sông Hồng", "B. Sông Hương", "C. Sông (Rạch) Bến Nghé", "D. Sông Cửu Long"]	C. Sông (Rạch) Bến Nghé	\N	2	Ngưu Chữ nghĩa là Bến Trâu, tên chữ Hán của Bến Nghé.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
18f8bcc8-8e6c-4b48-9bbf-6e4568cd0a52	9401eb10-9469-4b4a-963a-68041441569b	\N	multiple_choice	Sông Bến Nghé thuộc vùng đất nào?	["A. Thăng Long - Hà Nội", "B. Phú Xuân - Huế", "C. Gia Định - Sài Gòn", "D. Phố Hiến - Hưng Yên"]	C. Gia Định - Sài Gòn	\N	1	Bến Nghé là địa danh nổi tiếng của vùng đất Sài Gòn - Gia Định xưa.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
1e793268-df19-4fcd-ae11-1936ff0ce369	f3a49a22-ec62-492e-a662-29419f1c2fca	\N	multiple_choice	Núi Thiên Tôn nằm ở tỉnh nào?	["A. Thừa Thiên Huế", "B. Thanh Hóa", "C. Nghệ An", "D. Quảng Nam"]	B. Thanh Hóa	\N	2	Núi Thiên Tôn nằm ở huyện Hà Trung, Thanh Hóa, là quê gốc của các chúa Nguyễn và vua Nguyễn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
2dcdb42b-a57d-40c9-b1ea-55ce4b53a46b	f3a49a22-ec62-492e-a662-29419f1c2fca	\N	true_false	Núi Thiên Tôn được khắc lên Cao Đỉnh vì đây là nơi vua Gia Long sinh ra.	["Đúng", "Sai"]	Sai	\N	3	Núi Thiên Tôn là đất tổ (quý hương) của dòng họ Nguyễn, nơi phát tích tổ tiên, chứ không phải nơi vua Gia Long sinh ra (vua sinh tại Huế hoặc trong thời gian lưu lạc).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
30ed7954-16e1-4ba8-b07a-d1b3cf296d69	a42b833e-c260-4293-9fca-b5c8995c5651	\N	multiple_choice	Thiết Mộc trong nhóm 'tứ thiết' thường chỉ loại gỗ nào?	["A. Gỗ mít", "B. Gỗ lim", "C. Gỗ thông", "D. Gỗ xoan"]	B. Gỗ lim	\N	2	Thiết mộc (gỗ sắt) là tên gọi tôn xưng độ cứng của gỗ lim, loại gỗ quý hàng đầu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e79c697f-eb2f-49c0-9168-1adf25f988c7	a42b833e-c260-4293-9fca-b5c8995c5651	\N	true_false	Gỗ lim thường được dùng để làm cột đình, chùa vì độ bền cao.	["Đúng", "Sai"]	Đúng	\N	1	Nhờ đặc tính cứng, không mối mọt, gỗ lim là lựa chọn số một cho các công trình kiến trúc cổ cần sự trường tồn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
26c7dd17-147c-497f-b1ca-56e45ead25ec	dcf170b7-345a-4da8-a7fd-b9327517bdc3	\N	multiple_choice	Hổ được xem là biểu tượng của tầng lớp nào trong triều đình?	["A. Quan Văn", "B. Quan Võ (Võ tướng)", "C. Phi tần", "D. Nông dân"]	B. Quan Võ (Võ tướng)	\N	1	Với sức mạnh và sự dũng mãnh, hổ là biểu tượng tiêu biểu cho các võ tướng (Hổ tướng, Hổ phù).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
3e2e4b2f-e1c4-4105-aca8-8dea454ed6f8	dcf170b7-345a-4da8-a7fd-b9327517bdc3	\N	multiple_choice	Đấu trường nổi tiếng nào ở Huế là nơi diễn ra các trận đấu giữa Voi và Hổ?	["A. Đấu trường La Mã", "B. Hổ Quyền", "C. Văn Miếu", "D. Đàn Nam Giao"]	B. Hổ Quyền	\N	2	Hổ Quyền là di tích độc đáo tại Huế, nơi từng tổ chức các trận tử chiến giữa voi và hổ dưới triều Nguyễn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
807e0d21-6de3-420a-8375-9e8158b96993	d9963208-838a-45ee-a45c-3f22f1c5a157	\N	multiple_choice	Đa Tác Thuyền trên Cao Đỉnh đại diện cho phương tiện gì?	["A. Xe ngựa", "B. Thuyền buồm đi biển", "C. Kiệu rước", "D. Bè tre"]	B. Thuyền buồm đi biển	\N	1	Đa Tác Thuyền là loại thuyền buồm lớn, có khả năng đi biển, phục vụ giao thương và quân sự.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
6a329a7d-147f-4621-8b5d-b37a5eabf6a8	d9963208-838a-45ee-a45c-3f22f1c5a157	\N	true_false	Triều Nguyễn không quan tâm đến việc phát triển kỹ thuật đóng tàu.	["Đúng", "Sai"]	Sai	\N	1	Ngược lại, triều Nguyễn rất chú trọng phát triển thủy quân và kỹ thuật đóng tàu, thậm chí học hỏi cả kỹ thuật phương Tây.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
2867fb8d-e534-4e03-b61e-174f5f249e16	90c77d97-240a-4854-b5f3-f875362f5c8e	\N	multiple_choice	Đại bác (Thần công) tượng trưng cho lĩnh vực nào?	["A. Nông nghiệp", "B. Văn hóa", "C. Quốc phòng, quân sự", "D. Y tế"]	C. Quốc phòng, quân sự	\N	1	Đại bác là vũ khí hỏa lực mạnh, đại diện cho sức mạnh quân sự và khả năng bảo vệ đất nước.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f9ff057d-5e1b-46a4-b224-f349137504c0	90c77d97-240a-4854-b5f3-f875362f5c8e	\N	true_false	Các khẩu thần công thời Nguyễn thường được phong tước hiệu như con người.	["Đúng", "Sai"]	Đúng	\N	2	Đúng, triều đình thường phong tước (như Đại tướng quân) cho các khẩu súng lớn để thể hiện sự tôn trọng 'thần lực' của vũ khí.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
93309791-80f8-4106-8e1e-02df8d07e2b6	067a0a69-1a95-4489-9a38-b4565b61c9e1	\N	multiple_choice	Trầm hương được hình thành từ loài cây nào?	["A. Cây Thông", "B. Cây Dó Bầu", "C. Cây Mít", "D. Cây Quế"]	B. Cây Dó Bầu	\N	2	Trầm hương là phần gỗ chứa nhựa thơm sinh ra từ cây Dó Bầu khi cây bị tổn thương và tự chữa lành.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
128b7335-4a81-4963-907a-6ab7f687b2d3	067a0a69-1a95-4489-9a38-b4565b61c9e1	\N	multiple_choice	Câu thành ngữ nào nói về sự gian nan khi đi tìm trầm hương?	["A. Lên thác xuống ghềnh", "B. Ngậm ngải tìm trầm", "C. Chân cứng đá mềm", "D. Một nắng hai sương"]	B. Ngậm ngải tìm trầm	\N	2	'Ngậm ngải tìm trầm' diễn tả sự vất vả, hiểm nguy và yếu tố may mắn tâm linh của những người đi rừng tìm kiếm loại gỗ quý này.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
88371d99-0e1e-429a-b7ae-4acc4ced3a37	63f7f1f5-83b9-4e43-8e94-7debbb3ed2ab	\N	multiple_choice	Con 'Miết' trên Cao Đỉnh là tên gọi khác của con vật nào?	["A. Con cua", "B. Con rùa biển", "C. Con ba ba", "D. Con ếch"]	C. Con ba ba	\N	1	Miết là tên Hán Việt chỉ con ba ba, loài vật có mai mềm sống ở nước ngọt.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
9c489581-d100-4789-b23a-af7e8382c9f3	63f7f1f5-83b9-4e43-8e94-7debbb3ed2ab	\N	true_false	Ba ba được khắc trên Cửu Đỉnh vì nó là một linh vật trong tứ linh.	["Đúng", "Sai"]	Sai	\N	1	Sai. Ba ba là loài vật đời thường, có giá trị thực phẩm và dược liệu, không phải là linh vật (như Long, Lân, Quy, Phụng). Rùa (Quy) mới là linh vật.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ee9212e7-aaf2-476e-b773-79eac1121a5a	282f77b0-b908-4785-8592-3c8dcb0b9851	\N	multiple_choice	Nhân Đỉnh được đúc để tôn vinh vị vua nào?	["A. Vua Gia Long", "B. Vua Minh Mạng", "C. Vua Thiệu Trị", "D. Vua Tự Đức"]	B. Vua Minh Mạng	\N	1	Nhân Đỉnh là đỉnh thứ hai, ứng với thế thứ thứ hai trong Thế Miếu là vua Minh Mạng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0e564dd4-4415-4825-9a17-376fa22c648f	282f77b0-b908-4785-8592-3c8dcb0b9851	\N	multiple_choice	Chữ 'Nhân' trong tên đỉnh mang ý nghĩa gì?	["A. Sức mạnh quân sự", "B. Sự giàu có", "C. Lòng nhân ái, đức độ", "D. Sự thông minh"]	C. Lòng nhân ái, đức độ	\N	1	Trong Nho giáo, 'Nhân' là đức tính đứng đầu, chỉ lòng yêu thương con người và đức độ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
cd19d0d1-ecb0-4696-bef6-2443d952936b	e2bf57a0-8b09-459f-9213-40c95da2c647	\N	multiple_choice	Theo truyền thuyết, loài chim nào chỉ đậu trên cây Ngô Đồng?	["A. Chim Công", "B. Chim Phượng Hoàng", "C. Chim Hạc", "D. Chim Đại Bàng"]	B. Chim Phượng Hoàng	\N	1	Truyền thuyết 'Phượng hoàng đậu cây ngô đồng' là biểu tượng của điềm lành và sự xuất hiện của thánh nhân.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ba5ae7e3-2c9e-44bc-bded-e44a878236d1	e2bf57a0-8b09-459f-9213-40c95da2c647	\N	true_false	Cây Ngô Đồng được trồng nhiều trong Đại Nội Huế.	["Đúng", "Sai"]	Đúng	\N	1	Cây Ngô Đồng là loài cây đặc trưng của cung đình Huế, được trồng nhiều ở các khu vực trang trọng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
3eecc316-3070-4e21-810e-b6782dd6091d	65b59624-9f96-4713-83e5-ebb5505d61ca	\N	multiple_choice	Kỳ Nam là sản phẩm đặc biệt của loài cây nào?	["A. Cây Gỗ Sưa", "B. Cây Dó Bầu", "C. Cây Quế", "D. Cây Tùng"]	B. Cây Dó Bầu	\N	2	Kỳ Nam và Trầm hương đều được hình thành từ cây Dó Bầu bị thương, nhưng Kỳ Nam hiếm và quý hơn nhiều.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
c9fb7f8d-6576-4ce7-bee7-ae6526e295a9	65b59624-9f96-4713-83e5-ebb5505d61ca	\N	true_false	Kỳ Nam có giá trị thấp hơn Trầm hương.	["Đúng", "Sai"]	Sai	\N	1	Sai. Kỳ Nam là loại trầm hương phẩm chất cao nhất, quý hiếm và đắt giá hơn Trầm hương thường rất nhiều.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
db15e400-76a7-44af-9050-5d4fb996c606	2ffaa5e2-8f5b-49a3-ae8a-4c28cc9ca106	\N	multiple_choice	Lúa nếp thường được dùng để làm món gì trong dịp Tết?	["A. Cơm tẻ", "B. Bánh chưng, bánh tét", "C. Bún", "D. Phở"]	B. Bánh chưng, bánh tét	\N	1	Lúa nếp là nguyên liệu chính để gói bánh chưng, bánh tét - những món ăn cổ truyền không thể thiếu trong dịp Tết.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
670cdf2d-40e2-4b49-9b54-cf8f4ef79eb2	2ffaa5e2-8f5b-49a3-ae8a-4c28cc9ca106	\N	multiple_choice	Đặc tính nổi bật của gạo nếp khi nấu chín là gì?	["A. Khô và rời rạc", "B. Dẻo và dính", "C. Cứng và giòn", "D. Chua và cay"]	B. Dẻo và dính	\N	1	Gạo nếp chứa nhiều amylopectin nên khi nấu chín rất dẻo và dính, tượng trưng cho sự gắn kết.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
43affdba-dbbe-4553-b69c-1b21df1c474c	b5772322-b791-4fa2-88fa-852bfb254bc9	\N	multiple_choice	Tại sao trái bòn bon được vua ban tên là 'Nam Trân'?	["A. Vì nó có hình dáng giống viên ngọc", "B. Vì nó từng cứu đói chúa Nguyễn Ánh", "C. Vì nó rất đắt tiền", "D. Vì nó chỉ mọc ở phương Nam"]	B. Vì nó từng cứu đói chúa Nguyễn Ánh	\N	2	Vua Gia Long đặt tên Nam Trân (ngọc quý phương Nam) để tri ân loài quả đã giúp ông cầm cự trong lúc lẩn trốn quân Tây Sơn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
abaa5b89-ffe0-48ee-8006-fc12863368c9	b5772322-b791-4fa2-88fa-852bfb254bc9	\N	true_false	Bòn bon là loài cây thân leo.	["Đúng", "Sai"]	Sai	\N	2	Bòn bon là loài cây thân gỗ, quả mọc thành chùm trên thân và cành, không phải cây thân leo.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
48758088-e780-496f-af2b-3c93b449e12e	6984b326-0c85-43a4-9a4d-dabbeb7e13ba	\N	multiple_choice	Câu thơ 'Gần bùn mà chẳng hôi tanh mùi bùn' nói về loài hoa nào?	["A. Hoa Hồng", "B. Hoa Cúc", "C. Hoa Sen", "D. Hoa Đào"]	C. Hoa Sen	\N	1	Đây là câu thơ nổi tiếng ca ngợi phẩm chất thanh cao, tinh khiết của hoa sen.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
b4fc0cac-eb8e-43e8-851f-ec7f1dbce75b	6984b326-0c85-43a4-9a4d-dabbeb7e13ba	\N	multiple_choice	Trong Phật giáo, hoa sen tượng trưng cho điều gì?	["A. Sự giàu sang", "B. Sự giác ngộ và giải thoát", "C. Sức mạnh chiến tranh", "D. Tình yêu đôi lứa"]	B. Sự giác ngộ và giải thoát	\N	2	Hoa sen là biểu tượng của Phật giáo, đại diện cho trí tuệ, sự giác ngộ và sự vươn lên khỏi khổ đau.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
10f1ae99-6458-44b1-b023-2360af323a57	5068f86d-bfc1-41d6-b8ac-0073ff897b72	\N	multiple_choice	Lông chim công thường được dùng để làm gì trong triều đình xưa?	["A. Làm chổi quét nhà", "B. Trang trí mũ quan lại", "C. Làm tên bắn", "D. Làm bút viết"]	B. Trang trí mũ quan lại	\N	1	Lông công được cắm trên mũ của các quan lại để phân biệt phẩm cấp và tăng vẻ uy nghiêm.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f8719090-71d0-4bf7-8bd4-fb98bf120194	5068f86d-bfc1-41d6-b8ac-0073ff897b72	\N	true_false	Chỉ có chim công mái mới có bộ đuôi sặc sỡ.	["Đúng", "Sai"]	Sai	\N	1	Sai. Chim công trống mới là con có bộ đuôi dài và sặc sỡ để thu hút bạn tình.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
90c581b4-c1c4-4588-b119-494fac26fbe4	80ffc309-19f9-42ee-89fe-256c6b2ca88e	\N	true_false	Mai đồi mồi xưa kia thường được dùng để làm đồ trang sức, mỹ nghệ.	["Đúng", "Sai"]	Đúng	\N	1	Đúng, mai đồi mồi có vân đẹp, được chế tác thành lược, trâm, hộp... rất quý giá.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f4cea579-af5f-49a8-b357-d322b5f1175f	0b7a95ae-de5f-4e5b-a6f4-ff673d93ec2d	\N	multiple_choice	Nam Hải trên Nhân Đỉnh chỉ vùng biển nào?	["A. Vịnh Bắc Bộ", "B. Biển miền Trung", "C. Vùng biển phía Nam (Hà Tiên, Phú Quốc...)", "D. Biển Hồ"]	C. Vùng biển phía Nam (Hà Tiên, Phú Quốc...)	\N	2	Nam Hải là tên gọi chỉ vùng biển phía Nam của tổ quốc, nơi có nhiều đảo và tài nguyên phong phú.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ba6d722e-46ff-468a-824c-778430f619f8	0b7a95ae-de5f-4e5b-a6f4-ff673d93ec2d	\N	true_false	Việc khắc các vùng biển lên Cửu Đỉnh là để khẳng định chủ quyền quốc gia.	["Đúng", "Sai"]	Đúng	\N	1	Các hình ảnh biển (Đông Hải, Nam Hải, Tây Hải) trên Cửu Đỉnh là tuyên bố chủ quyền lãnh thổ và lãnh hải rõ ràng của triều Nguyễn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
6fb2457a-7e29-43f1-92c5-aa7ad75a9949	c6a51d0e-69d6-4b9f-8dee-48a51d46e39d	\N	multiple_choice	Tên 'Phổ Lợi' của con sông có ý nghĩa gì?	["A. Dòng sông lớn", "B. Lợi ích rộng khắp", "C. Dòng sông đẹp", "D. Chiến thắng vĩ đại"]	B. Lợi ích rộng khắp	\N	2	Phổ là rộng khắp, Lợi là lợi ích. Phổ Lợi là mang lại lợi ích cho đông đảo người dân.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f011b9f9-6b4d-466e-939b-f8cb982d7814	c6a51d0e-69d6-4b9f-8dee-48a51d46e39d	\N	multiple_choice	Sông Phổ Lợi là sông tự nhiên hay nhân tạo?	["A. Sông tự nhiên", "B. Sông đào (nhân tạo)", "C. Suối nguồn", "D. Một nhánh của sông Mê Kông"]	B. Sông đào (nhân tạo)	\N	2	Sông Phổ Lợi là công trình thủy lợi do vua Minh Mạng cho đào để phục vụ thoát lũ và giao thông.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
7d169ba7-d995-4b25-a622-07846644d518	c2c9f700-fcf1-4dc1-b9c5-58a9ce97f4b3	\N	multiple_choice	Mặt trăng (Nguyệt) trên Nhân Đỉnh đối ứng với hình tượng nào trên Cao Đỉnh?	["A. Các vì sao", "B. Mặt trời (Nhật)", "C. Mây", "D. Sấm chớp"]	B. Mặt trời (Nhật)	\N	1	Sự đối ứng Nhật (Cao Đỉnh) - Nguyệt (Nhân Đỉnh) thể hiện triết lý cân bằng Âm Dương.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
69dc2e78-8a3d-454f-a77a-5e22b29f1918	c2c9f700-fcf1-4dc1-b9c5-58a9ce97f4b3	\N	multiple_choice	Trong văn hóa, Mặt trăng thường đại diện cho yếu tố nào?	["A. Dương khí, nóng bức", "B. Âm khí, dịu dàng", "C. Chiến tranh", "D. Sự hủy diệt"]	B. Âm khí, dịu dàng	\N	1	Mặt trăng là Thái âm, đại diện cho tính nữ, sự mát mẻ, dịu dàng và ban đêm.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
424bfc98-97d3-402a-aeac-77e60f55a4e5	c75f919c-904d-483b-83ec-4debdb8e076f	\N	multiple_choice	Sông Hương chảy qua thành phố nào?	["A. Hà Nội", "B. Đà Nẵng", "C. Huế", "D. Hội An"]	C. Huế	\N	1	Sông Hương là biểu tượng gắn liền với thành phố Huế và quần thể di tích Cố đô.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ad50c9bb-dfe2-48f0-bfbd-817e811d5437	c75f919c-904d-483b-83ec-4debdb8e076f	\N	true_false	Sông Hương được coi là yếu tố 'Minh đường' trong phong thủy Kinh thành Huế.	["Đúng", "Sai"]	Đúng	\N	2	Trong phong thủy, sông Hương đóng vai trò là yếu tố tụ thủy (minh đường) trước mặt Kinh thành, mang lại vượng khí.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0c8ccd3f-000c-4fb2-bfac-f78062f92b58	d469214a-16e7-4120-ad15-7dece40629da	\N	multiple_choice	Trong phong thủy Kinh thành Huế, núi Ngự Bình đóng vai trò gì?	["A. Hậu chẩm (gối đầu)", "B. Tiền án (bình phong)", "C. Tả thanh long", "D. Hữu bạch hổ"]	B. Tiền án (bình phong)	\N	2	Núi Ngự Bình là bức bình phong tự nhiên che chắn phía trước Kinh thành.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
91541f86-30f4-425c-add7-49c6672c93d4	d469214a-16e7-4120-ad15-7dece40629da	\N	multiple_choice	Cặp địa danh nào là biểu tượng của Huế?	["A. Hồ Gươm - Tháp Rùa", "B. Sông Hương - Núi Ngự", "C. Chợ Bến Thành - Sông Sài Gòn", "D. Vịnh Hạ Long - Hòn Trống Mái"]	B. Sông Hương - Núi Ngự	\N	1	Sông Hương và Núi Ngự là hai danh thắng không thể tách rời khi nhắc đến Huế.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
b3ea3838-3615-4151-8fbe-8ac3cc4b650d	81f3deaa-51eb-420d-bf4f-4c99584662ef	\N	multiple_choice	Nhân Ngư (Cá người) thực chất là loài động vật nào?	["A. Cá mập", "B. Cá voi xanh", "C. Bò biển (Dugong)", "D. Hải cẩu"]	C. Bò biển (Dugong)	\N	2	Nhân Ngư là tên gọi cổ của loài Bò biển (Dugong) do dáng vẻ khi cho con bú giống người.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
744064e0-2c79-4070-a4bc-07c15d0d05c1	81f3deaa-51eb-420d-bf4f-4c99584662ef	\N	true_false	Nhân Ngư là loài động vật ăn thịt hung dữ.	["Đúng", "Sai"]	Sai	\N	1	Sai. Nhân Ngư (Bò biển) là loài ăn thực vật (cỏ biển) và rất hiền lành.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
8e714c3a-88e3-4a72-bde9-224e97c7734e	c947cdd0-5095-45af-9abe-43762e47dbde	\N	multiple_choice	Rau hẹ (Cửu) có ý nghĩa biểu tượng gì nhờ đồng âm?	["A. Sự giàu sang", "B. Sự trường cửu, lâu dài", "C. Sự thông minh", "D. Sự dũng cảm"]	B. Sự trường cửu, lâu dài	\N	2	Chữ Cửu (rau hẹ) đồng âm với Cửu (số 9, lâu dài), nên tượng trưng cho sự bền vững.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
dc234484-b1ff-4310-bec1-d018385961dc	c947cdd0-5095-45af-9abe-43762e47dbde	\N	true_false	Rau hẹ là một vị thuốc trong đông y.	["Đúng", "Sai"]	Đúng	\N	1	Đúng, hẹ có tính ấm, được dùng để chữa ho, cảm lạnh và bổ thận dương.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
76261514-3caa-480e-9f07-9eb3fda188ea	1ff69a0a-4718-4f51-97f3-0df32387a8e4	\N	multiple_choice	Lâu Thuyền là loại thuyền gì?	["A. Thuyền đánh cá nhỏ", "B. Thuyền chiến có lầu cao", "C. Bè tre", "D. Thuyền độc mộc"]	B. Thuyền chiến có lầu cao	\N	1	Lâu Thuyền là thuyền lớn có dựng lầu (lâu) để quan sát và chỉ huy chiến đấu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
8b24303d-a0d6-4b6c-b536-ede7a87230dd	1ff69a0a-4718-4f51-97f3-0df32387a8e4	\N	true_false	Lâu Thuyền di chuyển rất nhanh nhờ buồm lớn.	["Đúng", "Sai"]	Sai	\N	2	Sai. Lâu Thuyền to nặng, di chuyển thường chậm chạp, chủ yếu dùng trong chỉ huy hoặc phòng thủ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
69561a23-d46d-4474-8e47-2215610880fa	9f26573f-3fef-4130-884e-b2a10664513c	\N	multiple_choice	Điểm đặc biệt của Luân Xa Pháo so với thần công thường là gì?	["A. Bắn ra lửa", "B. Có bánh xe để di chuyển", "C. Làm bằng vàng", "D. Chỉ dùng để trưng bày"]	B. Có bánh xe để di chuyển	\N	1	Luân Xa là xe có bánh, giúp pháo cơ động trên chiến trường.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
68abb11c-0e3b-465e-98ef-e6d499f02ce0	9f26573f-3fef-4130-884e-b2a10664513c	\N	true_false	Luân Xa Pháo là vũ khí cố định, chỉ đặt trên thành.	["Đúng", "Sai"]	Sai	\N	1	Sai. Ưu điểm chính của nó là khả năng di chuyển (cơ động) nhờ bánh xe.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ecd48d14-7c37-420c-8445-db1c1382c35b	9a7cac22-df1b-4150-9db3-a3420b48fd9f	\N	multiple_choice	Trong tự nhiên, con báo nổi tiếng nhất về khả năng gì?	["A. Bơi lội", "B. Tốc độ và leo trèo", "C. Đào hang", "D. Bay lượn"]	B. Tốc độ và leo trèo	\N	1	Báo là loài chạy rất nhanh và leo cây rất giỏi.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e740d55e-b50c-4c84-926d-e3a6eebcc48c	9a7cac22-df1b-4150-9db3-a3420b48fd9f	\N	multiple_choice	Thành ngữ 'Quân tử biến như báo' có ý nghĩa gì?	["A. Người quân tử hung dữ như báo", "B. Người quân tử thay đổi tốt đẹp, rõ rệt", "C. Người quân tử chạy nhanh như báo", "D. Người quân tử thích mặc áo da báo"]	B. Người quân tử thay đổi tốt đẹp, rõ rệt	\N	3	Câu này ý nói người quân tử khi sửa mình thì thay đổi rõ rệt, rực rỡ như hoa văn trên da báo mới thay lông.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
01ebbbef-ff0e-45b2-a611-760519787468	80ffc309-19f9-42ee-89fe-256c6b2ca88e	\N	multiple_choice	Đại Mạo là tên gọi khác của con vật nào?	["A. Con Ba ba", "B. Con Đồi mồi", "C. Con Cua huỳnh đế", "D. Con Cá ngựa"]	B. Con Đồi mồi	\N	1	Đại Mạo là tên Hán Việt của loài rùa biển Đồi mồi.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
5fdd49fb-6133-405c-a3b4-14d3a7855d65	645bd72c-715f-448e-8db2-131340664238	\N	multiple_choice	Chương Đỉnh được dành để tôn vinh vị vua nào?	["A. Vua Minh Mạng", "B. Vua Thiệu Trị", "C. Vua Tự Đức", "D. Vua Khải Định"]	B. Vua Thiệu Trị	\N	1	Chương Đỉnh là đỉnh thứ ba, ứng với thế thứ thứ ba là vua Thiệu Trị.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
b1b0695f-3d82-4ab6-8388-289b3f14979e	645bd72c-715f-448e-8db2-131340664238	\N	multiple_choice	Ý nghĩa của chữ 'Chương' trong tên đỉnh là gì?	["A. Sự giàu có", "B. Sự rực rỡ, sáng tỏ, văn minh", "C. Sức mạnh vô địch", "D. Sự trường thọ"]	B. Sự rực rỡ, sáng tỏ, văn minh	\N	1	'Chương' có nghĩa là sáng sủa, rực rỡ (như trong từ chương), biểu thị cho sự văn minh và lề lối.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
3a3b9f9b-1067-4c81-9153-bb68fd4e3fa8	31832650-6463-405a-9ce3-8ac267c1c9da	\N	multiple_choice	Hoa nhài (Mạt Lị) thường được dùng để làm gì phổ biến nhất ở Việt Nam?	["A. Nấu canh", "B. Ướp trà", "C. Làm thuốc trừ sâu", "D. Nhuộm vải"]	B. Ướp trà	\N	1	Trà nhài là thức uống tao nhã, phổ biến và được yêu thích nhờ hương thơm đặc trưng của hoa.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
54ca1856-d1c8-4f2a-960d-fac3c661447c	31832650-6463-405a-9ce3-8ac267c1c9da	\N	true_false	Hoa nhài có màu đỏ rực rỡ.	["Đúng", "Sai"]	Sai	\N	1	Hoa nhài (Jasminum sambac) đặc trưng bởi màu trắng tinh khôi.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f2265022-7ead-461e-a162-ad9263d1dff7	dac97c73-f54d-4208-b262-b19034d979d3	\N	multiple_choice	Am La là tên gọi khác của loại trái cây nào?	["A. Trái Mít", "B. Trái Xoài", "C. Trái Ổi", "D. Trái Cam"]	B. Trái Xoài	\N	1	Am La là tên chữ Hán chỉ cây Xoài.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
bb8b9b06-3a1c-49e7-b6ae-1440f5ce57af	dac97c73-f54d-4208-b262-b19034d979d3	\N	true_false	Xoài là loại cây ôn đới, chỉ mọc ở xứ lạnh.	["Đúng", "Sai"]	Sai	\N	1	Xoài là cây ăn quả nhiệt đới điển hình, thích hợp với khí hậu nóng ẩm.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e9f1aa2c-68de-4ae5-a195-7d82c2154166	dc61f122-27eb-4f8c-84df-55c697f1eb12	\N	multiple_choice	Đậu khấu chủ yếu được sử dụng để làm gì?	["A. Làm thuốc và gia vị", "B. Làm đồ gỗ", "C. Dệt vải", "D. Làm giấy"]	A. Làm thuốc và gia vị	\N	1	Đậu khấu nổi tiếng với tính ấm, mùi thơm, dùng làm thuốc chữa bệnh tiêu hóa và gia vị nấu ăn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
95423198-9374-4ce5-972e-a28ac972f779	dc61f122-27eb-4f8c-84df-55c697f1eb12	\N	multiple_choice	Thuật ngữ 'tuổi đậu khấu' dùng để chỉ ai?	["A. Người già trên 80 tuổi", "B. Thiếu nữ 13-14 tuổi", "C. Trẻ sơ sinh", "D. Phụ nữ trung niên"]	B. Thiếu nữ 13-14 tuổi	\N	3	Xuất phát từ thơ Đường, 'đậu khấu sao đầu nhị nguyệt sơ', ví thiếu nữ trẻ đẹp như nụ hoa đậu khấu đầu tháng hai.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
c4aea14d-fe30-4154-bc24-a5d5f79e897c	15bb211a-d1df-47df-8409-ea51d4cbb899	\N	multiple_choice	Đậu xanh (Lục đậu) có tính chất gì nổi bật trong đông y?	["A. Tính nóng, gây nhiệt", "B. Tính mát, thanh nhiệt giải độc", "C. Tính độc, không ăn được", "D. Làm tăng huyết áp"]	B. Tính mát, thanh nhiệt giải độc	\N	1	Đậu xanh được biết đến rộng rãi với tác dụng làm mát cơ thể, giải độc tố.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
8387443e-77b3-4e87-8a55-67efd540259f	15bb211a-d1df-47df-8409-ea51d4cbb899	\N	true_false	Giá đỗ thường được làm từ hạt đậu xanh.	["Đúng", "Sai"]	Đúng	\N	1	Đậu xanh là nguyên liệu phổ biến nhất để ủ làm giá đỗ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
2b256629-79a6-4704-bb60-802fe20222aa	d4d34f66-7825-4cfc-a5f3-7b6ca7dd5e29	\N	multiple_choice	Củ kiệu thường được chế biến thành món gì trong ngày Tết?	["A. Luộc", "B. Muối chua ngọt", "C. Nướng", "D. Hấp"]	B. Muối chua ngọt	\N	1	Củ kiệu muối chua ngọt là món ăn kèm truyền thống không thể thiếu trong dịp Tết.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
2ff116df-ba77-43da-aad0-fd87f40d6a40	d4d34f66-7825-4cfc-a5f3-7b6ca7dd5e29	\N	multiple_choice	Cây kiệu thuộc họ thực vật nào?	["A. Họ Lúa", "B. Họ Hành tỏi", "C. Họ Cải", "D. Họ Đậu"]	B. Họ Hành tỏi	\N	2	Kiệu (Allium chinense) thuộc chi Hành (Allium), cùng họ với hành, tỏi, hẹ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e60bb7f2-5241-4b2c-a172-0597812df620	0c986397-4987-4b29-afea-42355d79d00a	\N	multiple_choice	Gà trống được người xưa ca ngợi là có mấy đức tính (Ngũ đức)?	["A. 3 đức", "B. 4 đức", "C. 5 đức", "D. 6 đức"]	C. 5 đức	\N	2	Ngũ đức của gà trống gồm: Văn, Võ, Dũng, Nhân, Tín.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
5392ea6a-1d9d-403d-905e-5d372edeb20c	0c986397-4987-4b29-afea-42355d79d00a	\N	true_false	Tiếng gà gáy được coi là tín hiệu xua đuổi tà ma, gọi mặt trời lên.	["Đúng", "Sai"]	Đúng	\N	1	Dân gian tin rằng ma quỷ sợ tiếng gà gáy sáng vì đó là lúc dương khí thịnh, mặt trời mọc.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0510cacb-df23-4bd1-a70d-9fa882e9385e	d71a8ff0-be8c-4ecb-8e4c-5a6308fa8edb	\N	multiple_choice	Tên gọi khác phổ biến của Thượng Sơn là gì?	["A. Núi Ngự Bình", "B. Núi Bạch Mã", "C. Núi Kim Phụng", "D. Núi Thần Đinh"]	C. Núi Kim Phụng	\N	2	Thượng Sơn chính là núi Kim Phụng, ngọn núi cao và đẹp nổi tiếng ở Huế.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
a61cc095-d646-468c-be1e-2ef1cc6e7c3b	d71a8ff0-be8c-4ecb-8e4c-5a6308fa8edb	\N	true_false	Núi Kim Phụng được coi là ngọn chủ sơn trong phong thủy Kinh thành Huế.	["Đúng", "Sai"]	Đúng	\N	2	Đúng, với độ cao và vị thế của mình, nó được xem là ngọn núi chủ, trấn giữ long mạch.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e1b4b2d1-1836-4a08-ab6f-b9f2fcef26d9	8aa3cbbd-b36e-4ab0-8167-979d2562c5de	\N	multiple_choice	Sông Lợi Nông còn có tên gọi dân gian quen thuộc nào?	["A. Sông Hương", "B. Sông An Cựu", "C. Sông Bạch Đằng", "D. Sông Như Ý"]	B. Sông An Cựu	\N	1	Sông An Cựu là tên gọi phổ biến của sông Lợi Nông.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
93ef59fb-e388-41ce-bf3b-ef20d0cabc6e	8aa3cbbd-b36e-4ab0-8167-979d2562c5de	\N	multiple_choice	Câu ca dao nào nói về đặc điểm lạ của sông An Cựu?	["A. Nước chảy đôi dòng", "B. Nắng đục mưa trong", "C. Bên lở bên bồi", "D. Sóng sau xô sóng trước"]	B. Nắng đục mưa trong	\N	2	Đặc điểm 'nắng đục mưa trong' là nét độc đáo gắn liền với tên tuổi sông An Cựu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
1cefd17e-e820-446c-a5df-98ceb191e169	43e66fe4-29b4-49bd-b492-4f5823a34b77	\N	multiple_choice	Ngũ Tinh bao gồm những hành tinh nào?	["A. Trái Đất, Mặt Trăng, Mặt Trời...", "B. Kim, Mộc, Thủy, Hỏa, Thổ", "C. Sao Bắc Đẩu, Nam Tào...", "D. Thiên Vương, Hải Vương..."]	B. Kim, Mộc, Thủy, Hỏa, Thổ	\N	1	Ngũ Tinh tương ứng với 5 hành tinh trong hệ mặt trời gắn với thuyết Ngũ Hành.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ec2cbcb6-7f3a-4e25-81f7-c6338c587706	43e66fe4-29b4-49bd-b492-4f5823a34b77	\N	true_false	Người xưa quan sát Ngũ Tinh để dự báo điềm lành dữ.	["Đúng", "Sai"]	Đúng	\N	1	Thiên văn (Chiêm tinh) là công việc quan trọng của Khâm Thiên Giám để tham mưu cho nhà vua.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
4c9164b9-2c37-4b65-acdb-e04a57b84a35	e7fd33e8-7cae-4557-ba91-a1a6f4641e69	\N	multiple_choice	Sông Gianh (Linh Giang) gắn liền với giai đoạn lịch sử nào?	["A. Kháng chiến chống Pháp", "B. Trịnh - Nguyễn phân tranh", "C. Nhà Trần đánh quân Nguyên", "D. Khởi nghĩa Lam Sơn"]	B. Trịnh - Nguyễn phân tranh	\N	2	Sông Gianh là ranh giới tự nhiên chia cắt Đàng Trong và Đàng Ngoài thời Trịnh - Nguyễn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
45f4ba43-43bd-4d57-851f-4f1b598cb078	e7fd33e8-7cae-4557-ba91-a1a6f4641e69	\N	multiple_choice	Sông Gianh nằm ở tỉnh nào?	["A. Nghệ An", "B. Hà Tĩnh", "C. Quảng Bình", "D. Quảng Trị"]	C. Quảng Bình	\N	1	Sông Gianh là con sông lớn nhất chảy qua địa phận tỉnh Quảng Bình.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
9fd775d0-8b81-403e-8aec-58a52e02d9ea	f405213c-8093-4196-8479-95c8851d6f95	\N	multiple_choice	Tây Hải trên Chương Đỉnh chỉ vùng biển nào?	["A. Biển Vũng Tàu", "B. Vùng biển Tây Nam (Vịnh Thái Lan)", "C. Biển Đà Nẵng", "D. Biển Hải Phòng"]	B. Vùng biển Tây Nam (Vịnh Thái Lan)	\N	2	Tây Hải là vùng biển phía Tây Nam tổ quốc, thuộc địa phận Kiên Giang, Cà Mau.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f2af5cdc-9593-444e-a4f2-c40c2e67eb7c	f405213c-8093-4196-8479-95c8851d6f95	\N	true_false	Biển Tây thường có sóng to gió lớn hơn Biển Đông.	["Đúng", "Sai"]	Sai	\N	2	Biển Tây nằm trong vịnh, được che chắn nên thường yên bình, sóng nhỏ hơn Biển Đông.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
323e8223-be8d-42e2-9542-17506e1a911a	9edc5858-1b2a-404a-bf9a-fe4b70f3eb62	\N	multiple_choice	Thuận Mộc thường được cho là loại cây gỗ quý nào?	["A. Gỗ Lim", "B. Gỗ Sưa (Huỳnh đàn)", "C. Gỗ Thông", "D. Gỗ Xoan"]	B. Gỗ Sưa (Huỳnh đàn)	\N	2	Thuận Mộc tương ứng với cây gỗ Sưa, loại gỗ quý có vân đẹp và giá trị rất cao.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
b55e1bf8-ef1d-4f80-b741-2bf7adbf8bb8	9edc5858-1b2a-404a-bf9a-fe4b70f3eb62	\N	multiple_choice	Đặc điểm nổi bật của gỗ sưa là gì?	["A. Rất mềm, dễ gãy", "B. Lõi đỏ, vân đẹp, mùi thơm nhẹ", "C. Màu trắng, không mùi", "D. Rất nhẹ như xốp"]	B. Lõi đỏ, vân đẹp, mùi thơm nhẹ	\N	1	Gỗ sưa quý bởi lõi màu đỏ thẫm, vân gỗ như mây và mùi hương dễ chịu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
d89973d7-015c-4558-a613-faaebfa76b56	7eb70120-14da-4020-85d5-9aea2501c838	\N	multiple_choice	Câu 'Hùm tha sấu bắt' nói về sự nguy hiểm của vùng đất nào xưa kia?	["A. Vùng núi Tây Bắc", "B. Vùng đồng bằng sông Hồng", "C. Vùng đất mới Nam Bộ", "D. Kinh thành Huế"]	C. Vùng đất mới Nam Bộ	\N	1	Nam Bộ xưa kia nhiều rừng rậm và sông ngòi, nơi hổ (hùm) và cá sấu hoành hành.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
3d7e57e2-e1d9-4aac-93b7-c9387aadfe52	7eb70120-14da-4020-85d5-9aea2501c838	\N	true_false	Ngạc Ngư là loài cá hiền lành, ăn cỏ.	["Đúng", "Sai"]	Sai	\N	1	Ngạc Ngư (Cá sấu) là loài ăn thịt hung dữ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
6c0f15e6-1689-4fd2-ade3-5ba526d1b927	e82b3077-b323-4835-a4d9-da22e28eccd5	\N	multiple_choice	Ưu điểm lớn nhất của thuyền Mông Đồng là gì?	["A. Chở được rất nhiều hàng hóa", "B. Tốc độ nhanh và cơ động", "C. Chịu được sóng thần", "D. Có lầu cao như pháo đài"]	B. Tốc độ nhanh và cơ động	\N	1	Thuyền Mông Đồng được thiết kế thon dài, nhiều chèo để đạt tốc độ cao và xoay trở linh hoạt.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
1e3fd0b2-e093-401e-8aa4-842eb8b6ba00	e82b3077-b323-4835-a4d9-da22e28eccd5	\N	multiple_choice	Thuyền Mông Đồng thường được dùng cho lực lượng nào?	["A. Bộ binh", "B. Thủy quân", "C. Kỵ binh", "D. Tượng binh"]	B. Thủy quân	\N	1	Đây là phương tiện chiến đấu chủ lực của lực lượng thủy quân.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
26f5a463-610f-47c6-9827-dceeba10593e	7f091ed9-06f5-46a7-a030-6341c0d293f8	\N	multiple_choice	Điểu Thương là loại vũ khí gì?	["A. Cung nỏ", "B. Súng hỏa mai cầm tay", "C. Đại bác", "D. Giáo mác"]	B. Súng hỏa mai cầm tay	\N	1	Điểu thương là loại súng trường nòng dài, dùng thuốc súng, trang bị cho cá nhân.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ee257ae5-0011-4fb7-890b-716a3781e87a	7f091ed9-06f5-46a7-a030-6341c0d293f8	\N	true_false	Quân đội nhà Nguyễn được trang bị súng hỏa mai rất phổ biến.	["Đúng", "Sai"]	Đúng	\N	1	Nhà Nguyễn rất chú trọng hỏa khí, tỷ lệ lính dùng súng trong quân đội khá cao.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
059f5124-55bb-49ec-95ce-530785614daa	5f05c475-8e53-4554-a667-c841614d78ef	\N	multiple_choice	Sừng tê giác ngày xưa được tin là có công dụng gì?	["A. Làm đẹp da", "B. Giải độc và trừ tà", "C. Tăng trí nhớ", "D. Giúp bay lượn"]	B. Giải độc và trừ tà	\N	1	Chén làm từ sừng tê (tê giác bôi) được vua chúa dùng để uống rượu vì tin rằng nó sẽ sủi bọt hoặc đổi màu nếu rượu có độc.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
874e12a3-708d-4a77-be73-635f292db485	5f05c475-8e53-4554-a667-c841614d78ef	\N	true_false	Tê giác hiện nay vẫn còn sinh sống nhiều trong rừng Việt Nam.	["Đúng", "Sai"]	Sai	\N	1	Tê giác một sừng Việt Nam đã được công bố tuyệt chủng vào năm 2010. Hình ảnh trên đỉnh là ký ức về quá khứ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
55852e9c-e32a-45e2-8ec9-5c2df1866a4a	883b8388-7f3d-466e-ba88-9659dfbe3b4b	\N	multiple_choice	Linh Quy (Rùa) nằm trong nhóm nào?	["A. Ngũ hành", "B. Tứ linh", "C. Tam đa", "D. Tứ quý"]	B. Tứ linh	\N	1	Tứ linh gồm Long, Lân, Quy, Phụng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
02f6bb29-2816-4fb5-a975-621c45381097	883b8388-7f3d-466e-ba88-9659dfbe3b4b	\N	multiple_choice	Hình tượng rùa đội bia đá thường thấy ở đâu?	["A. Chợ", "B. Văn Miếu (nơi thờ Khổng Tử)", "C. Bến cảng", "D. Sân vận động"]	B. Văn Miếu (nơi thờ Khổng Tử)	\N	1	Rùa đội bia tiến sĩ trong Văn Miếu để vinh danh những người đỗ đạt, thể hiện sự trường tồn của tri thức.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
01b21ca8-3a60-4bf7-a007-fd9f263e6135	e823f581-e98e-412e-a901-baf5918ed599	\N	multiple_choice	Anh Đỉnh ứng với thụy hiệu của vị vua nào?	["A. Vua Minh Mạng", "B. Vua Thiệu Trị", "C. Vua Tự Đức", "D. Vua Đồng Khánh"]	C. Vua Tự Đức	\N	1	Anh Đỉnh là đỉnh thứ tư, tương ứng với vua Tự Đức (Dực Tông Anh Hoàng đế).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
54fab8be-205b-4733-b41b-2ac8e42a8fc1	e823f581-e98e-412e-a901-baf5918ed599	\N	multiple_choice	Chữ 'Anh' trong tên đỉnh có ý nghĩa gì?	["A. Màu đỏ", "B. Tài năng xuất chúng, tinh hoa", "C. Sự giàu có", "D. Sức mạnh cơ bắp"]	B. Tài năng xuất chúng, tinh hoa	\N	1	Anh trong 'anh hùng', 'tinh anh', chỉ sự vượt trội về tài năng và đức độ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e25e8242-f718-4139-baa8-f7a419e7cebe	e823f581-e98e-412e-a901-baf5918ed599	\N	true_false	Vua Tự Đức là vị vua có thời gian trị vì ngắn nhất triều Nguyễn.	["Đúng", "Sai"]	Sai	\N	1	Sai. Vua Tự Đức là vua trị vì lâu nhất triều Nguyễn (36 năm, từ 1847-1883).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
d988ca86-d85e-4551-aa27-f5165fefc3ef	f043389a-e5aa-4092-9cba-4ede2943e761	\N	multiple_choice	Con ve sầu (Thiền) thường tượng trưng cho điều gì trong văn hóa cổ?	["A. Sự lười biếng", "B. Sự tái sinh và thanh khiết", "C. Sự ồn ào", "D. Sự phá hoại mùa màng"]	B. Sự tái sinh và thanh khiết	\N	2	Nhờ đặc tính lột xác và chỉ uống sương, ve sầu được coi là biểu tượng của sự tái sinh và thanh cao.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
eb23f59b-1fb3-48c5-b9c7-1567e9d8ba19	f043389a-e5aa-4092-9cba-4ede2943e761	\N	true_false	Tất cả ve sầu đều biết kêu.	["Đúng", "Sai"]	Sai	\N	1	Chỉ có ve sầu đực mới có bộ phận phát ra tiếng kêu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
d79726d9-cfcb-4fe8-b643-91a3af15ec0f	c7de7984-89a9-456c-ad39-eb28a0625771	\N	multiple_choice	Cây Tô Hợp còn có tên gọi dân gian nào khác?	["A. Cây Bàng", "B. Cây Sau Sau", "C. Cây Đa", "D. Cây Gạo"]	B. Cây Sau Sau	\N	2	Sau Sau là tên gọi phổ biến của cây Tô Hợp ở các vùng núi phía Bắc Việt Nam.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
fc9047e4-7f0f-4ab3-a3a5-d0860980dfb3	c7de7984-89a9-456c-ad39-eb28a0625771	\N	multiple_choice	Nhựa cây Tô Hợp có công dụng gì?	["A. Dán gỗ", "B. Làm thuốc và hương liệu", "C. Làm sơn mài", "D. Làm cao su"]	B. Làm thuốc và hương liệu	\N	2	Nhựa cây (Tô hợp hương) rất thơm, là vị thuốc quý và nguyên liệu làm hương.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
bb816bb0-8606-4224-86ad-e58df2e311a4	257959d8-ce69-4701-99a7-252c5e02eacb	\N	multiple_choice	Uất Kim là tên gọi một bộ phận của cây gì?	["A. Cây Gừng", "B. Cây Nghệ", "C. Cây Riềng", "D. Cây Sả"]	B. Cây Nghệ	\N	1	Uất kim là tên đông y chỉ phần củ con (rễ củ) của cây nghệ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
9a67a6b2-1987-4d85-b18e-59093d42c71a	257959d8-ce69-4701-99a7-252c5e02eacb	\N	true_false	Nghệ chỉ được dùng làm gia vị nấu ăn, không có tác dụng chữa bệnh.	["Đúng", "Sai"]	Sai	\N	1	Sai. Nghệ là vị thuốc nổi tiếng chữa đau dạ dày, làm lành sẹo và đẹp da.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e93092a0-6add-43ee-aee8-bd4f89a81924	4ba1f6ce-ac67-4389-87a3-4d44b09486a9	\N	multiple_choice	Trong sự tích Trầu Cau, cây cau là hóa thân của ai?	["A. Người vợ", "B. Người anh (Tân)", "C. Người em (Lang)", "D. Quan huyện"]	B. Người anh (Tân)	\N	2	Trong sự tích, người anh chết hóa thành cây cau, người em hóa đá vôi, người vợ hóa dây trầu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
c3cc3cda-6a98-4a45-8950-7fd95eb26e04	4ba1f6ce-ac67-4389-87a3-4d44b09486a9	\N	multiple_choice	Cây cau thường được trồng ở vị trí nào trong khuôn viên nhà truyền thống?	["A. Sau nhà", "B. Trước nhà", "C. Bên hông nhà", "D. Trong nhà"]	B. Trước nhà	\N	1	Câu tục ngữ 'Trước cau sau chuối' chỉ kinh nghiệm bố trí cây trồng hợp phong thủy và khí hậu của người xưa.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
8180a633-4709-4e8d-b0db-79452d1b2270	d81a0c2d-947b-4379-b82e-cc8efddbf185	\N	multiple_choice	Chim Hạc là biểu tượng trên phẩm phục của quan lại cấp bậc nào?	["A. Quan võ nhất phẩm", "B. Quan văn nhất phẩm", "C. Lính canh", "D. Quan huyện"]	B. Quan văn nhất phẩm	\N	2	Chim Hạc (Tiên hạc) là biểu tượng cao quý nhất dành cho quan văn đứng đầu triều đình.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
d75f8b74-d9c2-4176-ad43-e89f11148f02	d81a0c2d-947b-4379-b82e-cc8efddbf185	\N	true_false	Hạc thường được gắn liền với cây Tùng để chúc thọ.	["Đúng", "Sai"]	Đúng	\N	1	Tranh 'Tùng Hạc diên niên' (Cây tùng và chim hạc) là bức tranh chúc thọ phổ biến nhất.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
49b37ec1-7cc4-47f5-9c44-08ad81ec9ecb	7e398757-b356-4a0b-8457-4c2006160b7a	\N	multiple_choice	Mai Khôi Hoa là tên gọi cổ của loài hoa nào?	["A. Hoa Mai", "B. Hoa Đào", "C. Hoa Hồng", "D. Hoa Cúc"]	C. Hoa Hồng	\N	1	Mai Khôi (Mân Côi) là tên Hán Việt chỉ hoa hồng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
fa4c410c-8d15-42fa-9117-73a950d7d2ec	7e398757-b356-4a0b-8457-4c2006160b7a	\N	true_false	Thân cây hoa hồng thường có gai.	["Đúng", "Sai"]	Đúng	\N	1	Đây là đặc điểm nổi bật của loài hoa hồng: 'Hoa hồng nào mà chẳng có gai'.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
8afefb31-2c21-4205-93fb-61122d819dbc	b974a9c9-47ce-405c-b398-ec026ec08b00	\N	multiple_choice	Ngân Hán gắn liền với truyền thuyết nào?	["A. Sơn Tinh Thủy Tinh", "B. Ngưu Lang Chức Nữ", "C. Hằng Nga Hậu Nghệ", "D. Chú Cuội cung trăng"]	B. Ngưu Lang Chức Nữ	\N	1	Sông Ngân Hà là nơi chia cắt Ngưu Lang và Chức Nữ trong truyền thuyết.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
336139f4-16d8-442c-a36a-c9f52f6eb545	b974a9c9-47ce-405c-b398-ec026ec08b00	\N	multiple_choice	Chữ 'Ngân' trong Ngân Hán có nghĩa là gì?	["A. Vàng", "B. Bạc", "C. Đồng", "D. Sắt"]	B. Bạc	\N	2	Ngân Hán nghĩa là Sông Bạc.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
4ed98c67-8423-42c6-9cb1-373ff5667361	df8114b8-be0e-4223-a2ce-e4e4b5c06d1c	\N	multiple_choice	Sông Mã chảy qua tỉnh nào là chủ yếu?	["A. Nghệ An", "B. Thanh Hóa", "C. Quảng Bình", "D. Nam Định"]	B. Thanh Hóa	\N	1	Sông Mã là con sông lớn nhất và quan trọng nhất của tỉnh Thanh Hóa.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
2ac198a6-4732-40dc-a3ef-d58b9dc17d6e	df8114b8-be0e-4223-a2ce-e4e4b5c06d1c	\N	true_false	Sông Mã được đặt tên như vậy vì nó chảy êm đềm như nhung.	["Đúng", "Sai"]	Sai	\N	1	Sai. Sông Mã nổi tiếng hung dữ, chảy xiết, tên gọi gợi liên tưởng đến con ngựa (Mã).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
42509f39-e1f9-4c8a-a39d-6c60b7caa7ae	0524c8dc-ca80-4fd8-bc24-06898135d9f4	\N	multiple_choice	Chòm sao Bắc Đẩu gồm bao nhiêu ngôi sao chính?	["A. 5", "B. 7", "C. 9", "D. 12"]	B. 7	\N	1	Bắc Đẩu Thất Tinh gồm 7 ngôi sao xếp hình cái gáo.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ea428d37-6c38-4f4f-8624-b1927b918819	0524c8dc-ca80-4fd8-bc24-06898135d9f4	\N	multiple_choice	Sao Bắc Đẩu giúp người xưa xác định cái gì?	["A. Giờ giấc", "B. Phương hướng (phương Bắc)", "C. Độ mặn của biển", "D. Hướng gió"]	B. Phương hướng (phương Bắc)	\N	1	Bắc Đẩu là chòm sao quan trọng nhất để tìm ra phương Bắc trong đêm.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
b38a924d-44a0-4c2b-a21c-202ad99b82fe	ddcc58bd-deda-4c22-b7f3-cff9f0bcbae5	\N	multiple_choice	Sông Lô là phụ lưu của con sông nào?	["A. Sông Mã", "B. Sông Đà", "C. Sông Hồng", "D. Sông Hương"]	C. Sông Hồng	\N	2	Sông Lô hợp lưu với sông Hồng tại ngã ba Hạc, Việt Trì.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
c001c929-87f5-42d4-a8f3-daec88149665	ddcc58bd-deda-4c22-b7f3-cff9f0bcbae5	\N	true_false	Sông Lô chảy qua vùng Đồng bằng sông Cửu Long.	["Đúng", "Sai"]	Sai	\N	1	Sai. Sông Lô chảy qua vùng núi và trung du phía Bắc Việt Nam.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
9fae1abd-9afe-4ff0-8acd-efe0033c0ba1	129ee8ff-9912-4562-987c-bf1df6079dc0	\N	multiple_choice	Núi Hồng Lĩnh thuộc tỉnh nào?	["A. Nghệ An", "B. Hà Tĩnh", "C. Quảng Bình", "D. Thanh Hóa"]	B. Hà Tĩnh	\N	1	Núi Hồng Lĩnh nằm trên địa phận tỉnh Hà Tĩnh, là biểu tượng của vùng đất này.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f6bba010-7b63-4c7c-8347-b08cfde53b84	129ee8ff-9912-4562-987c-bf1df6079dc0	\N	multiple_choice	Truyền thuyết núi Hồng Lĩnh gắn với loài chim nào?	["A. Chim Hạc", "B. Chim Phượng Hoàng", "C. Chim Công", "D. Chim Đại Bàng"]	B. Chim Phượng Hoàng	\N	2	Truyền thuyết 99 ngọn núi và đàn phượng hoàng tìm đất đậu là câu chuyện nổi tiếng về Hồng Lĩnh.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
5b9f6df9-c887-4c09-b31d-ff01a98bfecc	99a0d77c-c789-4ee4-a7ba-3b714e817315	\N	multiple_choice	Câu chúc 'Mã đáo thành công' liên quan đến con vật nào?	["A. Con Hổ", "B. Con Rồng", "C. Con Ngựa", "D. Con Trâu"]	C. Con Ngựa	\N	1	Mã là ngựa. Mã đáo thành công nghĩa là ngựa quay về báo tin thắng lợi.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
9f37b9a5-9735-4520-81b5-3715d46f3ccf	99a0d77c-c789-4ee4-a7ba-3b714e817315	\N	true_false	Ngựa là phương tiện di chuyển chính của các trạm dịch thời xưa.	["Đúng", "Sai"]	Đúng	\N	1	Hệ thống chuyển phát nhanh (trạm dịch) thời phong kiến dựa chủ yếu vào sức ngựa.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
c4f8a48c-928e-4ed7-b030-c3107723fc94	2d339750-6ffc-4e07-b35b-b8d10cb0fe53	\N	multiple_choice	Lá của cây dâu tằm là thức ăn chính của con gì?	["A. Con Dế", "B. Con Tằm", "C. Con Ong", "D. Con Kiến"]	B. Con Tằm	\N	1	Con tằm ăn lá dâu để nhả tơ, tạo nên nghề 'trồng dâu nuôi tằm'.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
b38ad282-80d6-4499-8c05-99d80c71592f	2d339750-6ffc-4e07-b35b-b8d10cb0fe53	\N	multiple_choice	Trong dân gian, cành dâu thường được dùng để làm gì?	["A. Đánh bắt cá", "B. Trừ tà ma", "C. Làm củi đốt", "D. Làm nhà"]	B. Trừ tà ma	\N	2	Người xưa thường đeo vòng dâu hoặc dùng roi dâu để bảo vệ trẻ em khỏi tà ma.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
5d1c88a8-5538-44da-a391-1a1f278c8621	052469aa-b188-41d7-8e77-4b9ab6465683	\N	multiple_choice	Trong quân sự xưa, lá cờ (Kỳ) có vai trò chính là gì?	["A. Che nắng", "B. Ra hiệu lệnh và khích lệ tinh thần", "C. Làm đẹp đội hình", "D. Đựng đồ"]	B. Ra hiệu lệnh và khích lệ tinh thần	\N	1	Nhìn theo cờ hiệu để di chuyển đội hình là nguyên tắc sống còn trong chiến trận xưa.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
868df6c5-ecda-449d-9a40-47930d10fa1b	052469aa-b188-41d7-8e77-4b9ab6465683	\N	true_false	Mỗi đơn vị quân đội xưa đều có cờ hiệu riêng.	["Đúng", "Sai"]	Đúng	\N	1	Để phân biệt và chỉ huy, các đơn vị đều có cờ với màu sắc hoặc chữ viết riêng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
6130978f-7c82-4055-a690-2e91379d84aa	25a42e96-5aa0-4f57-9192-a4e3bdc9e137	\N	multiple_choice	Hồ Điệp Tử là tên gọi của loại vũ khí nào?	["A. Một loại kiếm", "B. Một loại đạn pháo nổ tỏa ra nhiều mảnh", "C. Một loại thuyền chiến", "D. Một loại áo giáp"]	B. Một loại đạn pháo nổ tỏa ra nhiều mảnh	\N	2	Đạn khi nổ tỏa ra như đàn bướm bay, gây sát thương rộng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
221af965-a65d-4bb4-9bba-dcf0a06a3ec2	25a42e96-5aa0-4f57-9192-a4e3bdc9e137	\N	true_false	Hồ Điệp Tử là tên một loài hoa độc.	["Đúng", "Sai"]	Sai	\N	1	Sai. Đây là tên một loại đạn (Tử ở đây là đạn/con, Hồ điệp là bướm).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
35d92651-5326-4cc9-92ab-998771ebf2e6	c981ef78-19cc-49aa-90e3-95e2f9b6b85a	\N	multiple_choice	Nhiêm Xà là tên gọi khác của con gì?	["A. Rắn hổ mang", "B. Con Trăn", "C. Con Lươn", "D. Con Rết"]	B. Con Trăn	\N	1	Nhiêm Xà (Xà là rắn lớn) chỉ con trăn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f0084fe1-c896-4f1a-885b-22d351506b10	c981ef78-19cc-49aa-90e3-95e2f9b6b85a	\N	true_false	Trăn giết con mồi bằng nọc độc.	["Đúng", "Sai"]	Sai	\N	1	Sai. Trăn không có nọc độc, nó giết mồi bằng cách siết chặt cho ngạt thở.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
20b1fcb1-cd05-4766-8fa4-1ef63d21da81	34768841-3aad-4d97-bf82-16e7e7dda5c0	\N	multiple_choice	Tử Mộc (Cây gỗ kiến) liên quan đến sản phẩm gì?	["A. Mật ong", "B. Nhựa cánh kiến (Sơn cánh kiến)", "C. Trầm hương", "D. Cao su"]	B. Nhựa cánh kiến (Sơn cánh kiến)	\N	2	Tử Mộc là cây chủ để nuôi bọ cánh kiến đỏ, thu hoạch nhựa cánh kiến.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
8cb49ad5-f79c-4320-a422-b42f5e06cb6c	34768841-3aad-4d97-bf82-16e7e7dda5c0	\N	multiple_choice	Nhựa cánh kiến đỏ có màu gì?	["A. Xanh", "B. Đỏ tím", "C. Trắng", "D. Đen"]	B. Đỏ tím	\N	1	Đúng như tên gọi (Tử: tía/đỏ), nhựa cánh kiến có màu đỏ đặc trưng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
56cc53fe-1f52-407d-bd6f-8bce5dd27060	33f759ab-d17d-4e24-9f74-369e14336bf3	\N	multiple_choice	Nghị Đỉnh được liên hệ với thụy hiệu của vị vua nào?	["A. Vua Hàm Nghi", "B. Vua Kiến Phúc", "C. Vua Duy Tân", "D. Vua Khải Định"]	B. Vua Kiến Phúc	\N	1	Nghị Đỉnh ứng với vua Giản Tông Nghị Hoàng đế (Kiến Phúc).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
d92eb695-40e3-4d1d-bf06-1195a402c554	33f759ab-d17d-4e24-9f74-369e14336bf3	\N	multiple_choice	Chữ 'Nghị' trong tên đỉnh có nghĩa là gì?	["A. Bàn bạc", "B. Vui vẻ", "C. Quả quyết, kiên định", "D. Nghi ngờ"]	C. Quả quyết, kiên định	\N	1	Nghị trong 'Cương nghị', 'Nghị lực', chỉ sự mạnh mẽ, cứng cỏi.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e65a24f5-eef0-4b63-ae4d-46a599a16ef4	0e90ba70-f73b-43ce-b3cb-0cf57a2c349b	\N	multiple_choice	Hoa Mai thường nở vào mùa nào?	["A. Mùa Hè", "B. Mùa Thu", "C. Mùa Xuân", "D. Mùa Đông"]	C. Mùa Xuân	\N	1	Hoa mai là sứ giả của mùa xuân Việt Nam.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
97e25874-0e7d-4eb8-bc16-346b5fbd249f	0e90ba70-f73b-43ce-b3cb-0cf57a2c349b	\N	multiple_choice	Hoa Mai nằm trong bộ tứ nào?	["A. Long Lân Quy Phụng", "B. Tùng Cúc Trúc Mai", "C. Công Dung Ngôn Hạnh", "D. Cầm Kỳ Thi Họa"]	B. Tùng Cúc Trúc Mai	\N	1	Mai là một trong 4 loài cây quý (Tứ quý) tượng trưng cho 4 mùa và đức tính quân tử.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0e4a07b2-e49a-40a0-9499-eef942e29cc7	c448233e-7507-4ba5-b707-f445eed4fee2	\N	multiple_choice	Đặc điểm nổi bật nhất của gỗ Đàn Mộc là gì?	["A. Có gai nhọn", "B. Có mùi thơm đặc biệt", "C. Mềm như xốp", "D. Có màu xanh lam"]	B. Có mùi thơm đặc biệt	\N	1	Gỗ Đàn hương (Đàn mộc) nổi tiếng thế giới vì mùi thơm quý phái và giữ mùi rất lâu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0d743f99-bcaf-4097-b6d5-391d5776e39f	c448233e-7507-4ba5-b707-f445eed4fee2	\N	true_false	Gỗ Đàn Mộc thường bị mối mọt tấn công.	["Đúng", "Sai"]	Sai	\N	1	Sai. Tinh dầu trong gỗ có khả năng xua đuổi côn trùng, mối mọt.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ffed4336-0235-4085-8337-eaa8dcb9738d	e39d9f9b-27d0-458e-a307-f00ff4c64293	\N	multiple_choice	Quế vùng nào ở Việt Nam nổi tiếng nhất thời xưa?	["A. Quế Lạng Sơn", "B. Quế Thanh Hóa", "C. Quế Đồng Nai", "D. Quế Cà Mau"]	B. Quế Thanh Hóa	\N	2	'Quế Thanh' (Thanh Hóa) được đánh giá là loại quế tốt nhất, vỏ dày và nhiều tinh dầu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e35668af-ea80-464f-95c1-b490c331ce77	e39d9f9b-27d0-458e-a307-f00ff4c64293	\N	multiple_choice	Bộ phận nào của cây quế được dùng phổ biến nhất?	["A. Lá", "B. Hoa", "C. Vỏ cây", "D. Rễ"]	C. Vỏ cây	\N	1	Vỏ quế (Nhục quế) là phần có giá trị kinh tế và y học cao nhất.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
395f2aa9-d11b-4abe-babd-612a889bf4b4	4736fd9a-1a7c-4561-9fa4-eb99b80613b7	\N	multiple_choice	Biển Đậu là tên gọi khác của cây gì?	["A. Đậu nành", "B. Đậu xanh", "C. Đậu ván", "D. Đậu phộng"]	C. Đậu ván	\N	1	Biển đậu (nhất là Bạch biển đậu - đậu ván trắng) là tên thuốc của cây đậu ván.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
3d0dba15-1203-4e43-8e56-306e8c6c61ed	4736fd9a-1a7c-4561-9fa4-eb99b80613b7	\N	true_false	Đậu ván là cây thân gỗ lớn.	["Đúng", "Sai"]	Sai	\N	1	Sai. Đậu ván là loài cây dây leo.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
7908ae91-3f34-443f-a1e3-022dce756bd1	aa34527e-3a15-41da-8ebe-cfd35ac09a0b	\N	multiple_choice	Người xưa quan niệm hoa Hải Đường tượng trưng cho điều gì?	["A. Sự nghèo khó", "B. Sự phú quý", "C. Sự chia ly", "D. Sự học hành"]	B. Sự phú quý	\N	1	Câu 'Phú quý chơi Hải Đường' đã nói lên ý nghĩa của loài hoa này.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ddea3ff8-2b08-47bd-adad-e9ef4d4cf080	aa34527e-3a15-41da-8ebe-cfd35ac09a0b	\N	multiple_choice	Hoa Hải Đường Việt Nam có màu gì đặc trưng?	["A. Vàng", "B. Xanh", "C. Đỏ thắm", "D. Tím"]	C. Đỏ thắm	\N	1	Hải đường Việt Nam nổi bật với màu đỏ rực rỡ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
c70a2d9b-65e6-4e74-a7e5-6caacfd3328d	9293bbac-360e-42c6-af8a-0470e8a39204	\N	multiple_choice	Hồ Da Tử (Đuông dừa) sống ký sinh ở đâu?	["A. Trong lòng đất", "B. Trên ngọn cây dừa", "C. Dưới nước", "D. Trong hang đá"]	B. Trên ngọn cây dừa	\N	1	Đuông dừa ăn phần non mềm (củ hủ) trên ngọn cây dừa.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
9d3146e4-4b83-483f-92ce-c59b5eac7432	9293bbac-360e-42c6-af8a-0470e8a39204	\N	true_false	Đuông dừa là một loài có lợi cho cây trồng.	["Đúng", "Sai"]	Sai	\N	1	Sai. Đuông dừa đục khoét làm chết cây dừa, là loài thiên địch của người trồng dừa.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
73c9843e-470c-4a33-8b2a-71438304f551	5d296943-0b9a-42ea-ba1f-d9901cc391c6	\N	multiple_choice	Quảng Bình Quan nằm ở tỉnh nào?	["A. Quảng Trị", "B. Quảng Bình", "C. Quảng Nam", "D. Quảng Ngãi"]	B. Quảng Bình	\N	1	Tên gọi đã chỉ rõ địa danh: Cửa quan ở Quảng Bình.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
45d35e9e-ae0e-4d7e-898f-79e3e5bae823	5d296943-0b9a-42ea-ba1f-d9901cc391c6	\N	multiple_choice	Quảng Bình Quan thuộc hệ thống phòng thủ nào nổi tiếng?	["A. Thành Cổ Loa", "B. Lũy Thầy (Lũy Đào Duy Từ)", "C. Thành Nhà Hồ", "D. Địa đạo Củ Chi"]	B. Lũy Thầy (Lũy Đào Duy Từ)	\N	2	Đây là công trình do Đào Duy Từ chỉ đạo xây dựng để giúp Chúa Nguyễn chống lại Chúa Trịnh.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
a77fabb4-da73-43a6-80ea-76fce2367eb0	1765de7a-fb29-4c9a-b769-370883202181	\N	multiple_choice	Sông Cửu An chảy qua khu vực nào?	["A. Đồng bằng sông Cửu Long", "B. Tây Nguyên", "C. Đồng bằng Bắc Bộ (Hưng Yên, Hải Dương)", "D. Miền Trung"]	C. Đồng bằng Bắc Bộ (Hưng Yên, Hải Dương)	\N	2	Sông Cửu An là sông quan trọng của vùng đồng bằng sông Hồng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0f8b2690-3fe0-4cd2-bfbd-b799ba7acd16	1765de7a-fb29-4c9a-b769-370883202181	\N	true_false	Sông Cửu An là một con sông lớn ở miền núi.	["Đúng", "Sai"]	Sai	\N	1	Sai. Đây là sông chảy qua vùng đồng bằng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
75c3b22b-e8c8-4a40-a1c8-4eec33852579	c3fb5c56-a8b9-43e8-9ddb-22385193cec6	\N	multiple_choice	Theo quan niệm dân gian, sao Nam Đẩu (Nam Tào) giữ sổ gì?	["A. Sổ Tử (Chết)", "B. Sổ Sinh (Sống)", "C. Sổ Lương", "D. Sổ Ruộng đất"]	B. Sổ Sinh (Sống)	\N	1	Nam Đẩu chủ sinh, Bắc Đẩu chủ tử.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ec454322-a78a-40ae-816f-15b339f7f77e	c3fb5c56-a8b9-43e8-9ddb-22385193cec6	\N	multiple_choice	Chòm sao Nam Đẩu gồm mấy ngôi sao?	["A. 5", "B. 6", "C. 7", "D. 8"]	B. 6	\N	2	Nam Đẩu Lục (6) Tinh.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0f7144a6-49fe-4f11-b910-38cfa47b0ad1	cc1a79bb-8da0-4462-8914-43ccb471cc39	\N	multiple_choice	Sông Bạch Đằng nổi tiếng với chiến thuật quân sự nào?	["A. Dùng thuyền lửa", "B. Dùng bãi cọc ngầm", "C. Đào hầm địa đạo", "D. Vườn không nhà trống"]	B. Dùng bãi cọc ngầm	\N	1	Cắm cọc xuống lòng sông, chờ thủy triều lên xuống để nhử thuyền địch vào bãi cọc là chiến thuật kinh điển trên sông Bạch Đằng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
b0c5d577-2925-495b-a65e-bd9600c3a761	cc1a79bb-8da0-4462-8914-43ccb471cc39	\N	multiple_choice	Vị tướng nào ĐÃ KHÔNG chỉ huy trận chiến trên sông Bạch Đằng?	["A. Ngô Quyền", "B. Trần Hưng Đạo", "C. Lê Hoàn", "D. Quang Trung"]	D. Quang Trung	\N	2	Vua Quang Trung nổi tiếng với trận Ngọc Hồi - Đống Đa, không gắn liền với sông Bạch Đằng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
2d5f0e25-c10c-429a-837f-ce3808d4aeae	eb8f7cdb-fe49-48dc-ad7f-2d8923e100de	\N	multiple_choice	Cửa biển Thuận An là nơi con sông nào đổ ra biển?	["A. Sông Hồng", "B. Sông Hàn", "C. Sông Hương", "D. Sông Cửu Long"]	C. Sông Hương	\N	1	Thuận An là cửa biển của sông Hương, lối vào Kinh thành Huế.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ae952ff7-f3c2-4974-b479-695d5d70a21a	eb8f7cdb-fe49-48dc-ad7f-2d8923e100de	\N	true_false	Cửa Thuận An có vai trò quan trọng trong việc bảo vệ Kinh thành Huế.	["Đúng", "Sai"]	Đúng	\N	1	Đúng. Đây là 'yết hầu' (cổ họng) đường thủy của Kinh đô.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
646a78d7-ddf4-482d-9dd5-dc220aac015e	617cbc43-a7ec-4826-b089-57b886a14996	\N	multiple_choice	Lục Hoa Ngư là tên gọi hoa mỹ của loài cá nào?	["A. Cá chép", "B. Cá lóc (Cá quả)", "C. Cá trê", "D. Cá rô"]	B. Cá lóc (Cá quả)	\N	1	Lục Hoa Ngư chính là con cá lóc quen thuộc.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
1e883cfd-584b-4c59-9cc1-ba58687da441	617cbc43-a7ec-4826-b089-57b886a14996	\N	multiple_choice	Món ăn nào sau đây KHÔNG thường làm từ cá lóc?	["A. Canh chua", "B. Cá kho tộ", "C. Sashimi sống", "D. Bánh canh cá"]	C. Sashimi sống	\N	2	Cá lóc là cá nước ngọt, thường nấu chín (kho, nấu canh) chứ ít khi ăn sống kiểu sashimi do nguy cơ ký sinh trùng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
77ef8ede-0e64-43b0-b62f-f8dbcd85e3e3	8096eca9-bea4-42ab-a96f-36f7e373c017	\N	multiple_choice	Hạt của cây rau cải (Giới tử) được dùng làm gì?	["A. Làm thuốc và gia vị (mù tạt)", "B. Làm đồ chơi", "C. Làm thuốc nổ", "D. Làm mực viết"]	A. Làm thuốc và gia vị (mù tạt)	\N	2	Hạt cải có vị cay nồng, là nguyên liệu làm mù tạt và thuốc.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
1385ea4d-25f8-4b19-a9fe-cedb0c3e65cb	8096eca9-bea4-42ab-a96f-36f7e373c017	\N	true_false	Rau cải là loại rau chịu nhiệt, chỉ trồng được vào mùa hè.	["Đúng", "Sai"]	Sai	\N	1	Sai. Đa số các loại cải ưa khí hậu mát mẻ, phát triển tốt vào vụ Đông Xuân.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
fa5c661e-2f16-4802-b696-c2790fad034e	4cbb533d-b417-477c-a075-d4c1bce38ad2	\N	multiple_choice	Trường Thương thuộc loại vũ khí nào?	["A. Vũ khí tầm xa (bắn)", "B. Vũ khí cận chiến (đâm)", "C. Vũ khí phòng thủ (khiên)", "D. Vũ khí ngụy trang"]	B. Vũ khí cận chiến (đâm)	\N	1	Thương dùng để đâm, gạt trong giao chiến gần.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0f799c05-ddce-4469-90ae-aa9b7070c559	4cbb533d-b417-477c-a075-d4c1bce38ad2	\N	multiple_choice	Ưu điểm chính của Trường Thương so với Kiếm ngắn là gì?	["A. Dễ giấu trong người", "B. Tầm đánh xa hơn", "C. Nhẹ hơn", "D. Đẹp hơn"]	B. Tầm đánh xa hơn	\N	1	Cán dài giúp lính cầm thương có thể tấn công địch từ khoảng cách xa hơn kiếm.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
4e5528e6-f8d6-4402-a970-7cb1c490373d	cb8421e4-3199-40e6-b7b3-9dfe5f571092	\N	multiple_choice	Thuyền Hải Đạo có đặc điểm gì nổi bật?	["A. To lớn như pháo đài", "B. Nhỏ, thon dài, di chuyển nhanh", "C. Dùng để chở hàng hóa nặng", "D. Chỉ đi được trên cạn"]	B. Nhỏ, thon dài, di chuyển nhanh	\N	2	Đây là loại thuyền chiến thiên về tốc độ và sự linh hoạt.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
cf7f993d-4573-470a-a7e6-7ac06a878048	cb8421e4-3199-40e6-b7b3-9dfe5f571092	\N	true_false	Thủy quân thời Nguyễn rất yếu kém và ít tàu thuyền.	["Đúng", "Sai"]	Sai	\N	1	Sai. Thủy quân nhà Nguyễn rất mạnh, sở hữu hàng ngàn chiến thuyền và tàu bọc đồng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e82b1eb5-a5e4-44f8-b4e9-4755bd371db6	54c162b8-7bb5-4761-b763-bb60c4293d0d	\N	multiple_choice	Chim Uyên Ương là biểu tượng của điều gì?	["A. Sức mạnh quân sự", "B. Tình yêu chung thủy", "C. Sự giàu có", "D. Trí tuệ"]	B. Tình yêu chung thủy	\N	1	Uyên ương luôn đi có đôi, tượng trưng cho tình vợ chồng sắt son.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
8f1b79c4-55e4-4db5-a490-3ce5ba9630ea	54c162b8-7bb5-4761-b763-bb60c4293d0d	\N	true_false	Con Uyên Ương trống và mái có bộ lông giống hệt nhau.	["Đúng", "Sai"]	Sai	\N	2	Sai. Con trống có bộ lông rất sặc sỡ để thu hút bạn tình, còn con mái có màu nâu xám giản dị để ngụy trang.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
132061a9-5663-41da-a774-63384eb8ada9	ce7718a7-ddae-4917-aca4-fad6e8a3de9a	\N	multiple_choice	Trong quân đội phong kiến, đơn vị lính cưỡi voi gọi là gì?	["A. Kỵ binh", "B. Thủy binh", "C. Tượng binh", "D. Bộ binh"]	C. Tượng binh	\N	1	Tượng là voi. Tượng binh là lính voi.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
9c6f04d7-63f3-4b02-8c39-1e51d00dbe91	ce7718a7-ddae-4917-aca4-fad6e8a3de9a	\N	true_false	Voi là loài động vật ăn thịt.	["Đúng", "Sai"]	Sai	\N	1	Sai. Voi là động vật ăn cỏ (thực vật).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
7f41070d-5b62-4f76-9ea2-103aaed46d88	61826813-bed7-49ff-b54a-7a1ef85a812f	\N	multiple_choice	Thuần Đỉnh ứng với thụy hiệu của vị vua nào?	["A. Vua Dục Đức", "B. Vua Hiệp Hòa", "C. Vua Đồng Khánh", "D. Vua Khải Định"]	C. Vua Đồng Khánh	\N	1	Vua Đồng Khánh có miếu hiệu là Cảnh Tông, thụy hiệu là Thuần Hoàng đế.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e3847bf9-6ab6-4ab0-bf43-0a1b0392258c	61826813-bed7-49ff-b54a-7a1ef85a812f	\N	multiple_choice	Thuần Đỉnh có đặc điểm gì về trọng lượng so với các đỉnh khác?	["A. Nặng nhất", "B. Nhẹ nhất", "C. Nặng trung bình", "D. Nặng bằng Cao Đỉnh"]	B. Nhẹ nhất	\N	2	Thuần Đỉnh nặng khoảng 3.229 cân (hệ cân xưa), nhẹ nhất trong 9 đỉnh.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
a950343c-0c31-43f8-ac28-fa421f2411f5	61a7b0da-2123-4bda-be59-b004e2d9a452	\N	multiple_choice	Hoa Đào là loài hoa đặc trưng cho ngày Tết ở miền nào?	["A. Miền Nam", "B. Miền Bắc", "C. Miền Trung", "D. Tây Nguyên"]	B. Miền Bắc	\N	1	Miền Bắc chơi hoa Đào, miền Nam chơi hoa Mai.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
a69c30f4-1377-4682-83a9-58a540d10b09	61a7b0da-2123-4bda-be59-b004e2d9a452	\N	true_false	Theo quan niệm dân gian, hoa Đào có khả năng trừ tà ma.	["Đúng", "Sai"]	Đúng	\N	1	Gỗ đào và hoa đào được cho là khắc tinh của ma quỷ (theo sự tích hai vị thần Trà và Uất Lũy dưới gốc đào).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
3e590468-ec70-4b11-b5cf-5c50609149f7	42d0ddb9-5f03-4970-8627-22b229615b01	\N	multiple_choice	Súc Sa Mật (Sa nhân) thường được dùng để chữa bệnh gì?	["A. Đau mắt", "B. Gãy xương", "C. Đau bụng, đầy hơi, tiêu hóa kém", "D. Bệnh ngoài da"]	C. Đau bụng, đầy hơi, tiêu hóa kém	\N	2	Tinh dầu sa nhân có tính ấm, rất tốt cho tỳ vị và đường ruột.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
df7851c0-77c3-418f-934a-d23f377ca65a	42d0ddb9-5f03-4970-8627-22b229615b01	\N	true_false	Quả Sa nhân mọc ở trên ngọn cây cao.	["Đúng", "Sai"]	Sai	\N	1	Sai. Quả sa nhân mọc thành chùm ở sát gốc cây, ngay trên mặt đất.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
367f0256-eb9a-4aec-911a-f7e90d0da6c5	ef926c95-6c55-4374-8788-4552e2ad8152	\N	multiple_choice	Công dụng phổ biến nhất của cây Hương Nhu là gì?	["A. Làm thuốc nhuộm vải", "B. Nấu nước xông giải cảm", "C. Làm thức ăn cho gia súc", "D. Làm vật liệu xây dựng"]	B. Nấu nước xông giải cảm	\N	1	Hương nhu có tính ấm, làm ra mồ hôi, rất tốt để giải cảm hàn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f5425047-786e-4d98-bbba-e65efd8276fe	ef926c95-6c55-4374-8788-4552e2ad8152	\N	true_false	Cây Hương Nhu có mùi hôi khó chịu.	["Đúng", "Sai"]	Sai	\N	1	Sai. Hương nhu có mùi thơm nồng, dễ chịu, chứa nhiều tinh dầu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
c8880ea8-551f-4b51-8cac-2ca73871787f	3ce87650-7d3c-4135-81ec-f083f855ed56	\N	multiple_choice	Hoàng Đậu là nguyên liệu chính để làm món gì?	["A. Bún chả", "B. Đậu phụ (Đậu hũ) và nước tương", "C. Bánh chưng", "D. Cốm"]	B. Đậu phụ (Đậu hũ) và nước tương	\N	1	Đậu nành xay ra làm sữa, đông tụ thành đậu phụ, ủ lên men thành tương.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
4da23694-6fa6-4fa1-9dce-737c1df09e36	3ce87650-7d3c-4135-81ec-f083f855ed56	\N	true_false	Cây đậu nành làm nghèo đất trồng.	["Đúng", "Sai"]	Sai	\N	2	Sai. Rễ cây họ đậu có vi khuẩn nốt sần giúp cố định đạm, làm đất màu mỡ hơn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
94ec982a-86d6-41b4-b260-1003493c4f12	01e7d41a-a4f3-49d3-972a-0fbd6a9c8117	\N	multiple_choice	Đặc điểm nổi bật nhất của Quỳ Hoa (Hướng dương) là gì?	["A. Nở vào ban đêm", "B. Luôn hướng về phía mặt trời", "C. Có mùi hôi", "D. Sống dưới nước"]	B. Luôn hướng về phía mặt trời	\N	1	Tên gọi 'Hướng dương' đã nói lên đặc tính này.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
291cdb3f-5d13-4ffa-8597-767e9ff682b9	01e7d41a-a4f3-49d3-972a-0fbd6a9c8117	\N	multiple_choice	Hạt hướng dương thường được dùng để làm gì?	["A. Làm thuốc nổ", "B. Ép dầu ăn và làm món ăn vặt", "C. Làm phân bón", "D. Làm vật liệu xây dựng"]	B. Ép dầu ăn và làm món ăn vặt	\N	1	Dầu hướng dương rất tốt cho sức khỏe, hạt rang là món ăn vặt quen thuộc.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
9f082f17-5a34-4317-9a4f-7d40d6f1283d	5bc76464-b9ab-4428-9462-7cd317515cde	\N	multiple_choice	Trong truyện Tấm Cám, Tấm đã hóa thân thành loài chim nào?	["A. Chim Sẻ", "B. Chim Vàng Anh", "C. Chim Bồ Câu", "D. Chim Phượng Hoàng"]	B. Chim Vàng Anh	\N	1	Tấm hóa thành chim Vàng Anh bay về cung vua: 'Giặt áo chồng tao thì giặt cho sạch...'.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
3bd64ded-6e16-4a45-8a92-074ecd99bc58	5bc76464-b9ab-4428-9462-7cd317515cde	\N	true_false	Chim Vàng Anh có bộ lông màu đen tuyền.	["Đúng", "Sai"]	Sai	\N	1	Sai. Chim vàng anh nổi bật với màu vàng rực rỡ (có thể pha chút đen ở cánh/đầu).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
93377b5b-b82e-49d9-80bb-f5314e8dbacd	1b519b34-f4a1-4014-9db8-ed29dcb8b3d1	\N	multiple_choice	Tản Viên Sơn gắn liền với vị thần nào trong Tứ bất tử?	["A. Chử Đồng Tử", "B. Thánh Gióng", "C. Sơn Tinh (Thánh Tản Viên)", "D. Mẫu Liễu Hạnh"]	C. Sơn Tinh (Thánh Tản Viên)	\N	1	Sơn Tinh là chúa tể vùng núi Tản Viên.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f898fa19-cd0f-4c2e-bea0-7d70d4b5c866	1b519b34-f4a1-4014-9db8-ed29dcb8b3d1	\N	multiple_choice	Núi Tản Viên còn có tên gọi phổ biến khác là gì?	["A. Núi Sóc", "B. Núi Ba Vì", "C. Núi Nùng", "D. Núi Ngự"]	B. Núi Ba Vì	\N	1	Dãy núi Ba Vì có 3 ngọn, trong đó cao nhất là đỉnh Tản Viên (hoặc Vua).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
94918b34-bc69-4d40-bbe3-3d8ff1730db9	c5a0a5ec-5ebe-4d7f-be43-dd88f0e184e1	\N	multiple_choice	Sông Vĩnh Định là con sông tự nhiên hay nhân tạo (sông đào)?	["A. Sông tự nhiên", "B. Sông đào", "C. Suối", "D. Hồ nước"]	B. Sông đào	\N	2	Sông được vua Minh Mạng cho đào để phục vụ thủy lợi và giao thông.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
798bd40f-fb99-429b-bbe2-758e192d415e	c5a0a5ec-5ebe-4d7f-be43-dd88f0e184e1	\N	multiple_choice	Sông Vĩnh Định nằm ở tỉnh nào?	["A. Thừa Thiên Huế", "B. Quảng Trị", "C. Quảng Bình", "D. Nghệ An"]	B. Quảng Trị	\N	2	Sông Vĩnh Định chảy qua các huyện Hải Lăng, Triệu Phong của Quảng Trị.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
00d396ef-08fa-4bdb-9ff0-c35b6e1e7862	29366526-461d-4127-ae32-8a7fa46fe020	\N	multiple_choice	Thành ngữ nào nói về sự thuận lợi nhờ gió?	["A. Gió chiều nào che chiều ấy", "B. Thuận buồm xuôi gió", "C. Chém gió", "D. Gió thổi bay nóc nhà"]	B. Thuận buồm xuôi gió	\N	1	Câu này chúc cho công việc trôi chảy, không gặp trở ngại.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ac98e087-517d-40c3-9fbd-4b8f4ed0b8e2	29366526-461d-4127-ae32-8a7fa46fe020	\N	true_false	Gió là một trong những yếu tố của Ngũ hành.	["Đúng", "Sai"]	Sai	\N	2	Sai. Ngũ hành gồm Kim, Mộc, Thủy, Hỏa, Thổ. Gió (Phong) không nằm trong đó, dù nó quan trọng trong phong thủy.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
8f9ffef3-4f0c-420d-a41a-ef72c522696c	5ff35034-ef86-4daf-b01c-38fd5398d5b4	\N	multiple_choice	Sông Thạch Hãn chảy qua tỉnh nào?	["A. Quảng Bình", "B. Quảng Trị", "C. Thừa Thiên Huế", "D. Đà Nẵng"]	B. Quảng Trị	\N	1	Thạch Hãn là dòng sông biểu tượng của Quảng Trị.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f1917ca6-df4c-498d-a0aa-3d4dcc57d244	5ff35034-ef86-4daf-b01c-38fd5398d5b4	\N	true_false	Sông Thạch Hãn gắn liền với sự kiện Thành Cổ Quảng Trị năm 1972.	["Đúng", "Sai"]	Đúng	\N	1	Đây là nơi diễn ra các trận đánh ác liệt và nhiều chiến sĩ đã hy sinh trên dòng sông này.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0f36954a-422f-4315-9340-4ea650924928	5d18cf10-4dc4-4bbe-9ee3-b0b70362a69f	\N	multiple_choice	Cần Giờ Hải Khẩu là cửa ngõ đường thủy dẫn vào thành phố nào?	["A. Hà Nội", "B. Huế", "C. Gia Định (TP. Hồ Chí Minh)", "D. Đà Nẵng"]	C. Gia Định (TP. Hồ Chí Minh)	\N	1	Cần Giờ thuộc TP.HCM, là cửa ngõ ra biển Đông.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
924db811-53a1-477b-ad12-3a73a8439b89	5d18cf10-4dc4-4bbe-9ee3-b0b70362a69f	\N	multiple_choice	Cần Giờ nổi tiếng với loại hình sinh thái nào?	["A. Rừng nguyên sinh trên núi đá", "B. Rừng ngập mặn", "C. Sa mạc cát", "D. Đồng cỏ thảo nguyên"]	B. Rừng ngập mặn	\N	1	Rừng Sác Cần Giờ là rừng ngập mặn rộng lớn với hệ động thực vật phong phú.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
d22fe74d-e416-49d8-9e96-dde196c35782	bb1779dc-38f6-4ad5-8b92-431869075aa1	\N	multiple_choice	Đặc điểm kỳ lạ nào giúp cá rô đồng có tên là 'Đăng Sơn Ngư' (Cá leo núi)?	["A. Chúng sống trên đỉnh núi", "B. Chúng có thể trườn trên cạn để di chuyển sang nơi khác", "C. Chúng biết bay", "D. Chúng có chân"]	B. Chúng có thể trườn trên cạn để di chuyển sang nơi khác	\N	1	Khả năng vượt cạn (leo bờ) của cá rô đồng rất nổi tiếng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
067aa358-3fd0-426b-80bc-d17e4b1a4def	bb1779dc-38f6-4ad5-8b92-431869075aa1	\N	true_false	Cá rô đồng chỉ sống được ở nước mặn.	["Đúng", "Sai"]	Sai	\N	1	Sai. Cá rô đồng là loài cá nước ngọt (sống ở ruộng, ao, đầm).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0d72b2d2-454f-479c-846c-85e6e4c4d8f5	7929755c-2737-4f1d-be93-c9c9bb17e726	\N	multiple_choice	Thành ngữ 'Bạng duật tương trì' (Trai cò đánh nhau) có ý nghĩa gì?	["A. Ca ngợi tình bạn", "B. Hai bên tranh chấp để kẻ thứ ba hưởng lợi", "C. Khen ngợi sức mạnh của con trai", "D. Miêu tả cảnh đẹp thiên nhiên"]	B. Hai bên tranh chấp để kẻ thứ ba hưởng lợi	\N	2	Trai kẹp mỏ cò, cò mổ thịt trai, cả hai đều bị ngư ông bắt.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
5c43f15b-58e0-4383-956f-9309d5a37930	7929755c-2737-4f1d-be93-c9c9bb17e726	\N	true_false	Tất cả các loài trai đều có ngọc.	["Đúng", "Sai"]	Sai	\N	1	Sai. Chỉ một số loài trai/ngao đặc biệt mới có khả năng tạo ngọc.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
09ce0b74-c464-480f-ace7-cb88c37608e0	a7c53882-c22b-4e79-bf13-2d0c66888558	\N	multiple_choice	Bài Đao (Giá gác đao) có chức năng chính là gì?	["A. Để mài đao cho sắc", "B. Để trưng bày và cất giữ đao kiếm gọn gàng", "C. Để tập luyện chém đao", "D. Để làm củi đốt"]	B. Để trưng bày và cất giữ đao kiếm gọn gàng	\N	1	Nó giúp bảo quản vũ khí và tạo vẻ uy nghiêm.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
bbad8cdf-4351-4679-abdf-bee67ea71d7f	a7c53882-c22b-4e79-bf13-2d0c66888558	\N	true_false	Trong quân đội xưa, vũ khí thường được vứt bừa bãi dưới đất.	["Đúng", "Sai"]	Sai	\N	1	Sai. Quân đội luôn đề cao kỷ luật, vũ khí phải được sắp xếp ngăn nắp trên giá (như Bài đao).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0b6e0570-9726-403c-8205-901016d7eaf0	192e0b2e-dfc3-423f-805f-b717ec39de16	\N	multiple_choice	Thuyền Đỉnh thường được dùng trong hoạt động văn hóa nào?	["A. Rước dâu", "B. Đua thuyền", "C. Chở lúa", "D. Đánh bắt cá xa bờ"]	B. Đua thuyền	\N	1	Với dáng thon dài, thuyền Đỉnh rất thích hợp cho các cuộc đua tốc độ trên sông.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
81c499ab-f870-4542-ad02-f2e9d7349ba6	192e0b2e-dfc3-423f-805f-b717ec39de16	\N	multiple_choice	Trong quân sự, ưu thế của thuyền Đỉnh là gì?	["A. Chở được nhiều đại bác", "B. Di chuyển nhanh và linh hoạt", "C. Chịu được sóng thần", "D. Có vỏ bọc thép"]	B. Di chuyển nhanh và linh hoạt	\N	1	Nhờ nhỏ gọn và nhiều tay chèo, thuyền Đỉnh di chuyển rất nhanh.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
25840c97-9eb0-4954-9eb5-3275de9f552e	f9ff3e74-297f-4ae3-a586-d0c2b84209b7	\N	multiple_choice	Nam Mộc (Gỗ Chò) thường được dùng để làm gì trong kiến trúc cổ?	["A. Làm củi đun", "B. Làm cột nhà, cột đình chùa", "C. Làm giấy", "D. Làm hàng rào"]	B. Làm cột nhà, cột đình chùa	\N	1	Nhờ thân thẳng, to và bền, gỗ Chò là lựa chọn hàng đầu để làm cột trụ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
4ddba678-f911-44fa-ab24-0885d0d2d6a3	f9ff3e74-297f-4ae3-a586-d0c2b84209b7	\N	true_false	Nam Mộc là loài cây bụi nhỏ, thân mềm.	["Đúng", "Sai"]	Sai	\N	1	Sai. Nam Mộc là cây thân gỗ lớn (cổ thụ).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f092f859-217d-4f75-bf99-ce288492e808	27f1d92f-b653-4088-a19d-2867460cfc0d	\N	multiple_choice	Ly Ngưu là tên gọi của loài vật nào?	["A. Con Trâu rừng", "B. Con Bò tót", "C. Con Tê giác", "D. Con Voi"]	B. Con Bò tót	\N	1	Ly Ngưu (Bò tót) là loài thú móng guốc lớn và hung dữ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
b7350c92-13ed-454e-ba8e-65296c1b9c8c	27f1d92f-b653-4088-a19d-2867460cfc0d	\N	true_false	Bò tót là loài vật hiền lành, dễ thuần hóa như bò nhà.	["Đúng", "Sai"]	Sai	\N	1	Sai. Bò tót rất hung dữ và nguy hiểm, khó thuần hóa.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
7edae3e3-8d04-4e9c-93e5-a3ebb3f6a13a	7e10639b-e0d4-4f5e-9263-24b005596d85	\N	multiple_choice	Tuyên Đỉnh ứng với thụy hiệu của vị vua nào?	["A. Vua Duy Tân", "B. Vua Khải Định", "C. Vua Bảo Đại", "D. Vua Thành Thái"]	B. Vua Khải Định	\N	1	Vua Khải Định có thụy hiệu là Tuyên Hoàng đế.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
13ca8124-7f30-4e09-be68-73e4de40fa67	7e10639b-e0d4-4f5e-9263-24b005596d85	\N	multiple_choice	Chữ 'Tuyên' trong tên đỉnh có nghĩa là gì?	["A. Giấu kín", "B. Tuyên bố, làm sáng tỏ", "C. Tuyên chiến", "D. Tuyển chọn"]	B. Tuyên bố, làm sáng tỏ	\N	1	Tuyên (trong Tuyên ngôn, Tuyên truyền) nghĩa là nói rõ cho mọi người biết.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
828df246-a2c5-4797-8188-43cbb54c72c1	7a4c0e26-fe4e-4885-ad47-3765a24856a8	\N	multiple_choice	Tần Cát Liễu là tên gọi khác của loài chim nào?	["A. Chim Sáo", "B. Chim Yểng (Nhồng)", "C. Chim Vẹt", "D. Chim Khướu"]	B. Chim Yểng (Nhồng)	\N	1	Tần Cát Liễu là tên văn vẻ của chim Yểng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
1c637793-4877-4f46-becd-0fe9af9f04c3	7a4c0e26-fe4e-4885-ad47-3765a24856a8	\N	true_false	Chim Yểng không biết bay.	["Đúng", "Sai"]	Sai	\N	1	Sai. Yểng là loài chim rừng bay rất khỏe.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
9888850c-bd2b-466c-b884-2c5aa1e6340d	bef239ca-da7e-4bf0-8353-10a092dd6091	\N	multiple_choice	Yến sào (Tổ yến) được làm từ chất liệu gì?	["A. Cỏ khô", "B. Lông chim", "C. Nước dãi của chim yến", "D. Bùn đất"]	C. Nước dãi của chim yến	\N	1	Chim yến tiết nước bọt (dãi) kết dính lại thành tổ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
47e3a520-b5e9-48f9-a27d-b59928bb9b40	bef239ca-da7e-4bf0-8353-10a092dd6091	\N	true_false	Tổ yến là món ăn bình dân, ai cũng ăn hàng ngày.	["Đúng", "Sai"]	Sai	\N	1	Sai. Tổ yến là thực phẩm cao cấp, giá thành rất đắt đỏ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
bb2249c0-80e6-48b2-a377-feab7b80efba	371a21e2-afc3-4b7f-b365-439a19111af4	\N	multiple_choice	Vùng đất nào nổi tiếng nhất với đặc sản Nhãn lồng?	["A. Hà Nội", "B. Hưng Yên", "C. Bắc Giang", "D. Hải Dương"]	B. Hưng Yên	\N	1	'Thứ nhất kinh kỳ, thứ nhì Phố Hiến'. Hưng Yên nổi tiếng với nhãn lồng tiến vua.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
35b6fd89-9b44-456d-9c63-b4056d9b7686	371a21e2-afc3-4b7f-b365-439a19111af4	\N	multiple_choice	Trong đông y, Long nhãn (cùi nhãn sấy khô) có tác dụng gì?	["A. Chữa đau bụng", "B. An thần, bổ máu", "C. Chữa gãy xương", "D. Chữa bệnh ngoài da"]	B. An thần, bổ máu	\N	2	Long nhãn là vị thuốc bổ tâm tỳ, giúp ngủ ngon.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
2e330b78-5e5a-42f7-b478-88d776886d99	a7cd9650-61f4-4e9f-8d8b-48beb32b3bcb	\N	multiple_choice	Hoa Sói (Trân Châu Hoa) thường được dùng để làm gì?	["A. Nấu canh", "B. Ướp trà", "C. Nhuộm vải", "D. Đuổi muỗi"]	B. Ướp trà	\N	1	Hương thơm dịu của hoa sói rất hợp để ướp trà xanh.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
5bf8628e-5e40-4ac0-b3fa-8d36fdcb84b3	a7cd9650-61f4-4e9f-8d8b-48beb32b3bcb	\N	true_false	Hoa Sói có bông to, màu đỏ rực rỡ.	["Đúng", "Sai"]	Sai	\N	1	Sai. Hoa sói nhỏ li ti, màu trắng ngà, mọc thành chuỗi.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
d76a170d-1a8c-4bb4-80dd-c7d8ea7b7815	10e81a65-2e1b-4d1f-8d8a-0b6a0811a71d	\N	multiple_choice	Tại sao gọi Lạc là 'Địa Đậu'?	["A. Vì hạt nó màu nâu như đất", "B. Vì quả (củ) của nó nằm dưới lòng đất", "C. Vì nó chỉ mọc ở địa phủ", "D. Vì nó cứng như đá"]	B. Vì quả (củ) của nó nằm dưới lòng đất	\N	1	Địa là đất, Đậu là đậu. Quả lạc phát triển trong đất.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
1a43f45e-99e8-42b0-924c-281976d1a45d	10e81a65-2e1b-4d1f-8d8a-0b6a0811a71d	\N	true_false	Lạc (Đậu phộng) là cây thân gỗ lâu năm.	["Đúng", "Sai"]	Sai	\N	1	Sai. Lạc là cây thân thảo hàng năm.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
9704b478-31ab-4b8c-97fa-ed67b11abf35	616daaaa-e9f8-4e7b-a967-ec7b46df5dc1	\N	multiple_choice	Cây Bá (Trắc bách diệp) thường được trồng ở đâu?	["A. Giữa ruộng lúa", "B. Nơi trang nghiêm như đình, chùa, lăng tẩm", "C. Trong phòng ngủ", "D. Dưới gầm cầu"]	B. Nơi trang nghiêm như đình, chùa, lăng tẩm	\N	1	Dáng cây nghiêm trang, xanh tốt quanh năm phù hợp với không gian tâm linh.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
389c141c-f9fe-4b51-9618-6008531d808a	616daaaa-e9f8-4e7b-a967-ec7b46df5dc1	\N	multiple_choice	Trong y học cổ truyền, Trắc bách diệp có công dụng gì nổi bật?	["A. Cầm máu (chữa chảy máu cam, nôn ra máu)", "B. Chữa đau răng", "C. Làm trắng da", "D. Tăng cân"]	A. Cầm máu (chữa chảy máu cam, nôn ra máu)	\N	2	Lá trắc bá sao đen là vị thuốc cầm máu rất hay.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0f546074-80f3-464b-9158-12f3a09e79d9	a46c369b-7b5b-4478-ad85-492725e5fccb	\N	multiple_choice	Núi Duệ (Duệ Sơn) nằm ở tỉnh nào?	["A. Quảng Nam", "B. Thừa Thiên Huế", "C. Thanh Hóa", "D. Ninh Bình"]	B. Thừa Thiên Huế	\N	1	Đây là ngọn núi danh thắng của đất Cố đô.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
9de5e3d1-a104-4114-bbdb-7cfdfdd9cc14	a46c369b-7b5b-4478-ad85-492725e5fccb	\N	true_false	Núi Duệ là ngọn núi cao nhất Việt Nam.	["Đúng", "Sai"]	Sai	\N	1	Sai. Núi Duệ là ngọn núi thấp, đồi gò ở vùng trung du Huế. Núi cao nhất là Fansipan.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
a91888bd-014b-4dd8-b438-4cc024a803d6	62b76d4a-9f9c-48c5-8a48-bd0e0be00d61	\N	multiple_choice	Nhĩ Hà là tên gọi khác của con sông nào?	["A. Sông Đà", "B. Sông Hồng", "C. Sông Thái Bình", "D. Sông Mã"]	B. Sông Hồng	\N	1	Nhĩ Hà là tên chữ Hán của sông Hồng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
dc78e548-11f2-447b-8fb5-a9a8c3635832	62b76d4a-9f9c-48c5-8a48-bd0e0be00d61	\N	multiple_choice	Đặc điểm nổi bật nhất của nước sông Hồng là gì?	["A. Trong vắt nhìn thấy đáy", "B. Màu xanh biếc", "C. Màu đỏ đục (do nhiều phù sa)", "D. Màu đen"]	C. Màu đỏ đục (do nhiều phù sa)	\N	1	Phù sa lơ lửng tạo nên màu đỏ đặc trưng của dòng sông.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ecb55a1a-2dc1-4ba2-8675-ed89c04dcc68	84039e96-9ff0-4303-a8e0-472f04ffe222	\N	multiple_choice	Trong nghệ thuật, Rồng thường xuất hiện cùng với hình ảnh nào?	["A. Đất", "B. Mây (Vân)", "C. Cây cỏ", "D. Nhà cửa"]	B. Mây (Vân)	\N	1	Rồng đạp mây (Long vân) là hình ảnh quyền lực và linh thiêng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
90ca196e-3fc5-4614-aa62-a47d898110b8	84039e96-9ff0-4303-a8e0-472f04ffe222	\N	true_false	Mây ngũ sắc (Khánh vân) được coi là điềm xui xẻo.	["Đúng", "Sai"]	Sai	\N	1	Sai. Mây ngũ sắc là điềm cực kỳ cát tường, báo hiệu thánh nhân xuất hiện hoặc thái bình thịnh trị.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
4c3f7739-6d9e-4166-a0ea-ed7d71e81099	1a597969-b683-4ccb-beb5-8397de37a0cf	\N	multiple_choice	Mũi Đại Lãnh thuộc tỉnh nào của Việt Nam?	["A. Khánh Hòa", "B. Phú Yên", "C. Bình Định", "D. Ninh Thuận"]	B. Phú Yên	\N	1	Đại Lãnh là danh thắng nổi tiếng của Phú Yên.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
b4e39ad3-0437-4155-aec3-5570cfb153cb	1a597969-b683-4ccb-beb5-8397de37a0cf	\N	true_false	Đại Lãnh là điểm cực Tây của Việt Nam.	["Đúng", "Sai"]	Sai	\N	1	Sai. Đại Lãnh là điểm cực Đông (trên đất liền), nơi đón bình minh sớm nhất.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0514bbb0-7d7b-4292-9e84-12aeb31e4b9b	0ae0148e-d9ac-4549-bdfd-8884967c621e	\N	multiple_choice	Sông Lam thường được nhắc đến cùng với ngọn núi nào?	["A. Núi Ngự", "B. Núi Hồng Lĩnh", "C. Núi Tản Viên", "D. Núi Bà Đen"]	B. Núi Hồng Lĩnh	\N	1	Cặp đôi 'Núi Hồng - Sông Lam' là biểu tượng của Nghệ Tĩnh.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
7a90b558-c6ab-4a88-afa0-404b53a342a8	0ae0148e-d9ac-4549-bdfd-8884967c621e	\N	multiple_choice	Sông Lam chảy qua tỉnh nào?	["A. Nghệ An và Hà Tĩnh", "B. Thanh Hóa", "C. Quảng Bình", "D. Quảng Ninh"]	A. Nghệ An và Hà Tĩnh	\N	1	Sông Lam là ranh giới tự nhiên và dòng sông chính của hai tỉnh này.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
711b04a5-486c-49fa-a2e1-7b6a412f95b2	8e2b8abb-d36a-4176-b130-cb1c9631078a	\N	multiple_choice	Thành ngữ 'Dính như sam' xuất phát từ đặc điểm gì của loài này?	["A. Chúng có nhiều chân dính chặt vào đá", "B. Con đực và con cái luôn bám chặt lấy nhau đi có đôi", "C. Thịt của chúng rất dính", "D. Chúng tiết ra keo dính"]	B. Con đực và con cái luôn bám chặt lấy nhau đi có đôi	\N	1	Sam luôn đi cặp đôi, con đực bám trên lưng con cái.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
28d3a86b-1bfb-498a-8e75-cb00f9134c47	8e2b8abb-d36a-4176-b130-cb1c9631078a	\N	true_false	Con Sam và con So là cùng một loài.	["Đúng", "Sai"]	Sai	\N	1	Sai. Con So rất giống con Sam nhưng nhỏ hơn và chứa độc tố Tetrodotoxin gây chết người.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
a4b7fb3e-aa01-4171-87ea-b2a5e180e413	fd43425d-1e0b-44bf-9be9-bf6fbfe94168	\N	multiple_choice	Trong câu ca dao 'Tay bưng đĩa muối chén gừng...', gừng và muối tượng trưng cho điều gì?	["A. Sự nghèo khó", "B. Tình nghĩa vợ chồng thủy chung, mặn nồng", "C. Bữa ăn đạm bạc", "D. Sự chua chát của cuộc đời"]	B. Tình nghĩa vợ chồng thủy chung, mặn nồng	\N	1	'Gừng cay muối mặn xin đừng quên nhau'.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
94d936eb-88f5-4948-af56-a4dee50acb1c	fd43425d-1e0b-44bf-9be9-bf6fbfe94168	\N	true_false	Gừng có tính hàn (lạnh).	["Đúng", "Sai"]	Sai	\N	1	Sai. Gừng có tính ôn/nhiệt (ấm/nóng), dùng để trị các bệnh do lạnh.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
51682803-bf59-4c4a-bb33-315b0ce1da3c	4bbd7497-e84d-46c8-871f-62a42a7c9465	\N	multiple_choice	Vũ khí nổi tiếng gắn liền với truyền thuyết An Dương Vương và thành Cổ Loa là gì?	["A. Kiếm Thuận Thiên", "B. Nỏ Thần", "C. Súng Thần công", "D. Ngựa sắt"]	B. Nỏ Thần	\N	1	Nỏ thần Kim Quy giúp An Dương Vương đánh bại Triệu Đà.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0b4d4119-5588-4378-b96d-a9197accfae7	4bbd7497-e84d-46c8-871f-62a42a7c9465	\N	multiple_choice	So với cung, nỏ có ưu điểm gì?	["A. Bắn nhanh hơn", "B. Có thể giữ dây căng sẵn chờ bắn (có lẫy cò) và ngắm bắn kỹ hơn", "C. Nhẹ hơn", "D. Dễ chế tạo hơn"]	B. Có thể giữ dây căng sẵn chờ bắn (có lẫy cò) và ngắm bắn kỹ hơn	\N	2	Nỏ có lẫy giữ dây nên người bắn không mất sức giữ, có thể ngắm lâu và chính xác.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
6b3444fe-e2f4-4b60-bee0-b9d1f3a2f333	db5621b4-394c-4edc-924c-e3110b1c9941	\N	multiple_choice	Lê Thuyền là phương tiện di chuyển trên địa hình nào?	["A. Đường bộ", "B. Đường thủy (sông, biển)", "C. Đường không", "D. Đường hầm"]	B. Đường thủy (sông, biển)	\N	1	Đây là một loại thuyền chèo.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
7ee4f4e0-cd40-479b-ad35-7033b34263d9	db5621b4-394c-4edc-924c-e3110b1c9941	\N	true_false	Lê Thuyền là loại tàu chiến lớn nhất của nhà Nguyễn.	["Đúng", "Sai"]	Sai	\N	2	Sai. Lê Thuyền là thuyền nhỏ/trung bình. Tàu lớn là tàu bọc đồng hoặc Định Quốc.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
4713417f-e6cf-4774-a7ae-abe45a9dc536	1f9addcc-52d4-416f-80b0-a10cc3de6da2	\N	multiple_choice	Trong tranh dân gian Đông Hồ, con lợn thường được vẽ với đặc điểm gì?	["A. Gầy gò, ốm yếu", "B. Béo tốt, có xoáy âm dương trên mình", "C. Đang đánh nhau", "D. Đang bay"]	B. Béo tốt, có xoáy âm dương trên mình	\N	1	Hình ảnh lợn âm dương thể hiện sự phồn thực, sinh sôi và hòa hợp.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0edddd1b-4790-4dee-a75f-b744830880e7	1f9addcc-52d4-416f-80b0-a10cc3de6da2	\N	true_false	Con Lợn (Thỉ) là con vật đứng đầu trong 12 con giáp.	["Đúng", "Sai"]	Sai	\N	1	Sai. Lợn (Hợi) đứng cuối cùng. Chuột (Tý) mới đứng đầu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
a2f0f7ba-4eec-44d6-95d4-34cb2c02ac83	d14077fe-7eee-4829-8a7b-ecfd8f3936ef	\N	multiple_choice	Con Ngoan (Vích) sống chủ yếu ở đâu?	["A. Trên núi cao", "B. Trong sông hồ", "C. Ngoài biển khơi", "D. Trong hang động"]	C. Ngoài biển khơi	\N	1	Vích là loài rùa biển.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
7ed632c1-08f6-407f-9732-c3004c7f3750	d14077fe-7eee-4829-8a7b-ecfd8f3936ef	\N	true_false	Vích là loài động vật đẻ con.	["Đúng", "Sai"]	Sai	\N	1	Sai. Vích là loài bò sát, chúng đẻ trứng trên bãi cát.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
920f101c-144e-4fa2-ba2e-b470c0f118af	96577e61-6e05-4640-92b0-3c1e025f9fb9	\N	multiple_choice	Chữ 'Dụ' trong tên Dụ Đỉnh có ý nghĩa gì?	["A. Buồn bã", "B. Giàu có, dư dả, khoan dung", "C. Dụ dỗ", "D. Dũng cảm"]	B. Giàu có, dư dả, khoan dung	\N	1	Dụ trong 'Phú dụ' (giàu có) hoặc 'Khoan dụ' (rộng lượng).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
99b05980-366d-445a-9b45-57799cf71e61	96577e61-6e05-4640-92b0-3c1e025f9fb9	\N	true_false	Dụ Đỉnh ứng với thụy hiệu của vua Gia Long.	["Đúng", "Sai"]	Sai	\N	1	Sai. Vua Gia Long ứng với Cao Đỉnh. Dụ Đỉnh không ứng với thụy hiệu chính thức nào hoặc được coi là đỉnh 'chờ'.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
a7c5392c-81c5-467b-8e51-8da21d895a4f	51180b9a-6c5a-48fd-9784-229c979352b2	\N	multiple_choice	Đặc điểm nổi bật nhất của chim Anh Vũ (Vẹt) là gì?	["A. Chạy rất nhanh", "B. Biết bơi", "C. Có thể bắt chước tiếng người", "D. Săn mồi ban đêm"]	C. Có thể bắt chước tiếng người	\N	1	Khả năng 'nhại' tiếng của vẹt là đặc điểm nổi tiếng nhất.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
75b8c7b6-7ac8-4067-8219-b31a5b121bad	51180b9a-6c5a-48fd-9784-229c979352b2	\N	true_false	Chim Anh Vũ có mỏ thẳng và dài.	["Đúng", "Sai"]	Sai	\N	1	Sai. Vẹt có chiếc mỏ quặp, rất khỏe để cắn vỡ hạt cứng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
d6239376-31de-4621-a68d-30b79d9766eb	31eab81a-d2b3-491d-9157-42e3ee5c3ef9	\N	multiple_choice	Ở Việt Nam, cây Lê được trồng chủ yếu ở vùng nào?	["A. Đồng bằng sông Cửu Long", "B. Duyên hải miền Trung", "C. Miền núi phía Bắc (Lạng Sơn, Cao Bằng)", "D. Tây Nguyên"]	C. Miền núi phía Bắc (Lạng Sơn, Cao Bằng)	\N	1	Lê là cây ôn đới, ưa khí hậu mát mẻ của vùng núi cao.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
27acdda4-cbd4-4399-b8ad-c25f0961b670	31eab81a-d2b3-491d-9157-42e3ee5c3ef9	\N	multiple_choice	Quả Lê có tác dụng gì trong y học?	["A. Gây nóng trong người", "B. Nhuận phế, giảm ho, tiêu đờm", "C. Làm tăng huyết áp", "D. Gây mất ngủ"]	B. Nhuận phế, giảm ho, tiêu đờm	\N	2	Lê chưng đường phèn là bài thuốc trị ho khan rất tốt.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ec386e50-84bb-441d-90aa-969e4b80dc5e	e3690c96-2f06-426b-8409-b2edc01f5349	\N	multiple_choice	Lá Trầu không thường được dùng chung với quả gì?	["A. Quả Sung", "B. Quả Cau", "C. Quả Táo", "D. Quả Ổi"]	B. Quả Cau	\N	1	Trầu và Cau là cặp đôi không thể tách rời trong tục ăn trầu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
2a479736-ecea-406f-8dda-1c2a564812a2	e3690c96-2f06-426b-8409-b2edc01f5349	\N	true_false	Lá Trầu không có tính sát khuẩn.	["Đúng", "Sai"]	Đúng	\N	1	Tinh dầu trong lá trầu có khả năng diệt khuẩn, nấm rất tốt.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
7217f0bd-3d03-4d34-8a9a-80639c53976c	4f795d28-a54d-4e16-8e5e-deceae503114	\N	multiple_choice	Bạch Đầu trong nhóm cây lương thực là cây gì?	["A. Cây lúa", "B. Cây đậu trắng", "C. Cây ngô", "D. Cây khoai"]	B. Cây đậu trắng	\N	1	Bạch là trắng, Đầu (Đậu) là đậu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
38112bea-d323-44d0-aebd-af7cc2d62353	4f795d28-a54d-4e16-8e5e-deceae503114	\N	true_false	Đậu trắng chứa nhiều protein thực vật.	["Đúng", "Sai"]	Đúng	\N	1	Như các loại đậu khác, đậu trắng là nguồn đạm thực vật dồi dào.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
4dcc8403-8987-45f2-b18e-18ada657eb8f	c2ed38c9-e06d-479c-98ec-e3058575a6b7	\N	multiple_choice	Cây Thuần Hoa (Dâm bụt) thường được trồng để làm gì ở nông thôn?	["A. Lấy gỗ làm nhà", "B. Làm hàng rào", "C. Lấy quả ăn", "D. Dệt vải"]	B. Làm hàng rào	\N	1	Hàng rào dâm bụt đỏ rực là hình ảnh quen thuộc của làng quê.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
8bdc0a06-31d8-4ec3-a56f-fbdc5914b455	c2ed38c9-e06d-479c-98ec-e3058575a6b7	\N	true_false	Hoa Dâm bụt rất thơm.	["Đúng", "Sai"]	Sai	\N	1	Câu thành ngữ 'Hữu sắc vô hương' thường dùng để nói về hoa dâm bụt.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
30cadbb6-6a51-4389-9c79-a1e296a7aab8	2dcbf913-dcf1-4f01-b722-4a7f3719959c	\N	multiple_choice	Cây Tùng tượng trưng cho phẩm chất gì của con người?	["A. Sự yếu đuối", "B. Sự khôn vặt", "C. Khí tiết quân tử, kiên cường", "D. Sự lười biếng"]	C. Khí tiết quân tử, kiên cường	\N	1	Tùng chịu được sương gió lạnh giá mà vẫn xanh tươi.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e3f5f3b8-1f44-4084-b725-f45cb1109adb	2dcbf913-dcf1-4f01-b722-4a7f3719959c	\N	multiple_choice	Bộ Tứ quý gồm những cây nào?	["A. Tùng, Cúc, Trúc, Mai", "B. Lan, Huệ, Hồng, Cúc", "C. Mít, Dừa, Đu đủ, Xoài", "D. Chanh, Cam, Quýt, Bưởi"]	A. Tùng, Cúc, Trúc, Mai	\N	1	Đây là 4 loài cây biểu tượng cho 4 mùa và các đức tính tốt đẹp.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
8795d9b5-2e8e-413f-a729-d0510ffaf71a	c3fc424f-3325-4801-9608-03cd6de1a20d	\N	multiple_choice	Hải Vân Quan nằm trên đỉnh đèo nào?	["A. Đèo Ngang", "B. Đèo Hải Vân", "C. Đèo Cả", "D. Đèo Cù Mông"]	B. Đèo Hải Vân	\N	1	Đèo Hải Vân (Đèo Mây) là ranh giới tự nhiên giữa Huế và Đà Nẵng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
4065e79e-e91e-4eee-8e67-555cb153af5a	c3fc424f-3325-4801-9608-03cd6de1a20d	\N	multiple_choice	Danh hiệu 'Thiên hạ đệ nhất hùng quan' được khắc ở đâu?	["A. Trên đỉnh núi Fansipan", "B. Trên cửa ải Hải Vân Quan", "C. Ở động Phong Nha", "D. Ở Vịnh Hạ Long"]	B. Trên cửa ải Hải Vân Quan	\N	2	Vua Lê Thánh Tông là người đầu tiên phong tặng danh hiệu này.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
5ab11ecb-9e0c-4cc8-8931-936ab854a657	f24dff99-3868-48eb-8df3-06e9b9585590	\N	multiple_choice	Sông Vĩnh Điện chảy qua tỉnh nào?	["A. Quảng Ngãi", "B. Quảng Nam", "C. Bình Định", "D. Phú Yên"]	B. Quảng Nam	\N	1	Sông thuộc địa phận thị xã Điện Bàn, Quảng Nam.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
2f19795a-3726-430f-b9b7-c785caf4f997	f24dff99-3868-48eb-8df3-06e9b9585590	\N	true_false	Sông Vĩnh Điện nối liền sông Thu Bồn và sông Hàn.	["Đúng", "Sai"]	Đúng	\N	2	Đây là tuyến đường thủy quan trọng kết nối hai hệ thống sông lớn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ecad8256-92d7-49c9-8e21-a5b699bd3a71	0c5ee60c-60d8-452d-9944-c1d87c17cc48	\N	multiple_choice	Theo kinh nghiệm dân gian, tiếng sấm có tác dụng gì đối với cây lúa?	["A. Làm lúa chết", "B. Giúp lúa phát triển nhanh (phất cờ mà lên)", "C. Làm lúa bị sâu bệnh", "D. Không có tác dụng gì"]	B. Giúp lúa phát triển nhanh (phất cờ mà lên)	\N	1	Sấm sét tạo ra phản ứng hóa học cố định đạm trong nước mưa, bón cho lúa.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
8a3f0326-2a30-4773-bd92-23b33d0294ef	0c5ee60c-60d8-452d-9944-c1d87c17cc48	\N	multiple_choice	Vị thần nào cai quản sấm sét trong thần thoại Việt Nam?	["A. Thần Gió", "B. Thần Mưa", "C. Thiên Lôi (Ông Sấm)", "D. Hà Bá"]	C. Thiên Lôi (Ông Sấm)	\N	1	Thiên Lôi cầm búa tầm sét để trừng trị kẻ gian ác.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
60017d4a-2be9-402a-aad9-e9f3d773fc52	b1df8b65-1219-483d-9e41-6e8943b76a03	\N	multiple_choice	Sông Vệ là con sông thuộc tỉnh nào?	["A. Quảng Ngãi", "B. Bình Định", "C. Phú Yên", "D. Khánh Hòa"]	A. Quảng Ngãi	\N	1	Sông Vệ cùng với sông Trà Khúc là hai sông lớn của Quảng Ngãi.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
55eb17cc-87d1-459d-b904-c4e07288723c	b1df8b65-1219-483d-9e41-6e8943b76a03	\N	true_false	Sông Vệ là một con sông rất hung dữ, quanh năm lũ lụt.	["Đúng", "Sai"]	Sai	\N	2	Sai. Sông Vệ chảy khá êm đềm, tuy cũng có lũ vào mùa mưa nhưng nhìn chung là dòng sông hiền hòa.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f25b9722-9c77-4228-9b50-f398a0501a52	a473c901-10b7-4d38-82fa-cbbacd08a06f	\N	multiple_choice	Cửa biển Đà Nẵng còn có tên gọi dân gian là gì?	["A. Cửa Tùng", "B. Cửa Hàn", "C. Cửa Lò", "D. Cửa Hội"]	B. Cửa Hàn	\N	1	Do nằm ở cửa sông Hàn nên gọi là Cửa Hàn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
581490f5-1886-4d79-9084-e7207d663123	a473c901-10b7-4d38-82fa-cbbacd08a06f	\N	multiple_choice	Sự kiện lịch sử nào gắn liền với cửa biển Đà Nẵng năm 1858?	["A. Chiến thắng Bạch Đằng", "B. Liên quân Pháp - Tây Ban Nha nổ súng xâm lược Việt Nam", "C. Nhật đảo chính Pháp", "D. Cách mạng tháng Tám"]	B. Liên quân Pháp - Tây Ban Nha nổ súng xâm lược Việt Nam	\N	2	Đà Nẵng là nơi thực dân Pháp nổ phát súng đầu tiên xâm lược nước ta.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
d859ed01-9787-464e-924c-c332c3f6a809	06288f6c-521d-4ae8-943c-3c11336a2159	\N	multiple_choice	Cá Mú (Thạch Thủ Ngư) thường sống ở môi trường nào?	["A. Ao hồ nước ngọt", "B. Rạn san hô, hốc đá dưới biển", "C. Trên cạn", "D. Trong bùn lầy"]	B. Rạn san hô, hốc đá dưới biển	\N	1	Cá mú là loài cá rạn san hô điển hình.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
1572a951-18f2-4d6a-8b67-79786856f09d	06288f6c-521d-4ae8-943c-3c11336a2159	\N	true_false	Thịt cá Mú rất dở và rẻ tiền.	["Đúng", "Sai"]	Sai	\N	1	Sai. Cá Mú là loại hải sản cao cấp, thịt rất ngon và đắt tiền.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
585c929e-2990-4b35-a341-d36d087b0d12	ca189580-e780-4a1b-b058-72fed51694f4	\N	multiple_choice	Công dụng y học nổi tiếng nhất của lá Tía tô là gì?	["A. Chữa đau chân", "B. Giải cảm, trừ hàn", "C. Làm thuốc mê", "D. Chữa cận thị"]	B. Giải cảm, trừ hàn	\N	1	Bát cháo tía tô nóng giúp ra mồ hôi, giải cảm rất tốt.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
47c3ac8a-3ac9-4053-b6ee-67ccc55f8939	ca189580-e780-4a1b-b058-72fed51694f4	\N	true_false	Lá Tía tô có màu xanh hoàn toàn.	["Đúng", "Sai"]	Sai	\N	1	Sai. Lá tía tô thường có màu tím hoặc mặt trên xanh mặt dưới tím.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
d9b4328b-0647-4a4b-999d-1c14836f16a4	07b1be33-af84-4928-82c4-405f27fb3875	\N	multiple_choice	Đặc điểm nhận dạng của Ô Thuyền là gì?	["A. Sơn màu đỏ", "B. Sơn màu đen", "C. Sơn màu vàng", "D. Không sơn"]	B. Sơn màu đen	\N	1	Ô có nghĩa là màu đen (như Ô thước, ngựa Ô).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f4c5e644-313f-4489-9463-dba6835218d1	07b1be33-af84-4928-82c4-405f27fb3875	\N	multiple_choice	Ô Thuyền được dùng để làm gì?	["A. Chở lúa gạo", "B. Chiến đấu trên biển", "C. Đua thuyền giải trí", "D. Rước dâu"]	B. Chiến đấu trên biển	\N	1	Đây là một loại thuyền chiến (chiến hạm) của triều đình.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
93d825c8-93be-47eb-b282-b243a7006b52	bc0cc630-57db-4918-a144-5ab55b9b2ab2	\N	multiple_choice	Phác Đao là loại vũ khí như thế nào?	["A. Dao găm nhỏ", "B. Đao có cán dài", "C. Kiếm hai lưỡi", "D. Cung tên"]	B. Đao có cán dài	\N	1	Cán dài giúp tăng lực chém và tầm với.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f3c5bc07-dcc1-406d-b384-3f3454980aa6	bc0cc630-57db-4918-a144-5ab55b9b2ab2	\N	true_false	Phác Đao chủ yếu dùng để bắn từ xa.	["Đúng", "Sai"]	Sai	\N	1	Sai. Phác đao là vũ khí cận chiến dùng để chém, bổ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
8db05101-a818-432c-b8c2-bec1f9bc7f56	de7364d9-540b-4930-847e-660e19b01b42	\N	multiple_choice	Con Cáp (Sò) thuộc nhóm động vật nào?	["A. Cá", "B. Giáp xác (Tôm cua)", "C. Nhuyễn thể hai mảnh vỏ", "D. Bò sát"]	C. Nhuyễn thể hai mảnh vỏ	\N	1	Sò, nghêu, hến đều thuộc lớp hai mảnh vỏ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
f0beb9dc-8520-4c87-b5a2-76d615b68daa	de7364d9-540b-4930-847e-660e19b01b42	\N	true_false	Vỏ sò không có tác dụng gì, chỉ vứt đi.	["Đúng", "Sai"]	Sai	\N	1	Sai. Vỏ sò nung vôi để ăn trầu, xây nhà hoặc làm đồ mỹ nghệ.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
b851a062-5412-434d-93a2-4dd790b1e60a	2c276f27-89b1-415f-a842-2441a0a04586	\N	multiple_choice	Trong 12 con giáp, con Dê (Mùi) đứng ở vị trí thứ mấy?	["A. 1", "B. 6", "C. 8", "D. 12"]	C. 8	\N	1	Tý, Sửu, Dần, Mão, Thìn, Tỵ, Ngọ, Mùi (8).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
0da0f709-7fed-4a55-a645-dfb0e325b3d7	2c276f27-89b1-415f-a842-2441a0a04586	\N	multiple_choice	Câu chúc 'Tam dương khai thái' liên quan đến con vật nào?	["A. Con Cừu", "B. Con Dê", "C. Con Ngựa", "D. Con Gà"]	B. Con Dê	\N	2	Tam dương (3 con dê) biểu thị cho tháng Giêng (tháng Dần), dương khí bắt đầu thịnh, mang lại may mắn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
10905d60-300f-4e4d-bd9b-595306011d88	b57e45b6-98c6-4315-86f6-7bc6be066a30	\N	multiple_choice	Chữ 'Huyền' trong tên Huyền Đỉnh có ý nghĩa gì?	["A. Màu trắng, sáng sủa", "B. Màu đen, sâu xa, huyền diệu", "C. Màu đỏ, rực rỡ", "D. Màu xanh, hy vọng"]	B. Màu đen, sâu xa, huyền diệu	\N	1	Huyền (như trong Huyền bí) chỉ màu đen hoặc sự sâu thẳm khó lường.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
1811393d-8874-4d74-b142-e6ac663a6526	b57e45b6-98c6-4315-86f6-7bc6be066a30	\N	true_false	Huyền Đỉnh là chiếc đỉnh lớn nhất trong Cửu Đỉnh.	["Đúng", "Sai"]	Sai	\N	1	Sai. Cao Đỉnh mới là đỉnh lớn nhất. Huyền Đỉnh là một trong những đỉnh nhỏ hơn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
398b1f3d-1cb8-4f88-847d-0a74f70c1102	89b9b2fe-c54a-4a46-b6d5-748d03e7c854	\N	multiple_choice	Hoa Ngọc Lan (Ngũ Điệp Lan) có màu gì?	["A. Màu đỏ", "B. Màu tím", "C. Màu trắng ngà", "D. Màu xanh dương"]	C. Màu trắng ngà	\N	1	Hoa ngọc lan trắng muốt hoặc trắng ngà, rất thơm.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
c609a7f9-1eee-408e-b345-df061ae7d461	89b9b2fe-c54a-4a46-b6d5-748d03e7c854	\N	true_false	Cây Ngọc Lan là loài cây thân leo.	["Đúng", "Sai"]	Sai	\N	1	Sai. Ngọc Lan là cây thân gỗ lớn, có thể cao hàng chục mét.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
1c90fa4d-3cff-4245-aa67-e75365444089	322f9cff-9b9f-4929-8aac-131652a7dca0	\N	multiple_choice	Vụ án oan nổi tiếng trong lịch sử liên quan đến Nguyễn Trãi có tên là gì?	["A. Vụ án hồ Hoàn Kiếm", "B. Vụ án Lệ Chi Viên (Vườn Vải)", "C. Vụ án sông Tô Lịch", "D. Vụ án núi Tản Viên"]	B. Vụ án Lệ Chi Viên (Vườn Vải)	\N	1	Lệ Chi Viên nghĩa là Vườn cây vải, nơi vua Lê Thái Tông băng hà đột ngột.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
084ee7a3-c6eb-4748-a402-446fe505dc8f	322f9cff-9b9f-4929-8aac-131652a7dca0	\N	multiple_choice	Vùng đất nào ở Việt Nam nổi tiếng với Vải thiều?	["A. Thanh Hà (Hải Dương) và Lục Ngạn (Bắc Giang)", "B. Đà Lạt (Lâm Đồng)", "C. Nha Trang (Khánh Hòa)", "D. Châu Đốc (Ninh Thuận)"]	A. Thanh Hà (Hải Dương) và Lục Ngạn (Bắc Giang)	\N	1	Đây là hai vựa vải lớn và ngon nhất cả nước.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
87b844bd-8244-4401-bac0-6b3511fc46d5	88c71d23-5d73-40dd-93e7-8a01b28d2b16	\N	multiple_choice	Theo quan niệm dân gian, tỏi thường được dùng để làm gì ngoài việc nấu ăn?	["A. Làm đẹp da", "B. Trừ tà ma, tránh gió độc", "C. Nhuộm quần áo", "D. Làm mực viết"]	B. Trừ tà ma, tránh gió độc	\N	1	Người xưa thường đeo tỏi cho trẻ em hoặc treo tỏi trước cửa để xua đuổi tà khí.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
4db7985d-cea6-47ae-98fd-3f9ac11056df	88c71d23-5d73-40dd-93e7-8a01b28d2b16	\N	true_false	Tỏi có tác dụng kháng khuẩn, tăng cường hệ miễn dịch.	["Đúng", "Sai"]	Đúng	\N	1	Tỏi chứa allicin là một chất kháng sinh tự nhiên mạnh.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
fd6027d8-c322-4399-b474-aa1c81ed0e55	9a6da058-cd77-4cf3-8442-394cd39f958a	\N	multiple_choice	Câu nói nổi tiếng 'Nam dược trị Nam nhân' (Thuốc Nam chữa bệnh người Nam) là của ai?	["A. Tuệ Tĩnh", "B. Hải Thượng Lãn Ông (Lê Hữu Trác)", "C. Hoa Đà", "D. Biển Thước"]	A. Tuệ Tĩnh	\N	2	Thiền sư Tuệ Tĩnh được tôn vinh là ông tổ của ngành thuốc Nam.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
7238447c-3dbf-48b5-bda8-e4cd723cab67	9a6da058-cd77-4cf3-8442-394cd39f958a	\N	true_false	Việt Nam không có loài sâm nào quý, phải nhập khẩu hoàn toàn.	["Đúng", "Sai"]	Sai	\N	1	Sai. Việt Nam có Sâm Ngọc Linh, Sâm Bố Chính, Sâm Lai Châu... đều là dược liệu rất quý.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
1ca05abf-b1a0-4672-9ca0-7dd5c1344ced	40e651b8-3308-462b-bbd0-c64f64023591	\N	multiple_choice	Sợi của cây Bông (Miên) được dùng để làm gì?	["A. Làm thức ăn", "B. Kéo sợi dệt vải", "C. Làm thuốc nổ", "D. Xây nhà"]	B. Kéo sợi dệt vải	\N	1	Bông (cotton) là nguyên liệu dệt may phổ biến nhất thế giới.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
1eceedc2-09d0-487b-80e2-120377a52488	40e651b8-3308-462b-bbd0-c64f64023591	\N	true_false	Quả bông khi chín có màu đỏ rực.	["Đúng", "Sai"]	Sai	\N	1	Sai. Quả bông khi chín nứt ra lộ lớp xơ bông màu trắng tinh.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
18dc50ff-01fa-4374-aade-da60dff989d5	063b1479-5e88-47c5-9a39-1161e3ee04e9	\N	multiple_choice	Chim Thốc Thu (Già đẫy) có đặc điểm ngoại hình gì nổi bật?	["A. Bộ lông bảy sắc cầu vồng", "B. Đầu và cổ trụi lông (hói)", "C. Đuôi dài như chim công", "D. Mỏ ngắn tí hon"]	B. Đầu và cổ trụi lông (hói)	\N	2	Đầu hói khiến chúng trông như những ông già, nên gọi là Già đẫy.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
b4b43f85-80ab-441a-b45d-fba328903e37	063b1479-5e88-47c5-9a39-1161e3ee04e9	\N	true_false	Chim Già đẫy thường sống ở vùng núi cao khô hạn.	["Đúng", "Sai"]	Sai	\N	1	Sai. Chúng sống ở vùng đất ngập nước, đầm lầy để kiếm ăn.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
907d7761-868b-445f-bbc3-2e9f2dcbdf6a	703b31cf-271c-44a8-9225-a97b11c598d4	\N	multiple_choice	Cầu Vồng thường xuất hiện khi nào?	["A. Giữa đêm khuya", "B. Trước hoặc sau cơn mưa khi có nắng", "C. Khi tuyết rơi", "D. Khi trời tối đen như mực"]	B. Trước hoặc sau cơn mưa khi có nắng	\N	1	Cần có ánh nắng mặt trời chiếu qua các hạt mưa để tạo ra cầu vồng.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
5873b9b0-11ce-4992-9fff-c78e161eb6cd	703b31cf-271c-44a8-9225-a97b11c598d4	\N	true_false	Cầu vồng chỉ có 3 màu chính.	["Đúng", "Sai"]	Sai	\N	1	Sai. Cầu vồng có 7 màu cơ bản: Đỏ, Cam, Vàng, Lục, Lam, Chàm, Tím.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
812563ac-6bc2-4a2e-9a1c-62c9a6c8a85a	a418ffb9-bc04-46b0-a6e3-d70ab13e4f39	\N	multiple_choice	Sông Tiền và Sông Hậu là hai nhánh của con sông lớn nào?	["A. Sông Hồng", "B. Sông Đồng Nai", "C. Sông Mê Kông (Cửu Long)", "D. Sông Thu Bồn"]	C. Sông Mê Kông (Cửu Long)	\N	1	Sông Mê Kông khi vào Việt Nam chia làm 2 nhánh Tiền và Hậu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ff3e0bf3-8253-44a6-91e6-81db54571c02	a418ffb9-bc04-46b0-a6e3-d70ab13e4f39	\N	multiple_choice	Đồng bằng sông Cửu Long nổi tiếng là gì của cả nước?	["A. Vựa than đá", "B. Vựa lúa, trái cây và thủy sản lớn nhất", "C. Trung tâm công nghiệp nặng", "D. Vùng núi cao hiểm trở"]	B. Vựa lúa, trái cây và thủy sản lớn nhất	\N	1	Nơi đây đóng góp phần lớn sản lượng gạo và trái cây xuất khẩu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
295ac0e6-43c2-4607-b329-266caf98a8c8	da2973be-78ac-4988-9e37-723d1c862eae	\N	multiple_choice	Trong câu tục ngữ về nông nghiệp 'Nhất nước, nhì phân, tam cần, tứ giống', yếu tố nào quan trọng nhất?	["A. Phân bón", "B. Nước (Mưa/Thủy lợi)", "C. Sức lao động", "D. Giống cây"]	B. Nước (Mưa/Thủy lợi)	\N	1	Không có nước thì cây không thể sống được, nên nước (Vũ/Thủy) đứng đầu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e9ecead0-4e40-460e-a640-e107027c5a75	da2973be-78ac-4988-9e37-723d1c862eae	\N	true_false	Mưa axit là loại mưa tốt cho cây trồng.	["Đúng", "Sai"]	Sai	\N	1	Sai. Mưa axit do ô nhiễm môi trường gây hại cho cây cối và công trình.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e6d0ee13-ef3f-4e44-9428-a6d01b3e10f4	6640dd03-34a0-4968-afc4-c5c87006b5b1	\N	multiple_choice	Bài thơ nổi tiếng nào miêu tả cảnh đẹp của Đèo Ngang (Hoành Sơn)?	["A. Bạn đến chơi nhà", "B. Qua Đèo Ngang", "C. Sông Lấp", "D. Thu điếu"]	B. Qua Đèo Ngang	\N	1	Bài thơ của Bà Huyện Thanh Quan là kiệt tác thơ Nôm đường luật.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
ea99117b-449b-40f0-8f06-c9baa988fcf4	6640dd03-34a0-4968-afc4-c5c87006b5b1	\N	multiple_choice	Đèo Ngang là ranh giới giữa hai tỉnh nào?	["A. Nghệ An - Hà Tĩnh", "B. Hà Tĩnh - Quảng Bình", "C. Quảng Bình - Quảng Trị", "D. Quảng Trị - Thừa Thiên Huế"]	B. Hà Tĩnh - Quảng Bình	\N	2	Dãy Hoành Sơn đâm ra biển tạo thành Đèo Ngang ngăn cách hai tỉnh này.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
a7f13090-748f-4135-8692-5ceb27aa17ac	9ed204bb-61b1-4796-9159-a93d1e5be3e3	\N	multiple_choice	Sông Thao chảy qua vùng đất nào được coi là Đất Tổ vua Hùng?	["A. Hà Nội", "B. Phú Thọ", "C. Thái Bình", "D. Nam Định"]	B. Phú Thọ	\N	1	Đền Hùng (Việt Trì, Phú Thọ) nằm gần ngã ba sông, nơi sông Thao chảy qua.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
aa2dac84-bcc4-4517-9e48-e15c5e6316de	9ed204bb-61b1-4796-9159-a93d1e5be3e3	\N	true_false	Sông Thao nước rất trong xanh.	["Đúng", "Sai"]	Sai	\N	1	Sai. Sông Thao (Sông Hồng) nổi tiếng với màu nước đỏ đục phù sa.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
60fb01da-094e-4a55-8561-41342fbda737	4e87a6eb-b18a-4a41-9ebf-d7e1479f07a9	\N	multiple_choice	Tinh dầu Cà Cuống có mùi thơm giống loại gia vị nào?	["A. Mùi Hạt Tiêu", "B. Mùi Quế", "C. Mùi Gừng", "D. Mùi Sả"]	B. Mùi Quế	\N	1	Chính vì mùi thơm giống quế nên nó còn được gọi là 'Sâu quế' hay 'Quế đỏ'.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
6c640639-d155-45ea-aa17-edce3f3ca32c	4e87a6eb-b18a-4a41-9ebf-d7e1479f07a9	\N	true_false	Con Cà Cuống cái mới có tinh dầu thơm.	["Đúng", "Sai"]	Sai	\N	2	Sai. Chỉ con đực mới có túi tinh dầu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
541b1b17-0ecf-42fc-bc6a-0a91ff7b9072	904b3781-be62-4b6a-87d8-4a613a1693a2	\N	multiple_choice	Thành ngữ 'Xa thư đồng văn' có ý nghĩa gì?	["A. Xe và sách giống nhau", "B. Đất nước thống nhất (xe cùng cỡ trục, sách cùng chữ viết)", "C. Đi xe đọc sách", "D. Mua xe tặng sách"]	B. Đất nước thống nhất (xe cùng cỡ trục, sách cùng chữ viết)	\N	2	Đây là tư tưởng thống nhất giang sơn về mọi mặt của các triều đại phong kiến.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
e6b7f16e-9eb3-4708-98ad-22c7d55583cf	904b3781-be62-4b6a-87d8-4a613a1693a2	\N	true_false	Xa (Xe) thời xưa chủ yếu chạy bằng động cơ hơi nước.	["Đúng", "Sai"]	Sai	\N	1	Sai. Xe thời xưa dùng sức kéo của động vật (ngựa, trâu) hoặc sức người.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
bbc7fc6a-38ef-48f3-bd79-8d9ab2ab86ec	a532c055-3b0c-449c-a5dd-1af1d5b8a0e7	\N	multiple_choice	Trong truyện cổ tích Thạch Sanh, nhân vật chính đã chiến đấu với con quái vật nào?	["A. Hồ Ly Tinh", "B. Chằn Tinh (Mãng Xà)", "C. Bạch Cốt Tinh", "D. Nhện Tinh"]	B. Chằn Tinh (Mãng Xà)	\N	1	Thạch Sanh chém đầu chằn tinh (mãng xà) để cứu người.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
5431a563-605c-44ba-bb85-a3888ea0ef78	a532c055-3b0c-449c-a5dd-1af1d5b8a0e7	\N	true_false	Mãng Xà là loài vật nhỏ bé, hiền lành.	["Đúng", "Sai"]	Sai	\N	1	Sai. Mãng xà là loài rắn lớn, hung dữ và nguy hiểm.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
d24fa7b7-607a-43dc-abc5-86f321293461	9308802b-a83f-4509-95e3-b4124bb24d3b	\N	multiple_choice	Hỏa Phún Đồng là loại vũ khí tấn công bằng gì?	["A. Bắn tên", "B. Phun nước", "C. Phun lửa", "D. Ném đá"]	C. Phun lửa	\N	1	Hỏa là lửa, Phún là phun. Vũ khí dùng lửa để đốt cháy mục tiêu.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
b611e9a5-06d4-4ad7-82a4-db16709f9c0c	9308802b-a83f-4509-95e3-b4124bb24d3b	\N	true_false	Quân đội nhà Nguyễn chỉ sử dụng gươm giáo, không có hỏa khí.	["Đúng", "Sai"]	Sai	\N	1	Sai. Quân đội Nguyễn trang bị rất nhiều súng thần công, súng điểu thương và hỏa hổ (ống phun lửa).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
00c30df6-769d-4e60-b622-8b53de4258b8	2cbe63e8-fa98-4fda-bf14-665d50f5b826	\N	multiple_choice	Sơn Mã (Con Mang) có đặc điểm tiếng kêu như thế nào?	["A. Hót líu lo", "B. Gầm gừ như hổ", "C. Kêu tác tác như chó sủa", "D. Rống to như bò"]	C. Kêu tác tác như chó sủa	\N	2	Tiếng kêu đặc trưng khiến nó có tên tiếng Anh là Barking Deer (Hươu sủa).	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
465cb481-b7cf-4697-9a79-14025d9212ed	2cbe63e8-fa98-4fda-bf14-665d50f5b826	\N	true_false	Sơn Mã là loài động vật ăn thịt hung dữ.	["Đúng", "Sai"]	Sai	\N	1	Sai. Sơn Mã là động vật ăn cỏ, lá cây, rất nhút nhát.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
2479ee64-a3a3-4540-8439-c29445e1d1e5	ed00c1fe-9a20-4781-815d-d320c4e353fa	\N	multiple_choice	Nhựa của cây Tất Mộc (Cây Sơn) được dùng để làm gì?	["A. Làm kẹo cao su", "B. Làm sơn mài, sơn đồ gỗ", "C. Làm thuốc trừ sâu", "D. Làm gia vị"]	B. Làm sơn mài, sơn đồ gỗ	\N	1	Sơn ta là nguyên liệu chính của nghệ thuật sơn mài truyền thống.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
8685e331-c4cf-44ea-9efc-61c53569f373	ed00c1fe-9a20-4781-815d-d320c4e353fa	\N	true_false	Tiếp xúc với nhựa sơn sống rất an toàn, không gây hại gì.	["Đúng", "Sai"]	Sai	\N	1	Sai. Nhựa sơn có thể gây dị ứng da nghiêm trọng (sơn ăn) đối với người cơ địa nhạy cảm.	t	t	2026-01-08 14:55:01.200388+00	draft	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: rag_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rag_documents (id, title, content, source_type, source_path, is_active, embedding, embedding_model, embedding_updated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rag_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rag_settings (id, system_instruction, prompt_prefix, model_override, temperature, max_documents, embedding_enabled, hybrid_alpha, created_at, updated_at) FROM stdin;
32bcbd19-cdc0-4928-ac6d-19a5a9842333	\N	\N	\N	\N	6	t	0.6	2026-01-16 00:24:34.007268+00	2026-01-16 00:24:34.007268+00
\.


--
-- Data for Name: recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recommendations (id, user_id, source, items, created_at) FROM stdin;
54ceadb3-587c-4f5d-8999-ca28210b171a	1df31222-3934-471c-8624-a87034fd017d	rules	[{"href": "/quests/dat-mua-mang", "kind": "quest", "title": "Đất & Mùa Màng", "metadata": {"quest_id": "3bddead6-ba0b-44c9-a232-8556f710fe0b"}, "description": "Khám phá họa tiết về nông nghiệp và mùa vụ."}]	2026-01-08 14:57:49.044186+00
23a265df-19e1-464d-9117-d105544cb9ea	9212f3ba-8e00-4199-83df-25271cd78d3c	rules	[{"href": "/quests/dat-mua-mang", "kind": "quest", "title": "Đất & Mùa Màng", "metadata": {"quest_id": "3bddead6-ba0b-44c9-a232-8556f710fe0b"}, "description": "Khám phá họa tiết về nông nghiệp và mùa vụ."}]	2026-01-08 15:02:11.969599+00
9290e325-c2e9-4d53-9083-6113f0c7c9b9	ac4276d6-a00d-48dc-8c4d-8cdabbfb49a6	rules	[{"href": "/quests/khoi-dau-hanh-trinh", "kind": "quest", "title": "Khởi Đầu Hành Trình", "metadata": {"quest_id": "2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f"}, "description": "Làm quen với Cửu Đỉnh và khám phá những họa tiết đầu tiên."}]	2026-01-15 02:20:24.87157+00
e7a3a827-f970-448c-905f-0d6a8c394c88	7b45c619-66f9-423a-8130-f7aae99374ca	rules	[{"href": "/quests/khoi-dau-hanh-trinh", "kind": "quest", "title": "Khởi Đầu Hành Trình", "metadata": {"quest_id": "2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f"}, "description": "Làm quen với Cửu Đỉnh và khám phá những họa tiết đầu tiên."}]	2026-01-15 02:23:52.20004+00
a530ca4e-25e8-404f-b1f1-c34b1828c2a7	3f8790e9-13ed-4a41-8e40-4885f86c2d99	rules	[{"href": "/quests/khoi-dau-hanh-trinh", "kind": "quest", "title": "Khởi Đầu Hành Trình", "metadata": {"quest_id": "2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f"}, "description": "Làm quen với Cửu Đỉnh và khám phá những họa tiết đầu tiên."}]	2026-01-17 12:55:32.367291+00
e37f45ad-6350-452d-86a6-742aa1bbd7a9	addd1a44-78b7-4657-898e-5e69276f3270	rules	[{"href": "/quests/khoi-dau-hanh-trinh", "kind": "quest", "title": "Khởi Đầu Hành Trình", "metadata": {"quest_id": "2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f"}, "description": "Làm quen với Cửu Đỉnh và khám phá những họa tiết đầu tiên."}]	2026-01-29 05:41:12.186258+00
5919454c-7bb9-42e7-baf1-3bf2d7b0111a	52f99b53-c2d8-4e46-8958-90545b552ca9	rules	[{"href": "/quests/khoi-dau-hanh-trinh", "kind": "quest", "title": "Khởi Đầu Hành Trình", "metadata": {"quest_id": "2ec5a1dd-309e-4b5e-aec8-67e15cccbe2f"}, "description": "Làm quen với Cửu Đỉnh và khám phá những họa tiết đầu tiên."}]	2026-01-29 07:19:45.613791+00
\.


--
-- Data for Name: scheduled_emails; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scheduled_emails (id, user_id, template_id, scheduled_for, status, context_data, sent_at, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: spaced_repetition_cards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spaced_repetition_cards (id, user_id, motif_id, ease_factor, interval_days, repetitions, next_review_at, last_reviewed_at, review_history, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: streak_rewards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.streak_rewards (id, user_id, streak_day, reward_type, reward_amount, awarded_at, created_at) FROM stdin;
\.


--
-- Data for Name: student_progress_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_progress_snapshots (id, student_id, classroom_id, snapshot_date, lessons_completed, quizzes_passed, average_quiz_score, motifs_discovered, current_streak, xp_earned, time_spent_minutes, created_at) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tags (id, slug, name, tag_type, description, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: urn_exam_attempts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.urn_exam_attempts (id, user_id, urn_exam_id, score, passed, time_taken, answers, created_at) FROM stdin;
\.


--
-- Data for Name: urn_exams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.urn_exams (id, urn_id, questions, passing_score, xp_reward) FROM stdin;
b81c6c68-b1df-424a-8fc7-ee9e2cedd50d	c669187e-adb8-432a-b79f-c5fc00ebcd20	[{"options": ["Vua Minh Mạng", "Vua Thiệu Trị", "Vua Tự Đức", "Vua Đồng Khánh"], "explanation": "Anh Đỉnh là đỉnh thứ tư trong Cửu Đỉnh, ứng với vua Tự Đức (Dực Tông Anh Hoàng đế). Ông là vị vua có thời gian trị vì lâu nhất triều Nguyễn (36 năm).", "question_text": "Anh Đỉnh được đúc năm 1835 để tượng trưng cho thụy hiệu của vị vua nào nhà Nguyễn?", "question_type": "multiple_choice", "correct_answer": "Vua Tự Đức"}, {"options": ["Sự bình yên, an lạc", "Tài năng xuất chúng, tinh hoa", "Sức mạnh vô địch", "Sự giàu sang phú quý"], "explanation": "Chữ 'Anh' (英) trong Anh Đỉnh có nghĩa là tài năng xuất chúng, tốt đẹp, hay tinh hoa (như trong từ anh hùng, anh minh), thể hiện kỳ vọng vào sự phát triển văn hóa rực rỡ.", "question_text": "Chữ 'Anh' trong tên gọi 'Anh Đỉnh' mang ý nghĩa gì?", "question_type": "multiple_choice", "correct_answer": "Tài năng xuất chúng, tinh hoa"}, {"options": ["Sao Chổi", "Dải Ngân Hà", "Mặt Trăng", "Sao Băng"], "explanation": "Ngân Hán (hay Thiên Hà) là dải Ngân Hà, được người xưa hình dung như một dòng sông bạc chảy vắt ngang bầu trời đêm, gắn liền với sự tích Ngưu Lang - Chức Nữ.", "question_text": "Hình tượng 'Ngân Hán' được chạm khắc trên Anh Đỉnh miêu tả hiện tượng thiên văn nào?", "question_type": "multiple_choice", "correct_answer": "Dải Ngân Hà"}, {"options": ["Con Bướm (Hồ Điệp)", "Con Ve sầu (Thiền)", "Con Dế (Súc Chức)", "Con Ong (Phong)"], "explanation": "Con ve sầu (Thiền) với đặc tính sống dưới đất rồi lột xác bay lên cao, chỉ uống sương mai, được người xưa xem là biểu tượng của sự thoát tục, tái sinh và thanh cao.", "question_text": "Loài côn trùng nào xuất hiện trên Anh Đỉnh được coi là biểu tượng của sự tái sinh và thanh khiết?", "question_type": "multiple_choice", "correct_answer": "Con Ve sầu (Thiền)"}, {"options": ["Cây Trầu không", "Cây Cau", "Cây Vôi", "Cây Chè"], "explanation": "Tân Lang là tên Hán Việt của cây Cau. Cây cau có thân thẳng đứng, tượng trưng cho người quân tử và là một phần không thể thiếu trong tục ăn trầu giao tiếp và cưới hỏi.", "question_text": "Hình ảnh 'Tân Lang' trên Anh Đỉnh nhắc đến loài cây nào quen thuộc trong văn hóa trầu cau của người Việt?", "question_type": "multiple_choice", "correct_answer": "Cây Cau"}, {"options": ["Núi Ngự Bình", "Núi Hồng Lĩnh", "Núi Bạch Mã", "Núi Quyết"], "explanation": "Hồng Sơn chính là núi Hồng Lĩnh, ngọn núi biểu tượng của Hà Tĩnh với truyền thuyết 99 ngọn núi và đàn phượng hoàng tìm đất đậu.", "question_text": "Địa danh 'Hồng Sơn' được khắc trên Anh Đỉnh là ngọn núi nổi tiếng nào ở Hà Tĩnh?", "question_type": "multiple_choice", "correct_answer": "Núi Hồng Lĩnh"}, {"options": ["Hoa Mai", "Hoa Đào", "Hoa Hồng", "Hoa Mẫu Đơn"], "explanation": "Mai Khôi (hay Mân Côi) là tên gọi cổ chỉ loài hoa hồng. Hoa hồng trên đỉnh được khắc họa mềm mại, tôn vinh vẻ đẹp hương sắc vẹn toàn.", "question_text": "Loài hoa nào được gọi là 'Mai Khôi Hoa' trên Anh Đỉnh, tượng trưng cho vẻ đẹp kiêu sa?", "question_type": "multiple_choice", "correct_answer": "Hoa Hồng"}, {"options": ["Một loại cung tên", "Đạn pháo nổ tỏa ra nhiều mảnh", "Kiếm lưỡi uốn lượn", "Lá chắn hình cánh bướm"], "explanation": "Hồ Điệp Tử (Đạn bươm bướm) là loại đạn pháo đặc biệt, khi nổ phóng ra nhiều mảnh nhỏ bay tản ra như đàn bướm, gây sát thương diện rộng.", "question_text": "Hình ảnh 'Hồ Điệp Tử' trên Anh Đỉnh là tên gọi của loại vũ khí gì?", "question_type": "multiple_choice", "correct_answer": "Đạn pháo nổ tỏa ra nhiều mảnh"}, {"options": ["Sông Lam", "Sông Mã", "Sông Chu", "Sông Cả"], "explanation": "Mã Giang là sông Mã. Dòng sông này gắn liền với vùng đất phát tích của nhà Nguyễn (Thanh Hóa) và nổi tiếng với những ghềnh thác hiểm trở.", "question_text": "Con sông nào ở Thanh Hóa, nổi tiếng với sự hùng vĩ và dữ dội, được khắc trên Anh Đỉnh với tên 'Mã Giang'?", "question_type": "multiple_choice", "correct_answer": "Sông Mã"}, {"options": ["Sao Nam Tào", "Sao Bắc Đẩu", "Sao Hôm", "Sao Mai"], "explanation": "Bắc Đẩu (Bắc Đẩu Thất Tinh) là chòm sao hình cái gáo, giúp người xưa tìm ra sao Bắc Cực để xác định phương Bắc trong đêm tối.", "question_text": "Chòm sao nào được khắc trên Anh Đỉnh có vai trò quan trọng trong việc xác định phương hướng (phương Bắc)?", "question_type": "multiple_choice", "correct_answer": "Sao Bắc Đẩu"}, {"options": ["Sông Đà", "Sông Thao", "Sông Lô", "Sông Chảy"], "explanation": "Lô Hà là sông Lô, một phụ lưu lớn của sông Hồng, nổi tiếng với dòng nước trong xanh và những chiến công lịch sử.", "question_text": "Hình ảnh 'Lô Hà' trên Anh Đỉnh đại diện cho con sông nào chảy qua vùng núi phía Bắc?", "question_type": "multiple_choice", "correct_answer": "Sông Lô"}, {"options": ["Cây Gừng", "Cây Nghệ", "Cây Riềng", "Cây Khoai"], "explanation": "Uất Kim là tên thuốc trong Đông y chỉ phần củ con của cây Nghệ. Củ nghệ có màu vàng cam (uất kim - vàng uất tích), là vị thuốc quý chữa đau dạ dày và làm đẹp.", "question_text": "Loài cây 'Uất Kim' được chạm trên Anh Đỉnh thực chất là cây gì, có củ màu vàng dùng làm gia vị và thuốc?", "question_type": "multiple_choice", "correct_answer": "Cây Nghệ"}, {"options": ["Đan lát mây tre", "Làm gốm sứ", "Trồng dâu nuôi tằm", "Chạm khắc gỗ"], "explanation": "Tang là cây dâu tằm. Lá dâu là thức ăn duy nhất của tằm để nhả tơ, vì vậy cây dâu là biểu tượng của nghề ươm tơ dệt lụa.", "question_text": "Cây 'Tang' trên Anh Đỉnh gắn liền với nghề thủ công truyền thống nào?", "question_type": "multiple_choice", "correct_answer": "Trồng dâu nuôi tằm"}, {"options": ["Chim Phượng Hoàng", "Chim Công", "Chim Hạc (Khôi Hạc)", "Chim Ưng"], "explanation": "Khôi Hạc (Hạc tiên) được coi là loài chim đứng đầu các loài chim (chỉ sau Phượng hoàng thần thoại), tượng trưng cho sự trường thọ và phẩm chất thanh cao của người quân tử.", "question_text": "Loài chim nào được mệnh danh là 'nhất phẩm điểu' (chim đứng đầu) xuất hiện trên Anh Đỉnh?", "question_type": "multiple_choice", "correct_answer": "Chim Hạc (Khôi Hạc)"}, {"options": ["Ngay bên phải Cao Đỉnh", "Bên trái, vị trí thứ 2 từ Cao Đỉnh đếm sang", "Vị trí ngoài cùng bên phải", "Vị trí ngoài cùng bên trái"], "explanation": "Theo thứ tự bố trí: Cao, Nhân, Chương, Anh, Nghị, Thuần, Tuyên, Dụ, Huyền. Anh Đỉnh là đỉnh thứ 4, nằm bên trái của Nhân Đỉnh (nếu tính từ Cao Đỉnh ra là vị trí thứ 2 bên trái).", "question_text": "Trong quần thể Cửu Đỉnh, Anh Đỉnh nằm ở vị trí nào so với đỉnh trung tâm (Cao Đỉnh)?", "question_type": "multiple_choice", "correct_answer": "Bên trái, vị trí thứ 2 từ Cao Đỉnh đếm sang"}]	80	100
3d4e0404-4421-4752-ae5b-abf78226525d	5dee75b5-558b-44ce-81da-6a44673927db	[{"options": ["Vua Gia Long", "Vua Minh Mạng", "Vua Thiệu Trị", "Vua Tự Đức"], "explanation": "Cao Đỉnh là đỉnh cao nhất và quan trọng nhất, được đặt ở vị trí trung tâm, dùng để thờ Thế Tổ Cao Hoàng Đế (vua Gia Long) - người sáng lập triều Nguyễn.", "question_text": "Cao Đỉnh được vua Minh Mạng cho đúc để dâng tặng và tôn vinh vị vua nào của triều Nguyễn?", "question_type": "multiple_choice", "correct_answer": "Vua Gia Long"}, {"options": ["Biểu tượng của sự trường thọ", "Biểu tượng của Hoàng đế và quyền lực tối cao", "Biểu tượng của mùa màng bội thu", "Biểu tượng của tri thức"], "explanation": "Trong quan niệm phương Đông, Mặt Trời (Thái Dương) là biểu tượng của đấng quân vương (Thiên tử), đại diện cho quyền lực tối thượng và sự chính thống.", "question_text": "Hình ảnh 'Nhật' (Mặt Trời) được khắc trên Cao Đỉnh mang ý nghĩa biểu tượng gì trong văn hóa phong kiến?", "question_type": "multiple_choice", "correct_answer": "Biểu tượng của Hoàng đế và quyền lực tối cao"}, {"options": ["Cây thông (tùng)", "Cây hành", "Cây trúc", "Cây ngô đồng"], "explanation": "Chữ 'Thông' (蔥) trên Cao Đỉnh chỉ cây hành - một loại gia vị quen thuộc, chứ không phải cây thông lấy gỗ. Nó tượng trưng cho sự thông suốt và khí dương.", "question_text": "Họa tiết 'Thông' trên Cao Đỉnh thực chất là hình ảnh của loài cây nào?", "question_type": "multiple_choice", "correct_answer": "Cây hành"}, {"options": ["Cây xoài", "Cây mít", "Cây dừa", "Cây sung"], "explanation": "Ba La Mật là tên gọi trân trọng của cây mít. Việc khắc cây mít lên Cao Đỉnh thể hiện sự trân trọng loại quả dân dã nhưng to lớn, tượng trưng cho sự sung túc.", "question_text": "Loài cây ăn quả nào có tên là 'Ba La Mật' được khắc trên Cao Đỉnh?", "question_type": "multiple_choice", "correct_answer": "Cây mít"}, {"options": ["Sông Hương", "Sông Hồng", "Sông Bến Nghé", "Sông Tiền"], "explanation": "Ngưu Chữ Giang tức sông Bến Nghé (Gia Định). Đây là huyết mạch giao thương quan trọng của vùng đất phương Nam thời bấy giờ.", "question_text": "Dòng sông 'Ngưu Chữ Giang' được khắc trên Cao Đỉnh ngày nay có tên gọi là gì?", "question_type": "multiple_choice", "correct_answer": "Sông Bến Nghé"}, {"options": ["Vĩnh Tế Hà", "Bảo Định Hà", "Lợi Nông Hà", "Phổ Lợi Hà"], "explanation": "Kênh Vĩnh Tế (Vĩnh Tế Hà) là công trình thủy lợi và quốc phòng vĩ đại dọc biên giới Tây Nam, được khắc lên Cao Đỉnh để ghi nhận tầm quan trọng chiến lược của nó.", "question_text": "Con kênh nào do danh tướng Thoại Ngọc Hầu chỉ huy đào, được khắc trên Cao Đỉnh?", "question_type": "multiple_choice", "correct_answer": "Vĩnh Tế Hà"}, {"options": ["Mô tả cảnh đẹp thiên nhiên", "Khẳng định chủ quyền biển đảo quốc gia", "Cầu mong mưa thuận gió hòa", "Thể hiện kỹ thuật đúc đồng"], "explanation": "Việc khắc Biển Đông lên đỉnh cao nhất là một tuyên bố mạnh mẽ về chủ quyền lãnh thổ và biển đảo của vua Minh Mạng đối với đất nước.", "question_text": "Hình ảnh 'Đông Hải' (Biển Đông) trên Cao Đỉnh thể hiện thông điệp gì của triều Nguyễn?", "question_type": "multiple_choice", "correct_answer": "Khẳng định chủ quyền biển đảo quốc gia"}, {"options": ["Sức mạnh quân sự", "Sản vật quý hiếm của núi rừng", "Sự thanh cao của kẻ sĩ", "Nghệ thuật âm nhạc"], "explanation": "Trầm hương là sản vật cực kỳ quý giá của Việt Nam ('Khánh Hòa là xứ trầm hương'), đại diện cho sự giàu có về tài nguyên rừng.", "question_text": "Họa tiết 'Trầm Hương' trên Cao Đỉnh đại diện cho điều gì?", "question_type": "multiple_choice", "correct_answer": "Sản vật quý hiếm của núi rừng"}, {"options": ["Hổ", "Báo", "Voi", "Sư tử"], "explanation": "Hổ (Cọp) là chúa sơn lâm, tượng trưng cho sự dũng mãnh, uy quyền và thường được dùng làm biểu tượng cho các quan võ (Hổ tướng).", "question_text": "Loài vật nào được khắc trên Cao Đỉnh tượng trưng cho sức mạnh của các võ tướng?", "question_type": "multiple_choice", "correct_answer": "Hổ"}, {"options": ["Là nơi vua Minh Mạng sinh ra", "Là nơi phát tích của dòng họ Nguyễn (Quý Hương)", "Là nơi diễn ra trận chiến quyết định", "Là ngọn núi cao nhất Việt Nam"], "explanation": "Núi Thiên Tôn (Thanh Hóa) nằm ở vùng Gia Miêu Ngoại Trang, được coi là đất tổ (Quý Hương), nơi phát tích của các chúa Nguyễn.", "question_text": "Địa danh 'Thiên Tôn Sơn' trên Cao Đỉnh có ý nghĩa lịch sử gì đối với nhà Nguyễn?", "question_type": "multiple_choice", "correct_answer": "Là nơi phát tích của dòng họ Nguyễn (Quý Hương)"}, {"options": ["Gỗ Trắc", "Gỗ Lim", "Gỗ Sưa", "Gỗ Hương"], "explanation": "Thiết Mộc (cây gỗ sắt) là cách gọi tôn xưng cây gỗ Lim, loài gỗ đứng đầu trong 'tứ thiết' (đinh, lim, sến, táu) vì độ cứng và bền bỉ.", "question_text": "Họa tiết 'Thiết Mộc' trên Cao Đỉnh đề cập đến loại gỗ quý nào?", "question_type": "multiple_choice", "correct_answer": "Gỗ Lim"}, {"options": ["Rồng ba móng", "Rồng bốn móng", "Rồng năm móng", "Rồng ngậm ngọc"], "explanation": "Trong quy định của triều Nguyễn, chỉ có rồng năm móng (ngũ trảo long) mới được dùng cho nhà vua, thể hiện quyền lực tối cao.", "question_text": "Hình tượng rồng (Long) trên Cao Đỉnh có đặc điểm gì thể hiện quyền uy của Hoàng đế?", "question_type": "multiple_choice", "correct_answer": "Rồng năm móng"}, {"options": ["Kỹ thuật đóng tàu", "Kỹ thuật đúc súng thần công và sức mạnh quân sự", "Nghệ thuật pháo hoa", "Kỹ thuật xây thành"], "explanation": "Hình ảnh khẩu thần công (Đại Bác) là minh chứng cho sự chú trọng phát triển hỏa khí và sức mạnh quốc phòng của triều đình.", "question_text": "Họa tiết 'Đại Bác' trên Cao Đỉnh phản ánh thành tựu gì của triều Nguyễn?", "question_type": "multiple_choice", "correct_answer": "Kỹ thuật đúc súng thần công và sức mạnh quân sự"}, {"options": ["Chim Công", "Chim Trĩ", "Chim Hạc", "Chim Ưng"], "explanation": "Chim Trĩ với bộ lông đuôi dài lộng lẫy được khắc trên Cao Đỉnh, tượng trưng cho vẻ đẹp văn hóa, sự nho nhã và điềm lành.", "question_text": "Loài chim nào được khắc trên Cao Đỉnh, thường được ví với vẻ đẹp của phượng hoàng?", "question_type": "multiple_choice", "correct_answer": "Chim Trĩ"}, {"options": ["Lúa nếp", "Lúa tẻ", "Khoai lang", "Sắn"], "explanation": "Canh là lúa tẻ, nguồn lương thực chính yếu hàng ngày. Việc khắc lúa tẻ lên đỉnh cao nhất thể hiện tư tưởng 'nông vi bản' (lấy nông nghiệp làm gốc) của triều Nguyễn.", "question_text": "'Canh' là họa tiết cây lương thực nào trên Cao Đỉnh?", "question_type": "multiple_choice", "correct_answer": "Lúa tẻ"}]	80	100
2246ad5d-2436-4a91-a26d-8c83acaec58d	a40d0ce2-b30d-4c99-bb2e-15a802f9221e	[{"options": ["Vua Gia Long", "Vua Thành Tổ (Nguyễn Phúc Lan)", "Vua Minh Mạng", "Vua Thiệu Trị"], "explanation": "Chương Đỉnh dâng tặng Thành Tổ Nhân Hoàng Đế (Nguyễn Phúc Lan), người đặt nền móng cho sự nghiệp thống nhất đất nước của các chúa Nguyễn.", "question_text": "Chương Đỉnh được đúc để tôn vinh vị vua nào của triều Nguyễn?", "question_type": "multiple_choice", "correct_answer": "Vua Thành Tổ (Nguyễn Phúc Lan)"}, {"options": ["Quyền lực của vua", "Hoàng hậu và đức hạnh của người phụ nữ", "Sự trường thọ", "Mùa màng bội thu"], "explanation": "Phượng (phụng hoàng) là biểu tượng của hoàng hậu, đại diện cho đức hạnh, sự cao quý và vẻ đẹp của người phụ nữ trong cung đình.", "question_text": "Họa tiết 'Phượng' trên Chương Đỉnh tượng trưng cho điều gì?", "question_type": "multiple_choice", "correct_answer": "Hoàng hậu và đức hạnh của người phụ nữ"}, {"options": ["Hoa đào", "Hoa sen", "Hoa cúc", "Hoa mai"], "explanation": "Hoa sen là biểu tượng của sự thanh cao, trong sạch 'xuất ô nhiễm nhi bất nhiễm' - mọc từ bùn nhưng không hôi tanh.", "question_text": "Loài hoa nào được khắc trên Chương Đỉnh, tượng trưng cho sự thanh cao?", "question_type": "multiple_choice", "correct_answer": "Hoa sen"}, {"options": ["Rồng", "Rùa", "Phượng", "Lân"], "explanation": "Quy (rùa) là một trong tứ linh, tượng trưng cho sự trường thọ, bền vững và trí tuệ.", "question_text": "Họa tiết 'Quy' trên Chương Đỉnh là hình ảnh con vật gì?", "question_type": "multiple_choice", "correct_answer": "Rùa"}, {"options": ["Quảng Trị", "Thừa Thiên Huế", "Quảng Nam", "Quảng Bình"], "explanation": "Thuận Hóa là tên cũ của vùng đất Huế, nơi đóng đô của triều Nguyễn.", "question_text": "Địa danh 'Thuận Hóa' trên Chương Đỉnh ngày nay là tỉnh nào?", "question_type": "multiple_choice", "correct_answer": "Thừa Thiên Huế"}, {"options": ["Cây tre", "Cây tùng (thông)", "Cây mai", "Cây đào"], "explanation": "Cây tùng (thông) tượng trưng cho sự kiên cường, bất khuất trước gió sương, là một trong 'tứ quý' (tùng, cúc, trúc, mai).", "question_text": "Loại cây nào được khắc trên Chương Đỉnh, tượng trưng cho sự kiên cường?", "question_type": "multiple_choice", "correct_answer": "Cây tùng (thông)"}, {"options": ["Nghệ thuật võ thuật", "Quyền lực quân sự và sự bảo vệ giang sơn", "Công cụ săn bắn", "Vũ khí nghi lễ"], "explanation": "Kiếm là biểu tượng của quyền lực quân sự, sự bảo vệ giang sơn và uy quyền của vua chúa.", "question_text": "Họa tiết 'Kiếm' trên Chương Đỉnh thể hiện điều gì?", "question_type": "multiple_choice", "correct_answer": "Quyền lực quân sự và sự bảo vệ giang sơn"}, {"options": ["Công", "Hạc", "Trĩ", "Ưng"], "explanation": "Hạc là biểu tượng của sự trường thọ, thanh cao và thường xuất hiện trong các tác phẩm nghệ thuật cung đình.", "question_text": "Loài chim nào được khắc trên Chương Đỉnh, tượng trưng cho sự trường thọ?", "question_type": "multiple_choice", "correct_answer": "Hạc"}, {"options": ["Sự giàu có", "Khí tiết của người quân tử", "Mùa màng bội thu", "Sức khỏe dồi dào"], "explanation": "Tre (trúc) tượng trưng cho khí tiết của người quân tử: 'trúc bất đổi tiết' - tre không đổi khí tiết dù gió sương.", "question_text": "Họa tiết 'Trúc' trên Chương Đỉnh mang ý nghĩa gì?", "question_type": "multiple_choice", "correct_answer": "Khí tiết của người quân tử"}, {"options": ["Nơi sinh của vua Gia Long", "Vùng đất quan trọng trong thời kỳ Đàng Trong", "Nơi đúc Cửu Đỉnh", "Thủ đô đầu tiên"], "explanation": "Quảng Nam là một trong những vùng đất quan trọng của Đàng Trong, nơi các chúa Nguyễn phát triển lãnh thổ về phía Nam.", "question_text": "Địa danh 'Quảng Nam' trên Chương Đỉnh có ý nghĩa lịch sử gì?", "question_type": "multiple_choice", "correct_answer": "Vùng đất quan trọng trong thời kỳ Đàng Trong"}, {"explanation": "Chương Đỉnh cùng với 8 đỉnh khác được đúc trong giai đoạn 1835-1837 dưới triều vua Minh Mạng.", "question_text": "Chương Đỉnh được đúc vào năm nào?", "question_type": "true_false", "correct_answer": "Đúng"}, {"explanation": "Các họa tiết trên Chương Đỉnh đều mang ý nghĩa chính trị sâu sắc, thể hiện quyền lực, lãnh thổ và thành tựu của triều Nguyễn.", "question_text": "Họa tiết trên Chương Đỉnh chỉ mô tả cảnh vật thiên nhiên, không có ý nghĩa chính trị.", "question_type": "true_false", "correct_answer": "Sai"}, {"explanation": "Cao Đỉnh là đỉnh lớn nhất, các đỉnh còn lại có kích thước tương đương nhau, không có đỉnh nào được coi là nhỏ nhất.", "question_text": "Chương Đỉnh là đỉnh nhỏ nhất trong Cửu Đỉnh.", "question_type": "true_false", "correct_answer": "Sai"}, {"explanation": "Chương Đỉnh được đặt ở phía Bắc, tượng trưng cho hướng Bắc và vị trí quan trọng trong bố cục không gian của Cửu Đỉnh.", "question_text": "Chương Đỉnh được đặt ở phía Bắc trong bố cục Cửu Đỉnh tại Thế Miếu.", "question_type": "true_false", "correct_answer": "Đúng"}, {"explanation": "Các họa tiết trên Cửu Đỉnh đều được tạo ra bằng kỹ thuật đúc đồng tinh xảo, với các chi tiết nổi rõ ràng và sắc nét.", "question_text": "Tất cả các họa tiết trên Chương Đỉnh đều được khắc nổi bằng kỹ thuật đúc đồng.", "question_type": "true_false", "correct_answer": "Đúng"}]	80	100
5967388b-2404-4101-9140-3b646ebea9bb	c2c33771-6473-4745-ba26-dd1d32cce0c6	[{"options": ["Vua Gia Long", "Vua Hiển Tông (Nguyễn Phúc Chu)", "Vua Minh Mạng", "Vua Thiệu Trị"], "explanation": "Dụ Đỉnh dâng tặng Hiển Tông Chương Hoàng Đế (Nguyễn Phúc Chu), người có công trong việc phát triển Đàng Trong.", "question_text": "Dụ Đỉnh được đúc để tôn vinh vị vua nào của triều Nguyễn?", "question_type": "multiple_choice", "correct_answer": "Vua Hiển Tông (Nguyễn Phúc Chu)"}, {"options": ["Sự giàu có", "Sự vươn lên và thành công", "Sự trường thọ", "Mùa màng bội thu"], "explanation": "Cá chép vượt vũ môn hóa rồng là biểu tượng của sự vươn lên, thành công và đổi đời.", "question_text": "Họa tiết 'Cá Chép' trên Dụ Đỉnh tượng trưng cho điều gì?", "question_type": "multiple_choice", "correct_answer": "Sự vươn lên và thành công"}, {"options": ["Hoa đào", "Hoa sen", "Hoa cúc", "Hoa mai"], "explanation": "Hoa sen là biểu tượng của sự thanh cao, trong sạch 'xuất ô nhiễm nhi bất nhiễm'.", "question_text": "Loài hoa nào được khắc trên Dụ Đỉnh, tượng trưng cho sự thanh cao?", "question_type": "multiple_choice", "correct_answer": "Hoa sen"}, {"options": ["Sức mạnh", "Sự nhẹ nhàng và điềm lành", "Trí tuệ", "Quyền lực"], "explanation": "Nai là biểu tượng của sự nhẹ nhàng, điềm lành và thường xuất hiện trong nghệ thuật cung đình.", "question_text": "Họa tiết 'Nai' trên Dụ Đỉnh có ý nghĩa gì?", "question_type": "multiple_choice", "correct_answer": "Sự nhẹ nhàng và điềm lành"}, {"options": ["Nơi sinh của vua Gia Long", "Vùng đất quan trọng trong việc mở rộng lãnh thổ về phía Nam", "Nơi đúc Cửu Đỉnh", "Thủ đô đầu tiên"], "explanation": "Quảng Ngãi là vùng đất quan trọng trong việc mở rộng lãnh thổ của các chúa Nguyễn về phía Nam.", "question_text": "Địa danh 'Quảng Ngãi' trên Dụ Đỉnh có ý nghĩa lịch sử gì?", "question_type": "multiple_choice", "correct_answer": "Vùng đất quan trọng trong việc mở rộng lãnh thổ về phía Nam"}, {"options": ["Cây tre", "Cây thông", "Cây mai", "Cây đào"], "explanation": "Cây tre tượng trưng cho sự kiên cường, bất khuất 'trúc bất đổi tiết'.", "question_text": "Loại cây nào được khắc trên Dụ Đỉnh, tượng trưng cho sự kiên cường?", "question_type": "multiple_choice", "correct_answer": "Cây tre"}, {"options": ["Nghệ thuật đóng tàu", "Giao thương biển và phát triển kinh tế", "Du lịch", "Đánh cá"], "explanation": "Thuyền buồm là biểu tượng của giao thương biển, vận chuyển và phát triển kinh tế.", "question_text": "Họa tiết 'Thuyền Buồm' trên Dụ Đỉnh thể hiện điều gì?", "question_type": "multiple_choice", "correct_answer": "Giao thương biển và phát triển kinh tế"}, {"options": ["Công", "Hạc", "Trĩ", "Ưng"], "explanation": "Hạc là biểu tượng của sự thanh cao, trường thọ và thường xuất hiện trong nghệ thuật cung đình.", "question_text": "Loài chim nào được khắc trên Dụ Đỉnh, tượng trưng cho sự thanh cao?", "question_type": "multiple_choice", "correct_answer": "Hạc"}, {"options": ["Sự giàu có", "Cây đặc trưng của vùng nhiệt đới và văn hóa dân gian", "Mùa màng bội thu", "Sức khỏe dồi dào"], "explanation": "Cây cau là cây đặc trưng của vùng nhiệt đới Việt Nam và gắn liền với văn hóa dân gian.", "question_text": "Họa tiết 'Cây Cau' trên Dụ Đỉnh mang ý nghĩa gì?", "question_type": "multiple_choice", "correct_answer": "Cây đặc trưng của vùng nhiệt đới và văn hóa dân gian"}, {"options": ["Nơi sinh của vua Gia Long", "Vùng đất ven biển quan trọng trong việc phát triển kinh tế", "Nơi đúc Cửu Đỉnh", "Thủ đô đầu tiên"], "explanation": "Phú Yên là vùng đất ven biển quan trọng trong việc phát triển kinh tế và giao thương.", "question_text": "Địa danh 'Phú Yên' trên Dụ Đỉnh có ý nghĩa lịch sử gì?", "question_type": "multiple_choice", "correct_answer": "Vùng đất ven biển quan trọng trong việc phát triển kinh tế"}, {"explanation": "Dụ Đỉnh cùng với 8 đỉnh khác được đúc trong giai đoạn 1835-1837 dưới triều vua Minh Mạng.", "question_text": "Dụ Đỉnh được đúc vào năm 1835-1837.", "question_type": "true_false", "correct_answer": "Đúng"}, {"explanation": "Các họa tiết trên Dụ Đỉnh đều mang ý nghĩa lịch sử, văn hóa và kinh tế sâu sắc.", "question_text": "Họa tiết trên Dụ Đỉnh chỉ mô tả cảnh vật thiên nhiên.", "question_type": "true_false", "correct_answer": "Sai"}, {"explanation": "Cao Đỉnh là đỉnh lớn nhất, các đỉnh còn lại có kích thước tương đương nhau.", "question_text": "Dụ Đỉnh là đỉnh nhỏ nhất trong Cửu Đỉnh.", "question_type": "true_false", "correct_answer": "Sai"}, {"explanation": "Dụ Đỉnh được đặt ở phía Đông Nam, tượng trưng cho hướng Đông Nam và vị trí quan trọng trong bố cục.", "question_text": "Dụ Đỉnh được đặt ở phía Đông Nam trong bố cục Cửu Đỉnh.", "question_type": "true_false", "correct_answer": "Đúng"}, {"explanation": "Các họa tiết trên Cửu Đỉnh đều được tạo ra bằng kỹ thuật đúc đồng tinh xảo.", "question_text": "Tất cả các họa tiết trên Dụ Đỉnh đều được khắc nổi bằng kỹ thuật đúc đồng.", "question_type": "true_false", "correct_answer": "Đúng"}]	80	100
f15740b1-dce5-4e4b-b9ca-94497fb1b579	90805a09-3a38-49e4-8827-e57da439d1a6	[{"options": ["Vua Gia Long", "Vua Thế Tông (Nguyễn Phúc Trăn)", "Vua Minh Mạng", "Vua Thiệu Trị"], "explanation": "Huyền Đỉnh dâng tặng Thế Tông Hiếu Nghĩa Hoàng Đế (Nguyễn Phúc Trăn), người có công trong việc củng cố Đàng Trong.", "question_text": "Huyền Đỉnh được đúc để tôn vinh vị vua nào của triều Nguyễn?", "question_type": "multiple_choice", "correct_answer": "Vua Thế Tông (Nguyễn Phúc Trăn)"}, {"options": ["Sức mạnh", "Sự trường thọ và trí tuệ", "Quyền lực", "Sự giàu có"], "explanation": "Rùa (Quy) là một trong tứ linh, tượng trưng cho sự trường thọ, bền vững và trí tuệ.", "question_text": "Họa tiết 'Rùa' trên Huyền Đỉnh tượng trưng cho điều gì?", "question_type": "multiple_choice", "correct_answer": "Sự trường thọ và trí tuệ"}, {"options": ["Hoa đào", "Hoa sen", "Hoa cúc", "Hoa mai"], "explanation": "Hoa sen là biểu tượng của sự thanh cao, trong sạch 'xuất ô nhiễm nhi bất nhiễm'.", "question_text": "Loài hoa nào được khắc trên Huyền Đỉnh, tượng trưng cho sự thanh cao?", "question_type": "multiple_choice", "correct_answer": "Hoa sen"}, {"options": ["Nhạc cụ giải trí", "Di sản văn hóa cổ đại và bản sắc dân tộc", "Công cụ báo giờ", "Vật phẩm tôn giáo"], "explanation": "Trống đồng là di sản văn hóa cổ đại của Việt Nam, biểu tượng của bản sắc dân tộc.", "question_text": "Họa tiết 'Trống Đồng' trên Huyền Đỉnh có ý nghĩa gì?", "question_type": "multiple_choice", "correct_answer": "Di sản văn hóa cổ đại và bản sắc dân tộc"}, {"options": ["Nơi sinh của vua Gia Long", "Vùng đất quan trọng với sản vật quý như trầm hương", "Nơi đúc Cửu Đỉnh", "Thủ đô đầu tiên"], "explanation": "Khánh Hòa là vùng đất nổi tiếng với sản vật quý như trầm hương, được gọi là 'xứ trầm hương'.", "question_text": "Địa danh 'Khánh Hòa' trên Huyền Đỉnh có ý nghĩa lịch sử gì?", "question_type": "multiple_choice", "correct_answer": "Vùng đất quan trọng với sản vật quý như trầm hương"}, {"options": ["Cây tre", "Cây thông", "Cây mai", "Cây đào"], "explanation": "Cây thông (tùng) tượng trưng cho sự kiên cường, bất khuất và là một trong 'tứ quý'.", "question_text": "Loại cây nào được khắc trên Huyền Đỉnh, tượng trưng cho sự kiên cường?", "question_type": "multiple_choice", "correct_answer": "Cây thông"}, {"options": ["Nghệ thuật đánh cá", "Sự phong phú của nguồn lợi thủy sản", "Du lịch", "Giao thương"], "explanation": "Cá là biểu tượng của sự phong phú về nguồn lợi thủy sản và đời sống ven biển.", "question_text": "Họa tiết 'Cá' trên Huyền Đỉnh thể hiện điều gì?", "question_type": "multiple_choice", "correct_answer": "Sự phong phú của nguồn lợi thủy sản"}, {"options": ["Công", "Hạc", "Trĩ", "Ưng"], "explanation": "Chim trĩ với bộ lông đuôi dài lộng lẫy tượng trưng cho sự thanh nhã và vẻ đẹp văn hóa.", "question_text": "Loài chim nào được khắc trên Huyền Đỉnh, tượng trưng cho sự thanh nhã?", "question_type": "multiple_choice", "correct_answer": "Trĩ"}, {"options": ["Sự giàu có", "Cây đặc trưng của vùng ven biển miền Nam", "Mùa màng bội thu", "Sức khỏe dồi dào"], "explanation": "Cây dừa là cây đặc trưng của vùng ven biển miền Nam Việt Nam và gắn liền với đời sống người dân.", "question_text": "Họa tiết 'Cây Dừa' trên Huyền Đỉnh mang ý nghĩa gì?", "question_type": "multiple_choice", "correct_answer": "Cây đặc trưng của vùng ven biển miền Nam"}, {"options": ["Nơi sinh của vua Gia Long", "Vùng đất của người Chăm với văn hóa đặc sắc", "Nơi đúc Cửu Đỉnh", "Thủ đô đầu tiên"], "explanation": "Ninh Thuận là vùng đất của người Chăm với văn hóa đặc sắc, được triều Nguyễn thống nhất.", "question_text": "Địa danh 'Ninh Thuận' trên Huyền Đỉnh có ý nghĩa lịch sử gì?", "question_type": "multiple_choice", "correct_answer": "Vùng đất của người Chăm với văn hóa đặc sắc"}, {"explanation": "Huyền Đỉnh cùng với 8 đỉnh khác được đúc trong giai đoạn 1835-1837 dưới triều vua Minh Mạng.", "question_text": "Huyền Đỉnh được đúc vào năm 1835-1837.", "question_type": "true_false", "correct_answer": "Đúng"}, {"explanation": "Các họa tiết trên Huyền Đỉnh đều mang ý nghĩa lịch sử, văn hóa và địa lý sâu sắc.", "question_text": "Họa tiết trên Huyền Đỉnh chỉ mô tả cảnh vật thiên nhiên.", "question_type": "true_false", "correct_answer": "Sai"}, {"explanation": "Cao Đỉnh là đỉnh lớn nhất, các đỉnh còn lại có kích thước tương đương nhau.", "question_text": "Huyền Đỉnh là đỉnh nhỏ nhất trong Cửu Đỉnh.", "question_type": "true_false", "correct_answer": "Sai"}, {"explanation": "Huyền Đỉnh được đặt ở phía Bắc, tượng trưng cho hướng Bắc và vị trí quan trọng trong bố cục.", "question_text": "Huyền Đỉnh được đặt ở phía Bắc trong bố cục Cửu Đỉnh.", "question_type": "true_false", "correct_answer": "Đúng"}, {"explanation": "Các họa tiết trên Cửu Đỉnh đều được tạo ra bằng kỹ thuật đúc đồng tinh xảo.", "question_text": "Tất cả các họa tiết trên Huyền Đỉnh đều được khắc nổi bằng kỹ thuật đúc đồng.", "question_type": "true_false", "correct_answer": "Đúng"}]	80	100
9ec6a179-7170-4a99-adcd-02c731b0b52e	a1dd8a81-fe6a-47d1-9e54-077708b5c05c	[{"options": ["Sự bàn bạc, thảo luận kỹ lưỡng", "Sự quả quyết, kiên định, cứng cỏi", "Sự nghi ngờ, đa nghi", "Sự vui vẻ, hòa thuận"], "explanation": "Chữ 'Nghị' (毅) trong Nghị Đỉnh mang ý nghĩa là sự cương nghị, quả quyết và ý chí sắt đá, tượng trưng cho đức tính cần có của một bậc quân vương để giữ gìn cơ nghiệp.", "question_text": "Chữ 'Nghị' trong tên gọi của Nghị Đỉnh mang ý nghĩa biểu tượng gì?", "question_type": "multiple_choice", "correct_answer": "Sự quả quyết, kiên định, cứng cỏi"}, {"options": ["Sao Bắc Đẩu", "Sao Nam Đẩu", "Sao Khuê", "Mặt Trăng"], "explanation": "Trên Nghị Đỉnh có khắc hình tượng sao Nam Đẩu (Nam Đẩu tinh quân). Trong văn hóa dân gian, Nam Tào (Nam Đẩu) giữ sổ Sinh (sự sống), đối lập với Bắc Đẩu giữ sổ Tử.", "question_text": "Hình ảnh thiên văn nào được khắc trên Nghị Đỉnh tượng trưng cho sự sống và tuổi thọ?", "question_type": "multiple_choice", "correct_answer": "Sao Nam Đẩu"}, {"options": ["Hải Vân Quan", "Quảng Bình Quan", "Trấn Bình Đài", "Ngọ Môn"], "explanation": "Quảng Bình Quan là một công trình phòng thủ trọng yếu trên đường thiên lý Bắc - Nam, thuộc hệ thống Lũy Thầy do Đào Duy Từ xây dựng, được khắc trên Nghị Đỉnh.", "question_text": "Cửa ải lịch sử nào thuộc hệ thống Lũy Thầy (Quảng Bình) được khắc họa trên Nghị Đỉnh?", "question_type": "multiple_choice", "correct_answer": "Quảng Bình Quan"}, {"options": ["Sông Như Nguyệt", "Sông Bạch Đằng", "Sông Gianh", "Sông Thạch Hãn"], "explanation": "Bạch Đằng Giang (Sông Bạch Đằng) là dòng sông lịch sử nơi Ngô Quyền, Lê Hoàn và Trần Hưng Đạo đã đánh bại quân xâm lược phương Bắc. Hình ảnh sông được khắc trên Nghị Đỉnh để ghi nhớ chiến công giữ nước.", "question_text": "Con sông nào gắn liền với ba chiến công lừng lẫy chống ngoại xâm (Nam Hán, Tống, Nguyên Mông) xuất hiện trên Nghị Đỉnh?", "question_type": "multiple_choice", "correct_answer": "Sông Bạch Đằng"}, {"options": ["Là nơi nghỉ mát của vua chúa", "Là cửa biển yết hầu, bảo vệ đường thủy vào Kinh thành", "Là cảng buôn bán sầm uất nhất Đàng Trong", "Là nơi nuôi trồng thủy sản hoàng gia"], "explanation": "Cửa Thuận An (nơi sông Hương đổ ra biển) được coi là 'yết hầu' (cổ họng) của Kinh thành Huế, có vị trí chiến lược sống còn về quân sự và giao thương.", "question_text": "'Thuận An Hải Khẩu' được khắc trên Nghị Đỉnh có vai trò gì đối với Kinh thành Huế xưa?", "question_type": "multiple_choice", "correct_answer": "Là cửa biển yết hầu, bảo vệ đường thủy vào Kinh thành"}, {"options": ["Hoa Đào", "Hoa Mai (Hoàng Mai)", "Hoa Cúc", "Hoa Lan"], "explanation": "Hoa Mai (cụ thể là Mai vàng) là biểu tượng của mùa xuân phương Nam, tượng trưng cho sự phú quý và khí tiết người quân tử.", "question_text": "Loài hoa nào khắc trên Nghị Đỉnh được coi là loài hoa đặc trưng của mùa xuân xứ Huế và miền Nam?", "question_type": "multiple_choice", "correct_answer": "Hoa Mai (Hoàng Mai)"}, {"options": ["Con Hồ ly", "Con Cá sấu", "Con Đuông dừa", "Con Tắc kè"], "explanation": "Hồ Da Tử là tên gọi của con đuông dừa (ấu trùng kiến dương), một loài sinh vật sống trong thân cây dừa, vừa là loài gây hại cây trồng nhưng cũng là món đặc sản ẩm thực.", "question_text": "Họa tiết 'Hồ Da Tử' trên Nghị Đỉnh mô tả loài sinh vật nào?", "question_type": "multiple_choice", "correct_answer": "Con Đuông dừa"}, {"options": ["Cá chép", "Cá trê", "Cá rô đồng", "Cá lóc (Cá quả)"], "explanation": "Lục Hoa Ngư chính là cá lóc (cá quả, cá chuối), loài cá nước ngọt phổ biến, có sức sống mãnh liệt và giá trị dinh dưỡng cao.", "question_text": "Loài cá nào quen thuộc với làng quê Việt Nam được khắc trên Nghị Đỉnh với tên gọi 'Lục Hoa Ngư'?", "question_type": "multiple_choice", "correct_answer": "Cá lóc (Cá quả)"}, {"options": ["Con Hổ", "Con Voi", "Con Trâu", "Con Ngựa"], "explanation": "Hình ảnh con Voi (Tượng) trên Nghị Đỉnh đại diện cho sức mạnh tự nhiên và lực lượng tượng binh hùng hậu của triều đình.", "question_text": "Loài vật nào xuất hiện trên Nghị Đỉnh tượng trưng cho sức mạnh của lực lượng 'Tượng binh' nhà Nguyễn?", "question_type": "multiple_choice", "correct_answer": "Con Voi"}, {"options": ["Một hòn đảo ngoài khơi", "Một loại hải đăng", "Một loại thuyền chiến nhanh nhẹn", "Một loại bản đồ biển"], "explanation": "Hải Đạo là tên một loại thuyền chiến nhỏ, thon dài, có khả năng di chuyển rất nhanh và linh hoạt, thường dùng để tuần tra và truy bắt cướp biển.", "question_text": "'Hải Đạo' được khắc trên Nghị Đỉnh là phương tiện gì?", "question_type": "multiple_choice", "correct_answer": "Một loại thuyền chiến nhanh nhẹn"}, {"options": ["Thanh Hóa", "Nghệ An", "Quảng Nam", "Yên Bái"], "explanation": "Quế Thanh (Thanh Hóa) xưa kia được mệnh danh là 'Ngọc quế', 'Châu thường', có giá trị dược liệu cao nhất và thường dùng làm cống phẩm.", "question_text": "Cây Quế trên Nghị Đỉnh thường gắn liền với địa danh nổi tiếng nào về chất lượng quế?", "question_type": "multiple_choice", "correct_answer": "Thanh Hóa"}, {"options": ["Rau Muống", "Rau Cải", "Rau Dền", "Rau Mồng tơi"], "explanation": "Giới là tên Hán Việt của cây rau cải. Hạt cải (Giới tử) có vị cay nồng, dùng làm thuốc trị ho hoặc làm gia vị.", "question_text": "Loài rau nào có hạt dùng làm thuốc và gia vị (mù tạt) được khắc trên Nghị Đỉnh với tên gọi 'Giới'?", "question_type": "multiple_choice", "correct_answer": "Rau Cải"}, {"options": ["Phượng Hoàng", "Hạc", "Uyên Ương", "Khổng Tước"], "explanation": "Uyên Ương (chim trống và chim mái) luôn đi có đôi, là biểu tượng kinh điển của hạnh phúc lứa đôi và lòng chung thủy trong văn hóa phương Đông.", "question_text": "Hình ảnh đôi chim nào trên Nghị Đỉnh biểu tượng cho tình yêu chung thủy?", "question_type": "multiple_choice", "correct_answer": "Uyên Ương"}, {"options": ["Đại Đao", "Trường Thương", "Cung tên", "Kiếm"], "explanation": "Trường Thương (Giáo dài) là vũ khí cận chiến cơ bản và quan trọng của bộ binh xưa, có lợi thế về tầm đánh xa.", "question_text": "Vũ khí nào thuộc nhóm 'Thập bát ban võ nghệ' dùng để đâm, có cán dài, được khắc trên Nghị Đỉnh?", "question_type": "multiple_choice", "correct_answer": "Trường Thương"}, {"options": ["Lễ Vu Lan", "Tết Trung Thu", "Tết Nguyên Đán", "Lễ Thất Tịch"], "explanation": "Hoa Hải Đường nở vào mùa xuân, có màu đỏ thắm rực rỡ, được người Việt ưa chuộng chưng vào dịp Tết để cầu mong phú quý, giàu sang ('Phú quý chơi Hải Đường').", "question_text": "Loài hoa 'Hải Đường' trên Nghị Đỉnh thường được người xưa trưng bày vào dịp nào với ý nghĩa cầu phú quý?", "question_type": "multiple_choice", "correct_answer": "Tết Nguyên Đán"}]	80	100
716b1322-d667-4ce0-aef0-e8a041f86065	ffa42b96-fdb3-4804-816c-29628d93792f	[{"options": ["Vua Gia Long", "Vua Minh Mạng", "Vua Thiệu Trị", "Vua Tự Đức"], "explanation": "Nhân Đỉnh dâng tặng Thánh Tổ Nhân Hoàng Đế (vua Minh Mạng), người có công lớn trong việc củng cố và phát triển triều Nguyễn.", "question_text": "Nhân Đỉnh được đúc để tôn vinh vị vua nào của triều Nguyễn?", "question_type": "multiple_choice", "correct_answer": "Vua Minh Mạng"}, {"options": ["Ba móng", "Bốn móng", "Năm móng", "Sáu móng"], "explanation": "Rồng năm móng (ngũ trảo long) là biểu tượng dành riêng cho hoàng đế, thể hiện quyền lực tối cao.", "question_text": "Họa tiết 'Rồng' trên Nhân Đỉnh có bao nhiêu móng?", "question_type": "multiple_choice", "correct_answer": "Năm móng"}, {"options": ["Hoa sen", "Hoa mẫu đơn", "Hoa cúc", "Hoa mai"], "explanation": "Hoa mẫu đơn là biểu tượng của sự phú quý, giàu sang và thịnh vượng.", "question_text": "Loài hoa nào được khắc trên Nhân Đỉnh, tượng trưng cho sự phú quý?", "question_type": "multiple_choice", "correct_answer": "Hoa mẫu đơn"}, {"options": ["Đồ trang sức", "Biểu tượng của quyền lực hoàng đế", "Công cụ viết chữ", "Vật phẩm tôn giáo"], "explanation": "Ngọc Ấn là ấn triện của hoàng đế, biểu tượng của quyền lực tối cao và sự chính thống.", "question_text": "Họa tiết 'Ngọc Ấn' trên Nhân Đỉnh có ý nghĩa gì?", "question_type": "multiple_choice", "correct_answer": "Biểu tượng của quyền lực hoàng đế"}, {"options": ["Nơi sinh của vua Minh Mạng", "Thủ đô của Đàng Ngoài, sau này được triều Nguyễn thống nhất", "Nơi đúc Cửu Đỉnh", "Thủ đô đầu tiên của triều Nguyễn"], "explanation": "Hà Nội là thủ đô của Đàng Ngoài, được vua Gia Long thống nhất vào năm 1802.", "question_text": "Địa danh 'Hà Nội' trên Nhân Đỉnh có ý nghĩa lịch sử gì?", "question_type": "multiple_choice", "correct_answer": "Thủ đô của Đàng Ngoài, sau này được triều Nguyễn thống nhất"}, {"options": ["Cây tre", "Cây tùng", "Cây mai", "Cây đào"], "explanation": "Cây tùng (thông) tượng trưng cho sự trường thọ, kiên cường và là một trong 'tứ quý'.", "question_text": "Loại cây nào được khắc trên Nhân Đỉnh, tượng trưng cho sự trường thọ?", "question_type": "multiple_choice", "correct_answer": "Cây tùng"}, {"options": ["Nghệ thuật viết chữ", "Văn hóa và giáo dục", "Lịch sử triều đại", "Tôn giáo"], "explanation": "Sách là biểu tượng của văn hóa, giáo dục và sự trọng dụng người tài đức.", "question_text": "Họa tiết 'Sách' trên Nhân Đỉnh thể hiện điều gì?", "question_type": "multiple_choice", "correct_answer": "Văn hóa và giáo dục"}, {"options": ["Công", "Hạc", "Trĩ", "Ưng"], "explanation": "Chim trĩ với bộ lông đuôi dài lộng lẫy tượng trưng cho sự thanh nhã và vẻ đẹp văn hóa.", "question_text": "Loài chim nào được khắc trên Nhân Đỉnh, tượng trưng cho sự thanh nhã?", "question_type": "multiple_choice", "correct_answer": "Trĩ"}, {"options": ["Sự giàu có", "Văn chương và học vấn", "Mùa màng bội thu", "Sức khỏe dồi dào"], "explanation": "Bút là biểu tượng của văn chương, học vấn và sự trọng dụng người tài.", "question_text": "Họa tiết 'Bút' trên Nhân Đỉnh mang ý nghĩa gì?", "question_type": "multiple_choice", "correct_answer": "Văn chương và học vấn"}, {"options": ["Nơi sinh của vua Gia Long", "Quê hương của nhiều danh nhân và vùng đất có truyền thống yêu nước", "Nơi đúc Cửu Đỉnh", "Thủ đô đầu tiên"], "explanation": "Nghệ An là quê hương của nhiều danh nhân và có truyền thống yêu nước, chống giặc ngoại xâm.", "question_text": "Địa danh 'Nghệ An' trên Nhân Đỉnh có ý nghĩa lịch sử gì?", "question_type": "multiple_choice", "correct_answer": "Quê hương của nhiều danh nhân và vùng đất có truyền thống yêu nước"}, {"explanation": "Nhân Đỉnh cùng với 8 đỉnh khác được đúc trong giai đoạn 1835-1837 dưới triều vua Minh Mạng.", "question_text": "Nhân Đỉnh được đúc vào năm 1835-1837.", "question_type": "true_false", "correct_answer": "Đúng"}, {"explanation": "Các họa tiết trên Nhân Đỉnh đều mang ý nghĩa lịch sử, văn hóa và chính trị sâu sắc.", "question_text": "Họa tiết trên Nhân Đỉnh chỉ mô tả cảnh vật thiên nhiên.", "question_type": "true_false", "correct_answer": "Sai"}, {"explanation": "Cao Đỉnh là đỉnh lớn nhất, các đỉnh còn lại có kích thước tương đương nhau.", "question_text": "Nhân Đỉnh là đỉnh nhỏ nhất trong Cửu Đỉnh.", "question_type": "true_false", "correct_answer": "Sai"}, {"explanation": "Nhân Đỉnh được đặt ở phía Tây, tượng trưng cho hướng Tây và vị trí quan trọng trong bố cục.", "question_text": "Nhân Đỉnh được đặt ở phía Tây trong bố cục Cửu Đỉnh.", "question_type": "true_false", "correct_answer": "Đúng"}, {"explanation": "Các họa tiết trên Cửu Đỉnh đều được tạo ra bằng kỹ thuật đúc đồng tinh xảo.", "question_text": "Tất cả các họa tiết trên Nhân Đỉnh đều được khắc nổi bằng kỹ thuật đúc đồng.", "question_type": "true_false", "correct_answer": "Đúng"}]	80	100
59b58c4e-10f1-4ff5-8a16-ad60bb1a2f8a	a73d39ad-7096-4c19-bebc-a0ceaa246a3a	[{"options": ["Vua Gia Long", "Vua Thái Tổ (Nguyễn Hoàng)", "Vua Minh Mạng", "Vua Thiệu Trị"], "explanation": "Thuần Đỉnh dâng tặng Thái Tổ Khoan Hoàng Đế (Nguyễn Hoàng), người khai sáng lãnh thổ Đàng Trong và là tổ tiên đầu tiên của các chúa Nguyễn.", "question_text": "Thuần Đỉnh được đúc để tôn vinh vị vua nào của triều Nguyễn?", "question_type": "multiple_choice", "correct_answer": "Vua Thái Tổ (Nguyễn Hoàng)"}, {"options": ["Quyền lực quân sự", "Sự thịnh vượng và điềm lành", "Sự trường thọ", "Trí tuệ"], "explanation": "Lân (kỳ lân) là một trong tứ linh, tượng trưng cho sự thịnh vượng, hòa bình và điềm lành cho quốc gia.", "question_text": "Họa tiết 'Lân' trên Thuần Đỉnh tượng trưng cho điều gì?", "question_type": "multiple_choice", "correct_answer": "Sự thịnh vượng và điềm lành"}, {"options": ["Hoa sen", "Hoa mẫu đơn", "Hoa cúc", "Hoa mai"], "explanation": "Hoa mẫu đơn là biểu tượng của sự giàu sang, phú quý và thịnh vượng trong văn hóa phương Đông.", "question_text": "Loài hoa nào được khắc trên Thuần Đỉnh, tượng trưng cho sự giàu sang?", "question_type": "multiple_choice", "correct_answer": "Hoa mẫu đơn"}, {"options": ["Nhạc cụ giải trí", "Biểu tượng của quyền lực và lễ nghi triều đình", "Công cụ báo giờ", "Vật phẩm tôn giáo"], "explanation": "Chuông là biểu tượng của quyền lực, lễ nghi triều đình và được sử dụng trong các nghi thức quan trọng.", "question_text": "Họa tiết 'Chuông' trên Thuần Đỉnh có ý nghĩa gì?", "question_type": "multiple_choice", "correct_answer": "Biểu tượng của quyền lực và lễ nghi triều đình"}, {"options": ["Đà Nẵng", "Huế", "Hội An", "Quảng Trị"], "explanation": "Phú Xuân là tên cũ của thành phố Huế, kinh đô của triều Nguyễn.", "question_text": "Địa danh 'Phú Xuân' trên Thuần Đỉnh ngày nay là thành phố nào?", "question_type": "multiple_choice", "correct_answer": "Huế"}, {"options": ["Cây tre", "Cây cúc", "Cây mai", "Cây đào"], "explanation": "Cây cúc tượng trưng cho sự thanh cao, kiên cường và là một trong 'tứ quý' (tùng, cúc, trúc, mai).", "question_text": "Loại cây nào được khắc trên Thuần Đỉnh, tượng trưng cho sự thanh cao?", "question_type": "multiple_choice", "correct_answer": "Cây cúc"}, {"options": ["Nhạc cụ dân gian", "Sức mạnh quân sự và tinh thần chiến đấu", "Lễ hội truyền thống", "Nghệ thuật âm nhạc"], "explanation": "Trống là biểu tượng của sức mạnh quân sự, tinh thần chiến đấu và được sử dụng để chỉ huy quân đội.", "question_text": "Họa tiết 'Trống' trên Thuần Đỉnh thể hiện điều gì?", "question_type": "multiple_choice", "correct_answer": "Sức mạnh quân sự và tinh thần chiến đấu"}, {"options": ["Công", "Hạc", "Trĩ", "Ưng"], "explanation": "Chim công là biểu tượng của sự cao quý, vẻ đẹp và thường xuất hiện trong các tác phẩm nghệ thuật cung đình.", "question_text": "Loài chim nào được khắc trên Thuần Đỉnh, tượng trưng cho sự cao quý?", "question_type": "multiple_choice", "correct_answer": "Công"}, {"options": ["Sự giàu có", "Sự kiên cường và tinh thần bất khuất", "Mùa màng bội thu", "Sức khỏe dồi dào"], "explanation": "Hoa mai tượng trưng cho sự kiên cường, tinh thần bất khuất trước nghịch cảnh và là một trong 'tứ quý'.", "question_text": "Họa tiết 'Mai' trên Thuần Đỉnh mang ý nghĩa gì?", "question_type": "multiple_choice", "correct_answer": "Sự kiên cường và tinh thần bất khuất"}, {"options": ["Nơi sinh của vua Gia Long", "Vùng đất biên giới quan trọng giữa Đàng Trong và Đàng Ngoài", "Nơi đúc Cửu Đỉnh", "Thủ đô đầu tiên"], "explanation": "Quảng Bình là vùng đất biên giới quan trọng, nơi diễn ra nhiều trận chiến giữa Đàng Trong và Đàng Ngoài.", "question_text": "Địa danh 'Quảng Bình' trên Thuần Đỉnh có ý nghĩa lịch sử gì?", "question_type": "multiple_choice", "correct_answer": "Vùng đất biên giới quan trọng giữa Đàng Trong và Đàng Ngoài"}, {"explanation": "Thuần Đỉnh cùng với 8 đỉnh khác được đúc trong giai đoạn 1835-1837 dưới triều vua Minh Mạng.", "question_text": "Thuần Đỉnh được đúc vào năm 1835-1837.", "question_type": "true_false", "correct_answer": "Đúng"}, {"explanation": "Các họa tiết trên Thuần Đỉnh đều mang ý nghĩa lịch sử sâu sắc, thể hiện lãnh thổ, thành tựu và quyền lực của triều Nguyễn.", "question_text": "Họa tiết trên Thuần Đỉnh chỉ có giá trị thẩm mỹ, không có ý nghĩa lịch sử.", "question_type": "true_false", "correct_answer": "Sai"}, {"explanation": "Cao Đỉnh là đỉnh lớn nhất, các đỉnh còn lại có kích thước tương đương nhau.", "question_text": "Thuần Đỉnh là đỉnh lớn thứ hai sau Cao Đỉnh.", "question_type": "true_false", "correct_answer": "Sai"}, {"explanation": "Thuần Đỉnh được đặt ở phía Đông, tượng trưng cho hướng Đông và vị trí quan trọng trong bố cục không gian.", "question_text": "Thuần Đỉnh được đặt ở phía Đông trong bố cục Cửu Đỉnh.", "question_type": "true_false", "correct_answer": "Đúng"}, {"explanation": "Các họa tiết trên Cửu Đỉnh đều được tạo ra bằng kỹ thuật đúc đồng tinh xảo.", "question_text": "Tất cả các họa tiết trên Thuần Đỉnh đều được khắc nổi bằng kỹ thuật đúc đồng.", "question_type": "true_false", "correct_answer": "Đúng"}]	80	100
19f0e051-b791-45e4-bd2d-4f1d56782408	4bb3d53e-e89c-474e-9715-1c42bc7eaafa	[{"options": ["Vua Gia Long", "Vua Thần Tông (Nguyễn Phúc Tần)", "Vua Minh Mạng", "Vua Thiệu Trị"], "explanation": "Tuyên Đỉnh dâng tặng Thần Tông Hiếu Vũ Hoàng Đế (Nguyễn Phúc Tần), người có công lớn trong việc mở rộng lãnh thổ về phía Nam.", "question_text": "Tuyên Đỉnh được đúc để tôn vinh vị vua nào của triều Nguyễn?", "question_type": "multiple_choice", "correct_answer": "Vua Thần Tông (Nguyễn Phúc Tần)"}, {"options": ["Sự trường thọ", "Sức mạnh và quyền lực", "Trí tuệ", "Sự giàu có"], "explanation": "Voi là biểu tượng của sức mạnh, quyền lực và được sử dụng trong quân đội và lễ nghi triều đình.", "question_text": "Họa tiết 'Voi' trên Tuyên Đỉnh tượng trưng cho điều gì?", "question_type": "multiple_choice", "correct_answer": "Sức mạnh và quyền lực"}, {"options": ["Hoa đào", "Hoa sen", "Hoa cúc", "Hoa mai"], "explanation": "Hoa sen là biểu tượng của sự trong sạch, thanh cao 'xuất ô nhiễm nhi bất nhiễm'.", "question_text": "Loài hoa nào được khắc trên Tuyên Đỉnh, tượng trưng cho sự trong sạch?", "question_type": "multiple_choice", "correct_answer": "Hoa sen"}, {"options": ["Vũ khí", "Nhạc khí cổ làm bằng ngọc", "Đồ trang sức", "Công cụ lao động"], "explanation": "Ngọc Tỷ là nhạc khí cổ làm bằng ngọc, biểu tượng của văn hóa và lễ nghi cao cấp.", "question_text": "Họa tiết 'Ngọc Tỷ' trên Tuyên Đỉnh là gì?", "question_type": "multiple_choice", "correct_answer": "Nhạc khí cổ làm bằng ngọc"}, {"options": ["Hà Nội", "Thành phố Hồ Chí Minh", "Đà Nẵng", "Cần Thơ"], "explanation": "Gia Định là tên cũ của thành phố Hồ Chí Minh, vùng đất quan trọng của Đàng Trong.", "question_text": "Địa danh 'Gia Định' trên Tuyên Đỉnh ngày nay là thành phố nào?", "question_type": "multiple_choice", "correct_answer": "Thành phố Hồ Chí Minh"}, {"options": ["Cây tre", "Cây thông", "Cây mai", "Cây đào"], "explanation": "Cây tre tượng trưng cho sự bất khuất, khí tiết của người quân tử 'trúc bất đổi tiết'.", "question_text": "Loại cây nào được khắc trên Tuyên Đỉnh, tượng trưng cho sự bất khuất?", "question_type": "multiple_choice", "correct_answer": "Cây tre"}, {"options": ["Nghệ thuật đóng tàu", "Giao thương và phát triển kinh tế", "Du lịch", "Đánh cá"], "explanation": "Thuyền là biểu tượng của giao thương, vận chuyển và phát triển kinh tế qua đường thủy.", "question_text": "Họa tiết 'Thuyền' trên Tuyên Đỉnh thể hiện điều gì?", "question_type": "multiple_choice", "correct_answer": "Giao thương và phát triển kinh tế"}, {"options": ["Công", "Hạc", "Trĩ", "Ưng"], "explanation": "Hạc là biểu tượng của sự thanh cao, trường thọ và thường xuất hiện trong nghệ thuật cung đình.", "question_text": "Loài chim nào được khắc trên Tuyên Đỉnh, tượng trưng cho sự thanh cao?", "question_type": "multiple_choice", "correct_answer": "Hạc"}, {"options": ["Sự giàu có", "Văn hóa và nghệ thuật âm nhạc", "Mùa màng bội thu", "Sức khỏe dồi dào"], "explanation": "Đàn là nhạc khí truyền thống, tượng trưng cho văn hóa, nghệ thuật âm nhạc và sự thanh nhã.", "question_text": "Họa tiết 'Đàn' trên Tuyên Đỉnh mang ý nghĩa gì?", "question_type": "multiple_choice", "correct_answer": "Văn hóa và nghệ thuật âm nhạc"}, {"options": ["Nơi sinh của vua Gia Long", "Vùng đất quan trọng trong việc mở rộng lãnh thổ về phía Nam", "Nơi đúc Cửu Đỉnh", "Thủ đô đầu tiên"], "explanation": "Biên Hòa là vùng đất quan trọng trong việc mở rộng lãnh thổ của các chúa Nguyễn về phía Nam.", "question_text": "Địa danh 'Biên Hòa' trên Tuyên Đỉnh có ý nghĩa lịch sử gì?", "question_type": "multiple_choice", "correct_answer": "Vùng đất quan trọng trong việc mở rộng lãnh thổ về phía Nam"}, {"explanation": "Tuyên Đỉnh cùng với 8 đỉnh khác được đúc trong giai đoạn 1835-1837 dưới triều vua Minh Mạng.", "question_text": "Tuyên Đỉnh được đúc vào năm 1835-1837.", "question_type": "true_false", "correct_answer": "Đúng"}, {"explanation": "Các họa tiết trên Tuyên Đỉnh đều mang ý nghĩa lịch sử, chính trị và văn hóa sâu sắc.", "question_text": "Họa tiết trên Tuyên Đỉnh chỉ mô tả cảnh vật thiên nhiên.", "question_type": "true_false", "correct_answer": "Sai"}, {"explanation": "Cao Đỉnh là đỉnh lớn nhất, các đỉnh còn lại có kích thước tương đương nhau.", "question_text": "Tuyên Đỉnh là đỉnh nhỏ nhất trong Cửu Đỉnh.", "question_type": "true_false", "correct_answer": "Sai"}, {"explanation": "Tuyên Đỉnh được đặt ở phía Nam, tượng trưng cho hướng Nam và vị trí quan trọng trong bố cục.", "question_text": "Tuyên Đỉnh được đặt ở phía Nam trong bố cục Cửu Đỉnh.", "question_type": "true_false", "correct_answer": "Đúng"}, {"explanation": "Các họa tiết trên Cửu Đỉnh đều được tạo ra bằng kỹ thuật đúc đồng tinh xảo.", "question_text": "Tất cả các họa tiết trên Tuyên Đỉnh đều được khắc nổi bằng kỹ thuật đúc đồng.", "question_type": "true_false", "correct_answer": "Đúng"}]	80	100
\.


--
-- Data for Name: urns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.urns (id, slug, name, name_han, represents, description, model_url, thumbnail_url, display_order, is_demo, created_at) FROM stdin;
5dee75b5-558b-44ce-81da-6a44673927db	cao-dinh	Cao Đỉnh	\N	\N	\N	/assets/models/CAO-DINH-v1.glb	/assets/ban-duc-noi/CAO%20DINH/CAO%20DINH.jpg	1	t	2026-01-08 14:55:01.200388+00
ffa42b96-fdb3-4804-816c-29628d93792f	nhan-dinh	Nhân Đỉnh	\N	\N	\N		/assets/ban-duc-noi/NHAN%20DINH/NH%C3%82N%20%C4%90%E1%BB%88NH.jpg	2	f	2026-01-08 14:55:01.200388+00
a40d0ce2-b30d-4c99-bb2e-15a802f9221e	chuong-dinh	Chương Đỉnh	\N	\N	\N	/assets/models/CHUONG-DINH-v1.glb	/assets/ban-duc-noi/CHUONG%20DINH/CH%C6%AF%C6%A0NG%20%C4%90%E1%BB%88NH.jpg	3	f	2026-01-08 14:55:01.200388+00
c669187e-adb8-432a-b79f-c5fc00ebcd20	anh-dinh	Anh Đỉnh	\N	\N	\N		/assets/ban-duc-noi/ANH%20DINH/ANH%20%C4%90%E1%BB%88NH.jpg	4	f	2026-01-08 14:55:01.200388+00
a1dd8a81-fe6a-47d1-9e54-077708b5c05c	nghi-dinh	Nghị Đỉnh	\N	\N	\N	/assets/models/NGHI-DINH-v1.glb	/assets/ban-duc-noi/NGHI%20DINH/NGHI%20DINH.jpg	5	f	2026-01-08 14:55:01.200388+00
a73d39ad-7096-4c19-bebc-a0ceaa246a3a	thuan-dinh	Thuần Đỉnh	\N	\N	\N	/assets/models/THUAN-DINH-v1.glb	/assets/ban-duc-noi/THUAN%20DINH/THU%E1%BA%A6N%20%C4%90%E1%BB%88NH.jpg	6	f	2026-01-08 14:55:01.200388+00
4bb3d53e-e89c-474e-9715-1c42bc7eaafa	tuyen-dinh	Tuyên Đỉnh	\N	\N	\N	/assets/models/TUYEN-DINH-v1.glb	/assets/ban-duc-noi/TUYEN%20DINH/TUYEN%20DINH.jpg	7	f	2026-01-08 14:55:01.200388+00
c2c33771-6473-4745-ba26-dd1d32cce0c6	du-dinh	Dụ Đỉnh	\N	\N	\N		/assets/ban-duc-noi/DU%20DINH/D%E1%BB%A4%20%C4%90%E1%BB%88NH.jpg	8	f	2026-01-08 14:55:01.200388+00
90805a09-3a38-49e4-8827-e57da439d1a6	huyen-dinh	Huyền Đỉnh	\N	\N	\N	/assets/models/HUYEN-DINH-v1.glb	/assets/ban-duc-noi/HUYEN%20DINH/HUYEN%20DINH.jpg	9	f	2026-01-08 14:55:01.200388+00
\.


--
-- Data for Name: user_badges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_badges (id, user_id, badge_id, earned_at, current_tier) FROM stdin;
0b5ebbd0-ea43-410d-a1df-488c6fe215e9	1df31222-3934-471c-8624-a87034fd017d	6d53a206-604b-4ca0-8025-950a4a8c3099	2026-01-09 03:54:56.353594+00	bronze
a2d8949b-29ac-482f-8829-755e9559536c	1df31222-3934-471c-8624-a87034fd017d	aef1d95c-9b78-449f-a4a5-6e76add9a1ca	2026-01-12 07:58:34.994829+00	bronze
b06ffb79-381b-4153-9503-ad8e037014b2	1df31222-3934-471c-8624-a87034fd017d	2b881a08-fba9-40de-a004-1ec37945fc47	2026-01-12 08:02:16.298053+00	bronze
5be7f0e4-f396-4a4f-9969-fa4fd319df25	1df31222-3934-471c-8624-a87034fd017d	aad694ca-3c38-4bce-a267-1c3f3fe1af4c	2026-01-12 08:02:16.298053+00	bronze
a8d1ff32-ac3e-433d-ae8c-bbe1aca4ea24	1df31222-3934-471c-8624-a87034fd017d	3fa3337c-e77e-4a58-b2c3-8c3c86453012	2026-01-23 05:12:33.61035+00	bronze
\.


--
-- Data for Name: user_content_interactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_content_interactions (id, user_id, content_type, content_id, interaction_type, duration_seconds, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: user_daily_missions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_daily_missions (id, user_id, mission_id, mission_date, current_count, is_completed, completed_at, xp_awarded, created_at) FROM stdin;
\.


--
-- Data for Name: user_experiment_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_experiment_assignments (id, user_id, experiment_id, variant_key, assigned_at) FROM stdin;
\.


--
-- Data for Name: user_follows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_follows (id, follower_id, following_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_hearts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_hearts (id, user_id, current_hearts, max_hearts, last_heart_lost_at, hearts_refill_at, unlimited_until, streak_freezes, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_leaderboard_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_leaderboard_settings (id, user_id, show_on_global, show_real_name, preferred_leaderboard, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_learning_paths; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_learning_paths (id, user_id, path_date, recommended_lessons, recommended_reviews, recommended_quizzes, estimated_time_minutes, completed_items, is_completed, generated_at, completed_at) FROM stdin;
\.


--
-- Data for Name: user_milestones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_milestones (id, user_id, milestone_type, achieved_at, context_data, celebrated, created_at) FROM stdin;
\.


--
-- Data for Name: user_notification_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_notification_settings (id, user_id, push_enabled, push_token, push_platform, email_enabled, streak_reminders, daily_mission_reminders, weekly_digest, marketing_enabled, quiet_hours_start, quiet_hours_end, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_progress (id, user_id, motif_id, status, discovered_at, lesson_viewed_at, learned_at, mastered_at, quiz_attempts, quiz_best_score, xp_earned, created_at, updated_at, ease_factor, interval_days, repetitions, next_review_at, last_reviewed_at, review_history) FROM stdin;
ccbd4fb2-5ccb-4da8-8700-427249356797	1df31222-3934-471c-8624-a87034fd017d	ee64b246-96ba-4a9f-87a5-524fb427d54f	discovered	2026-01-09 03:54:56.363737+00	\N	\N	\N	0	0	25	2026-01-09 03:54:56.353594+00	2026-01-09 03:54:56.353594+00	2.5	0	0	\N	\N	[]
8c41a242-1f98-493f-8997-4061b5e8a860	1df31222-3934-471c-8624-a87034fd017d	bf4a67a3-162d-4d04-98b0-adff8a1860f1	learned	2026-01-12 07:58:13.967619+00	2026-01-12 07:58:19.45803+00	2026-01-12 07:58:19.45803+00	\N	1	67	75	2026-01-12 07:58:13.963116+00	2026-01-12 07:58:34.994829+00	2.5	0	0	\N	\N	[]
9f76d441-995f-46b5-b682-4b130bd1337e	1df31222-3934-471c-8624-a87034fd017d	284e4bb9-a798-45a1-9926-4e9cc8debdcc	discovered	2026-01-12 08:01:30.402221+00	\N	\N	\N	0	0	25	2026-01-12 08:01:30.396252+00	2026-01-12 08:01:30.396252+00	2.5	0	0	\N	\N	[]
578c96da-4378-43b4-ada5-6d075b2c6b12	1df31222-3934-471c-8624-a87034fd017d	798e6ca7-ca19-4851-b320-889549db1096	mastered	2026-01-12 08:01:44.873079+00	2026-01-12 08:02:05.489615+00	2026-01-12 08:02:05.489615+00	2026-01-12 08:02:16.304746+00	1	100	150	2026-01-12 08:01:44.869579+00	2026-01-12 08:02:16.298053+00	2.5	0	0	\N	\N	[]
c766f02b-8496-48fe-b417-549d28da5b5f	1df31222-3934-471c-8624-a87034fd017d	dcf170b7-345a-4da8-a7fd-b9327517bdc3	discovered	2026-01-23 04:19:18.027173+00	\N	\N	\N	0	0	25	2026-01-23 04:19:18.020499+00	2026-01-23 04:19:18.020499+00	2.5	0	0	\N	\N	[]
ef9e45ac-f8ed-4579-ad7f-acd84de6c43f	1df31222-3934-471c-8624-a87034fd017d	9401eb10-9469-4b4a-963a-68041441569b	discovered	2026-01-23 05:13:58.973798+00	\N	\N	\N	0	0	25	2026-01-23 05:13:58.969038+00	2026-01-23 05:13:58.969038+00	2.5	0	0	\N	\N	[]
19ebcecc-3bb7-470c-8e19-2fa6a9572cdc	1df31222-3934-471c-8624-a87034fd017d	63f7f1f5-83b9-4e43-8e94-7debbb3ed2ab	learned	2026-01-12 08:01:27.310212+00	2026-01-23 05:45:10.980342+00	2026-01-23 05:45:10.980342+00	\N	0	0	75	2026-01-12 08:01:27.303663+00	2026-01-23 05:45:10.976283+00	2.5	0	0	\N	\N	[]
eb75a52e-2b41-4182-9588-9bb4debdd530	1df31222-3934-471c-8624-a87034fd017d	d9963208-838a-45ee-a45c-3f22f1c5a157	discovered	2026-01-24 02:12:52.724625+00	\N	\N	\N	0	0	25	2026-01-24 02:12:52.719871+00	2026-01-24 02:12:52.719871+00	2.5	0	0	\N	\N	[]
31186b96-1433-418b-b581-417d83ff8183	1df31222-3934-471c-8624-a87034fd017d	a9d3e605-ac3e-44ef-bf07-8712b6b4eefd	discovered	2026-01-24 02:13:00.548571+00	\N	\N	\N	0	0	25	2026-01-24 02:13:00.542746+00	2026-01-24 02:13:00.542746+00	2.5	0	0	\N	\N	[]
d2831178-581c-4b3c-961e-9d5c9bbce23c	1df31222-3934-471c-8624-a87034fd017d	9e95bea4-a087-4dc5-ade2-c4e453878f41	learned	2026-01-15 07:53:41.684421+00	2026-01-28 15:41:47.132951+00	2026-01-28 15:41:47.132951+00	\N	0	0	75	2026-01-15 07:53:41.674876+00	2026-01-28 15:41:47.128316+00	2.5	0	0	\N	\N	[]
b46d79ce-bf38-4b83-b9c0-2f178fc1cb51	1df31222-3934-471c-8624-a87034fd017d	036b8060-4597-4028-bded-135081787c70	learned	2026-01-12 07:31:10.990189+00	2026-01-29 05:23:51.433717+00	2026-01-29 05:23:51.433717+00	\N	0	0	75	2026-01-12 07:31:10.921594+00	2026-01-29 05:23:51.427581+00	2.5	0	0	\N	\N	[]
352b0b48-0378-46c3-96f8-f2dde82641b7	1df31222-3934-471c-8624-a87034fd017d	f3a49a22-ec62-492e-a662-29419f1c2fca	learned	2026-01-23 05:12:33.617562+00	2026-02-05 16:39:12.477307+00	2026-02-05 16:39:12.477307+00	\N	0	0	75	2026-01-23 05:12:33.61035+00	2026-02-05 16:39:12.47283+00	2.5	0	0	\N	\N	[]
cf2ef89c-cbad-4f29-9788-13a7749d02c8	1df31222-3934-471c-8624-a87034fd017d	d27e9e0b-a9eb-42a2-8466-83442f48939d	learned	2026-01-23 02:44:35.556003+00	2026-02-06 11:50:43.920041+00	2026-02-06 11:50:43.920041+00	\N	0	0	75	2026-01-23 02:44:35.550689+00	2026-02-06 11:50:43.91439+00	2.5	0	0	\N	\N	[]
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sessions (id, user_id, session_id, started_at, last_active_at, ended_at, device_type, platform, app_version, is_active) FROM stdin;
\.


--
-- Data for Name: user_shares; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_shares (id, user_id, share_type, content_id, caption, visibility, share_url, view_count, created_at) FROM stdin;
\.


--
-- Data for Name: user_skill_levels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_skill_levels (id, user_id, skill_type, skill_level, total_questions, correct_answers, last_updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_weekly_quests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_weekly_quests (id, user_id, quest_id, week_start_date, current_count, is_completed, completed_at, xp_awarded, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, display_name, avatar_url, bio, username, starting_urn_id, is_profile_public, ai_personalization_enabled, role, total_xp, current_streak, longest_streak, streak_freezes, last_active_at, created_at, updated_at, birth_year, age_verified, age_verified_at, push_permission_prompted, onboarding_goal, onboarding_completed, onboarding_completed_at, xp_boost_active, xp_boost_expires_at, xp_boost_multiplier) FROM stdin;
91335bab-f27b-4b29-b650-b9b29d5997e8	teacher@luuniensuki.local	$2b$12$sANlWR7Ncg6FIcT..R7VeO.gQKt4mt6K5BjaRqc4D4KqpCONGI7tK	Teacher Demo	\N	\N	\N	\N	t	t	teacher	0	0	0	0	\N	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	\N	f	\N	f	\N	f	\N	f	\N	1
3aebcf92-c7c5-424b-9b3a-c4a396041416	admin@luuniensuki.local	$2b$12$sANlWR7Ncg6FIcT..R7VeO.gQKt4mt6K5BjaRqc4D4KqpCONGI7tK	Admin Demo	\N	\N	\N	\N	t	t	admin	0	0	0	0	\N	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	\N	f	\N	f	\N	f	\N	f	\N	1
929d5ff0-7f2a-4003-add7-50036aac943f	superadmin@luuniensuki.local	$2b$12$sANlWR7Ncg6FIcT..R7VeO.gQKt4mt6K5BjaRqc4D4KqpCONGI7tK	Super Admin	\N	\N	\N	\N	t	t	super_admin	0	0	0	0	\N	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	\N	f	\N	f	\N	f	\N	f	\N	1
5290740d-3e7b-4774-b7d2-567d09b0ad94	learner@luuniensuki.local	$2b$12$sANlWR7Ncg6FIcT..R7VeO.gQKt4mt6K5BjaRqc4D4KqpCONGI7tK	Learner Demo	\N	\N	\N	\N	t	t	learner	0	0	0	0	\N	2026-01-08 14:55:01.200388+00	2026-01-08 14:55:01.200388+00	\N	f	\N	f	\N	f	\N	f	\N	1
9212f3ba-8e00-4199-83df-25271cd78d3c	truongminhkhiemvta@gmail.com	$2b$12$/CrT6jEQ.xafoHWf./9YzuI.twEUTIOkW5G2vl3qwwA3IBNkHxYdK	RemyVN	\N	\N	\N	5dee75b5-558b-44ce-81da-6a44673927db	t	t	learner	0	0	0	0	\N	2026-01-08 15:02:11.530754+00	2026-01-08 15:02:23.519642+00	\N	f	\N	f	\N	f	\N	f	\N	1
3b4efeb2-6689-4a1d-af65-ba8858b63984	test@example.com	$2b$12$UfOrq8b0wUWM85pKhWPyOer6HWMapE2VMvhB0pX6H5BdEW6JNB.jC	Test User	\N	\N	\N	\N	t	t	learner	0	0	0	0	\N	2026-01-08 16:09:54.081893+00	2026-01-08 16:09:54.081893+00	\N	f	\N	f	\N	f	\N	f	\N	1
f15ecb74-115b-46c0-9c19-3de602370647	testmobile@test.com	$2b$12$L2SkenaL0oEjdu870vfuYer4QZ0I1fp4gkfwchvnWHuOoB.e/A3L6	Test Mobile	\N	\N	\N	\N	t	t	learner	0	0	0	0	\N	2026-01-11 16:58:47.950646+00	2026-01-11 16:58:47.950646+00	\N	f	\N	f	\N	f	\N	f	\N	1
addd1a44-78b7-4657-898e-5e69276f3270	info@kylekode.com	$2b$12$C6CC5mgObqXaq.xnhQEAKu7ryLDH.bMBh7i7XA.GJwtODeXgm8tVm	Kha Tran	\N	\N	\N	\N	t	t	learner	0	0	0	0	\N	2026-01-29 05:40:52.684828+00	2026-01-29 05:40:52.684828+00	\N	f	\N	f	\N	f	\N	f	\N	1
52f99b53-c2d8-4e46-8958-90545b552ca9	tmquang8112009@gmail.com	$2b$12$JxH31DLkzR0Xp8nQXVnyAO/BrV.5NniZ.a1oOT6fvUzNFzu7qeWHm	Quang	\N	\N	\N	\N	t	t	learner	0	0	0	0	\N	2026-01-29 07:19:33.13959+00	2026-01-29 07:19:33.13959+00	\N	f	\N	f	\N	f	\N	f	\N	1
1df31222-3934-471c-8624-a87034fd017d	admin@histolab.icu	$2b$12$hao5ox/RMZiY4akp9YOQTOnpzmo31rAYBEFcgqp6nXDzHxDNoN/hC	admin	\N	\N	\N	5dee75b5-558b-44ce-81da-6a44673927db	t	t	admin	1550	2	3	0	2026-02-06 11:50:43.920041+00	2026-01-08 14:57:48.182478+00	2026-02-06 11:50:43.91439+00	\N	f	\N	f	\N	f	\N	f	\N	1
ac4276d6-a00d-48dc-8c4d-8cdabbfb49a6	test@gmail.com	$2b$12$h8g1sIX49TTt1PjgmOyQ9.JZQE1oWhZC87H0ew41H1V7jjXc1THa2	wtf	\N	\N	\N	\N	t	t	learner	0	0	0	0	\N	2026-01-15 02:20:19.932231+00	2026-01-15 02:20:19.932231+00	\N	f	\N	f	\N	f	\N	f	\N	1
7b45c619-66f9-423a-8130-f7aae99374ca	test@test.com	$2b$12$FHA6n.j6yZoj7CW7PUF0/OwRPurgMtzvgQBmWefeSkCboME/xzYB.	test	\N	\N	\N	\N	t	t	learner	0	0	0	0	\N	2026-01-15 02:23:20.251696+00	2026-01-15 02:23:20.251696+00	\N	f	\N	f	\N	f	\N	f	\N	1
3f8790e9-13ed-4a41-8e40-4885f86c2d99	tester@gmail.com	$2b$12$vFroXjY4VPG0Y9O4XXzWOui/FOWVGEiMgDMMZzBlKwtLW1XDh7qiq	Test User	\N	\N	\N	\N	t	t	learner	0	0	0	0	\N	2026-01-17 12:38:13.741698+00	2026-01-17 12:38:13.741698+00	\N	f	\N	f	\N	f	\N	f	\N	1
\.


--
-- Data for Name: weekly_quests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.weekly_quests (id, slug, name, description, category, week_number, year, target_count, xp_reward, badge_slug, is_recurring, is_active, created_at) FROM stdin;
\.


--
-- Name: abuse_reports abuse_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.abuse_reports
    ADD CONSTRAINT abuse_reports_pkey PRIMARY KEY (id);


--
-- Name: ai_conversations ai_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_conversations
    ADD CONSTRAINT ai_conversations_pkey PRIMARY KEY (id);


--
-- Name: ai_jobs ai_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_jobs
    ADD CONSTRAINT ai_jobs_pkey PRIMARY KEY (id);


--
-- Name: ai_messages ai_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_messages
    ADD CONSTRAINT ai_messages_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: analytics_events analytics_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT analytics_events_pkey PRIMARY KEY (id);


--
-- Name: app_versions app_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_versions
    ADD CONSTRAINT app_versions_pkey PRIMARY KEY (id);


--
-- Name: assignment_progress assignment_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignment_progress
    ADD CONSTRAINT assignment_progress_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: badges badges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_pkey PRIMARY KEY (id);


--
-- Name: badges badges_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_slug_key UNIQUE (slug);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: class_members class_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_members
    ADD CONSTRAINT class_members_pkey PRIMARY KEY (id);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: content_flags content_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_flags
    ADD CONSTRAINT content_flags_pkey PRIMARY KEY (id);


--
-- Name: content_provenance content_provenance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_provenance
    ADD CONSTRAINT content_provenance_pkey PRIMARY KEY (id);


--
-- Name: content_tags content_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_tags
    ADD CONSTRAINT content_tags_pkey PRIMARY KEY (id);


--
-- Name: content_versions content_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_versions
    ADD CONSTRAINT content_versions_pkey PRIMARY KEY (id);


--
-- Name: crash_reports crash_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crash_reports
    ADD CONSTRAINT crash_reports_pkey PRIMARY KEY (id);


--
-- Name: daily_missions daily_missions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_missions
    ADD CONSTRAINT daily_missions_pkey PRIMARY KEY (id);


--
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- Name: embedding_jobs embedding_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embedding_jobs
    ADD CONSTRAINT embedding_jobs_pkey PRIMARY KEY (id);


--
-- Name: experiment_events experiment_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiment_events
    ADD CONSTRAINT experiment_events_pkey PRIMARY KEY (id);


--
-- Name: experiment_metric_events experiment_metric_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiment_metric_events
    ADD CONSTRAINT experiment_metric_events_pkey PRIMARY KEY (id);


--
-- Name: experiments experiments_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT experiments_key_key UNIQUE (key);


--
-- Name: experiments experiments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT experiments_pkey PRIMARY KEY (id);


--
-- Name: feature_flags feature_flags_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_key_key UNIQUE (key);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (id);


--
-- Name: friend_requests friend_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friend_requests
    ADD CONSTRAINT friend_requests_pkey PRIMARY KEY (id);


--
-- Name: guest_previews guest_previews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guest_previews
    ADD CONSTRAINT guest_previews_pkey PRIMARY KEY (id);


--
-- Name: heart_transactions heart_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.heart_transactions
    ADD CONSTRAINT heart_transactions_pkey PRIMARY KEY (id);


--
-- Name: lesson_cache lesson_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_cache
    ADD CONSTRAINT lesson_cache_pkey PRIMARY KEY (id);


--
-- Name: lesson_content lesson_content_motif_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_content
    ADD CONSTRAINT lesson_content_motif_id_key UNIQUE (motif_id);


--
-- Name: lesson_content lesson_content_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_content
    ADD CONSTRAINT lesson_content_pkey PRIMARY KEY (id);


--
-- Name: lesson_prerequisites lesson_prerequisites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_prerequisites
    ADD CONSTRAINT lesson_prerequisites_pkey PRIMARY KEY (id);


--
-- Name: motifs motifs_mesh_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motifs
    ADD CONSTRAINT motifs_mesh_name_key UNIQUE (mesh_name);


--
-- Name: motifs motifs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motifs
    ADD CONSTRAINT motifs_pkey PRIMARY KEY (id);


--
-- Name: streak_rewards pk_streak_rewards; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.streak_rewards
    ADD CONSTRAINT pk_streak_rewards PRIMARY KEY (id);


--
-- Name: push_notifications push_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_notifications
    ADD CONSTRAINT push_notifications_pkey PRIMARY KEY (id);


--
-- Name: quest_assignments quest_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quest_assignments
    ADD CONSTRAINT quest_assignments_pkey PRIMARY KEY (id);


--
-- Name: quest_objectives quest_objectives_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quest_objectives
    ADD CONSTRAINT quest_objectives_pkey PRIMARY KEY (id);


--
-- Name: quest_progress quest_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quest_progress
    ADD CONSTRAINT quest_progress_pkey PRIMARY KEY (id);


--
-- Name: quest_rewards quest_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quest_rewards
    ADD CONSTRAINT quest_rewards_pkey PRIMARY KEY (id);


--
-- Name: quest_steps quest_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quest_steps
    ADD CONSTRAINT quest_steps_pkey PRIMARY KEY (id);


--
-- Name: quests quests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quests
    ADD CONSTRAINT quests_pkey PRIMARY KEY (id);


--
-- Name: quests quests_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quests
    ADD CONSTRAINT quests_slug_key UNIQUE (slug);


--
-- Name: quiz_attempts quiz_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempts
    ADD CONSTRAINT quiz_attempts_pkey PRIMARY KEY (id);


--
-- Name: quiz_hint_requests quiz_hint_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_hint_requests
    ADD CONSTRAINT quiz_hint_requests_pkey PRIMARY KEY (id);


--
-- Name: quiz_questions quiz_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_questions
    ADD CONSTRAINT quiz_questions_pkey PRIMARY KEY (id);


--
-- Name: rag_documents rag_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rag_documents
    ADD CONSTRAINT rag_documents_pkey PRIMARY KEY (id);


--
-- Name: rag_settings rag_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rag_settings
    ADD CONSTRAINT rag_settings_pkey PRIMARY KEY (id);


--
-- Name: recommendations recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_pkey PRIMARY KEY (id);


--
-- Name: scheduled_emails scheduled_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_emails
    ADD CONSTRAINT scheduled_emails_pkey PRIMARY KEY (id);


--
-- Name: spaced_repetition_cards spaced_repetition_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spaced_repetition_cards
    ADD CONSTRAINT spaced_repetition_cards_pkey PRIMARY KEY (id);


--
-- Name: student_progress_snapshots student_progress_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_progress_snapshots
    ADD CONSTRAINT student_progress_snapshots_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_slug_key UNIQUE (slug);


--
-- Name: app_versions uq_app_version_platform_version; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_versions
    ADD CONSTRAINT uq_app_version_platform_version UNIQUE (platform, version);


--
-- Name: assignment_progress uq_assignment_progress; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignment_progress
    ADD CONSTRAINT uq_assignment_progress UNIQUE (assignment_id, user_id);


--
-- Name: certificates uq_certificates_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT uq_certificates_code UNIQUE (code);


--
-- Name: certificates uq_certificates_reason; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT uq_certificates_reason UNIQUE (user_id, reason_type, reason_id);


--
-- Name: class_members uq_class_members; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_members
    ADD CONSTRAINT uq_class_members UNIQUE (class_id, user_id);


--
-- Name: classes uq_classes_class_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT uq_classes_class_code UNIQUE (class_code);


--
-- Name: content_tags uq_content_tag; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_tags
    ADD CONSTRAINT uq_content_tag UNIQUE (tag_id, content_type, content_id);


--
-- Name: daily_missions uq_daily_missions_slug; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_missions
    ADD CONSTRAINT uq_daily_missions_slug UNIQUE (slug);


--
-- Name: email_templates uq_email_templates_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT uq_email_templates_key UNIQUE (key);


--
-- Name: friend_requests uq_friend_requests; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friend_requests
    ADD CONSTRAINT uq_friend_requests UNIQUE (from_user_id, to_user_id);


--
-- Name: lesson_cache uq_lesson_cache_user_lesson; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_cache
    ADD CONSTRAINT uq_lesson_cache_user_lesson UNIQUE (user_id, lesson_id);


--
-- Name: lesson_prerequisites uq_lesson_prereq_lesson_prereq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_prerequisites
    ADD CONSTRAINT uq_lesson_prereq_lesson_prereq UNIQUE (lesson_id, prerequisite_lesson_id);


--
-- Name: user_notification_settings uq_notification_settings_user; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_settings
    ADD CONSTRAINT uq_notification_settings_user UNIQUE (user_id);


--
-- Name: student_progress_snapshots uq_progress_snapshot_student_classroom_date; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_progress_snapshots
    ADD CONSTRAINT uq_progress_snapshot_student_classroom_date UNIQUE (student_id, classroom_id, snapshot_date);


--
-- Name: quest_progress uq_quest_progress_user; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quest_progress
    ADD CONSTRAINT uq_quest_progress_user UNIQUE (user_id, quest_id);


--
-- Name: spaced_repetition_cards uq_sr_cards_user_motif; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spaced_repetition_cards
    ADD CONSTRAINT uq_sr_cards_user_motif UNIQUE (user_id, motif_id);


--
-- Name: streak_rewards uq_streak_rewards_user_streak_day; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.streak_rewards
    ADD CONSTRAINT uq_streak_rewards_user_streak_day UNIQUE (user_id, streak_day);


--
-- Name: user_badges uq_user_badges_user_badge; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT uq_user_badges_user_badge UNIQUE (user_id, badge_id);


--
-- Name: user_daily_missions uq_user_daily_mission; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_daily_missions
    ADD CONSTRAINT uq_user_daily_mission UNIQUE (user_id, mission_id, mission_date);


--
-- Name: user_experiment_assignments uq_user_experiment_assignment; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_experiment_assignments
    ADD CONSTRAINT uq_user_experiment_assignment UNIQUE (user_id, experiment_id);


--
-- Name: user_follows uq_user_follows; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_follows
    ADD CONSTRAINT uq_user_follows UNIQUE (follower_id, following_id);


--
-- Name: user_learning_paths uq_user_learning_path_user_date; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_learning_paths
    ADD CONSTRAINT uq_user_learning_path_user_date UNIQUE (user_id, path_date);


--
-- Name: user_milestones uq_user_milestones_user_type; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_milestones
    ADD CONSTRAINT uq_user_milestones_user_type UNIQUE (user_id, milestone_type);


--
-- Name: user_progress uq_user_progress_user_motif; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT uq_user_progress_user_motif UNIQUE (user_id, motif_id);


--
-- Name: user_skill_levels uq_user_skill; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_skill_levels
    ADD CONSTRAINT uq_user_skill UNIQUE (user_id, skill_type);


--
-- Name: user_weekly_quests uq_user_weekly_quest; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_weekly_quests
    ADD CONSTRAINT uq_user_weekly_quest UNIQUE (user_id, quest_id, week_start_date);


--
-- Name: urn_exam_attempts urn_exam_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.urn_exam_attempts
    ADD CONSTRAINT urn_exam_attempts_pkey PRIMARY KEY (id);


--
-- Name: urn_exams urn_exams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.urn_exams
    ADD CONSTRAINT urn_exams_pkey PRIMARY KEY (id);


--
-- Name: urns urns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.urns
    ADD CONSTRAINT urns_pkey PRIMARY KEY (id);


--
-- Name: urns urns_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.urns
    ADD CONSTRAINT urns_slug_key UNIQUE (slug);


--
-- Name: user_badges user_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_pkey PRIMARY KEY (id);


--
-- Name: user_content_interactions user_content_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_content_interactions
    ADD CONSTRAINT user_content_interactions_pkey PRIMARY KEY (id);


--
-- Name: user_daily_missions user_daily_missions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_daily_missions
    ADD CONSTRAINT user_daily_missions_pkey PRIMARY KEY (id);


--
-- Name: user_experiment_assignments user_experiment_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_experiment_assignments
    ADD CONSTRAINT user_experiment_assignments_pkey PRIMARY KEY (id);


--
-- Name: user_follows user_follows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_follows
    ADD CONSTRAINT user_follows_pkey PRIMARY KEY (id);


--
-- Name: user_hearts user_hearts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_hearts
    ADD CONSTRAINT user_hearts_pkey PRIMARY KEY (id);


--
-- Name: user_hearts user_hearts_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_hearts
    ADD CONSTRAINT user_hearts_user_id_key UNIQUE (user_id);


--
-- Name: user_leaderboard_settings user_leaderboard_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_leaderboard_settings
    ADD CONSTRAINT user_leaderboard_settings_pkey PRIMARY KEY (id);


--
-- Name: user_leaderboard_settings user_leaderboard_settings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_leaderboard_settings
    ADD CONSTRAINT user_leaderboard_settings_user_id_key UNIQUE (user_id);


--
-- Name: user_learning_paths user_learning_paths_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_learning_paths
    ADD CONSTRAINT user_learning_paths_pkey PRIMARY KEY (id);


--
-- Name: user_milestones user_milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_milestones
    ADD CONSTRAINT user_milestones_pkey PRIMARY KEY (id);


--
-- Name: user_notification_settings user_notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_settings
    ADD CONSTRAINT user_notification_settings_pkey PRIMARY KEY (id);


--
-- Name: user_progress user_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_session_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_id_key UNIQUE (session_id);


--
-- Name: user_shares user_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_shares
    ADD CONSTRAINT user_shares_pkey PRIMARY KEY (id);


--
-- Name: user_skill_levels user_skill_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_skill_levels
    ADD CONSTRAINT user_skill_levels_pkey PRIMARY KEY (id);


--
-- Name: user_weekly_quests user_weekly_quests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_weekly_quests
    ADD CONSTRAINT user_weekly_quests_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: weekly_quests weekly_quests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weekly_quests
    ADD CONSTRAINT weekly_quests_pkey PRIMARY KEY (id);


--
-- Name: weekly_quests weekly_quests_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weekly_quests
    ADD CONSTRAINT weekly_quests_slug_key UNIQUE (slug);


--
-- Name: idx_abuse_reports_assigned_to; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_abuse_reports_assigned_to ON public.abuse_reports USING btree (assigned_to_id);


--
-- Name: idx_abuse_reports_content_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_abuse_reports_content_type ON public.abuse_reports USING btree (content_type);


--
-- Name: idx_abuse_reports_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_abuse_reports_created_at ON public.abuse_reports USING btree (created_at);


--
-- Name: idx_abuse_reports_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_abuse_reports_priority ON public.abuse_reports USING btree (priority);


--
-- Name: idx_abuse_reports_reported_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_abuse_reports_reported_user ON public.abuse_reports USING btree (reported_user_id);


--
-- Name: idx_abuse_reports_reporter; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_abuse_reports_reporter ON public.abuse_reports USING btree (reporter_id);


--
-- Name: idx_abuse_reports_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_abuse_reports_status ON public.abuse_reports USING btree (status);


--
-- Name: idx_ai_conversation_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_conversation_active ON public.ai_conversations USING btree (is_active);


--
-- Name: idx_ai_conversation_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_conversation_context ON public.ai_conversations USING btree (context_type, context_id);


--
-- Name: idx_ai_conversation_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_conversation_created ON public.ai_conversations USING btree (created_at);


--
-- Name: idx_ai_conversation_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_conversation_user ON public.ai_conversations USING btree (user_id);


--
-- Name: idx_ai_jobs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_jobs_status ON public.ai_jobs USING btree (status);


--
-- Name: idx_ai_jobs_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_jobs_user ON public.ai_jobs USING btree (user_id);


--
-- Name: idx_ai_message_conversation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_message_conversation ON public.ai_messages USING btree (conversation_id);


--
-- Name: idx_ai_message_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_message_created ON public.ai_messages USING btree (created_at);


--
-- Name: idx_ai_message_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_message_role ON public.ai_messages USING btree (role);


--
-- Name: idx_analytics_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_category ON public.analytics_events USING btree (event_category);


--
-- Name: idx_analytics_cohort; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_cohort ON public.analytics_events USING btree (cohort);


--
-- Name: idx_analytics_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_created_at ON public.analytics_events USING btree (created_at);


--
-- Name: idx_analytics_event_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_event_name ON public.analytics_events USING btree (event_name);


--
-- Name: idx_analytics_session; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_session ON public.analytics_events USING btree (session_id);


--
-- Name: idx_analytics_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_user ON public.analytics_events USING btree (user_id);


--
-- Name: idx_app_versions_is_current; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_app_versions_is_current ON public.app_versions USING btree (is_current);


--
-- Name: idx_app_versions_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_app_versions_platform ON public.app_versions USING btree (platform);


--
-- Name: idx_app_versions_released_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_app_versions_released_at ON public.app_versions USING btree (released_at);


--
-- Name: idx_assignment_progress_assignment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignment_progress_assignment ON public.assignment_progress USING btree (assignment_id);


--
-- Name: idx_assignment_progress_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignment_progress_user ON public.assignment_progress USING btree (user_id);


--
-- Name: idx_assignments_class; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignments_class ON public.quest_assignments USING btree (class_id);


--
-- Name: idx_assignments_quest; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignments_quest ON public.quest_assignments USING btree (quest_id);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_resource; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_resource ON public.audit_logs USING btree (resource_type, resource_id);


--
-- Name: idx_audit_logs_resource_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_resource_type ON public.audit_logs USING btree (resource_type);


--
-- Name: idx_audit_logs_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_user ON public.audit_logs USING btree (user_id);


--
-- Name: idx_certificates_reason; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_certificates_reason ON public.certificates USING btree (reason_type, reason_id);


--
-- Name: idx_certificates_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_certificates_user ON public.certificates USING btree (user_id);


--
-- Name: idx_class_members_class; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_class_members_class ON public.class_members USING btree (class_id);


--
-- Name: idx_class_members_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_class_members_user ON public.class_members USING btree (user_id);


--
-- Name: idx_classes_class_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_classes_class_code ON public.classes USING btree (class_code);


--
-- Name: idx_classes_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_classes_created_at ON public.classes USING btree (created_at);


--
-- Name: idx_classes_teacher; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_classes_teacher ON public.classes USING btree (teacher_id);


--
-- Name: idx_content_flags_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_flags_type ON public.content_flags USING btree (content_type);


--
-- Name: idx_content_flags_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_flags_user ON public.content_flags USING btree (user_id);


--
-- Name: idx_content_provenance_content; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_provenance_content ON public.content_provenance USING btree (content_id);


--
-- Name: idx_content_provenance_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_provenance_type ON public.content_provenance USING btree (content_type);


--
-- Name: idx_content_tags_content; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_tags_content ON public.content_tags USING btree (content_type, content_id);


--
-- Name: idx_content_tags_content_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_tags_content_type ON public.content_tags USING btree (content_type);


--
-- Name: idx_content_tags_tag; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_tags_tag ON public.content_tags USING btree (tag_id);


--
-- Name: idx_content_versions_content; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_versions_content ON public.content_versions USING btree (content_id);


--
-- Name: idx_content_versions_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_versions_created ON public.content_versions USING btree (created_at);


--
-- Name: idx_content_versions_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_versions_type ON public.content_versions USING btree (content_type);


--
-- Name: idx_crash_reports_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_crash_reports_created_at ON public.crash_reports USING btree (created_at);


--
-- Name: idx_crash_reports_error_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_crash_reports_error_type ON public.crash_reports USING btree (error_type);


--
-- Name: idx_crash_reports_is_resolved; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_crash_reports_is_resolved ON public.crash_reports USING btree (is_resolved);


--
-- Name: idx_crash_reports_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_crash_reports_platform ON public.crash_reports USING btree (platform);


--
-- Name: idx_crash_reports_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_crash_reports_session_id ON public.crash_reports USING btree (session_id);


--
-- Name: idx_crash_reports_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_crash_reports_user_id ON public.crash_reports USING btree (user_id);


--
-- Name: idx_daily_missions_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_daily_missions_active ON public.daily_missions USING btree (is_active);


--
-- Name: idx_daily_missions_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_daily_missions_slug ON public.daily_missions USING btree (slug);


--
-- Name: idx_daily_missions_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_daily_missions_type ON public.daily_missions USING btree (mission_type);


--
-- Name: idx_email_templates_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_email_templates_active ON public.email_templates USING btree (is_active);


--
-- Name: idx_email_templates_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_email_templates_key ON public.email_templates USING btree (key);


--
-- Name: idx_embedding_jobs_created_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_embedding_jobs_created_by ON public.embedding_jobs USING btree (created_by_id);


--
-- Name: idx_embedding_jobs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_embedding_jobs_status ON public.embedding_jobs USING btree (status);


--
-- Name: idx_experiment_events_assignment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_experiment_events_assignment ON public.experiment_events USING btree (assignment_id);


--
-- Name: idx_experiment_events_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_experiment_events_created ON public.experiment_events USING btree (created_at);


--
-- Name: idx_experiment_events_experiment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_experiment_events_experiment ON public.experiment_events USING btree (experiment_id);


--
-- Name: idx_experiment_events_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_experiment_events_type ON public.experiment_events USING btree (event_type);


--
-- Name: idx_experiment_events_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_experiment_events_user ON public.experiment_events USING btree (user_id);


--
-- Name: idx_experiment_metric_events_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_experiment_metric_events_created ON public.experiment_metric_events USING btree (created_at);


--
-- Name: idx_experiment_metric_events_experiment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_experiment_metric_events_experiment ON public.experiment_metric_events USING btree (experiment_id);


--
-- Name: idx_experiment_metric_events_metric_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_experiment_metric_events_metric_name ON public.experiment_metric_events USING btree (metric_name);


--
-- Name: idx_experiment_metric_events_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_experiment_metric_events_user ON public.experiment_metric_events USING btree (user_id);


--
-- Name: idx_experiment_metric_events_variant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_experiment_metric_events_variant ON public.experiment_metric_events USING btree (variant);


--
-- Name: idx_experiments_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_experiments_active ON public.experiments USING btree (is_active);


--
-- Name: idx_experiments_created_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_experiments_created_by ON public.experiments USING btree (created_by_id);


--
-- Name: idx_experiments_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_experiments_key ON public.experiments USING btree (key);


--
-- Name: idx_feature_flags_created_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_flags_created_by ON public.feature_flags USING btree (created_by_id);


--
-- Name: idx_feature_flags_enabled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_flags_enabled ON public.feature_flags USING btree (is_enabled);


--
-- Name: idx_feature_flags_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_flags_key ON public.feature_flags USING btree (key);


--
-- Name: idx_friend_requests_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_friend_requests_created ON public.friend_requests USING btree (created_at);


--
-- Name: idx_friend_requests_from_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_friend_requests_from_user ON public.friend_requests USING btree (from_user_id);


--
-- Name: idx_friend_requests_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_friend_requests_status ON public.friend_requests USING btree (status);


--
-- Name: idx_friend_requests_to_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_friend_requests_to_user ON public.friend_requests USING btree (to_user_id);


--
-- Name: idx_guest_previews_converted_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_guest_previews_converted_user ON public.guest_previews USING btree (converted_to_user_id);


--
-- Name: idx_guest_previews_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_guest_previews_session_id ON public.guest_previews USING btree (session_id);


--
-- Name: idx_guest_previews_started_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_guest_previews_started_at ON public.guest_previews USING btree (started_at);


--
-- Name: idx_heart_transactions_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_heart_transactions_created ON public.heart_transactions USING btree (created_at);


--
-- Name: idx_heart_transactions_reason; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_heart_transactions_reason ON public.heart_transactions USING btree (reason);


--
-- Name: idx_heart_transactions_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_heart_transactions_user ON public.heart_transactions USING btree (user_id);


--
-- Name: idx_learning_path_completed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_learning_path_completed ON public.user_learning_paths USING btree (is_completed);


--
-- Name: idx_learning_path_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_learning_path_date ON public.user_learning_paths USING btree (path_date);


--
-- Name: idx_learning_path_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_learning_path_user ON public.user_learning_paths USING btree (user_id);


--
-- Name: idx_lesson_cache_cached_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lesson_cache_cached_at ON public.lesson_cache USING btree (cached_at);


--
-- Name: idx_lesson_cache_lesson; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lesson_cache_lesson ON public.lesson_cache USING btree (lesson_id);


--
-- Name: idx_lesson_cache_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lesson_cache_user ON public.lesson_cache USING btree (user_id);


--
-- Name: idx_lesson_content_rating; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lesson_content_rating ON public.lesson_content USING btree (content_rating);


--
-- Name: idx_lesson_prereq_lesson; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lesson_prereq_lesson ON public.lesson_prerequisites USING btree (lesson_id);


--
-- Name: idx_lesson_prereq_prerequisite; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lesson_prereq_prerequisite ON public.lesson_prerequisites USING btree (prerequisite_lesson_id);


--
-- Name: idx_motifs_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_motifs_category ON public.motifs USING btree (category);


--
-- Name: idx_motifs_content_rating; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_motifs_content_rating ON public.motifs USING btree (content_rating);


--
-- Name: idx_motifs_mesh; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_motifs_mesh ON public.motifs USING btree (mesh_name);


--
-- Name: idx_motifs_rarity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_motifs_rarity ON public.motifs USING btree (rarity);


--
-- Name: idx_motifs_urn; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_motifs_urn ON public.motifs USING btree (urn_id);


--
-- Name: idx_notification_settings_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_settings_user ON public.user_notification_settings USING btree (user_id);


--
-- Name: idx_progress_motif; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_progress_motif ON public.user_progress USING btree (motif_id);


--
-- Name: idx_progress_snapshots_classroom; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_progress_snapshots_classroom ON public.student_progress_snapshots USING btree (classroom_id);


--
-- Name: idx_progress_snapshots_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_progress_snapshots_date ON public.student_progress_snapshots USING btree (snapshot_date);


--
-- Name: idx_progress_snapshots_student; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_progress_snapshots_student ON public.student_progress_snapshots USING btree (student_id);


--
-- Name: idx_progress_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_progress_status ON public.user_progress USING btree (status);


--
-- Name: idx_progress_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_progress_user ON public.user_progress USING btree (user_id);


--
-- Name: idx_push_notifications_scheduled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_push_notifications_scheduled ON public.push_notifications USING btree (scheduled_for);


--
-- Name: idx_push_notifications_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_push_notifications_status ON public.push_notifications USING btree (status);


--
-- Name: idx_push_notifications_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_push_notifications_type ON public.push_notifications USING btree (notification_type);


--
-- Name: idx_push_notifications_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_push_notifications_user ON public.push_notifications USING btree (user_id);


--
-- Name: idx_push_notifications_user_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_push_notifications_user_created ON public.push_notifications USING btree (user_id, created_at);


--
-- Name: idx_quest_objectives_step; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quest_objectives_step ON public.quest_objectives USING btree (quest_step_id);


--
-- Name: idx_quest_objectives_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quest_objectives_type ON public.quest_objectives USING btree (objective_type);


--
-- Name: idx_quest_progress_quest; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quest_progress_quest ON public.quest_progress USING btree (quest_id);


--
-- Name: idx_quest_progress_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quest_progress_status ON public.quest_progress USING btree (status);


--
-- Name: idx_quest_progress_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quest_progress_user ON public.quest_progress USING btree (user_id);


--
-- Name: idx_quest_rewards_quest; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quest_rewards_quest ON public.quest_rewards USING btree (quest_id);


--
-- Name: idx_quest_rewards_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quest_rewards_type ON public.quest_rewards USING btree (reward_type);


--
-- Name: idx_quest_steps_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quest_steps_order ON public.quest_steps USING btree (display_order);


--
-- Name: idx_quest_steps_quest; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quest_steps_quest ON public.quest_steps USING btree (quest_id);


--
-- Name: idx_quests_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quests_active ON public.quests USING btree (is_active);


--
-- Name: idx_quests_content_rating; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quests_content_rating ON public.quests USING btree (content_rating);


--
-- Name: idx_quests_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quests_order ON public.quests USING btree (display_order);


--
-- Name: idx_quests_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quests_slug ON public.quests USING btree (slug);


--
-- Name: idx_quiz_attempts_motif; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quiz_attempts_motif ON public.quiz_attempts USING btree (motif_id);


--
-- Name: idx_quiz_attempts_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quiz_attempts_user ON public.quiz_attempts USING btree (user_id);


--
-- Name: idx_quiz_hints_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quiz_hints_created ON public.quiz_hint_requests USING btree (created_at);


--
-- Name: idx_quiz_hints_question; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quiz_hints_question ON public.quiz_hint_requests USING btree (question_id);


--
-- Name: idx_quiz_hints_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quiz_hints_user ON public.quiz_hint_requests USING btree (user_id);


--
-- Name: idx_quiz_q_motif; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quiz_q_motif ON public.quiz_questions USING btree (motif_id);


--
-- Name: idx_rag_documents_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_rag_documents_active ON public.rag_documents USING btree (is_active);


--
-- Name: idx_rag_documents_updated; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_rag_documents_updated ON public.rag_documents USING btree (updated_at);


--
-- Name: idx_recommendations_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recommendations_created ON public.recommendations USING btree (created_at);


--
-- Name: idx_recommendations_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recommendations_user ON public.recommendations USING btree (user_id);


--
-- Name: idx_scheduled_emails_scheduled_for; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scheduled_emails_scheduled_for ON public.scheduled_emails USING btree (scheduled_for);


--
-- Name: idx_scheduled_emails_sent_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scheduled_emails_sent_at ON public.scheduled_emails USING btree (sent_at);


--
-- Name: idx_scheduled_emails_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scheduled_emails_status ON public.scheduled_emails USING btree (status);


--
-- Name: idx_scheduled_emails_template; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scheduled_emails_template ON public.scheduled_emails USING btree (template_id);


--
-- Name: idx_scheduled_emails_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scheduled_emails_user ON public.scheduled_emails USING btree (user_id);


--
-- Name: idx_scheduled_emails_user_template; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scheduled_emails_user_template ON public.scheduled_emails USING btree (user_id, template_id);


--
-- Name: idx_sr_cards_motif; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sr_cards_motif ON public.spaced_repetition_cards USING btree (motif_id);


--
-- Name: idx_sr_cards_next_review; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sr_cards_next_review ON public.spaced_repetition_cards USING btree (next_review_at);


--
-- Name: idx_sr_cards_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sr_cards_user ON public.spaced_repetition_cards USING btree (user_id);


--
-- Name: idx_sr_cards_user_next_review; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sr_cards_user_next_review ON public.spaced_repetition_cards USING btree (user_id, next_review_at);


--
-- Name: idx_streak_rewards_streak_day; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_streak_rewards_streak_day ON public.streak_rewards USING btree (streak_day);


--
-- Name: idx_streak_rewards_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_streak_rewards_user ON public.streak_rewards USING btree (user_id);


--
-- Name: idx_tags_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tags_active ON public.tags USING btree (is_active);


--
-- Name: idx_tags_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tags_slug ON public.tags USING btree (slug);


--
-- Name: idx_tags_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tags_type ON public.tags USING btree (tag_type);


--
-- Name: idx_urn_exam_attempts_exam; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_urn_exam_attempts_exam ON public.urn_exam_attempts USING btree (urn_exam_id);


--
-- Name: idx_urn_exam_attempts_passed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_urn_exam_attempts_passed ON public.urn_exam_attempts USING btree (passed);


--
-- Name: idx_urn_exam_attempts_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_urn_exam_attempts_user ON public.urn_exam_attempts USING btree (user_id);


--
-- Name: idx_urn_exams_urn; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_urn_exams_urn ON public.urn_exams USING btree (urn_id);


--
-- Name: idx_user_badges_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_badges_user ON public.user_badges USING btree (user_id);


--
-- Name: idx_user_content_interactions_content; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_content_interactions_content ON public.user_content_interactions USING btree (content_type, content_id);


--
-- Name: idx_user_content_interactions_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_content_interactions_created ON public.user_content_interactions USING btree (created_at);


--
-- Name: idx_user_content_interactions_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_content_interactions_type ON public.user_content_interactions USING btree (interaction_type);


--
-- Name: idx_user_content_interactions_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_content_interactions_user ON public.user_content_interactions USING btree (user_id);


--
-- Name: idx_user_content_interactions_user_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_content_interactions_user_type ON public.user_content_interactions USING btree (user_id, content_type);


--
-- Name: idx_user_daily_missions_completed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_daily_missions_completed ON public.user_daily_missions USING btree (is_completed);


--
-- Name: idx_user_daily_missions_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_daily_missions_date ON public.user_daily_missions USING btree (mission_date);


--
-- Name: idx_user_daily_missions_mission; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_daily_missions_mission ON public.user_daily_missions USING btree (mission_id);


--
-- Name: idx_user_daily_missions_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_daily_missions_user ON public.user_daily_missions USING btree (user_id);


--
-- Name: idx_user_experiment_assignments_experiment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_experiment_assignments_experiment ON public.user_experiment_assignments USING btree (experiment_id);


--
-- Name: idx_user_experiment_assignments_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_experiment_assignments_user ON public.user_experiment_assignments USING btree (user_id);


--
-- Name: idx_user_follows_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_follows_created ON public.user_follows USING btree (created_at);


--
-- Name: idx_user_follows_follower; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_follows_follower ON public.user_follows USING btree (follower_id);


--
-- Name: idx_user_follows_following; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_follows_following ON public.user_follows USING btree (following_id);


--
-- Name: idx_user_hearts_refill; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_hearts_refill ON public.user_hearts USING btree (hearts_refill_at);


--
-- Name: idx_user_hearts_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_hearts_user ON public.user_hearts USING btree (user_id);


--
-- Name: idx_user_leaderboard_settings_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_leaderboard_settings_user ON public.user_leaderboard_settings USING btree (user_id);


--
-- Name: idx_user_milestones_celebrated; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_milestones_celebrated ON public.user_milestones USING btree (celebrated);


--
-- Name: idx_user_milestones_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_milestones_type ON public.user_milestones USING btree (milestone_type);


--
-- Name: idx_user_milestones_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_milestones_user ON public.user_milestones USING btree (user_id);


--
-- Name: idx_user_sessions_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sessions_is_active ON public.user_sessions USING btree (is_active);


--
-- Name: idx_user_sessions_last_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sessions_last_active ON public.user_sessions USING btree (last_active_at);


--
-- Name: idx_user_sessions_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sessions_session_id ON public.user_sessions USING btree (session_id);


--
-- Name: idx_user_sessions_started_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sessions_started_at ON public.user_sessions USING btree (started_at);


--
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: idx_user_shares_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_shares_created ON public.user_shares USING btree (created_at);


--
-- Name: idx_user_shares_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_shares_type ON public.user_shares USING btree (share_type);


--
-- Name: idx_user_shares_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_shares_user ON public.user_shares USING btree (user_id);


--
-- Name: idx_user_shares_visibility; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_shares_visibility ON public.user_shares USING btree (visibility);


--
-- Name: idx_user_skill_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_skill_type ON public.user_skill_levels USING btree (skill_type);


--
-- Name: idx_user_skill_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_skill_user ON public.user_skill_levels USING btree (user_id);


--
-- Name: idx_user_weekly_quests_completed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_weekly_quests_completed ON public.user_weekly_quests USING btree (is_completed);


--
-- Name: idx_user_weekly_quests_quest; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_weekly_quests_quest ON public.user_weekly_quests USING btree (quest_id);


--
-- Name: idx_user_weekly_quests_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_weekly_quests_user ON public.user_weekly_quests USING btree (user_id);


--
-- Name: idx_user_weekly_quests_week; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_weekly_quests_week ON public.user_weekly_quests USING btree (week_start_date);


--
-- Name: idx_users_age_verified; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_age_verified ON public.users USING btree (age_verified);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_starting_urn; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_starting_urn ON public.users USING btree (starting_urn_id);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_weekly_quests_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_weekly_quests_active ON public.weekly_quests USING btree (is_active);


--
-- Name: idx_weekly_quests_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_weekly_quests_category ON public.weekly_quests USING btree (category);


--
-- Name: idx_weekly_quests_recurring; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_weekly_quests_recurring ON public.weekly_quests USING btree (is_recurring);


--
-- Name: idx_weekly_quests_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_weekly_quests_slug ON public.weekly_quests USING btree (slug);


--
-- Name: idx_weekly_quests_week_year; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_weekly_quests_week_year ON public.weekly_quests USING btree (week_number, year);


--
-- Name: ix_guest_previews_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_guest_previews_session_id ON public.guest_previews USING btree (session_id);


--
-- Name: abuse_reports abuse_reports_assigned_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.abuse_reports
    ADD CONSTRAINT abuse_reports_assigned_to_id_fkey FOREIGN KEY (assigned_to_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: abuse_reports abuse_reports_reported_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.abuse_reports
    ADD CONSTRAINT abuse_reports_reported_user_id_fkey FOREIGN KEY (reported_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: abuse_reports abuse_reports_reporter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.abuse_reports
    ADD CONSTRAINT abuse_reports_reporter_id_fkey FOREIGN KEY (reporter_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_conversations ai_conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_conversations
    ADD CONSTRAINT ai_conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_jobs ai_jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_jobs
    ADD CONSTRAINT ai_jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_messages ai_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_messages
    ADD CONSTRAINT ai_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.ai_conversations(id) ON DELETE CASCADE;


--
-- Name: analytics_events analytics_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT analytics_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: assignment_progress assignment_progress_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignment_progress
    ADD CONSTRAINT assignment_progress_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.quest_assignments(id) ON DELETE CASCADE;


--
-- Name: assignment_progress assignment_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignment_progress
    ADD CONSTRAINT assignment_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: class_members class_members_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_members
    ADD CONSTRAINT class_members_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: class_members class_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_members
    ADD CONSTRAINT class_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: classes classes_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: content_flags content_flags_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_flags
    ADD CONSTRAINT content_flags_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: embedding_jobs embedding_jobs_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embedding_jobs
    ADD CONSTRAINT embedding_jobs_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: experiment_events experiment_events_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiment_events
    ADD CONSTRAINT experiment_events_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.user_experiment_assignments(id) ON DELETE CASCADE;


--
-- Name: experiment_events experiment_events_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiment_events
    ADD CONSTRAINT experiment_events_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiments(id) ON DELETE CASCADE;


--
-- Name: experiment_events experiment_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiment_events
    ADD CONSTRAINT experiment_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: experiment_metric_events experiment_metric_events_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiment_metric_events
    ADD CONSTRAINT experiment_metric_events_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiments(id) ON DELETE CASCADE;


--
-- Name: experiment_metric_events experiment_metric_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiment_metric_events
    ADD CONSTRAINT experiment_metric_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: audit_logs fk_audit_logs_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT fk_audit_logs_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: content_tags fk_content_tags_tag; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_tags
    ADD CONSTRAINT fk_content_tags_tag FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: content_versions fk_content_versions_editor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_versions
    ADD CONSTRAINT fk_content_versions_editor FOREIGN KEY (editor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: crash_reports fk_crash_reports_resolved_by; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crash_reports
    ADD CONSTRAINT fk_crash_reports_resolved_by FOREIGN KEY (resolved_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: crash_reports fk_crash_reports_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crash_reports
    ADD CONSTRAINT fk_crash_reports_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: experiments fk_experiments_created_by_id_users; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT fk_experiments_created_by_id_users FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: feature_flags fk_feature_flags_created_by_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT fk_feature_flags_created_by_id FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: lesson_content fk_lesson_content_last_editor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_content
    ADD CONSTRAINT fk_lesson_content_last_editor FOREIGN KEY (last_editor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: lesson_content fk_lesson_content_reviewed_by; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_content
    ADD CONSTRAINT fk_lesson_content_reviewed_by FOREIGN KEY (reviewed_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: quiz_questions fk_quiz_questions_created_by; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_questions
    ADD CONSTRAINT fk_quiz_questions_created_by FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: quiz_questions fk_quiz_questions_reviewed_by; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_questions
    ADD CONSTRAINT fk_quiz_questions_reviewed_by FOREIGN KEY (reviewed_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: streak_rewards fk_streak_rewards_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.streak_rewards
    ADD CONSTRAINT fk_streak_rewards_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: friend_requests friend_requests_from_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friend_requests
    ADD CONSTRAINT friend_requests_from_user_id_fkey FOREIGN KEY (from_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: friend_requests friend_requests_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friend_requests
    ADD CONSTRAINT friend_requests_to_user_id_fkey FOREIGN KEY (to_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: guest_previews guest_previews_converted_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guest_previews
    ADD CONSTRAINT guest_previews_converted_to_user_id_fkey FOREIGN KEY (converted_to_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: guest_previews guest_previews_preview_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guest_previews
    ADD CONSTRAINT guest_previews_preview_lesson_id_fkey FOREIGN KEY (preview_lesson_id) REFERENCES public.lesson_content(id) ON DELETE SET NULL;


--
-- Name: heart_transactions heart_transactions_user_hearts_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.heart_transactions
    ADD CONSTRAINT heart_transactions_user_hearts_id_fkey FOREIGN KEY (user_hearts_id) REFERENCES public.user_hearts(id) ON DELETE CASCADE;


--
-- Name: heart_transactions heart_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.heart_transactions
    ADD CONSTRAINT heart_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: lesson_cache lesson_cache_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_cache
    ADD CONSTRAINT lesson_cache_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lesson_content(id) ON DELETE CASCADE;


--
-- Name: lesson_cache lesson_cache_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_cache
    ADD CONSTRAINT lesson_cache_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: lesson_content lesson_content_motif_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_content
    ADD CONSTRAINT lesson_content_motif_id_fkey FOREIGN KEY (motif_id) REFERENCES public.motifs(id) ON DELETE CASCADE;


--
-- Name: lesson_prerequisites lesson_prerequisites_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_prerequisites
    ADD CONSTRAINT lesson_prerequisites_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lesson_content(id) ON DELETE CASCADE;


--
-- Name: lesson_prerequisites lesson_prerequisites_prerequisite_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_prerequisites
    ADD CONSTRAINT lesson_prerequisites_prerequisite_lesson_id_fkey FOREIGN KEY (prerequisite_lesson_id) REFERENCES public.lesson_content(id) ON DELETE CASCADE;


--
-- Name: motifs motifs_urn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motifs
    ADD CONSTRAINT motifs_urn_id_fkey FOREIGN KEY (urn_id) REFERENCES public.urns(id) ON DELETE CASCADE;


--
-- Name: push_notifications push_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_notifications
    ADD CONSTRAINT push_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: quest_assignments quest_assignments_assigned_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quest_assignments
    ADD CONSTRAINT quest_assignments_assigned_by_id_fkey FOREIGN KEY (assigned_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: quest_assignments quest_assignments_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quest_assignments
    ADD CONSTRAINT quest_assignments_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: quest_assignments quest_assignments_quest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quest_assignments
    ADD CONSTRAINT quest_assignments_quest_id_fkey FOREIGN KEY (quest_id) REFERENCES public.quests(id) ON DELETE CASCADE;


--
-- Name: quest_objectives quest_objectives_quest_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quest_objectives
    ADD CONSTRAINT quest_objectives_quest_step_id_fkey FOREIGN KEY (quest_step_id) REFERENCES public.quest_steps(id) ON DELETE CASCADE;


--
-- Name: quest_progress quest_progress_quest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quest_progress
    ADD CONSTRAINT quest_progress_quest_id_fkey FOREIGN KEY (quest_id) REFERENCES public.quests(id) ON DELETE CASCADE;


--
-- Name: quest_progress quest_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quest_progress
    ADD CONSTRAINT quest_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: quest_rewards quest_rewards_quest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quest_rewards
    ADD CONSTRAINT quest_rewards_quest_id_fkey FOREIGN KEY (quest_id) REFERENCES public.quests(id) ON DELETE CASCADE;


--
-- Name: quest_steps quest_steps_quest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quest_steps
    ADD CONSTRAINT quest_steps_quest_id_fkey FOREIGN KEY (quest_id) REFERENCES public.quests(id) ON DELETE CASCADE;


--
-- Name: quests quests_prerequisite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quests
    ADD CONSTRAINT quests_prerequisite_id_fkey FOREIGN KEY (prerequisite_id) REFERENCES public.quests(id) ON DELETE SET NULL;


--
-- Name: quiz_attempts quiz_attempts_motif_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempts
    ADD CONSTRAINT quiz_attempts_motif_id_fkey FOREIGN KEY (motif_id) REFERENCES public.motifs(id) ON DELETE CASCADE;


--
-- Name: quiz_attempts quiz_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempts
    ADD CONSTRAINT quiz_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: quiz_hint_requests quiz_hint_requests_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_hint_requests
    ADD CONSTRAINT quiz_hint_requests_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.quiz_questions(id) ON DELETE CASCADE;


--
-- Name: quiz_hint_requests quiz_hint_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_hint_requests
    ADD CONSTRAINT quiz_hint_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: quiz_questions quiz_questions_motif_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_questions
    ADD CONSTRAINT quiz_questions_motif_id_fkey FOREIGN KEY (motif_id) REFERENCES public.motifs(id) ON DELETE CASCADE;


--
-- Name: quiz_questions quiz_questions_urn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_questions
    ADD CONSTRAINT quiz_questions_urn_id_fkey FOREIGN KEY (urn_id) REFERENCES public.urns(id) ON DELETE CASCADE;


--
-- Name: recommendations recommendations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: scheduled_emails scheduled_emails_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_emails
    ADD CONSTRAINT scheduled_emails_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.email_templates(id) ON DELETE CASCADE;


--
-- Name: scheduled_emails scheduled_emails_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_emails
    ADD CONSTRAINT scheduled_emails_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: spaced_repetition_cards spaced_repetition_cards_motif_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spaced_repetition_cards
    ADD CONSTRAINT spaced_repetition_cards_motif_id_fkey FOREIGN KEY (motif_id) REFERENCES public.motifs(id) ON DELETE CASCADE;


--
-- Name: spaced_repetition_cards spaced_repetition_cards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spaced_repetition_cards
    ADD CONSTRAINT spaced_repetition_cards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: student_progress_snapshots student_progress_snapshots_classroom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_progress_snapshots
    ADD CONSTRAINT student_progress_snapshots_classroom_id_fkey FOREIGN KEY (classroom_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: student_progress_snapshots student_progress_snapshots_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_progress_snapshots
    ADD CONSTRAINT student_progress_snapshots_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: urn_exam_attempts urn_exam_attempts_urn_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.urn_exam_attempts
    ADD CONSTRAINT urn_exam_attempts_urn_exam_id_fkey FOREIGN KEY (urn_exam_id) REFERENCES public.urn_exams(id) ON DELETE CASCADE;


--
-- Name: urn_exam_attempts urn_exam_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.urn_exam_attempts
    ADD CONSTRAINT urn_exam_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: urn_exams urn_exams_urn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.urn_exams
    ADD CONSTRAINT urn_exams_urn_id_fkey FOREIGN KEY (urn_id) REFERENCES public.urns(id) ON DELETE CASCADE;


--
-- Name: user_badges user_badges_badge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_badge_id_fkey FOREIGN KEY (badge_id) REFERENCES public.badges(id) ON DELETE CASCADE;


--
-- Name: user_badges user_badges_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_content_interactions user_content_interactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_content_interactions
    ADD CONSTRAINT user_content_interactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_daily_missions user_daily_missions_mission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_daily_missions
    ADD CONSTRAINT user_daily_missions_mission_id_fkey FOREIGN KEY (mission_id) REFERENCES public.daily_missions(id) ON DELETE CASCADE;


--
-- Name: user_daily_missions user_daily_missions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_daily_missions
    ADD CONSTRAINT user_daily_missions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_experiment_assignments user_experiment_assignments_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_experiment_assignments
    ADD CONSTRAINT user_experiment_assignments_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiments(id) ON DELETE CASCADE;


--
-- Name: user_experiment_assignments user_experiment_assignments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_experiment_assignments
    ADD CONSTRAINT user_experiment_assignments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_follows user_follows_follower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_follows
    ADD CONSTRAINT user_follows_follower_id_fkey FOREIGN KEY (follower_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_follows user_follows_following_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_follows
    ADD CONSTRAINT user_follows_following_id_fkey FOREIGN KEY (following_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_hearts user_hearts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_hearts
    ADD CONSTRAINT user_hearts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_leaderboard_settings user_leaderboard_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_leaderboard_settings
    ADD CONSTRAINT user_leaderboard_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_learning_paths user_learning_paths_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_learning_paths
    ADD CONSTRAINT user_learning_paths_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_milestones user_milestones_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_milestones
    ADD CONSTRAINT user_milestones_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_notification_settings user_notification_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_settings
    ADD CONSTRAINT user_notification_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_progress user_progress_motif_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_motif_id_fkey FOREIGN KEY (motif_id) REFERENCES public.motifs(id) ON DELETE CASCADE;


--
-- Name: user_progress user_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_shares user_shares_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_shares
    ADD CONSTRAINT user_shares_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_skill_levels user_skill_levels_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_skill_levels
    ADD CONSTRAINT user_skill_levels_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_weekly_quests user_weekly_quests_quest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_weekly_quests
    ADD CONSTRAINT user_weekly_quests_quest_id_fkey FOREIGN KEY (quest_id) REFERENCES public.weekly_quests(id) ON DELETE CASCADE;


--
-- Name: user_weekly_quests user_weekly_quests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_weekly_quests
    ADD CONSTRAINT user_weekly_quests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_starting_urn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_starting_urn_id_fkey FOREIGN KEY (starting_urn_id) REFERENCES public.urns(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict Dva2pG47iBmJohczRRKnaooagqQNuz1vn6d7oe9QiEbjUzScxzu88B4co0diJsG

